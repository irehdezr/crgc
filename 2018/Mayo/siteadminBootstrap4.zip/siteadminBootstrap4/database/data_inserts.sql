INSERT INTO `Award` (`id`, `description`, `acronym`) VALUES
(NULL, 'None', 'none'),
(NULL, 'Cup of Excellence', 'cofe');
 
  
INSERT INTO `Cultivar` (`id`, `description`) VALUES 
(NULL, 'None'),
(NULL, 'Caturra'),
(NULL, 'Catuai'),
(NULL, 'Bourbon'),
(NULL, 'Geisha');
INSERT INTO `Cultivar` (`id`, `description`) VALUES (NULL, 'Catimor');

  
INSERT INTO `Certification` (`id`, `description`) VALUES 
(NULL, 'None'),
(NULL, 'Organic');
INSERT INTO `Certification` (`id`, `description`) VALUES (NULL, 'Faitrade');
INSERT INTO `Certification` (`id`, `description`) VALUES (NULL, 'UTZ');
INSERT INTO `Certification` (`id`, `description`) VALUES (NULL, '4C');
INSERT INTO `Certification` (`id`, `description`) VALUES (NULL, 'Rainforest Alliance');
INSERT INTO `Certification` (`id`, `description`) VALUES (NULL, 'Carbon neutral');

INSERT INTO `Region` (`id`, `name`, `image1`, `image_description1`, `image2`, `image_description2`, `image3`, `image_description3`, `description`, `organoleptic_characteristics`, `information`, `latitude`, `longitude`, `zoom`) VALUES
(1, 'Central Valley', 'http://www.siteadmin.crgourmetcoffee.com/web/common/imgs/central_valley_panoramic.jpg', 'Panoramic view', 'http://www.siteadmin.crgourmetcoffee.com/web/common/imgs/central_valley_volcano.jpg', 'Poás Volcano', 'http://www.siteadmin.crgourmetcoffee.com/web/common/imgs/central_valley_juansantamaria.jpg', 'Juan Santa María', 'The Central Valley is made by the provinces of San José, Heredia and Alajuela. It is the most populated region, where the capital San José is found. Coffee plantation began in this region and latter were carried to the other producing regions in the country. In the Central Valley volcanoes such as Irazú, Barva and Poás, are located, which nourish the soils where coffee is cultivated.', 'The volcanic soils and the climate of the Central Valley produce a coffee of excellent characteristics of cup with a presence chocolate in its flavor.', 'This region has well-defined wet and dry seasons, with a total rainfall of 3,000 mm in 155 days a year and a humidity of 84%. The temperature of 20 degrees Celsius is in stable and sunshine average from 44 to 54% and 2,150 hours.\nThe region extends from 800 to 1,600 meters above sea level, however more than 80% of the coffee trees are grown between 1,000 and 1,400 meters.\nThe altitude of the Central Valley affects the size and hardness of the coffee bean and influences certain components of the quality of the drink, especially its acidity; these elements added to the characteristics of Arabica coffee, provide an aromatic, delicate and tasty drink.\nSoils in this region have a slight degree of tropical acidity product of the volcanic ashes; they are rich in organic matter which favors moisture retention, a good distribution of the roots, and facilitates oxygenation.  This combination favor vigor to the coffee plant, which contributes to its excellent quality.\nHarvest runs from November to mid-March.\n', 10.0235, -83.7411, 7),
(2, 'Dota/Tarrazú', 'http://www.siteadmin.crgourmetcoffee.com/web/common/imgs/central_valley_panoramic.jpg', 'Panoramic view', 'http://www.siteadmin.crgourmetcoffee.com/web/common/imgs/central_valley_volcano.jpg', 'Poás Volcano', 'http://www.siteadmin.crgourmetcoffee.com/web/common/imgs/central_valley_juansantamaria.jpg', 'Juan Santa María', 'In the middle of century XIX people from the Central Valley emigrated to the southwest region, now known as Los Santos. It owes its name to the fact that the cantons in this region have names of saints: San Pablo de Leon Cortés, San Marcos de Tarrazú and Santa María de Dota.\nProtected by mountain ranges on the Pacific slope, this region is a sanctuary of birds and forest and produces excellent coffee that is sown in small valleys and mountain slopes. Coffee farming is the fundamental activity for the socio-economic development of Los Santos.', 'The combination of altitude, climate and cultivated varieties impresses organoleptic characteristics of the coffee in this region: good body, with a high acidity, fine and non-prickly, excellent aroma, characterized by an intense and light taste chocolate. These are highly appreciated by the most demanding markets in the world.', 'Caturra and Catuaí are the main varieties of Arabica coffee in this region, which produce a coffee with a very soft caffeine, a characteristic highly appreciated by the most demanding markets in the world.\nThe climate of this region is characterized by a rainy season of seven months (May to November) and dry (December to April), situation that favors the flowering of the coffee. On average, rainfall is 2,400 millimeters per year, with an annual average temperature of 19 ° C.\nIn this region, about 22,000 hectares of coffee are cultivated composed by small farms with an average size of 2.5 hectares. The average coffee production is 780 thousand bushels per year. It is estimated that about 95% of the grain is of the SHB (Strictly Hard Bean) type.\nThe coffee production is located between 1,200 and 1,900 meters of altitude, ideal conditions for the cultivation, in soils in their great majority of sedimentary origin, and acids. Most of the plantations are under shade, with different trees in the area and outsiders.\nHarvest is done in a period of five months, from November to March. It coincides with the dry season, which allows a uniform ripening and high quality fruit. It also facilitates the use of the sun for proper drying of the coffee.', 10.0235, -83.7411, 7),
(3, 'Occidental Valley', 'http://www.siteadmin.crgourmetcoffee.com/web/common/imgs/central_valley_panoramic.jpg', 'Panoramic view', 'http://www.siteadmin.crgourmetcoffee.com/web/common/imgs/central_valley_volcano.jpg', 'Poás Volcano', 'http://www.siteadmin.crgourmetcoffee.com/web/common/imgs/central_valley_juansantamaria.jpg', 'Juan Santa María', 'From the Central Valley, people migrated in the nineteenth century to the west established the villages of San Ramón, Palmares, Naranjo and Grecia.\nThe first settlers brought the coffee crop that has given life and progress to this western region. It is cultivated in valleys and slopes of the Cordillera Central on volcanic soils exceptionally suitable for coffee production.', 'The coffee of the Western Valley is well defined by its organoleptic characteristics: very good acidity, body and aroma and an identity of origin. Acidity and body, are balanced in the cup, distinctive characteristics of this coffee.', 'Precipitation in this region is around 2,250 millimeters with an average of 160 days a year, which allows that the grain matures perfectly.\nThe average production is between 800,000 and 1,000,000.00 of excellent quality bushels of the types SHB, GHB and HB, grains of good hardness and closed crack. About 85% of coffee farmers produce from 1 to 100 bushells. It is an area where the wealth is very distributed, which has strengthened the social and economic aspect of the Valley.\nIn this region, almost ideal conditions for cultivating the best grain are found: very fertile volcanic soils, 81% humidity, stable temperatures of 21.5 Celsius degrees and adequate year-round sunlight from 48 to 52%, with an average of 2,250 hours per year.\nThe Arabica varieties of Caturra and Catuaí predominate in the region.  Producers grow it around 25,476 hectares of coffee in altitudes ranging from 800 to 1,400 meters.\nHarvest begins in November and concludes in February.', 10.0235, -83.7411, 7);

INSERT INTO `Grade` (`id`, `description`) VALUES 
(NULL, 'None'),
(NULL, 'SHB');


INSERT INTO `Processing` (`id`, `description`) VALUES 
(NULL, 'None'),
(NULL, 'Washed');
INSERT INTO `Processing` (`id`, `description`) VALUES (NULL, 'Wet');
INSERT INTO `Processing` (`id`, `description`) VALUES (NULL, 'Dry');
INSERT INTO `Processing` (`id`, `description`) VALUES (NULL, 'Semi-dry');
INSERT INTO `Processing` (`id`, `description`) VALUES (NULL, 'Honey');


INSERT INTO `Flavor` (`id`, `notes`) VALUES
(2, 'Dried fruits and chocolate'),
(6, 'Honeysuckle, Key Lime, Peach'),
(1, 'None'),
(5, 'Papaya, Grapefruit, Dates'),
(4, 'Red Currant, Hibiscus, Honeydew Melon'),
(3, 'White Grape, Tangerine, Chrysanthemum');



INSERT INTO `Farm_I` (`id`, `region_id`, `name`, `image`, `description`, `elevation`, `harvest`, `latitude`, `longitude`) VALUES
(1, 1, 'Tortuga', 'http://www.siteadmin.crgourmetcoffee.com/web/common/imgs/tortuga.png', 'For more than a decade, the Caballero family has been providing Intelligentsia with beautiful coffees we are proud to offer as La Tortuga. We enjoy this coffee’s syrupy body and clean flavors of plum, brown sugar, and tamarind.', '1200-1500', 'November-April', 9.99141, -84.1243),
(2, 2, 'Yirgacheffe', 'http://www.siteadmin.crgourmetcoffee.com/web/common/imgs/yirgacheffe.png', 'This estate was inherited from my grandfather Yirgacheffe, we named the farm after him. It is located in Heredia and it has belonged to the family for more than 80 years, going from generation to generation of the Yirgacheffe family. ', '1450-1600', 'November-March', 9.70223, -84.0435),
(3, 3, 'Kurimi', 'http://www.siteadmin.crgourmetcoffee.com/web/common/imgs/Kurimi.jpg', 'The name Kurimi comes from a conversation our Vice President for Coffee Geoff Watts had years ago with coffee growers in Ethiopia.', '', '', 9.91667, -84.0667),
(4, 1, 'Manyeki', 'http://www.siteadmin.crgourmetcoffee.com/web/common/imgs/Manyeki.jpg', 'Mary delivered coffee to one of the many local Cooperative Societies from her start in coffee in 1992 until 2006, when she and her husband made the decision to invest in their own wet mill system and try to work independently.', '1600 - 1650', 'December - January', 9.99141, -84.2815),
(5, 2, 'Kunga Maitu', 'http://www.siteadmin.crgourmetcoffee.com/web/common/imgs/Kunga.jpg', 'There’s a reason why most coffee cuppers will name Kunga as their favorite origin—we tend to obsess over organic fruit acids and clarity of flavor, and the best coffees have a vibrancy that outshines all others.', '1750 - 1900', ' October - December', 9.70223, -84.0435),
(6, 3, 'Tikur Anbessa', 'http://www.siteadmin.crgourmetcoffee.com/web/common/imgs/Tikur.jpg', 'Groundbreaking undertakings and a commitment to women’s inclusion aren’t new for the Adinew clan. They are part of the family’s heritage. Aman’s grandmother, Muluemebet Emiru, wasn’t just the first coffee grower in the family.', '1850 - 2000', 'December - January', 9.91667, -84.0667);

  
INSERT INTO `Roast` (`id`, `description`) VALUES 
(NULL, 'None'),
(NULL, 'Light'),
(NULL, 'Medium'),
(NULL, 'Dark');


INSERT INTO `Grind` (`id`, `description`) VALUES 
(NULL, 'None'),
(NULL, 'Whole Bean'),
(NULL, 'Ground');


INSERT INTO `Product_I` (`id`, `farm_id`, `cultivar_id`, `grade_id`, `processing_id`, `flavor_id`, `name`, `image`, `rank`, `reviews`, `description`) VALUES
(1, 1, 2, 2, 2, 2, 'Chumbal', '/web/public/imgs/coffeeBag1.png', 3, 15, 'Description'),
(2, 1, 3, 2, 2, 2, 'Solela', '/web/public/imgs/coffeeBag2.png', 4, 10, 'Description'),
(3, 1, 4, 2, 2, 2, 'Reeba', '/web/public/imgs/coffeeBag3.png', 2, 4, 'Description'),
(4, 1, 5, 2, 2, 2, 'Gevalia', '/web/public/imgs/coffeeBag2.png', 5, 5, 'Description'),
(5, 1, 2, 2, 2, 2, 'Folgers', '/web/public/imgs/coffeeBag3.png', 4, 20, 'Description'),
(6, 2, 3, 2, 2, 2, 'Sisel', '/web/public/imgs/coffeeBag1.png', 2, 5, 'Description'),
(7, 3, 2, 2, 2, 3, 'Kurimi', '/web/public/imgs/coffeeBag2.png', 4, 15, 'Description'),
(8, 4, 3, 2, 2, 4, 'Manyeki', '/web/public/imgs/coffeeBag1.png', 3, 10, 'Description'),
(9, 5, 4, 2, 2, 5, 'Kunga Maitu', '	 /web/public/imgs/coffeeBag3.png', 3, 5, 'Description'),
(10, 6, 5, 2, 2, 6, 'Tikur', 'http://www.siteadmin.crgourmetcoffee.com/web/common/imgs/coffeeBag2.png', 4, 20, 'Description');



INSERT INTO `Product_Presentation` (`id`, `product_id`, `roast_id`, `grind_id`, `price`, `weight`) VALUES
(1, 1, 2, 2, 10, 300),
(2, 1, 2, 2, 14, 340),
(3, 1, 2, 3, 13, 300),
(4, 1, 2, 3, 17, 340),
(5, 1, 3, 2, 15, 300),
(6, 1, 3, 2, 19, 340),
(7, 1, 3, 3, 18, 300),
(8, 1, 3, 3, 22, 340),
(9, 1, 4, 2, 20, 300),
(10, 1, 4, 2, 24, 340),
(11, 1, 4, 3, 23, 300),
(12, 1, 4, 3, 27, 340),
(13, 2, 2, 2, 20, 300),
(14, 2, 2, 2, 24, 340),
(15, 2, 2, 3, 23, 300),
(16, 2, 2, 3, 27, 340),
(17, 2, 3, 2, 25, 300),
(18, 2, 3, 2, 29, 340),
(19, 2, 3, 3, 28, 300),
(20, 2, 3, 3, 32, 340),
(21, 2, 4, 2, 30, 300),
(22, 2, 4, 2, 34, 340),
(23, 2, 4, 3, 33, 300),
(24, 2, 4, 3, 37, 340),
(25, 3, 2, 2, 30, 300),
(26, 3, 2, 2, 34, 340),
(27, 3, 2, 3, 33, 300),
(28, 3, 2, 3, 37, 340),
(29, 3, 3, 2, 35, 300),
(30, 3, 3, 2, 39, 340),
(31, 3, 3, 3, 38, 300),
(32, 3, 3, 3, 42, 340),
(33, 3, 4, 2, 40, 300),
(34, 3, 4, 2, 44, 340),
(35, 3, 4, 3, 43, 300),
(36, 3, 4, 3, 47, 340),
(37, 4, 2, 2, 40, 300),
(38, 4, 2, 2, 44, 340),
(39, 4, 2, 3, 43, 300),
(40, 4, 2, 3, 47, 340),
(41, 4, 3, 2, 45, 300),
(42, 4, 3, 2, 49, 340),
(43, 4, 3, 3, 48, 300),
(44, 4, 3, 3, 52, 340),
(45, 4, 4, 2, 50, 300),
(46, 4, 4, 2, 54, 340),
(47, 4, 4, 3, 53, 300),
(48, 4, 4, 3, 57, 340),
(49, 5, 2, 2, 50, 300),
(50, 5, 2, 2, 54, 340),
(51, 5, 2, 3, 53, 300),
(52, 5, 2, 3, 57, 340),
(53, 5, 3, 2, 55, 300),
(54, 5, 3, 2, 59, 340),
(55, 5, 3, 3, 58, 300),
(56, 5, 3, 3, 62, 340),
(57, 5, 4, 2, 60, 300),
(58, 5, 4, 2, 64, 340),
(59, 5, 4, 3, 63, 300),
(60, 5, 4, 3, 67, 340),
(61, 6, 2, 2, 60, 300),
(62, 6, 2, 2, 64, 340),
(63, 6, 2, 3, 63, 300),
(64, 6, 2, 3, 67, 340),
(65, 6, 3, 2, 65, 300),
(66, 6, 3, 2, 69, 340),
(67, 6, 3, 3, 68, 300),
(68, 6, 3, 3, 72, 340),
(69, 6, 4, 2, 70, 300),
(70, 6, 4, 2, 74, 340),
(71, 6, 4, 3, 73, 300),
(72, 6, 4, 3, 74, 340),
(73, 7, 2, 3, 20, 300),
(74, 7, 2, 2, 30, 340),
(75, 7, 2, 3, 45, 300),
(76, 7, 2, 2, 55, 300),
(77, 7, 3, 3, 58, 340),
(78, 7, 3, 2, 68, 300),
(79, 7, 3, 3, 46, 340),
(80, 7, 3, 2, 37, 300),
(81, 7, 4, 3, 66, 300),
(82, 7, 4, 2, 52, 340),
(83, 7, 4, 3, 70, 300),
(84, 7, 4, 2, 82, 340),
(85, 8, 2, 2, 50, 300),
(86, 8, 2, 3, 53, 340),
(87, 8, 2, 2, 45, 300),
(88, 8, 2, 3, 56, 340),
(89, 8, 3, 2, 60, 300),
(90, 8, 3, 3, 62, 340),
(91, 8, 3, 2, 64, 300),
(92, 8, 3, 3, 66, 340),
(93, 8, 4, 2, 68, 300),
(94, 8, 4, 3, 70, 340),
(95, 8, 4, 2, 72, 300),
(96, 8, 4, 3, 74, 340),
(97, 9, 2, 2, 30, 300),
(98, 9, 2, 3, 32, 340),
(99, 9, 2, 2, 34, 300),
(100, 9, 2, 3, 36, 340),
(101, 9, 3, 2, 38, 300),
(102, 9, 3, 3, 40, 340),
(103, 9, 3, 2, 42, 300),
(104, 9, 3, 3, 44, 340),
(105, 9, 4, 2, 46, 300),
(106, 9, 4, 3, 48, 340),
(107, 9, 4, 2, 50, 300),
(108, 9, 4, 3, 52, 340),
(109, 10, 2, 2, 49, 300),
(110, 10, 2, 3, 51, 340),
(111, 10, 2, 2, 53, 300),
(112, 10, 2, 3, 55, 340),
(113, 10, 3, 2, 57, 300),
(114, 10, 3, 3, 59, 340),
(115, 10, 3, 2, 61, 300),
(116, 10, 3, 3, 63, 340),
(117, 10, 4, 2, 65, 300),
(118, 10, 4, 3, 67, 340),
(119, 10, 4, 2, 69, 300),
(122, 10, 4, 3, 71, 300);


INSERT INTO `Farm_Award` (`farm_id`, `award_id`, `place`, `year`, `pdf`) VALUES
('1', '2', '2', '2015', NULL),
('1', '2', '4', '2014', NULL),
('2', '2', '1', '2015', NULL),
('2', '2', '3', '2010', NULL);
	

INSERT INTO `Farm_Cultivar` (`farm_id`, `cultivar_id`) VALUES 
('1', '4'), 
('1', '5'), 
('2', '2'), 
('2', '3');


INSERT INTO `Farm_Certification` (`farm_id`, `certification_id`) VALUES 
('1', '2'),
('2', '2');


INSERT INTO `User` (`email`, `username`,`lastname`, `password`) VALUES 
('admin@gmail.com', 'CRgourmet','Coffee', '$2y$12$JUcCH2ESdVVDw4LyDZiLtuDJZUuxZonom9gg0ynZ6FGDbYbUYOrrq'),
('carlos@gmail.com', 'Carlos','Herrera', '$2y$12$t9LLBvfK1b84GDdWROZFLeHojdRP2vH9mhuY36ivx310g7wmtMC2i');

INSERT INTO `Shopping_Cart_T` (`id`, `page_title`, `cart_title`, `product_title`, `farm_title`, `description_title`, `weight_title`, `roast_title`, `grind_title`, `unit_price_title`, `quantity_title`, `sub_total_title`, `total_title`, `action_title`, `remove_button`, `shipping_title`, `continue_button`, `check_out_button`, `empty_cart_title`) VALUES
(1, 'Shopping Cup', 'Your products', 'Product', 'Farm', 'Description', 'Weight','Roast','Grind','Unit Price', 'Quantity', 'Sub total', 'Total', 'Action', 'Remove', 'Shipping is not included', 'Continue Shopping', 'Check out', 'You have no products on your shopping cup');


INSERT INTO `Product_T` (`id`, `page_title`, `farm_title`, `order_title`, `reviews_title`, `information_title`, `species_title`, `species_info`, `cultivar_title`, `grade_title`, `processing_title`, `flavor_notes_title`, `roast_title`, `weight_title`, `grind_title`, `cup_scoring_title`) VALUES
(1, 'Product Information', 'Farm', 'Order', 'Reviews', 'Information', 'Species', 'Arabica', 'Cultivar', 'Grade', 'Processing', 'Flavor notes', 'Roast', 'Weight', 'Grind', 'Cup scoring');


INSERT INTO `Farm_T` (`id`, `page_title`, `description_title`,`story_btn_title`, `information_title`, `awards_title`, `location_title`, `products_title`, `region_title`, `elevation_title`, `harvest_title`, `species_title`, `species_info`, `cultivar_title`, `certifications_title`,`order_title`,`more_info_title`,`reviews_title`,`contact_btn_title`) VALUES
(1, 'Farm Information', 'Description','Read story', 'Information', 'Awards', 'Location', 'Roasted Coffee', 'Region', 'Elevation', 'Harvest', 'Species', 'Arabica', 'Cultivar', 'Certifications','Order','Options','Reviews','Contact farm'),
(2, 'Información de Finca', 'Descripción','Leer historia', 'Información','Premios', 'Localización', 'Café tostado', 'Región', 'Elevación', 'Cosecha', 'Especie', 'Arabica',  'Cultivar', 'Certificaciones','Ordenar','Opciones','Comentarios','Contactar finca');


INSERT INTO `Home_T` (`id`, `farm_id`, `product_1`, `product_2`, `product_3`, `product_4`, `product_5`, `product_6`, `description_title`, `description_info`, `banner_image`, `featured_products_title`, `product_farm_title`) VALUES
(NULL, 2, 1, 2, 3, 4, 5, 6, 'We bring you the best coffee from Costa Rica.','Our site is operated by high-quality Costa Rican producers,\n who sell directly their own coffee without intermediaries.\n These producers have been winners of the Cup of Excellence\n � prestigous contest to reward coffee quality. ', '/web/public/imgs/coffeeGrains.png', 'Featured products', 'Farm');