<?php

namespace FarmBundle\Entity;

/**
 * Farm
 */
class Farm{
    
    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     */
    private $name;

    /**
     * @var string
     */
    private $image;

    /**
     * @var string
     */
    private $description;

    /**
     * @var string
     */
    private $elevation;

    /**
     * @var string
     */
    private $harvest;

    /**
     * @var float
     */
    private $latitude;

    /**
     * @var float
     */
    private $longitude;

    /**
     * @var \Doctrine\Common\Collections\Collection
     */
    private $farm_awards;

    /**
     * Constructor
     */
    public function __construct(){
        $this->farm_awards = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId(){
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return Farm
     */
    public function setName($name){
        $this->name = $name;
    
        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName(){
        return $this->name;
    }

    /**
     * Set image
     *
     * @param string $image
     *
     * @return Farm
     */
    public function setImage($image){
        $this->image = $image;
    
        return $this;
    }

    /**
     * Get image
     *
     * @return string
     */
    public function getImage(){
        return $this->image;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return Farm
     */
    public function setDescription($description){
        $this->description = $description;
    
        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getDescription(){
        return $this->description;
    }

    /**
     * Set elevation
     *
     * @param string $elevation
     *
     * @return Farm
     */
    public function setElevation($elevation){
        $this->elevation = $elevation;
    
        return $this;
    }

    /**
     * Get elevation
     *
     * @return string
     */
    public function getElevation(){
        return $this->elevation;
    }

    /**
     * Set harvest
     *
     * @param string $harvest
     *
     * @return Farm
     */
    public function setHarvest($harvest){
        $this->harvest = $harvest;
    
        return $this;
    }

    /**
     * Get harvest
     *
     * @return string
     */
    public function getHarvest(){
        return $this->harvest;
    }

    /**
     * Set latitude
     *
     * @param float $latitude
     *
     * @return Farm
     */
    public function setLatitude($latitude){
        $this->latitude = $latitude;
    
        return $this;
    }

    /**
     * Get latitude
     *
     * @return float
     */
    public function getLatitude(){
        return $this->latitude;
    }

    /**
     * Set longitude
     *
     * @param float $longitude
     *
     * @return Farm
     */
    public function setLongitude($longitude){
        $this->longitude = $longitude;
    
        return $this;
    }

    /**
     * Get longitude
     *
     * @return float
     */
    public function getLongitude(){
        return $this->longitude;
    }

    /**
     * Add farmAward
     *
     * @param \FarmBundle\Entity\Farm_Award $farmAward
     *
     * @return Farm
     */
    public function addFarmAward(\FarmBundle\Entity\Farm_Award $farmAward){
        $this->farm_awards[] = $farmAward;

        return $this;
    }

    /**
     * Remove farmAward
     *
     * @param \FarmBundle\Entity\Farm_Award $farmAward
     */
    public function removeFarmAward(\FarmBundle\Entity\Farm_Award $farmAward){
        $this->farm_awards->removeElement($farmAward);
    }

    /**
     * Get farmAwards
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getFarmAwards(){
        return $this->farm_awards;
    }
}
