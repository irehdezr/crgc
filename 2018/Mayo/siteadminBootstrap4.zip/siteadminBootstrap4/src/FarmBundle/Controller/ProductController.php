<?php

namespace FarmBundle\Controller;

use Doctrine\Common\Collections\ArrayCollection;
use FarmBundle\Entity\Presentation;
use FarmBundle\Entity\Product_I;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class ProductController extends Controller
{
    public function indexAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $product_repo = $em->getRepository("FarmBundle:Product_I");
        $product = $product_repo->findAllProductsByFarm($id);
        $products = new ArrayCollection();
        $empty = 'false';
        foreach ($product as $pr){
            $prod = new Product_I();
            $prod->setID($pr["id"]);
            $prod->setName($pr["name"]);
            $prod->setImage($pr["image"]);
            $prod->setCultivar($em->getRepository("FarmBundle:Cultivar")->find($pr["cultivar"]));
            $prod->setGrade($em->getRepository("FarmBundle:Grade")->find($pr["grade"]));
            $prod->setProcessing($em->getRepository("FarmBundle:Processing")->find($pr["processing"]));
            $prod->setFlavor($em->getRepository("FarmBundle:Flavor")->find($pr["flavor"]));
            $products->add($prod);
        }
        if(sizeof($products) == 0){
            $empty = 'true';
        }
        return $this->render('FarmBundle:Default:product.html.twig', [
            'products'=>$products, 'farm_id'=>$id, 'empty'=>$empty
        ]);
    }

    // --------------------- Edit ----------------------------
    public function editViewAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $product_repo = $em->getRepository("FarmBundle:Product_I");
        $products = $product_repo->findBy(array('id'=>$id));
        $farm_id = $products[0]->getFarm()->getId();
        $farm = $em->getRepository("FarmBundle:Farm_I")->findBy(['id'=>$farm_id]);
        $cultivars = $em->getRepository("FarmBundle:Cultivar")->findAll();
        $grade = $em->getRepository("FarmBundle:Grade")->findAll();
        $processing = $em->getRepository("FarmBundle:Processing")->findAll();
        $flavor = $em->getRepository("FarmBundle:Flavor")->findAll();
        $roast = $em->getRepository('FarmBundle:Roast')->findBy([], ['id' => 'ASC']);
        $grind = $em->getRepository('FarmBundle:Grind')->findBy([], ['id' => 'ASC']);
        return $this->render('FarmBundle:Default:editProduct.html.twig', [
            'products'=>$products, 'farm'=>$farm, 'cultivars'=>$cultivars,
            'grade'=>$grade, 'processing'=>$processing, 'flavor'=>$flavor,
            'roast'=>$roast, 'grind'=>$grind
        ]);
    }

    // --------------------- Save/Update ----------------------------
    public function saveAction(Request $request)
    {
        $response = 'false';
        if($request->isXMLHttpRequest()){
            $id = $request->request->get('id');
            $name = $request->request->get('name');
            $description = $request->request->get('description');

            $cultivar_id = $request->request->get('cultivar');
            $grade_id = $request->request->get('grade');
            $processing_id = $request->request->get('processing');
            $flavor_id = $request->request->get('flavor');

            $em = $this->getDoctrine()->getManager();
            $cultivar = $em->getRepository("FarmBundle:Cultivar")->find($cultivar_id);
            $grade = $em->getRepository("FarmBundle:Grade")->find($grade_id);
            $processing = $em->getRepository("FarmBundle:Processing")->find($processing_id);
            $flavor = $em->getRepository("FarmBundle:Flavor")->find($flavor_id);
            $product = $em->getRepository("FarmBundle:Product_I")->find($id);
            if (!empty($product)) {
                $product ->setName($name);
                $product ->setDescription($description);
                $product->setCultivar($cultivar);
                $product->setGrade($grade);
                $product->setProcessing($processing);
                $product->setFlavor($flavor);
                $em->flush();
            }
            $response = $this->generateUrl('farm_product_homepage', ['id'=>$product->getFarm()->getId()]);
            //$response = 'true';
        }
        return new Response($response);
    }

    // --------------------- Insert ----------------------------
    public function addAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $farm = $em->getRepository("FarmBundle:Farm_I")->findBy(['id'=>$id]);
        $cultivars = $em->getRepository("FarmBundle:Cultivar")->findAll();
        $grade = $em->getRepository("FarmBundle:Grade")->findAll();
        $processing = $em->getRepository("FarmBundle:Processing")->findAll();
        $flavor = $em->getRepository("FarmBundle:Flavor")->findAll();
        $roast = $em->getRepository('FarmBundle:Roast')->findBy([], ['id' => 'ASC']);
        $grind = $em->getRepository('FarmBundle:Grind')->findBy([], ['id' => 'ASC']);
        return $this->render('FarmBundle:Default:insertProduct.html.twig',[
            'farm'=>$farm[0], 'cultivars'=>$cultivars,'grade'=>$grade, 'processing'=>$processing,
            'flavor'=>$flavor, 'roast'=>$roast, 'grind'=>$grind
        ]);
    }

    public function insertAction(Request $request){
        $response = 'false';
        if($request->isXMLHttpRequest()){
            try{
                $id_farm = $request->request->get('id_farm');
                $name = $request->request->get('name');
                $description = $request->request->get('description');
                $cultivar_id = $request->request->get('cultivar');
                $grade_id = $request->request->get('grade');
                $processing_id = $request->request->get('processing');
                $flavor_id = $request->request->get('flavor');

                $em = $this->getDoctrine()->getManager();
                $farm = $em->getRepository("FarmBundle:Farm_I")->find($id_farm);
                $cultivar = $em->getRepository("FarmBundle:Cultivar")->find($cultivar_id);
                $grade = $em->getRepository("FarmBundle:Grade")->find($grade_id);
                $processing = $em->getRepository("FarmBundle:Processing")->find($processing_id);
                $flavor = $em->getRepository("FarmBundle:Flavor")->find($flavor_id);

                $product = new Product_I();
                $product->setName($name);
                $product->setDescription($description);
                $product->setImage("/");
                $product->setCultivar($cultivar);
                $product->setGrade($grade);
                $product->setProcessing($processing);
                $product->setFlavor($flavor);
                $product->setFarm($farm);
                $product->setRank(0);
                $product->setReviews(0);

                $em->merge($product);
                $em->flush();
            }catch (Exception $e){
                echo 'Excepción capturada: ',  $e->getMessage(), "\n";
            }

            $response = $this->generateUrl('farm_product_homepage', ['id'=>$product->getFarm()->getId()]);
        }
        return new Response($response);
    }

    // --------------------- Images ----------------------------
    public function imageAction(Request $request, $id)
    {
        $file = $request->files->get('upload');
        $status = array('status' => "success", "fileUploaded" => false);

        // If a file was uploaded
        if (!is_null($file)) {
            // generate a random name for the file but keep the extension
            //$filename = uniqid() . "." . $file->getClientOriginalExtension();

            $em = $this->getDoctrine()->getManager();
            $product = $em->getRepository("FarmBundle:Product_I")->find($id);
            $filename = $product->getName()."_".$file->getClientOriginalName();
            //Lower case everything
            $filename = strtolower($filename);
            //Clean up multiple dashes or whitespaces
            $filename = preg_replace("/[\s-]+/", " ", $filename);
            //Convert whitespaces and underscore to dash
            $filename = preg_replace("/[\s_]/", "-", $filename);
            $path = "C:/xampp/htdocs/siteadmin/web/common/imgs/products/";
            //$path = "common/imgs";
            $file->move($path, $filename); // move the file to a path
            $name = "/siteadmin/web/common/imgs/products/".$filename;
            //$name = "http://www.siteadmin.crgourmetcoffee.com/web/".$path."/".$filename;
            $status = array('status' => "success", "fileUploaded" => true, 'path' => $name);
            $product->setImage($name);
            $em->flush();
        }
        return new JsonResponse($status);
    }

    // --------------------- Add Presentations ----------------------------
    public function addPresentationsAction(Request $request)
    {
        $response = 'false';
        if($request->isXMLHttpRequest()){
            $product_id = $request->request->get('product_id');
            $roast_id = $request->request->get('roast_id');
            $grind_id = $request->request->get('grind_id');
            $price = $request->request->get('price');
            $weight = $request->request->get('weight');

            $em = $this->getDoctrine()->getManager();
            $product = $em->getRepository("FarmBundle:Product_I")->find($product_id);
            $roast = $em->getRepository("FarmBundle:Roast")->find($roast_id);
            $grind = $em->getRepository("FarmBundle:Grind")->find($grind_id);

            $i = 0;
            if($product->getPresentations() != null) {
                foreach ($product->getPresentations() as $pres) {
                    if ($pres->getRoast()->getId() == $roast_id && $pres->getGrind()->getId() == $grind_id && $pres->getPrice() == $price && $pres->getWeight() == $weight) {
                        $i = 1;
                    }
                }
            }
            if($i == 0){
                $product_presentation = new Presentation();
                $product_presentation->setProduct($product);
                $product_presentation->setRoast($roast);
                $product_presentation->setGrind($grind);
                $product_presentation->setPrice($price);
                $product_presentation->setWeight($weight);
                $em->persist($product_presentation);
                $em->flush();
                $response = 'true';
            }

        }
        return new JsonResponse($response);
    }

    // --------------------- Delete Presentations ----------------------------
    public function deletePresentationsAction(Request $request)
    {
        $response = 'false';
        if($request->isXMLHttpRequest()){
            $id_presentation = $request->request->get('id_presentation');
            $id_product = $request->request->get('id_product');
            $em = $this->getDoctrine()->getManager();
            $product_presentation = $em->getRepository("FarmBundle:Presentation")->find($id_presentation);
            $product = $em->getRepository("FarmBundle:Product_I")->find($id_product);
            $product->removePresentation($product_presentation);
            $em->remove($product_presentation);
            $em->flush();
            $response = 'true';
        }
        return new Response($response);
    }

    // --------------------- Search Presentations ----------------------------
    public function searchAction(Request $request)
    {
        $status = 'false';
        if($request->isXMLHttpRequest()) {
            $id_farm = $request->request->get('id_farm');
            $name = $request->request->get('name');
            $description = $request->request->get('description');
            $cultivar_id = $request->request->get('cultivar');
            $grade_id = $request->request->get('grade');
            $processing_id = $request->request->get('processing');
            $flavor_id = $request->request->get('flavor');

            $em = $this->getDoctrine()->getManager();
            $products = $em->getRepository("FarmBundle:Product_I")->findAll();

            for ($i = 0; $i < count($products); $i++) {
                $prod = $products[$i];
                if($prod->getFarm()->getId() == $id_farm && $prod->getName() == $name && $prod->getDescription() == $description &&
                    $prod->getCultivar()->getId() == $cultivar_id && $prod->getGrade()->getId() == $grade_id && $prod->getProcessing()->getId() == $processing_id &&
                    $prod->getFlavor()->getId() == $flavor_id){
                    $status = $prod->getId();
                    break;
                }
            }
        }

        return new JsonResponse($status);
    }

    // --------------------- Delete ----------------------------
    public function deleteAction(Request $request)
    {
        $response = 'false';
        if($request->isXMLHttpRequest()) {
            $em = $this->getDoctrine()->getManager();
            $id = $request->request->get('id');
            $product = $em->getRepository("FarmBundle:Product_I")->find($id);
            $id_farm = $product->getFarm()->getId();

            /*if (!empty($product->getPresentations())) {
                //$response = 'tiene presentaciones';
                // --------------------- Presentation -----------------------
                foreach ($product->getPresentations() as $presentation) {
                    $em->remove($presentation);
                }
            }
            // --------------------- Product -----------------------*/
            $em->remove($product);
            $em->flush();
            $response = $this->generateUrl('farm_product_homepage', ['id'=>$id_farm]);
        }
        return new Response($response);
    }
}
