<?php

namespace RegionBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use RegionBundle\Entity\Region;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\HttpFoundation\File\File;

class DefaultController extends Controller
{
    // --------------------- Show all Regions ----------------------------
    public function indexAction()
    {
        $em = $this->getDoctrine()->getManager(); 
        $region_repo = $em->getRepository("RegionBundle:Region");
        $regions = $region_repo->findAll();
        return $this->render('RegionBundle:Default:region.html.twig', [
            'regions'=>$regions
        ]);
    }

    // --------------------- Edit Region ----------------------------
    public function editAction($id, Request $request)
    {
        $em = $this->getDoctrine()->getManager();
        $region = $em->getRepository("RegionBundle:Region")->find($id);

        $image1Name = $region->getImage1();
        $image2Name = $region->getImage2();
        $image3Name = $region->getImage3();

        $region->setImage1(new File("C:/xampp/htdocs".$region->getImage1()));
        $region->setImage2(new File("C:/xampp/htdocs".$region->getImage2()));
        $region->setImage3(new File("C:/xampp/htdocs".$region->getImage3()));

        $form = $this->createFormBuilder($region, ['validation_groups' => ['update']])
                ->add('name', TextType::class, array('label' => 'Nombre (en inglés)'))
                ->add('image1', FileType::class, array('label' => 'Imagen 1'))
                ->add('image_description1', TextType::class, array('label' => 'Descripción de la imagen 1'))
                ->add('image2', FileType::class, array('label' => 'Imagen 2'))
                ->add('image_description2', TextType::class, array('label' => 'Descripción de la imagen 2'))
                ->add('image3', FileType::class, array('label' => 'Imagen 3'))
                ->add('image_description3', TextType::class, array('label' => 'Descripción de la imagen 3'))
                ->add('description', TextareaType::class, array('label' => 'Descripción (en inglés)'))
                ->add('organoleptic_characteristics', TextareaType::class, array('label' => 'Características organolépticas (en inglés)'))
                ->add('information', TextareaType::class, array('label' => 'Información (en inglés)'))
                ->add('latitude', NumberType::class, array('label' => 'Latitud'))
                ->add('longitude', NumberType::class, array('label' => 'Longitud'))
                ->add('zoom', NumberType::class, array('label' => 'Zoom'))
                ->add('save', SubmitType::class, array('label' => 'Guardar'))
                ->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // $form->getData() holds the submitted values
            // but, the original `$task` variable has also been updated
            $region = $form->getData();

            $path = "C:/xampp/htdocs/siteadminBootstrap4/web/common/imgs/regions/";
            //$path = "common/imgs";
            $imagepath = "/siteadminBootstrap4/web/common/imgs/regions/";

            $image1 = $region->getImage1();
            if($image1 != null){
                $filename = self::generateImageFileName($region->getName(),"image1.".$image1->guessExtension());
                $image1->move($path, $filename); // move the file to a path
                $region->setImage1($imagepath.$filename);
            }else
                $region->setImage1($image1Name);
            
            $image2 = $region->getImage2();
            if($image2 != null){
                $filename = self::generateImageFileName($region->getName(),"image2.".$image2->guessExtension());
                $image2->move($path, $filename); // move the file to a path
                $region->setImage2($imagepath.$filename);
            }else
                $region->setImage2($image2Name);

            $image3 = $region->getImage3();
            if($image3 != null){
                $filename = self::generateImageFileName($region->getName(),"image3.".$image3->guessExtension());
                $image3->move($path, $filename); // move the file to a path
                $region->setImage3($imagepath.$filename);
            }else
                $region->setImage3($image3Name);
    
            // ... perform some action, such as saving the task to the database
            // for example, if Task is a Doctrine entity, save it!
            $em = $this->getDoctrine()->getManager();
            $em->persist($region);
            $em->flush();
    
            return $this->redirectToRoute('region_homepage');
        }

        return $this->render('RegionBundle:Default:edit.html.twig', [
            'form' => $form->createView(), 'image1' => $image1Name, 'image2' => $image2Name,
            'image3' => $image3Name
        ]);
    }

    // --------------------- Delete ----------------------------
    public function deleteAction(Request $request)
    {
        $response = 'false';
        if($request->isXMLHttpRequest()) {
            $em = $this->getDoctrine()->getManager();
            $id = $request->request->get('id');
            $region = $em->getRepository("FarmBundle:Region")->find($id);
            $response = 'entro if';

            if (!empty($region->getFarms())) {
                $response = 'tiene farms';
                foreach ($region->getFarms() as $farm) {
                    $farm = $em->getRepository("FarmBundle:Farm_I")->find($farm->getId());
                    if (!empty($farm->getProducts())) {
                        $response = 'tiene productos';
                        foreach ($farm->getProducts() as $product) {
                            $product = $em->getRepository("FarmBundle:Product_I")->find($product->getId());
                            if (!empty($product->getPresentations())) {
                                $response = 'tiene presentaciones';
                                // --------------------- Presentation -----------------------
                                foreach ($product->getPresentations() as $presentation) {
                                    $em->remove($presentation);
                                }
                            }
                            // --------------------- Product -----------------------
                            $em->remove($product);
                        }
                    }
                    if (!empty($farm->getFarmAwards())) {
                        // --------------------- Award -----------------------
                        foreach ($farm->getFarmAwards() as $award) {
                            $em->remove($award);
                        }
                    }
                    // --------------------- Farm -----------------------
                    $em->remove($farm);
                }
            }
            // --------------------- Region -----------------------
            $em->remove($region);

            $em->flush();
            $response = $this->generateUrl('region_homepage');
        }
        return new Response($response);
    }

    // --------------------- New Region ----------------------------
    public function newAction(Request $request){
        $region = new Region();

        $form = $this->createFormBuilder($region, ['validation_groups' => ['create']])
                ->add('name', TextType::class, array('label' => 'Nombre (en inglés)'))
                ->add('image1', FileType::class, array('label' => 'Imagen 1'))
                ->add('image_description1', TextType::class, array('label' => 'Descripción de la imagen 1'))
                ->add('image2', FileType::class, array('label' => 'Imagen 2'))
                ->add('image_description2', TextType::class, array('label' => 'Descripción de la imagen 2'))
                ->add('image3', FileType::class, array('label' => 'Imagen 3'))
                ->add('image_description3', TextType::class, array('label' => 'Descripción de la imagen 3'))
                ->add('description', TextareaType::class, array('label' => 'Descripción (en inglés)'))
                ->add('organoleptic_characteristics', TextareaType::class, array('label' => 'Características organolépticas (en inglés)'))
                ->add('information', TextareaType::class, array('label' => 'Información (en inglés)'))
                ->add('latitude', NumberType::class, array('label' => 'Latitud'))
                ->add('longitude', NumberType::class, array('label' => 'Longitud'))
                ->add('zoom', NumberType::class, array('label' => 'Zoom'))
                ->add('save', SubmitType::class, array('label' => 'Guardar'))
                ->getForm();

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // $form->getData() holds the submitted values
            // but, the original `$task` variable has also been updated
            $region = $form->getData();

            $path = "C:/xampp/htdocs/siteadminBootstrap4/web/common/imgs/regions/";
            //$path = "common/imgs";
            $imagepath = "/siteadminBootstrap4/web/common/imgs/regions/";

            $image1 = $region->getImage1();
            $filename = self::generateImageFileName($region->getName(),"image1.".$image1->guessExtension());
            $image1->move($path, $filename); // move the file to a path
            $region->setImage1($imagepath.$filename);
            
            $image2 = $region->getImage2();
            $filename = self::generateImageFileName($region->getName(),"image2.".$image2->guessExtension());
            $image2->move($path, $filename); // move the file to a path
            $region->setImage2($imagepath.$filename);

            $image3 = $region->getImage3();
            $filename = self::generateImageFileName($region->getName(),"image3.".$image3->guessExtension());
            $image3->move($path, $filename); // move the file to a path
            $region->setImage3($imagepath.$filename);
    
            // ... perform some action, such as saving the task to the database
            // for example, if Task is a Doctrine entity, save it!
            $em = $this->getDoctrine()->getManager();
            $em->persist($region);
            $em->flush();
    
            return $this->redirectToRoute('region_homepage');
        }

        return $this->render('RegionBundle:Default:insert.html.twig', array(
            'form' => $form->createView(),
        ));
    }

    private function generateImageFileName($region,$clientName)
    {
        $filename = $region."-".$clientName;
        //Lower case everything
        $filename = strtolower($filename);
        //Clean up multiple dashes or whitespaces
        $filename = preg_replace("/[\s-]+/", " ", $filename);
        //Convert whitespaces and underscore to dash
        $filename = preg_replace("/[\s_]/", "-", $filename);
        
        return $filename;
    }
}
