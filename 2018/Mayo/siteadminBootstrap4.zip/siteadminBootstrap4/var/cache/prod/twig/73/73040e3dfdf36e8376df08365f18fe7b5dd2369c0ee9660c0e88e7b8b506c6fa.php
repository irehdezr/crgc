<?php

/* RegionBundle:Default:insert.html.twig */
class __TwigTemplate_310ef03e8a1a2aa1fab8c54f5b1a427c287f4c06dfd88044488c18bc53a15046 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "RegionBundle:Default:insert.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_39a85638eb7f3e9ab044d207ac89f5afe218e0d7709fafc859efe5cf9d51f131 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_39a85638eb7f3e9ab044d207ac89f5afe218e0d7709fafc859efe5cf9d51f131->enter($__internal_39a85638eb7f3e9ab044d207ac89f5afe218e0d7709fafc859efe5cf9d51f131_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "RegionBundle:Default:insert.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_39a85638eb7f3e9ab044d207ac89f5afe218e0d7709fafc859efe5cf9d51f131->leave($__internal_39a85638eb7f3e9ab044d207ac89f5afe218e0d7709fafc859efe5cf9d51f131_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_3a3a666a0d0097a4f5ffc5f2009c0dcacc08c96f2679b37974787ccec8460b56 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3a3a666a0d0097a4f5ffc5f2009c0dcacc08c96f2679b37974787ccec8460b56->enter($__internal_3a3a666a0d0097a4f5ffc5f2009c0dcacc08c96f2679b37974787ccec8460b56_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Agregar Regiones";
        
        $__internal_3a3a666a0d0097a4f5ffc5f2009c0dcacc08c96f2679b37974787ccec8460b56->leave($__internal_3a3a666a0d0097a4f5ffc5f2009c0dcacc08c96f2679b37974787ccec8460b56_prof);

    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        $__internal_afb0b33993ba4b25a08a0885adda01a326c7317a28a1e9e145c6bd77897daf5f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_afb0b33993ba4b25a08a0885adda01a326c7317a28a1e9e145c6bd77897daf5f->enter($__internal_afb0b33993ba4b25a08a0885adda01a326c7317a28a1e9e145c6bd77897daf5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "
<section>
    <div class=\"bg-white\">
        <div class=\"text-center\">
            <h2 class=\"text-light-brown\"><strong>AGREGAR REGIÓN</strong></h2>
        </div>
        <br>
        <div class=\"row\">
            <div class=\"col-auto\"></div>
            <div class=\"col\">
                    ";
        // line 17
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start');
        echo "
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 19
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "name", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            ";
        // line 21
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "name", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Nombre de la región")));
        echo "  
                            <span class=\"text-danger\">";
        // line 22
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "name", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 26
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image1", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            ";
        // line 28
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image1", array()), 'widget');
        echo "  
                            <span class=\"text-danger\">";
        // line 29
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image1", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 33
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image_description1", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            ";
        // line 35
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image_description1", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Descripción de la imagen 1")));
        echo "  
                            <span class=\"text-danger\">";
        // line 36
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image_description1", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 40
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image2", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            ";
        // line 42
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image2", array()), 'widget');
        echo "  
                            <span class=\"text-danger\">";
        // line 43
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image2", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 47
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image_description2", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            ";
        // line 49
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image_description2", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Descripción de la imagen 2")));
        echo "  
                            <span class=\"text-danger\">";
        // line 50
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image_description2", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 54
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image3", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            ";
        // line 56
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image3", array()), 'widget');
        echo "  
                            <span class=\"text-danger\">";
        // line 57
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image3", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 61
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image_description3", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            ";
        // line 63
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image_description3", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Descripción de la imagen 3")));
        echo "  
                            <span class=\"text-danger\">";
        // line 64
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image_description3", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 68
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "description", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            ";
        // line 70
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "description", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Descripción de la región", "rows" => "7", "cols" => "45")));
        echo "  
                            <span class=\"text-danger\">";
        // line 71
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "description", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 75
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "organoleptic_characteristics", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            ";
        // line 77
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "organoleptic_characteristics", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Características organolépticas de la región", "rows" => "7", "cols" => "45")));
        echo "  
                            <span class=\"text-danger\">";
        // line 78
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "organoleptic_characteristics", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 82
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "information", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            ";
        // line 84
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "information", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Información de la región", "rows" => "7", "cols" => "45")));
        echo "  
                            <span class=\"text-danger\">";
        // line 85
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "information", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 89
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "latitude", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            ";
        // line 91
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "latitude", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Latitud")));
        echo "  
                            <span class=\"text-danger\">";
        // line 92
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "latitude", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 96
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "longitude", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            ";
        // line 98
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "longitude", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Longitud")));
        echo "  
                            <span class=\"text-danger\">";
        // line 99
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "longitude", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 103
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "zoom", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            ";
        // line 105
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "zoom", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Zoom")));
        echo "  
                            <span class=\"text-danger\">";
        // line 106
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "zoom", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <div class=\"col-sm-10\">
                            <a href=\"";
        // line 111
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_homepage");
        echo "\" class=\"btn btn-dark btn-xs pull-right\"><i class=\"fa fa-ban\" aria-hidden=\"true\"></i> Cancelar</a>
                            ";
        // line 112
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "save", array()), 'widget', array("attr" => array("class" => "pull-right btn btn-success btn-margin", "fa" => "fa-floppy-o", "right" => true)));
        echo " ";
        // line 113
        echo "                        </div>
                    </div>
                    ";
        // line 115
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
            </div>
            <div class=\"col-auto\"></div>
        </div>
    </div>
</section>

";
        
        $__internal_afb0b33993ba4b25a08a0885adda01a326c7317a28a1e9e145c6bd77897daf5f->leave($__internal_afb0b33993ba4b25a08a0885adda01a326c7317a28a1e9e145c6bd77897daf5f_prof);

    }

    // line 124
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_644842868767131053819da93628c95551f682f04f06d16fc1475e25e1172a05 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_644842868767131053819da93628c95551f682f04f06d16fc1475e25e1172a05->enter($__internal_644842868767131053819da93628c95551f682f04f06d16fc1475e25e1172a05_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 125
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
";
        
        $__internal_644842868767131053819da93628c95551f682f04f06d16fc1475e25e1172a05->leave($__internal_644842868767131053819da93628c95551f682f04f06d16fc1475e25e1172a05_prof);

    }

    // line 128
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_5fb35d988231b7f1d530d1d80d34066caca77896dfb767b008b1f67e3ee34aa2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5fb35d988231b7f1d530d1d80d34066caca77896dfb767b008b1f67e3ee34aa2->enter($__internal_5fb35d988231b7f1d530d1d80d34066caca77896dfb767b008b1f67e3ee34aa2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 129
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
";
        
        $__internal_5fb35d988231b7f1d530d1d80d34066caca77896dfb767b008b1f67e3ee34aa2->leave($__internal_5fb35d988231b7f1d530d1d80d34066caca77896dfb767b008b1f67e3ee34aa2_prof);

    }

    public function getTemplateName()
    {
        return "RegionBundle:Default:insert.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  329 => 129,  323 => 128,  313 => 125,  307 => 124,  292 => 115,  288 => 113,  285 => 112,  281 => 111,  273 => 106,  269 => 105,  264 => 103,  257 => 99,  253 => 98,  248 => 96,  241 => 92,  237 => 91,  232 => 89,  225 => 85,  221 => 84,  216 => 82,  209 => 78,  205 => 77,  200 => 75,  193 => 71,  189 => 70,  184 => 68,  177 => 64,  173 => 63,  168 => 61,  161 => 57,  157 => 56,  152 => 54,  145 => 50,  141 => 49,  136 => 47,  129 => 43,  125 => 42,  120 => 40,  113 => 36,  109 => 35,  104 => 33,  97 => 29,  93 => 28,  88 => 26,  81 => 22,  77 => 21,  72 => 19,  67 => 17,  55 => 7,  49 => 6,  37 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Agregar Regiones{% endblock %}

{% block body %}

<section>
    <div class=\"bg-white\">
        <div class=\"text-center\">
            <h2 class=\"text-light-brown\"><strong>AGREGAR REGIÓN</strong></h2>
        </div>
        <br>
        <div class=\"row\">
            <div class=\"col-auto\"></div>
            <div class=\"col\">
                    {{ form_start(form) }}
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.name) }}</label>
                        <div class=\"col-sm-8\">
                            {{ form_widget(form.name, { \"attr\": {\"class\": \"form-control\", \"placeholder\": \"Nombre de la región\"} }) }}  
                            <span class=\"text-danger\">{{ form_errors(form.name) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.image1) }}</label>
                        <div class=\"col-sm-8\">
                            {{ form_widget(form.image1) }}  
                            <span class=\"text-danger\">{{ form_errors(form.image1) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.image_description1) }}</label>
                        <div class=\"col-sm-8\">
                            {{ form_widget(form.image_description1, { \"attr\": {\"class\": \"form-control\", \"placeholder\": \"Descripción de la imagen 1\"} }) }}  
                            <span class=\"text-danger\">{{ form_errors(form.image_description1) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.image2) }}</label>
                        <div class=\"col-sm-8\">
                            {{ form_widget(form.image2) }}  
                            <span class=\"text-danger\">{{ form_errors(form.image2) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.image_description2) }}</label>
                        <div class=\"col-sm-8\">
                            {{ form_widget(form.image_description2, { \"attr\": {\"class\": \"form-control\", \"placeholder\": \"Descripción de la imagen 2\"} }) }}  
                            <span class=\"text-danger\">{{ form_errors(form.image_description2) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.image3) }}</label>
                        <div class=\"col-sm-8\">
                            {{ form_widget(form.image3) }}  
                            <span class=\"text-danger\">{{ form_errors(form.image3) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.image_description3) }}</label>
                        <div class=\"col-sm-8\">
                            {{ form_widget(form.image_description3, { \"attr\": {\"class\": \"form-control\", \"placeholder\": \"Descripción de la imagen 3\"} }) }}  
                            <span class=\"text-danger\">{{ form_errors(form.image_description3) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.description) }}</label>
                        <div class=\"col-sm-8\">
                            {{ form_widget(form.description, { \"attr\": {\"class\": \"form-control\", \"placeholder\": \"Descripción de la región\", \"rows\": \"7\", \"cols\": \"45\" } }) }}  
                            <span class=\"text-danger\">{{ form_errors(form.description) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.organoleptic_characteristics) }}</label>
                        <div class=\"col-sm-8\">
                            {{ form_widget(form.organoleptic_characteristics, { \"attr\": {\"class\": \"form-control\", \"placeholder\": \"Características organolépticas de la región\", \"rows\": \"7\", \"cols\": \"45\" } }) }}  
                            <span class=\"text-danger\">{{ form_errors(form.organoleptic_characteristics) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.information) }}</label>
                        <div class=\"col-sm-8\">
                            {{ form_widget(form.information, { \"attr\": {\"class\": \"form-control\", \"placeholder\": \"Información de la región\", \"rows\": \"7\", \"cols\": \"45\" } }) }}  
                            <span class=\"text-danger\">{{ form_errors(form.information) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.latitude) }}</label>
                        <div class=\"col-sm-8\">
                            {{ form_widget(form.latitude, { \"attr\": {\"class\": \"form-control\", \"placeholder\": \"Latitud\"} }) }}  
                            <span class=\"text-danger\">{{ form_errors(form.latitude) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.longitude) }}</label>
                        <div class=\"col-sm-8\">
                            {{ form_widget(form.longitude, { \"attr\": {\"class\": \"form-control\", \"placeholder\": \"Longitud\"} }) }}  
                            <span class=\"text-danger\">{{ form_errors(form.longitude) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.zoom) }}</label>
                        <div class=\"col-sm-8\">
                            {{ form_widget(form.zoom, { \"attr\": {\"class\": \"form-control\", \"placeholder\": \"Zoom\"} }) }}  
                            <span class=\"text-danger\">{{ form_errors(form.zoom) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <div class=\"col-sm-10\">
                            <a href=\"{{ path('region_homepage') }}\" class=\"btn btn-dark btn-xs pull-right\"><i class=\"fa fa-ban\" aria-hidden=\"true\"></i> Cancelar</a>
                            {{ form_widget(form.save, {\"attr\": { \"class\": \"pull-right btn btn-success btn-margin\",'fa' : 'fa-floppy-o','right' : true} }) }} {#<i class=\"fa fa-floppy-o\" aria-hidden=\"true\"></i>#}
                        </div>
                    </div>
                    {{ form_end(form) }}
            </div>
            <div class=\"col-auto\"></div>
        </div>
    </div>
</section>

{% endblock %}

{% block stylesheets %}
    {{ parent() }}
{% endblock %}

{% block javascripts %}
    {{ parent() }}
{% endblock %}
", "RegionBundle:Default:insert.html.twig", "C:\\xampp\\htdocs\\siteadminBootstrap4\\src\\RegionBundle\\Resources\\views\\Default\\insert.html.twig");
    }
}
