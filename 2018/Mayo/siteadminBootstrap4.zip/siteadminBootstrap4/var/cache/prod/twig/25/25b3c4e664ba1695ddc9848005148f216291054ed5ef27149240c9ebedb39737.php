<?php

/* ProductBundle:Default:product.html.twig */
class __TwigTemplate_93526a14b2c0e254492236905b0f2aa0065a1ee48bc11967d5494a8d5ea54435 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "ProductBundle:Default:product.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Product Maintenance";
    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        // line 7
        echo "\t<div class=\"row col-md-9 col-md-offset-1 custyle\">
\t\t<a href=\"";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("product_add");
        echo "\" class=\"btn btn-primary btn-xs pull-right\"><span class=\"glyphicon glyphicon-plus\"></span> Add</a>
\t\t<table class=\"table table-striped custab\">
\t\t\t<thead>
\t\t\t<tr>
\t\t\t\t<th>ID</th>
\t\t\t\t<th>Name</th>
\t\t\t\t";
        // line 15
        echo "\t\t\t\t<th>Image</th>
\t\t\t\t<th class=\"text-center\">Action</th>
\t\t\t</tr>
\t\t\t</thead>
\t\t\t<tbody>
            ";
        // line 20
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["products"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 21
            echo "\t\t\t\t<tr>
\t\t\t\t\t<td> ";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "</td>
\t\t\t\t\t<td> ";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo " </td>
\t\t\t\t\t<td> <img src=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage", array(), "method"), "html", null, true);
            echo "\" class=\"mediana\"></td>
\t\t\t\t\t<td class=\"text-center\">
\t\t\t\t\t\t<a class='btn btn-info btn-xs btn-edit' style=\"margin-top: 10px\" id=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-edit\"></span> Edit</a>
\t\t\t\t\t\t<a href=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_delete", array("id" => $this->getAttribute($context["temp"], "getId", array(), "method"))), "html", null, true);
            echo "\" class=\"btn btn-danger btn-xs\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-remove\"></span> Delete</a>
\t\t\t\t\t</td>
\t\t\t\t</tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 31
        echo "\t\t\t</tbody>
\t\t</table>
\t</div>
";
    }

    // line 37
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 38
        echo "\t<link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
\t<link rel=\"stylesheet\" href=\"";
        // line 39
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/styles.css"), "html", null, true);
        echo "\">
";
    }

    // line 42
    public function block_javascripts($context, array $blocks = array())
    {
        // line 43
        echo "\t<script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
\t<script type=\"text/javascript\" src=\"";
        // line 44
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/js/products.js"), "html", null, true);
        echo "\"></script>
";
    }

    public function getTemplateName()
    {
        return "ProductBundle:Default:product.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  122 => 44,  117 => 43,  114 => 42,  108 => 39,  103 => 38,  100 => 37,  93 => 31,  83 => 27,  79 => 26,  74 => 24,  70 => 23,  66 => 22,  63 => 21,  59 => 20,  52 => 15,  43 => 8,  40 => 7,  37 => 6,  31 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "ProductBundle:Default:product.html.twig", "C:\\xampp\\htdocs\\src\\ProductBundle/Resources/views/Default/product.html.twig");
    }
}
