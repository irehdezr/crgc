<?php

/* FarmBundle:Default:edit.html.twig */
class __TwigTemplate_adc0686e847de8790b146b1f6e3d11ce19626c71e9282e841a1521f9e40b5301 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "FarmBundle:Default:edit.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'navbar' => array($this, 'block_navbar'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4cad6089a3bdbbf6079a3d48d9b4572ff8d07a489d4a2bf62a355106c479bb07 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4cad6089a3bdbbf6079a3d48d9b4572ff8d07a489d4a2bf62a355106c479bb07->enter($__internal_4cad6089a3bdbbf6079a3d48d9b4572ff8d07a489d4a2bf62a355106c479bb07_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FarmBundle:Default:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4cad6089a3bdbbf6079a3d48d9b4572ff8d07a489d4a2bf62a355106c479bb07->leave($__internal_4cad6089a3bdbbf6079a3d48d9b4572ff8d07a489d4a2bf62a355106c479bb07_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_82f0b33fc1fdc8ce04d9d69515a037968f8af156b292d9ea2ad44a8ed932b00c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_82f0b33fc1fdc8ce04d9d69515a037968f8af156b292d9ea2ad44a8ed932b00c->enter($__internal_82f0b33fc1fdc8ce04d9d69515a037968f8af156b292d9ea2ad44a8ed932b00c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Mantenimiento de fincas";
        
        $__internal_82f0b33fc1fdc8ce04d9d69515a037968f8af156b292d9ea2ad44a8ed932b00c->leave($__internal_82f0b33fc1fdc8ce04d9d69515a037968f8af156b292d9ea2ad44a8ed932b00c_prof);

    }

    // line 6
    public function block_navbar($context, array $blocks = array())
    {
        $__internal_37ab1abff2dc0ddce010ab1cb292864daacfdde9108688547bce360f584b60b4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_37ab1abff2dc0ddce010ab1cb292864daacfdde9108688547bce360f584b60b4->enter($__internal_37ab1abff2dc0ddce010ab1cb292864daacfdde9108688547bce360f584b60b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        echo "Mantenimiento de fincas - Editar";
        
        $__internal_37ab1abff2dc0ddce010ab1cb292864daacfdde9108688547bce360f584b60b4->leave($__internal_37ab1abff2dc0ddce010ab1cb292864daacfdde9108688547bce360f584b60b4_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_4723b5a8667b135445f45178624b5da96ed936edfeacb8c5a4f298d5fe94e317 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4723b5a8667b135445f45178624b5da96ed936edfeacb8c5a4f298d5fe94e317->enter($__internal_4723b5a8667b135445f45178624b5da96ed936edfeacb8c5a4f298d5fe94e317_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo "    <div class=\"row col-md-8 col-md-offset-2 custyle\" style=\"margin-top: 50px\">
        <table class=\"table table-striped custab\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"2\">EDICIÓN DE FINCAS</th>
            </tr>
            </thead>
            <tbody>
            ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["farms"] ?? $this->getContext($context, "farms")));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 18
            echo "                <tr>
                    <th>ID</th>
                    <td> ";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "</td>
                </tr>
                <tr>
                    <th>Nombre (en inglés)</th>
                    <td><input type=\"text\" name=\"name\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo "\" id=\"name\"></td>
                </tr>
                <tr>
                    <th>Descripción (en inglés)</th>
                    <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\">";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getDescription", array(), "method"), "html", null, true);
            echo "</textarea></td>
                </tr>
                <tr>
                    <th>Imagen</th>
                    <td>
                        <img src=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage", array(), "method"), "html", null, true);
            echo "\" class=\"mediana\">
                        <form id=\"myform\" method=\"post\" style=\"margin-top: 5px;\">
                            <input type=\"button\" id=\"loadFileXml\" value=\"Seleccione un archivo\" onclick=\"document.getElementById('image').click();\" />
                            <input id=\"image\" style=\"display:none;\" type=\"file\" name=\"upload\" />
                        </form>
                        <p id=\"imageError\" style=\"color: red; display: none;\"><small>Selecciona una imagen </small></p>
                        <p id=\"image1Error\" style=\"color: red; display: none;\"><small>Selecciona una imagen con la extensión .jpg, .jpeg, .gif o .png</small></p>
                    </td>
                </tr>
                <tr>
                    <th>Nombre de la región</th>
                    <td>";
            // line 44
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["temp"], "region", array()), "name", array()), "html", null, true);
            echo "
                    </td>
                </tr>
                <tr>
                    <th>Elevación</th>
                    <td>
                        <p name=\"elevation\" id=\"elevation\">";
            // line 50
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getElevation", array(), "method"), "html", null, true);
            echo "</p>
                        <label>Min:</label>
                        <select name=\"elevation-Min\" id=\"elevation-Min\">
                            ";
            // line 53
            $context["ele"] = 500;
            // line 54
            echo "                            ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(range(1, 16));
            foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
                // line 55
                echo "                                <option value=\"";
                echo twig_escape_filter($this->env, ($context["ele"] ?? $this->getContext($context, "ele")), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, ($context["ele"] ?? $this->getContext($context, "ele")), "html", null, true);
                echo "</option>
                                ";
                // line 56
                $context["ele"] = (($context["ele"] ?? $this->getContext($context, "ele")) + 100);
                // line 57
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 58
            echo "                        </select>
                        <label>Max:</label>
                        <select name=\"elevation-Max\" id=\"elevation-Max\">
                            ";
            // line 61
            $context["ele"] = 2000;
            // line 62
            echo "                            ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(range(1, 16));
            foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
                // line 63
                echo "                                <option value=\"";
                echo twig_escape_filter($this->env, ($context["ele"] ?? $this->getContext($context, "ele")), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, ($context["ele"] ?? $this->getContext($context, "ele")), "html", null, true);
                echo "</option>
                                ";
                // line 64
                $context["ele"] = (($context["ele"] ?? $this->getContext($context, "ele")) - 100);
                // line 65
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 66
            echo "                        </select>
                        <p id=\"elevationError\" style=\"color: red; display: none;\"><small>Seleccione un valor mínimo o máximo</small></p>
                        <p id=\"elevationError-min\" style=\"color: red; display: none;\"><small>El valor mínimo no puede ser mayor o igual al valor máximo</small></p>
                        <p id=\"elevationError-max\" style=\"color: red; display: none;\"><small>El valor máximo no puede ser menor o igual al valor mínimo</small></p>
                    </td>
                </tr>
                <tr>
                    <th>Cosecha</th>
                    <td>
                       <p name=\"harvest\" id=\"harvest\">";
            // line 75
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getHarvest", array(), "method"), "html", null, true);
            echo "</p>
                       <label>Empieza:</label>
                       <select name=\"harvest-begin\" id=\"harvest-begin\">
                           <option value=\"January\">January</option>
                           <option value=\"February\">February</option>
                           <option value=\"March\">March</option>
                           <option value=\"April\">April</option>
                           <option value=\"May\">May</option>
                           <option value=\"June\">June</option>
                           <option value=\"July\">July</option>
                           <option value=\"August\">August</option>
                           <option value=\"September\">September</option>
                           <option value=\"October\">October</option>
                           <option value=\"November\">November</option>
                           <option value=\"December\">December </option>
                       </select>
                       <label>Termina:</label>
                       <select name=\"harvest-end\" id=\"harvest-end\">
                            <option value=\"December\">December </option>
                            <option value=\"November\">November</option>
                            <option value=\"October\">October</option>
                            <option value=\"September\">September</option>
                            <option value=\"August\">August</option>
                            <option value=\"July\">July</option>
                            <option value=\"June\">June</option>
                            <option value=\"May\">May</option>
                            <option value=\"April\">April</option>
                            <option value=\"March\">March</option>
                            <option value=\"February\">February</option>
                            <option value=\"January\">January</option>
                       </select>
                        <p id=\"harvestError\" style=\"color: red; display: none;\"><small>Indique el valor para cuado empiza o termina la cosecha</small></p>
                        <p id=\"harvestError-begin\" style=\"color: red; display: none;\"><small>El mes en el empieza la cosecha no puede ser igual al mes en que termina</small></p>
                        <p id=\"harvestError-end\" style=\"color: red; display: none;\"><small>El mes en el termina la cosecha no puede ser igual al mes en que empieza</small></p>
                    </td>
                </tr>
                <tr>
                    <th>Cultivar</th>
                    <td>
                        <form>
                            ";
            // line 115
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["cultivars"] ?? $this->getContext($context, "cultivars")));
            foreach ($context['_seq'] as $context["_key"] => $context["culti"]) {
                // line 116
                echo "                                ";
                $context["flag"] = 0;
                // line 117
                echo "                                ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["temp"], "cultivars", array(), "method"));
                foreach ($context['_seq'] as $context["_key"] => $context["aux"]) {
                    // line 118
                    echo "                                    ";
                    if (($this->getAttribute($context["aux"], "getId", array(), "method") == $this->getAttribute($context["culti"], "getId", array(), "method"))) {
                        // line 119
                        echo "                                        ";
                        if (($this->getAttribute($context["culti"], "getId", array(), "method") != 1)) {
                            // line 120
                            echo "                                            <input type=\"checkbox\" name=\"cultivar\" id=\"";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
                            echo "\" value=\"";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getId", array(), "method"), "html", null, true);
                            echo "\" checked> ";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getDescription", array(), "method"), "html", null, true);
                            echo "</br>
                                            ";
                            // line 121
                            $context["flag"] = 1;
                            // line 122
                            echo "                                        ";
                        }
                        // line 123
                        echo "                                    ";
                    }
                    // line 124
                    echo "                                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['aux'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 125
                echo "                                ";
                if ((($context["flag"] ?? $this->getContext($context, "flag")) == 0)) {
                    // line 126
                    echo "                                    ";
                    if (($this->getAttribute($context["culti"], "getId", array(), "method") != 1)) {
                        // line 127
                        echo "                                        <input type=\"checkbox\" name=\"cultivar\" id=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
                        echo "\" value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getId", array(), "method"), "html", null, true);
                        echo "\"> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getDescription", array(), "method"), "html", null, true);
                        echo "</br>
                                    ";
                    }
                    // line 129
                    echo "                                 ";
                }
                // line 130
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['culti'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 131
            echo "                        </form>
                        <p id=\"cultivarError\" style=\"color: red; display: none;\"><small>Selecciona una opción</small></p>
                    </td>
                </tr>
                <tr>
                    <th>Certificaciones</th>
                    <td>
                        <form>
                            ";
            // line 139
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["certifications"] ?? $this->getContext($context, "certifications")));
            foreach ($context['_seq'] as $context["_key"] => $context["certi"]) {
                // line 140
                echo "                                ";
                $context["flag"] = 0;
                // line 141
                echo "                                ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["temp"], "certifications", array(), "method"));
                foreach ($context['_seq'] as $context["_key"] => $context["aux"]) {
                    // line 142
                    echo "                                    ";
                    if (($this->getAttribute($context["aux"], "getId", array(), "method") == $this->getAttribute($context["certi"], "getId", array(), "method"))) {
                        // line 143
                        echo "                                        ";
                        if (($this->getAttribute($context["certi"], "getId", array(), "method") != 1)) {
                            // line 144
                            echo "                                            <input type=\"checkbox\" name=\"certification\" id=\"";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
                            echo "\" value=\"";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["certi"], "getId", array(), "method"), "html", null, true);
                            echo "\" checked> ";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["certi"], "getDescription", array(), "method"), "html", null, true);
                            echo "</br>
                                            ";
                            // line 145
                            $context["flag"] = 1;
                            // line 146
                            echo "                                        ";
                        }
                        // line 147
                        echo "                                    ";
                    }
                    // line 148
                    echo "                                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['aux'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 149
                echo "                                ";
                if ((($context["flag"] ?? $this->getContext($context, "flag")) == 0)) {
                    // line 150
                    echo "                                    ";
                    if (($this->getAttribute($context["certi"], "getId", array(), "method") != 1)) {
                        // line 151
                        echo "                                        <input type=\"checkbox\" name=\"certification\" id=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
                        echo "\" value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["certi"], "getId", array(), "method"), "html", null, true);
                        echo "\" > ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["certi"], "getDescription", array(), "method"), "html", null, true);
                        echo "</br>
                                    ";
                    }
                    // line 153
                    echo "                                ";
                }
                // line 154
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['certi'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 155
            echo "                        </form>
                        <p id=\"certificationError\" style=\"color: red; display: none;\"><small>Selecciona una opción</small></p>
                    </td>
                </tr>
                <tr>
                    <th>Premios</th>
                    <td>
                        <table class=\"table table-striped\" id=\"table-awards\">
                            <thead>
                                <th></th>
                                <th>Lugar</th>
                                <th>Año</th>
                                <th>Certificado</th>
                                <th>Acción</th>
                            </thead>
                            <tbody id=\"tbody-awards\">
                                ";
            // line 171
            $context["num"] = 1;
            // line 172
            echo "                                ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["temp"], "GetfarmAwards", array(), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["award"]) {
                // line 173
                echo "                                    <tr id=\"";
                echo twig_escape_filter($this->env, ($context["num"] ?? $this->getContext($context, "num")), "html", null, true);
                echo "\">
                                        <td class=\"award-description-";
                // line 174
                echo twig_escape_filter($this->env, ($context["num"] ?? $this->getContext($context, "num")), "html", null, true);
                echo "\" id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["award"], "getAward", array(), "method"), "getId", array(), "method"), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["award"], "getAward", array(), "method"), "getDescription", array(), "method"), "html", null, true);
                echo "</td>
                                        <td class=\"award-place-";
                // line 175
                echo twig_escape_filter($this->env, ($context["num"] ?? $this->getContext($context, "num")), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["award"], "getPlace", array(), "method"), "html", null, true);
                echo "</td>
                                        <td class=\"award-year-";
                // line 176
                echo twig_escape_filter($this->env, ($context["num"] ?? $this->getContext($context, "num")), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["award"], "getYear", array(), "method"), "html", null, true);
                echo "</td>
                                        <td id=\"td-pdf-";
                // line 177
                echo twig_escape_filter($this->env, ($context["num"] ?? $this->getContext($context, "num")), "html", null, true);
                echo "\">
                                            <p>
                                                <a style=\"margin: 0; padding-left: 14px; padding-right: 14px;\" class=\"btn btn-default btn-xs\" onclick=\"window.open('";
                // line 179
                echo twig_escape_filter($this->env, $this->getAttribute($context["award"], "getPDF", array(), "method"), "html", null, true);
                echo "')\" >";
                echo "  Mostrar certificado  </a><br>
                                                <a style=\"margin: 0; margin-top: 5px;\" class=\"btn btn-danger btn-xs btn-delete-pdf\" id=\"";
                // line 180
                echo twig_escape_filter($this->env, ($context["num"] ?? $this->getContext($context, "num")), "html", null, true);
                echo "\"><span class=\"glyphicon glyphicon-minus\"></span> Eliminar certificado</a>
                                            </p>
                                        </td>
                                        <td><a class=\"btn btn-danger btn-xs btn-delete-award\" id=\"";
                // line 183
                echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
                echo "-";
                echo twig_escape_filter($this->env, ($context["num"] ?? $this->getContext($context, "num")), "html", null, true);
                echo "\"><span class=\"glyphicon glyphicon-minus\"></span> Eliminar</a></td>
                                    </tr>
                                    ";
                // line 185
                $context["num"] = (($context["num"] ?? $this->getContext($context, "num")) + 1);
                // line 186
                echo "                                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['award'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 187
            echo "                            </tbody>
                            <tfoot>
                                <tr>
                                    <td class=\"award-description-add\" id=\"2\">Cup of Excellence</td>
                                    <td><input type=\"number\" name=\"place\" value=\"1\" id=\"place\" min=\"1\" class=\"textboxclass\"></td>
                                    <td>
                                        <select name=\"year\" id=\"year\">
                                            ";
            // line 194
            $context["year"] = twig_date_format_filter($this->env, "now", "Y");
            // line 195
            echo "                                            ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(range(2007, ($context["year"] ?? $this->getContext($context, "year"))));
            foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
                // line 196
                echo "                                                ";
                if (($context["i"] != 2010)) {
                    // line 197
                    echo "                                                    ";
                    if (($context["i"] == 2007)) {
                        // line 198
                        echo "                                                        <option value=\"";
                        echo twig_escape_filter($this->env, $context["i"], "html", null, true);
                        echo "\" selected>";
                        echo twig_escape_filter($this->env, $context["i"], "html", null, true);
                        echo "</option>
                                                    ";
                    }
                    // line 200
                    echo "                                                    <option value=\"";
                    echo twig_escape_filter($this->env, $context["i"], "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $context["i"], "html", null, true);
                    echo "</option>
                                                ";
                }
                // line 202
                echo "                                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 203
            echo "                                        </select>
                                    </td>
                                    <td></td>
                                    <td>
                                        <a class=\"btn btn-info btn-xs btn-add-award\" style=\"margin: 0px;\" id=\"";
            // line 207
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-plus\"></span> Agregar</a>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </td>
                </tr>
                <tr>
                    <th>Latitud</th>
                    <td><input type=\"number\" name=\"latitude\" value=\"";
            // line 216
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getLatitude", array(), "method"), "html", null, true);
            echo "\" id=\"latitude\" min=\"0\"></td>
                </tr>
                <tr>
                    <th>Longitud</th>
                    <td><input type=\"number\" name=\"longitude\" value=\"";
            // line 220
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getLongitude", array(), "method"), "html", null, true);
            echo "\" id=\"longitude\" min=\"0\"></td>
                </tr>

                <tr>
                    <td class=\"text-center\" colspan=\"2\">
                        <a class='btn btn-success btn-xs btn-save' id=\"";
            // line 225
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-save\"></span> Guardar</a>
                        <a href=\"";
            // line 226
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_homepage");
            echo "\" class=\"btn btn-warning btn-xs\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancelar</a>
                        <a href=\"";
            // line 227
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_product_homepage", array("id" => $this->getAttribute($context["temp"], "getId", array(), "method"))), "html", null, true);
            echo "\" class=\"btn btn-info btn-xs\"><span class=\"glyphicon glyphicon-edit\"></span> Editar productos</a>
                    </td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 231
        echo "            </tbody>
        </table>
    </div>

    <!-- The Modal -->
    <div id=\"errorModal\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
        <!-- Modal content -->
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <span class=\"close\">&times;</span>
                <div id=\"modal-header\">
                    <span class='glyphicon glyphicon-remove-sign modal-icon'></span> <h3 style=\"color: darkred;\" class='modal-p'>Error</h3>
                </div>
            </div>
            <div class=\"modal-body\" id=\"modal-body\">
                <p>Hay errores en algunos campos</p>
                <div id=\"modal-body-error\">
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_4723b5a8667b135445f45178624b5da96ed936edfeacb8c5a4f298d5fe94e317->leave($__internal_4723b5a8667b135445f45178624b5da96ed936edfeacb8c5a4f298d5fe94e317_prof);

    }

    // line 256
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_0eb30cab268e5e7e40979726c196205def8359d4043581df03f06fd5ca0a52eb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0eb30cab268e5e7e40979726c196205def8359d4043581df03f06fd5ca0a52eb->enter($__internal_0eb30cab268e5e7e40979726c196205def8359d4043581df03f06fd5ca0a52eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 257
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
";
        
        $__internal_0eb30cab268e5e7e40979726c196205def8359d4043581df03f06fd5ca0a52eb->leave($__internal_0eb30cab268e5e7e40979726c196205def8359d4043581df03f06fd5ca0a52eb_prof);

    }

    // line 261
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_3c0253c4661b7e6b217600d77cadfc77d9640e19a44794dd32a0052d9767433f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3c0253c4661b7e6b217600d77cadfc77d9640e19a44794dd32a0052d9767433f->enter($__internal_3c0253c4661b7e6b217600d77cadfc77d9640e19a44794dd32a0052d9767433f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 262
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script type=\"text/javascript\" src=\"";
        // line 263
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./js/farm.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_3c0253c4661b7e6b217600d77cadfc77d9640e19a44794dd32a0052d9767433f->leave($__internal_3c0253c4661b7e6b217600d77cadfc77d9640e19a44794dd32a0052d9767433f_prof);

    }

    public function getTemplateName()
    {
        return "FarmBundle:Default:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  614 => 263,  609 => 262,  603 => 261,  593 => 257,  587 => 256,  558 => 231,  548 => 227,  544 => 226,  540 => 225,  532 => 220,  525 => 216,  513 => 207,  507 => 203,  501 => 202,  493 => 200,  485 => 198,  482 => 197,  479 => 196,  474 => 195,  472 => 194,  463 => 187,  457 => 186,  455 => 185,  448 => 183,  442 => 180,  437 => 179,  432 => 177,  426 => 176,  420 => 175,  412 => 174,  407 => 173,  402 => 172,  400 => 171,  382 => 155,  376 => 154,  373 => 153,  363 => 151,  360 => 150,  357 => 149,  351 => 148,  348 => 147,  345 => 146,  343 => 145,  334 => 144,  331 => 143,  328 => 142,  323 => 141,  320 => 140,  316 => 139,  306 => 131,  300 => 130,  297 => 129,  287 => 127,  284 => 126,  281 => 125,  275 => 124,  272 => 123,  269 => 122,  267 => 121,  258 => 120,  255 => 119,  252 => 118,  247 => 117,  244 => 116,  240 => 115,  197 => 75,  186 => 66,  180 => 65,  178 => 64,  171 => 63,  166 => 62,  164 => 61,  159 => 58,  153 => 57,  151 => 56,  144 => 55,  139 => 54,  137 => 53,  131 => 50,  122 => 44,  108 => 33,  100 => 28,  93 => 24,  86 => 20,  82 => 18,  78 => 17,  68 => 9,  62 => 8,  50 => 6,  38 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Mantenimiento de fincas{% endblock %}

{% block navbar %}Mantenimiento de fincas - Editar{% endblock %}

{% block body %}
    <div class=\"row col-md-8 col-md-offset-2 custyle\" style=\"margin-top: 50px\">
        <table class=\"table table-striped custab\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"2\">EDICIÓN DE FINCAS</th>
            </tr>
            </thead>
            <tbody>
            {% for temp in farms %}
                <tr>
                    <th>ID</th>
                    <td> {{ temp.getId() }}</td>
                </tr>
                <tr>
                    <th>Nombre (en inglés)</th>
                    <td><input type=\"text\" name=\"name\" value=\"{{ temp.getName() }}\" id=\"name\"></td>
                </tr>
                <tr>
                    <th>Descripción (en inglés)</th>
                    <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\">{{ temp.getDescription() }}</textarea></td>
                </tr>
                <tr>
                    <th>Imagen</th>
                    <td>
                        <img src=\"{{ temp.getImage() }}\" class=\"mediana\">
                        <form id=\"myform\" method=\"post\" style=\"margin-top: 5px;\">
                            <input type=\"button\" id=\"loadFileXml\" value=\"Seleccione un archivo\" onclick=\"document.getElementById('image').click();\" />
                            <input id=\"image\" style=\"display:none;\" type=\"file\" name=\"upload\" />
                        </form>
                        <p id=\"imageError\" style=\"color: red; display: none;\"><small>Selecciona una imagen </small></p>
                        <p id=\"image1Error\" style=\"color: red; display: none;\"><small>Selecciona una imagen con la extensión .jpg, .jpeg, .gif o .png</small></p>
                    </td>
                </tr>
                <tr>
                    <th>Nombre de la región</th>
                    <td>{{ temp.region.name }}
                    </td>
                </tr>
                <tr>
                    <th>Elevación</th>
                    <td>
                        <p name=\"elevation\" id=\"elevation\">{{ temp.getElevation() }}</p>
                        <label>Min:</label>
                        <select name=\"elevation-Min\" id=\"elevation-Min\">
                            {% set ele = 500 %}
                            {% for i in 1..16 %}
                                <option value=\"{{ ele }}\">{{ ele }}</option>
                                {% set ele = ele+100 %}
                            {% endfor %}
                        </select>
                        <label>Max:</label>
                        <select name=\"elevation-Max\" id=\"elevation-Max\">
                            {% set ele = 2000 %}
                            {% for i in 1..16 %}
                                <option value=\"{{ ele }}\">{{ ele }}</option>
                                {% set ele = ele-100 %}
                            {% endfor %}
                        </select>
                        <p id=\"elevationError\" style=\"color: red; display: none;\"><small>Seleccione un valor mínimo o máximo</small></p>
                        <p id=\"elevationError-min\" style=\"color: red; display: none;\"><small>El valor mínimo no puede ser mayor o igual al valor máximo</small></p>
                        <p id=\"elevationError-max\" style=\"color: red; display: none;\"><small>El valor máximo no puede ser menor o igual al valor mínimo</small></p>
                    </td>
                </tr>
                <tr>
                    <th>Cosecha</th>
                    <td>
                       <p name=\"harvest\" id=\"harvest\">{{ temp.getHarvest() }}</p>
                       <label>Empieza:</label>
                       <select name=\"harvest-begin\" id=\"harvest-begin\">
                           <option value=\"January\">January</option>
                           <option value=\"February\">February</option>
                           <option value=\"March\">March</option>
                           <option value=\"April\">April</option>
                           <option value=\"May\">May</option>
                           <option value=\"June\">June</option>
                           <option value=\"July\">July</option>
                           <option value=\"August\">August</option>
                           <option value=\"September\">September</option>
                           <option value=\"October\">October</option>
                           <option value=\"November\">November</option>
                           <option value=\"December\">December </option>
                       </select>
                       <label>Termina:</label>
                       <select name=\"harvest-end\" id=\"harvest-end\">
                            <option value=\"December\">December </option>
                            <option value=\"November\">November</option>
                            <option value=\"October\">October</option>
                            <option value=\"September\">September</option>
                            <option value=\"August\">August</option>
                            <option value=\"July\">July</option>
                            <option value=\"June\">June</option>
                            <option value=\"May\">May</option>
                            <option value=\"April\">April</option>
                            <option value=\"March\">March</option>
                            <option value=\"February\">February</option>
                            <option value=\"January\">January</option>
                       </select>
                        <p id=\"harvestError\" style=\"color: red; display: none;\"><small>Indique el valor para cuado empiza o termina la cosecha</small></p>
                        <p id=\"harvestError-begin\" style=\"color: red; display: none;\"><small>El mes en el empieza la cosecha no puede ser igual al mes en que termina</small></p>
                        <p id=\"harvestError-end\" style=\"color: red; display: none;\"><small>El mes en el termina la cosecha no puede ser igual al mes en que empieza</small></p>
                    </td>
                </tr>
                <tr>
                    <th>Cultivar</th>
                    <td>
                        <form>
                            {% for culti in cultivars %}
                                {% set flag = 0 %}
                                {% for aux in temp.cultivars() %}
                                    {% if  aux.getId() == culti.getId() %}
                                        {% if culti.getId() != 1 %}
                                            <input type=\"checkbox\" name=\"cultivar\" id=\"{{ temp.getId() }}\" value=\"{{ culti.getId() }}\" checked> {{ culti.getDescription() }}</br>
                                            {% set flag = 1 %}
                                        {% endif %}
                                    {% endif %}
                                {% endfor %}
                                {% if flag == 0 %}
                                    {% if culti.getId() != 1 %}
                                        <input type=\"checkbox\" name=\"cultivar\" id=\"{{ temp.getId() }}\" value=\"{{ culti.getId() }}\"> {{ culti.getDescription() }}</br>
                                    {% endif %}
                                 {% endif %}
                            {% endfor %}
                        </form>
                        <p id=\"cultivarError\" style=\"color: red; display: none;\"><small>Selecciona una opción</small></p>
                    </td>
                </tr>
                <tr>
                    <th>Certificaciones</th>
                    <td>
                        <form>
                            {% for certi in certifications %}
                                {% set flag = 0 %}
                                {% for aux in temp.certifications() %}
                                    {% if  aux.getId() == certi.getId() %}
                                        {% if certi.getId() != 1 %}
                                            <input type=\"checkbox\" name=\"certification\" id=\"{{ temp.getId() }}\" value=\"{{ certi.getId() }}\" checked> {{ certi.getDescription() }}</br>
                                            {% set flag = 1 %}
                                        {% endif %}
                                    {% endif %}
                                {% endfor %}
                                {% if flag == 0 %}
                                    {% if certi.getId() != 1 %}
                                        <input type=\"checkbox\" name=\"certification\" id=\"{{ temp.getId() }}\" value=\"{{ certi.getId() }}\" > {{ certi.getDescription() }}</br>
                                    {% endif %}
                                {% endif %}
                            {% endfor %}
                        </form>
                        <p id=\"certificationError\" style=\"color: red; display: none;\"><small>Selecciona una opción</small></p>
                    </td>
                </tr>
                <tr>
                    <th>Premios</th>
                    <td>
                        <table class=\"table table-striped\" id=\"table-awards\">
                            <thead>
                                <th></th>
                                <th>Lugar</th>
                                <th>Año</th>
                                <th>Certificado</th>
                                <th>Acción</th>
                            </thead>
                            <tbody id=\"tbody-awards\">
                                {% set num=1 %}
                                {% for award in temp.GetfarmAwards() %}
                                    <tr id=\"{{ num }}\">
                                        <td class=\"award-description-{{ num }}\" id=\"{{ award.getAward().getId() }}\">{{ award.getAward().getDescription() }}</td>
                                        <td class=\"award-place-{{ num }}\">{{ award.getPlace() }}</td>
                                        <td class=\"award-year-{{ num }}\">{{ award.getYear() }}</td>
                                        <td id=\"td-pdf-{{ num }}\">
                                            <p>
                                                <a style=\"margin: 0; padding-left: 14px; padding-right: 14px;\" class=\"btn btn-default btn-xs\" onclick=\"window.open('{{ award.getPDF() }}')\" >{#{{ award.getPDF()[27:] }}#}  Mostrar certificado  </a><br>
                                                <a style=\"margin: 0; margin-top: 5px;\" class=\"btn btn-danger btn-xs btn-delete-pdf\" id=\"{{ num }}\"><span class=\"glyphicon glyphicon-minus\"></span> Eliminar certificado</a>
                                            </p>
                                        </td>
                                        <td><a class=\"btn btn-danger btn-xs btn-delete-award\" id=\"{{ temp.getId() }}-{{ num }}\"><span class=\"glyphicon glyphicon-minus\"></span> Eliminar</a></td>
                                    </tr>
                                    {% set num=num+1 %}
                                {% endfor %}
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td class=\"award-description-add\" id=\"2\">Cup of Excellence</td>
                                    <td><input type=\"number\" name=\"place\" value=\"1\" id=\"place\" min=\"1\" class=\"textboxclass\"></td>
                                    <td>
                                        <select name=\"year\" id=\"year\">
                                            {% set year= \"now\"|date(\"Y\") %}
                                            {% for i in 2007..year %}
                                                {% if i != 2010 %}
                                                    {% if i == 2007 %}
                                                        <option value=\"{{ i }}\" selected>{{ i }}</option>
                                                    {% endif %}
                                                    <option value=\"{{ i }}\">{{ i }}</option>
                                                {% endif %}
                                            {% endfor %}
                                        </select>
                                    </td>
                                    <td></td>
                                    <td>
                                        <a class=\"btn btn-info btn-xs btn-add-award\" style=\"margin: 0px;\" id=\"{{ temp.getId() }}\"><span class=\"glyphicon glyphicon-plus\"></span> Agregar</a>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </td>
                </tr>
                <tr>
                    <th>Latitud</th>
                    <td><input type=\"number\" name=\"latitude\" value=\"{{ temp.getLatitude() }}\" id=\"latitude\" min=\"0\"></td>
                </tr>
                <tr>
                    <th>Longitud</th>
                    <td><input type=\"number\" name=\"longitude\" value=\"{{ temp.getLongitude() }}\" id=\"longitude\" min=\"0\"></td>
                </tr>

                <tr>
                    <td class=\"text-center\" colspan=\"2\">
                        <a class='btn btn-success btn-xs btn-save' id=\"{{ temp.getId() }}\"><span class=\"glyphicon glyphicon-save\"></span> Guardar</a>
                        <a href=\"{{ path('farm_homepage') }}\" class=\"btn btn-warning btn-xs\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancelar</a>
                        <a href=\"{{ path('farm_product_homepage', { 'id': temp.getId() }) }}\" class=\"btn btn-info btn-xs\"><span class=\"glyphicon glyphicon-edit\"></span> Editar productos</a>
                    </td>
                </tr>
            {% endfor %}
            </tbody>
        </table>
    </div>

    <!-- The Modal -->
    <div id=\"errorModal\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
        <!-- Modal content -->
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <span class=\"close\">&times;</span>
                <div id=\"modal-header\">
                    <span class='glyphicon glyphicon-remove-sign modal-icon'></span> <h3 style=\"color: darkred;\" class='modal-p'>Error</h3>
                </div>
            </div>
            <div class=\"modal-body\" id=\"modal-body\">
                <p>Hay errores en algunos campos</p>
                <div id=\"modal-body-error\">
                </div>
            </div>
        </div>
    </div>
{% endblock %}


{% block stylesheets %}
    {{ parent() }}
{% endblock %}


{% block javascripts %}
    {{ parent() }}
    <script type=\"text/javascript\" src=\"{{ asset('./js/farm.js') }}\"></script>
{% endblock %}", "FarmBundle:Default:edit.html.twig", "C:\\xampp\\htdocs\\siteadminBootstrap4\\src\\FarmBundle\\Resources\\views\\Default\\edit.html.twig");
    }
}
