<?php

/* AppBundle:Default:home.html.twig */
class __TwigTemplate_dd5a524ce693a69621118671bea53125799b4b24ddaf87b9d26f4d31d198a310 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "AppBundle:Default:home.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d4ce7c8f2d6a3b67b1b8884b47665b5088b9b03ca6cbd3aba0c733562155174e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d4ce7c8f2d6a3b67b1b8884b47665b5088b9b03ca6cbd3aba0c733562155174e->enter($__internal_d4ce7c8f2d6a3b67b1b8884b47665b5088b9b03ca6cbd3aba0c733562155174e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Default:home.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d4ce7c8f2d6a3b67b1b8884b47665b5088b9b03ca6cbd3aba0c733562155174e->leave($__internal_d4ce7c8f2d6a3b67b1b8884b47665b5088b9b03ca6cbd3aba0c733562155174e_prof);

    }

    // line 4
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_c5a637f22c34d91c8fd876536d5267e786c4ad88fb7afddc6b1a893393aca297 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c5a637f22c34d91c8fd876536d5267e786c4ad88fb7afddc6b1a893393aca297->enter($__internal_c5a637f22c34d91c8fd876536d5267e786c4ad88fb7afddc6b1a893393aca297_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 5
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    ";
        
        $__internal_c5a637f22c34d91c8fd876536d5267e786c4ad88fb7afddc6b1a893393aca297->leave($__internal_c5a637f22c34d91c8fd876536d5267e786c4ad88fb7afddc6b1a893393aca297_prof);

    }

    // line 9
    public function block_title($context, array $blocks = array())
    {
        $__internal_5f6de75c7f97058cc29b4a92fc18207083efc91de4644d3945d6ea1e96da0ec0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5f6de75c7f97058cc29b4a92fc18207083efc91de4644d3945d6ea1e96da0ec0->enter($__internal_5f6de75c7f97058cc29b4a92fc18207083efc91de4644d3945d6ea1e96da0ec0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 10
        echo "    Principal
";
        
        $__internal_5f6de75c7f97058cc29b4a92fc18207083efc91de4644d3945d6ea1e96da0ec0->leave($__internal_5f6de75c7f97058cc29b4a92fc18207083efc91de4644d3945d6ea1e96da0ec0_prof);

    }

    // line 13
    public function block_body($context, array $blocks = array())
    {
        $__internal_9368177cd360c121d9226eba2c9abbec3b93c629cdedbf035fdb3674f8d987ef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9368177cd360c121d9226eba2c9abbec3b93c629cdedbf035fdb3674f8d987ef->enter($__internal_9368177cd360c121d9226eba2c9abbec3b93c629cdedbf035fdb3674f8d987ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 14
        echo "    <section class=\"principal-menu no-padding-bottom\">
    
      <div class=\"container-fluid\">
        <div class=\"row bg-white has-shadow\">
          <!-- Item -->
            <div class=\"col-xl-3 col-sm-6\">
              <div class=\"item d-flex align-items-center\">
                <div class=\"icon bg-light-brown\"><i class=\"fa fa-coffee\" aria-hidden=\"true\"></i></div>
                <div class=\"title\"><span>Regiones</span>
                  <div class=\"see-button-menu\">
                    <a href=\"";
        // line 24
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_homepage");
        echo "\" class=\"btn btn-link\"><i class=\"fa fa-eye\" aria-hidden=\"true\"></i> Ver</a>
                  </div>
                </div>
              </div>
            </div>
          <!-- Item -->
          <div class=\"col-xl-3 col-sm-6\">
              <div class=\"item d-flex align-items-center\">
                <div class=\"icon bg-dark-brown\"><i class=\"fa fa-coffee\" aria-hidden=\"true\"></i></div>
                <div class=\"title\"><span>Fincas</span>
                  <div class=\"see-button-menu\">
                    <a href=\"";
        // line 35
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_homepage");
        echo "\" class=\"btn btn-link\"><i class=\"fa fa-eye\" aria-hidden=\"true\"></i> Ver</a>
                  </div>
                </div>
              </div>
            </div>

            <!-- Item -->
            <div class=\"col-xl-3 col-sm-6\">
              <div class=\"item d-flex align-items-center\">
                <div class=\"icon bg-light-brown\"><i class=\"fa fa-coffee\" aria-hidden=\"true\"></i></div>
                <div class=\"title\"><span></span></div>
              </div>
            </div>
          <!-- Item -->
          <div class=\"col-xl-3 col-sm-6\">
              <div class=\"item d-flex align-items-center\">
                <div class=\"icon bg-dark-brown\"><i class=\"fa fa-coffee\" aria-hidden=\"true\"></i></div>
                <div class=\"title\"><span></span></div>
              </div>
            </div>


        </div>
      </section>
";
        
        $__internal_9368177cd360c121d9226eba2c9abbec3b93c629cdedbf035fdb3674f8d987ef->leave($__internal_9368177cd360c121d9226eba2c9abbec3b93c629cdedbf035fdb3674f8d987ef_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Default:home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  98 => 35,  84 => 24,  72 => 14,  66 => 13,  58 => 10,  52 => 9,  42 => 5,  36 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block stylesheets %}
    {{parent()}}
    {#<link rel=\"stylesheet\" href=\"{{ asset('./css/style.default.css')}}\" id=\"theme-stylesheet\">#}
{% endblock %}

{% block title %}
    Principal
{% endblock %}

{% block body %}
    <section class=\"principal-menu no-padding-bottom\">
    
      <div class=\"container-fluid\">
        <div class=\"row bg-white has-shadow\">
          <!-- Item -->
            <div class=\"col-xl-3 col-sm-6\">
              <div class=\"item d-flex align-items-center\">
                <div class=\"icon bg-light-brown\"><i class=\"fa fa-coffee\" aria-hidden=\"true\"></i></div>
                <div class=\"title\"><span>Regiones</span>
                  <div class=\"see-button-menu\">
                    <a href=\"{{ path('region_homepage') }}\" class=\"btn btn-link\"><i class=\"fa fa-eye\" aria-hidden=\"true\"></i> Ver</a>
                  </div>
                </div>
              </div>
            </div>
          <!-- Item -->
          <div class=\"col-xl-3 col-sm-6\">
              <div class=\"item d-flex align-items-center\">
                <div class=\"icon bg-dark-brown\"><i class=\"fa fa-coffee\" aria-hidden=\"true\"></i></div>
                <div class=\"title\"><span>Fincas</span>
                  <div class=\"see-button-menu\">
                    <a href=\"{{ path('farm_homepage') }}\" class=\"btn btn-link\"><i class=\"fa fa-eye\" aria-hidden=\"true\"></i> Ver</a>
                  </div>
                </div>
              </div>
            </div>

            <!-- Item -->
            <div class=\"col-xl-3 col-sm-6\">
              <div class=\"item d-flex align-items-center\">
                <div class=\"icon bg-light-brown\"><i class=\"fa fa-coffee\" aria-hidden=\"true\"></i></div>
                <div class=\"title\"><span></span></div>
              </div>
            </div>
          <!-- Item -->
          <div class=\"col-xl-3 col-sm-6\">
              <div class=\"item d-flex align-items-center\">
                <div class=\"icon bg-dark-brown\"><i class=\"fa fa-coffee\" aria-hidden=\"true\"></i></div>
                <div class=\"title\"><span></span></div>
              </div>
            </div>


        </div>
      </section>
{% endblock %}", "AppBundle:Default:home.html.twig", "C:\\xampp\\htdocs\\siteadminBootstrap4\\src\\AppBundle\\Resources\\views\\Default\\home.html.twig");
    }
}
