<?php

/* FarmBundle:Default:editProduct.html.twig */
class __TwigTemplate_a64d60031e3c7172abca34eed3c5726cbcae7c71aa4372e6eac5d4dd70a498d4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "FarmBundle:Default:editProduct.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8ac57eb907293b6527c5ee95e237bbc85dd806bc25edeb0cdcbd7efdb655f59c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ac57eb907293b6527c5ee95e237bbc85dd806bc25edeb0cdcbd7efdb655f59c->enter($__internal_8ac57eb907293b6527c5ee95e237bbc85dd806bc25edeb0cdcbd7efdb655f59c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FarmBundle:Default:editProduct.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8ac57eb907293b6527c5ee95e237bbc85dd806bc25edeb0cdcbd7efdb655f59c->leave($__internal_8ac57eb907293b6527c5ee95e237bbc85dd806bc25edeb0cdcbd7efdb655f59c_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_e08519ff319dc6d9ed4b9ba5b4e42dbe3c438ce0bad8efe789642cc48dfd8edf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e08519ff319dc6d9ed4b9ba5b4e42dbe3c438ce0bad8efe789642cc48dfd8edf->enter($__internal_e08519ff319dc6d9ed4b9ba5b4e42dbe3c438ce0bad8efe789642cc48dfd8edf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Mantenimiento de productos";
        
        $__internal_e08519ff319dc6d9ed4b9ba5b4e42dbe3c438ce0bad8efe789642cc48dfd8edf->leave($__internal_e08519ff319dc6d9ed4b9ba5b4e42dbe3c438ce0bad8efe789642cc48dfd8edf_prof);

    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        $__internal_06f2701f2307421eeb2d3360043d799dab71df76c87de41fcc03dcd513a61f8e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_06f2701f2307421eeb2d3360043d799dab71df76c87de41fcc03dcd513a61f8e->enter($__internal_06f2701f2307421eeb2d3360043d799dab71df76c87de41fcc03dcd513a61f8e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "    <div class=\"row col-md-8 col-md-offset-2 custyle product-body\" style=\"margin-top: 20px\">
        <table class=\"table table-striped custab\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"2\">EDICIÓN DE PRODUCTOS</th>
            </tr>
            </thead>
            <tbody>
            ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["products"] ?? $this->getContext($context, "products")));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 16
            echo "                <tr>
                    <th>ID</th>
                    <td> ";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "</td>
                </tr>
                <tr>
                    <th>Nombre</th>
                    <td><input type=\"text\" name=\"name\" value=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo "\" id=\"name\"></td>
                </tr>
                <tr>
                    <th>Descripción</th>
                    <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\">";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getDescription", array(), "method"), "html", null, true);
            echo "</textarea></td>
                </tr>
                <tr>
                    <th>Imagen</th>
                    <td>
                        <img src=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage", array(), "method"), "html", null, true);
            echo "\" class=\"mediana\">
                        <form id=\"myform1\" method=\"post\" style=\"margin-top: 5px;\">
                            <input type=\"button\" id=\"loadFileXml\" value=\"Seleccione un archivo\" onclick=\"document.getElementById('image').click();\" />
                            <input id=\"image\" style=\"display:none;\" type=\"file\" name=\"upload\" />
                        </form>
                        <p id=\"imageError\" style=\"color: red; display: none;\"><small>Selecciona una imagen </small></p>
                        <p id=\"image1Error\" style=\"color: red; display: none;\"><small>Selecciona una imagen con la extensión .jpg, .jpeg, .gif o .png</small></p>
                    </td>
                </tr>
                <tr>
                    <th>Nombre de la finca</th>
                    <td>";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["temp"], "getFarm", array(), "method"), "getName", array(), "method"), "html", null, true);
            echo "</td>
                </tr>
                <tr>
                    <th>Cultivar</th>
                    <td>
                        <select name=\"cultivar\" id=\"cultivar\">
                            ";
            // line 48
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["cultivars"] ?? $this->getContext($context, "cultivars")));
            foreach ($context['_seq'] as $context["_key"] => $context["culti"]) {
                // line 49
                echo "                                ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($context["temp"], "getFarm", array(), "method"), "getCultivars", array(), "method"));
                foreach ($context['_seq'] as $context["_key"] => $context["aux"]) {
                    // line 50
                    echo "                                    ";
                    if (($this->getAttribute($context["aux"], "getId", array(), "method") == $this->getAttribute($context["culti"], "getId", array(), "method"))) {
                        // line 51
                        echo "                                        ";
                        if (($this->getAttribute($this->getAttribute($context["temp"], "getCultivar", array(), "method"), "getId", array(), "method") == $this->getAttribute($context["culti"], "getId", array(), "method"))) {
                            // line 52
                            echo "                                            <option value=\"";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getId", array(), "method"), "html", null, true);
                            echo "\" selected> ";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getDescription", array(), "method"), "html", null, true);
                            echo "</option>
                                        ";
                        } else {
                            // line 54
                            echo "                                            <option value=\"";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getId", array(), "method"), "html", null, true);
                            echo "\"> ";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getDescription", array(), "method"), "html", null, true);
                            echo "</option>
                                        ";
                        }
                        // line 56
                        echo "                                    ";
                    }
                    // line 57
                    echo "                                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['aux'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 58
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['culti'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 59
            echo "                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Grado</th>
                    <td>
                        <select name=\"grade\" id=\"grade\">
                            ";
            // line 66
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["grade"] ?? $this->getContext($context, "grade")));
            foreach ($context['_seq'] as $context["_key"] => $context["gr"]) {
                // line 67
                echo "                                ";
                if (($this->getAttribute($context["gr"], "getId", array(), "method") != 1)) {
                    // line 68
                    echo "                                    ";
                    if (($this->getAttribute($this->getAttribute($context["temp"], "getGrade", array(), "method"), "getId", array(), "method") == $this->getAttribute($context["gr"], "getId", array(), "method"))) {
                        // line 69
                        echo "                                        <option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["gr"], "getId", array(), "method"), "html", null, true);
                        echo "\" selected> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["gr"], "getDescription", array(), "method"), "html", null, true);
                        echo "</option>
                                    ";
                    } else {
                        // line 71
                        echo "                                        <option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["gr"], "getId", array(), "method"), "html", null, true);
                        echo "\"> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["gr"], "getDescription", array(), "method"), "html", null, true);
                        echo "</option>
                                    ";
                    }
                    // line 73
                    echo "                                ";
                }
                // line 74
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['gr'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 75
            echo "                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Tratamiento</th>
                    <td>
                        <select name=\"processing\" id=\"processing\">
                            ";
            // line 82
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["processing"] ?? $this->getContext($context, "processing")));
            foreach ($context['_seq'] as $context["_key"] => $context["pr"]) {
                // line 83
                echo "                                ";
                if (($this->getAttribute($context["pr"], "getId", array(), "method") != 1)) {
                    // line 84
                    echo "                                    ";
                    if (($this->getAttribute($this->getAttribute($context["temp"], "getProcessing", array(), "method"), "getId", array(), "method") == $this->getAttribute($context["pr"], "getId", array(), "method"))) {
                        // line 85
                        echo "                                        <option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["pr"], "getId", array(), "method"), "html", null, true);
                        echo "\" selected> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["pr"], "getDescription", array(), "method"), "html", null, true);
                        echo "</option>
                                    ";
                    } else {
                        // line 87
                        echo "                                        <option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["pr"], "getId", array(), "method"), "html", null, true);
                        echo "\"> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["pr"], "getDescription", array(), "method"), "html", null, true);
                        echo "</option>
                                    ";
                    }
                    // line 89
                    echo "                                ";
                }
                // line 90
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pr'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 91
            echo "                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Sabor</th>
                    <td>
                        <select name=\"flavor\" id=\"flavor\">
                            ";
            // line 98
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["flavor"] ?? $this->getContext($context, "flavor")));
            foreach ($context['_seq'] as $context["_key"] => $context["fl"]) {
                // line 99
                echo "                                ";
                if (($this->getAttribute($context["fl"], "getId", array(), "method") != 1)) {
                    // line 100
                    echo "                                    ";
                    if (($this->getAttribute($this->getAttribute($context["temp"], "getFlavor", array(), "method"), "getId", array(), "method") == $this->getAttribute($context["fl"], "getId", array(), "method"))) {
                        // line 101
                        echo "                                        <option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["fl"], "getId", array(), "method"), "html", null, true);
                        echo "\" selected> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["fl"], "notes", array(), "method"), "html", null, true);
                        echo "</option>
                                    ";
                    } else {
                        // line 103
                        echo "                                        <option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["fl"], "getId", array(), "method"), "html", null, true);
                        echo "\"> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["fl"], "notes", array(), "method"), "html", null, true);
                        echo "</option>
                                    ";
                    }
                    // line 105
                    echo "                                ";
                }
                // line 106
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fl'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 107
            echo "                        </select>
                    </td>
                </tr>
                <tr>
                    <th class=\"text-center\" colspan=\"2\">
                        PRESENTACIONES
                        <a class=\"btn btn-primary btn-xs pull-right btn-add-presentation\" style=\"margin: 0px;\"><span class=\"glyphicon glyphicon-plus\"></span> Agregar Presentación</a>
                    </th>
                </tr>

                <tr>
                    <td colspan=\"2\">
                        <table class=\"table table-striped custab\" id=\"table-presentations\">
                            <thead>
                                <th>Tostado</th>
                                <th>Molido</th>
                                <th>Peso</th>
                                <th>Precio</th>
                                <th></th>
                            </thead>
                            <tbody id=\"tbody-presentations\">
                                ";
            // line 128
            $context["num"] = 1;
            // line 129
            echo "                                ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["temp"], "getPresentations", array(), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["presentation"]) {
                // line 130
                echo "                                    <tr id=\"";
                echo twig_escape_filter($this->env, ($context["num"] ?? $this->getContext($context, "num")), "html", null, true);
                echo "\">
                                        <td class=\"presentation-roast-";
                // line 131
                echo twig_escape_filter($this->env, ($context["num"] ?? $this->getContext($context, "num")), "html", null, true);
                echo "\" id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["presentation"], "getRoast", array(), "method"), "getId", array(), "method"), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["presentation"], "getRoast", array(), "method"), "getDescription", array(), "method"), "html", null, true);
                echo "</td>
                                        <td class=\"presentation-grind-";
                // line 132
                echo twig_escape_filter($this->env, ($context["num"] ?? $this->getContext($context, "num")), "html", null, true);
                echo "\" id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["presentation"], "getGrind", array(), "method"), "getId", array(), "method"), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["presentation"], "getGrind", array(), "method"), "getDescription", array(), "method"), "html", null, true);
                echo "</td>
                                        <td class=\"presentation-weight-";
                // line 133
                echo twig_escape_filter($this->env, ($context["num"] ?? $this->getContext($context, "num")), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["presentation"], "getWeight", array(), "method"), "html", null, true);
                echo "</td>
                                        <td class=\"presentation-price-";
                // line 134
                echo twig_escape_filter($this->env, ($context["num"] ?? $this->getContext($context, "num")), "html", null, true);
                echo "\">\$";
                echo twig_escape_filter($this->env, $this->getAttribute($context["presentation"], "getPrice", array(), "method"), "html", null, true);
                echo "</td>
                                        <td>
                                            <a class=\"btn btn-xs btn-danger btn-delete-presentation\" style=\"margin: 0px;\" id=\"";
                // line 136
                echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
                echo "-";
                echo twig_escape_filter($this->env, ($context["num"] ?? $this->getContext($context, "num")), "html", null, true);
                echo "\" name=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["presentation"], "getId", array(), "method"), "html", null, true);
                echo "\"><span class=\"glyphicon glyphicon-minus\"></span> Eliminar</a>
                                        </td>
                                    </tr>
                                    ";
                // line 139
                $context["num"] = (($context["num"] ?? $this->getContext($context, "num")) + 1);
                // line 140
                echo "                                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['presentation'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 141
            echo "                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td class=\"text-center\" colspan=\"2\">
                        <a class='btn btn-success btn-xs btn-save' id=\"";
            // line 147
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-save\"></span> Guardar</a>
                        <a href=\"";
            // line 148
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_product_homepage", array("id" => $this->getAttribute($this->getAttribute($context["temp"], "farm", array()), "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-warning btn-xs\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancelar</a>
                    </td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 152
        echo "            </tbody>
        </table>
    </div>

    <!-- The Modal Add Presentations -->
    <div id=\"addPresentation\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
            <!-- Modal content -->
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <span class=\"close\">&times;</span>
                    <h3>Agregar Presentación</h3>
                </div>
                <div class=\"modal-body\" id=\"modal-body\">
                    <form>
                        <div class=\"form-group row\">
                            <label class=\"col-sm-3 form-control-label\">Tostado</label>
                            <div class=\"col-sm-9\">
                                ";
        // line 170
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["roast"] ?? $this->getContext($context, "roast")));
        foreach ($context['_seq'] as $context["_key"] => $context["rt"]) {
            // line 171
            echo "                                    ";
            if (($this->getAttribute($context["rt"], "id", array()) != 1)) {
                // line 172
                echo "                                        <label class=\"radio-inline\" for=\"roast";
                echo twig_escape_filter($this->env, $this->getAttribute($context["rt"], "id", array()), "html", null, true);
                echo "\">
                                            <input type=\"radio\" name=\"roast\" id=\"roast";
                // line 173
                echo twig_escape_filter($this->env, $this->getAttribute($context["rt"], "id", array()), "html", null, true);
                echo "\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["rt"], "id", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["rt"], "description", array()), "html", null, true);
                echo "
                                        </label>
                                    ";
            }
            // line 176
            echo "                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['rt'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 177
        echo "                            </div>
                            <p id=\"roastError\" style=\"color: red; display: none;\"><small>Seleccione un tipo de tostado</small></p>
                        </div>
                        <div class=\"form-group row\">
                            <label class=\"col-sm-3 form-control-label\">Molido</label>
                            <div class=\"col-sm-9\">
                                ";
        // line 183
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["grind"] ?? $this->getContext($context, "grind")));
        foreach ($context['_seq'] as $context["_key"] => $context["gd"]) {
            // line 184
            echo "                                    ";
            if (($this->getAttribute($context["gd"], "id", array()) != 1)) {
                // line 185
                echo "                                        <label class=\"radio-inline\" for=\"grind";
                echo twig_escape_filter($this->env, $this->getAttribute($context["gd"], "id", array()), "html", null, true);
                echo "\">
                                            <input type=\"radio\" name=\"grind\" id=\"grind";
                // line 186
                echo twig_escape_filter($this->env, $this->getAttribute($context["gd"], "id", array()), "html", null, true);
                echo "\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["gd"], "id", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["gd"], "description", array()), "html", null, true);
                echo "
                                        </label>
                                    ";
            }
            // line 189
            echo "                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['gd'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 190
        echo "                            </div>
                            <p id=\"grindError\" style=\"color: red; display: none;\"><small>Seleccione un tipo de molido</small></p>
                        </div>
                        <div class=\"form-group\">
                            <div class=\"row\">
                                <label class=\"col-sm-3 form-control-label\">Peso</label>
                                <div class=\"col-sm-9\">
                                    <label class=\"radio-inline\" for=\"onzas\">
                                        <input type=\"radio\" name=\"onzas\" id=\"onzas\" value=\"oz\">oz
                                    </label>
                                    <label class=\"radio-inline\" for=\"gramos\">
                                        <input type=\"radio\" name=\"onzas\" id=\"gramos\" value=\"g\">g
                                    </label>
                                </div>
                            </div>
                            <input type=\"number\" placeholder=\"Peso\" id=\"weight\" class=\"form-control\" min=\"1\" disabled>
                            <p id=\"weightError\" style=\"color: red; display: none;\"><small>Ingrese un peso</small></p>
                        </div>
                        <div class=\"form-group\">
                            <label>Precio</label>
                            <input type=\"number\" placeholder=\"Precio\" id=\"price\" class=\"form-control\" min=\"1\">
                            <p id=\"priceError\" style=\"color: red; display: none;\"><small>Ingrese un precio</small></p>
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                    <button type=\"button\" class=\"btn btn-primary btn-save-presentation\">Guardar cambios</button>
                    <button type=\"button\" class=\"btn btn-close-modal\" style=\"margin: 0px;\">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

     <!-- The Modal -->
    <div id=\"errorModal\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
        <!-- Modal content -->
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <span class=\"close close-error\">&times;</span>
                <div id=\"modal-header\">
                    <h3 style=\"color: red;\">Error</h3>
                </div>
            </div>
            <div class=\"modal-body\" id=\"modal-body\">
                <span class='glyphicon glyphicon-remove-sign modal-icon'></span>
                <p class='modal-p'>Algunos campos se encuentran en blanco</p>
                <div id=\"modal-body-error\">
                </div>
            </div>
        </div>
    </div>

    ";
        // line 278
        echo "
";
        
        $__internal_06f2701f2307421eeb2d3360043d799dab71df76c87de41fcc03dcd513a61f8e->leave($__internal_06f2701f2307421eeb2d3360043d799dab71df76c87de41fcc03dcd513a61f8e_prof);

    }

    // line 282
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_32476a94f0ac92929878ad42a03bb3f9116bb5318dfaf3cfd37bed19b0ec742a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_32476a94f0ac92929878ad42a03bb3f9116bb5318dfaf3cfd37bed19b0ec742a->enter($__internal_32476a94f0ac92929878ad42a03bb3f9116bb5318dfaf3cfd37bed19b0ec742a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 283
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 284
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 285
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/css/styles.css"), "html", null, true);
        echo "\">
";
        
        $__internal_32476a94f0ac92929878ad42a03bb3f9116bb5318dfaf3cfd37bed19b0ec742a->leave($__internal_32476a94f0ac92929878ad42a03bb3f9116bb5318dfaf3cfd37bed19b0ec742a_prof);

    }

    // line 289
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_96cd64bae5b1ffc9acd68985f85e8992643709965ac01d2522644c222bc44e7e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_96cd64bae5b1ffc9acd68985f85e8992643709965ac01d2522644c222bc44e7e->enter($__internal_96cd64bae5b1ffc9acd68985f85e8992643709965ac01d2522644c222bc44e7e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 290
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script type=\"text/javascript\" src=\"";
        // line 291
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/js/products.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_96cd64bae5b1ffc9acd68985f85e8992643709965ac01d2522644c222bc44e7e->leave($__internal_96cd64bae5b1ffc9acd68985f85e8992643709965ac01d2522644c222bc44e7e_prof);

    }

    public function getTemplateName()
    {
        return "FarmBundle:Default:editProduct.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  582 => 291,  577 => 290,  571 => 289,  562 => 285,  558 => 284,  553 => 283,  547 => 282,  539 => 278,  484 => 190,  478 => 189,  468 => 186,  463 => 185,  460 => 184,  456 => 183,  448 => 177,  442 => 176,  432 => 173,  427 => 172,  424 => 171,  420 => 170,  400 => 152,  390 => 148,  386 => 147,  378 => 141,  372 => 140,  370 => 139,  360 => 136,  353 => 134,  347 => 133,  339 => 132,  331 => 131,  326 => 130,  321 => 129,  319 => 128,  296 => 107,  290 => 106,  287 => 105,  279 => 103,  271 => 101,  268 => 100,  265 => 99,  261 => 98,  252 => 91,  246 => 90,  243 => 89,  235 => 87,  227 => 85,  224 => 84,  221 => 83,  217 => 82,  208 => 75,  202 => 74,  199 => 73,  191 => 71,  183 => 69,  180 => 68,  177 => 67,  173 => 66,  164 => 59,  158 => 58,  152 => 57,  149 => 56,  141 => 54,  133 => 52,  130 => 51,  127 => 50,  122 => 49,  118 => 48,  109 => 42,  95 => 31,  87 => 26,  80 => 22,  73 => 18,  69 => 16,  65 => 15,  55 => 7,  49 => 6,  37 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Mantenimiento de productos{% endblock %}

{% block body %}
    <div class=\"row col-md-8 col-md-offset-2 custyle product-body\" style=\"margin-top: 20px\">
        <table class=\"table table-striped custab\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"2\">EDICIÓN DE PRODUCTOS</th>
            </tr>
            </thead>
            <tbody>
            {% for temp in products %}
                <tr>
                    <th>ID</th>
                    <td> {{ temp.getId() }}</td>
                </tr>
                <tr>
                    <th>Nombre</th>
                    <td><input type=\"text\" name=\"name\" value=\"{{ temp.getName() }}\" id=\"name\"></td>
                </tr>
                <tr>
                    <th>Descripción</th>
                    <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\">{{ temp.getDescription() }}</textarea></td>
                </tr>
                <tr>
                    <th>Imagen</th>
                    <td>
                        <img src=\"{{ temp.getImage() }}\" class=\"mediana\">
                        <form id=\"myform1\" method=\"post\" style=\"margin-top: 5px;\">
                            <input type=\"button\" id=\"loadFileXml\" value=\"Seleccione un archivo\" onclick=\"document.getElementById('image').click();\" />
                            <input id=\"image\" style=\"display:none;\" type=\"file\" name=\"upload\" />
                        </form>
                        <p id=\"imageError\" style=\"color: red; display: none;\"><small>Selecciona una imagen </small></p>
                        <p id=\"image1Error\" style=\"color: red; display: none;\"><small>Selecciona una imagen con la extensión .jpg, .jpeg, .gif o .png</small></p>
                    </td>
                </tr>
                <tr>
                    <th>Nombre de la finca</th>
                    <td>{{ temp.getFarm().getName() }}</td>
                </tr>
                <tr>
                    <th>Cultivar</th>
                    <td>
                        <select name=\"cultivar\" id=\"cultivar\">
                            {% for culti in cultivars %}
                                {% for aux in temp.getFarm().getCultivars() %}
                                    {% if  aux.getId() == culti.getId() %}
                                        {% if  temp.getCultivar().getId() == culti.getId() %}
                                            <option value=\"{{ culti.getId() }}\" selected> {{ culti.getDescription() }}</option>
                                        {% else %}
                                            <option value=\"{{ culti.getId() }}\"> {{ culti.getDescription() }}</option>
                                        {% endif %}
                                    {% endif %}
                                {% endfor %}
                            {% endfor %}
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Grado</th>
                    <td>
                        <select name=\"grade\" id=\"grade\">
                            {% for gr in grade %}
                                {% if  gr.getId() != 1 %}
                                    {% if  temp.getGrade().getId() == gr.getId() %}
                                        <option value=\"{{ gr.getId() }}\" selected> {{ gr.getDescription() }}</option>
                                    {% else %}
                                        <option value=\"{{ gr.getId() }}\"> {{ gr.getDescription() }}</option>
                                    {% endif %}
                                {% endif %}
                            {% endfor %}
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Tratamiento</th>
                    <td>
                        <select name=\"processing\" id=\"processing\">
                            {% for pr in processing %}
                                {% if  pr.getId() != 1 %}
                                    {% if  temp.getProcessing().getId() == pr.getId() %}
                                        <option value=\"{{ pr.getId() }}\" selected> {{ pr.getDescription() }}</option>
                                    {% else %}
                                        <option value=\"{{ pr.getId() }}\"> {{ pr.getDescription() }}</option>
                                    {% endif %}
                                {% endif %}
                            {% endfor %}
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Sabor</th>
                    <td>
                        <select name=\"flavor\" id=\"flavor\">
                            {% for fl in flavor %}
                                {% if  fl.getId() != 1 %}
                                    {% if  temp.getFlavor().getId() == fl.getId() %}
                                        <option value=\"{{ fl.getId() }}\" selected> {{ fl.notes() }}</option>
                                    {% else %}
                                        <option value=\"{{ fl.getId() }}\"> {{ fl.notes() }}</option>
                                    {% endif %}
                                {% endif %}
                            {% endfor %}
                        </select>
                    </td>
                </tr>
                <tr>
                    <th class=\"text-center\" colspan=\"2\">
                        PRESENTACIONES
                        <a class=\"btn btn-primary btn-xs pull-right btn-add-presentation\" style=\"margin: 0px;\"><span class=\"glyphicon glyphicon-plus\"></span> Agregar Presentación</a>
                    </th>
                </tr>

                <tr>
                    <td colspan=\"2\">
                        <table class=\"table table-striped custab\" id=\"table-presentations\">
                            <thead>
                                <th>Tostado</th>
                                <th>Molido</th>
                                <th>Peso</th>
                                <th>Precio</th>
                                <th></th>
                            </thead>
                            <tbody id=\"tbody-presentations\">
                                {% set num=1 %}
                                {% for presentation in temp.getPresentations() %}
                                    <tr id=\"{{ num }}\">
                                        <td class=\"presentation-roast-{{ num }}\" id=\"{{ presentation.getRoast().getId() }}\">{{ presentation.getRoast().getDescription() }}</td>
                                        <td class=\"presentation-grind-{{ num }}\" id=\"{{ presentation.getGrind().getId() }}\">{{ presentation.getGrind().getDescription() }}</td>
                                        <td class=\"presentation-weight-{{ num }}\">{{ presentation.getWeight() }}</td>
                                        <td class=\"presentation-price-{{ num }}\">\${{ presentation.getPrice() }}</td>
                                        <td>
                                            <a class=\"btn btn-xs btn-danger btn-delete-presentation\" style=\"margin: 0px;\" id=\"{{ temp.getId() }}-{{ num }}\" name=\"{{ presentation.getId()}}\"><span class=\"glyphicon glyphicon-minus\"></span> Eliminar</a>
                                        </td>
                                    </tr>
                                    {% set num=num+1 %}
                                {% endfor %}
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td class=\"text-center\" colspan=\"2\">
                        <a class='btn btn-success btn-xs btn-save' id=\"{{ temp.getId() }}\"><span class=\"glyphicon glyphicon-save\"></span> Guardar</a>
                        <a href=\"{{ path('farm_product_homepage', {'id': temp.farm.id}) }}\" class=\"btn btn-warning btn-xs\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancelar</a>
                    </td>
                </tr>
            {% endfor %}
            </tbody>
        </table>
    </div>

    <!-- The Modal Add Presentations -->
    <div id=\"addPresentation\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
            <!-- Modal content -->
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <span class=\"close\">&times;</span>
                    <h3>Agregar Presentación</h3>
                </div>
                <div class=\"modal-body\" id=\"modal-body\">
                    <form>
                        <div class=\"form-group row\">
                            <label class=\"col-sm-3 form-control-label\">Tostado</label>
                            <div class=\"col-sm-9\">
                                {% for rt in roast %}
                                    {% if rt.id != 1 %}
                                        <label class=\"radio-inline\" for=\"roast{{ rt.id }}\">
                                            <input type=\"radio\" name=\"roast\" id=\"roast{{ rt.id }}\" value=\"{{ rt.id }}\">{{ rt.description }}
                                        </label>
                                    {% endif %}
                                {% endfor %}
                            </div>
                            <p id=\"roastError\" style=\"color: red; display: none;\"><small>Seleccione un tipo de tostado</small></p>
                        </div>
                        <div class=\"form-group row\">
                            <label class=\"col-sm-3 form-control-label\">Molido</label>
                            <div class=\"col-sm-9\">
                                {% for gd in grind %}
                                    {% if gd.id != 1 %}
                                        <label class=\"radio-inline\" for=\"grind{{ gd.id }}\">
                                            <input type=\"radio\" name=\"grind\" id=\"grind{{ gd.id }}\" value=\"{{ gd.id }}\">{{ gd.description }}
                                        </label>
                                    {% endif %}
                                {% endfor %}
                            </div>
                            <p id=\"grindError\" style=\"color: red; display: none;\"><small>Seleccione un tipo de molido</small></p>
                        </div>
                        <div class=\"form-group\">
                            <div class=\"row\">
                                <label class=\"col-sm-3 form-control-label\">Peso</label>
                                <div class=\"col-sm-9\">
                                    <label class=\"radio-inline\" for=\"onzas\">
                                        <input type=\"radio\" name=\"onzas\" id=\"onzas\" value=\"oz\">oz
                                    </label>
                                    <label class=\"radio-inline\" for=\"gramos\">
                                        <input type=\"radio\" name=\"onzas\" id=\"gramos\" value=\"g\">g
                                    </label>
                                </div>
                            </div>
                            <input type=\"number\" placeholder=\"Peso\" id=\"weight\" class=\"form-control\" min=\"1\" disabled>
                            <p id=\"weightError\" style=\"color: red; display: none;\"><small>Ingrese un peso</small></p>
                        </div>
                        <div class=\"form-group\">
                            <label>Precio</label>
                            <input type=\"number\" placeholder=\"Precio\" id=\"price\" class=\"form-control\" min=\"1\">
                            <p id=\"priceError\" style=\"color: red; display: none;\"><small>Ingrese un precio</small></p>
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                    <button type=\"button\" class=\"btn btn-primary btn-save-presentation\">Guardar cambios</button>
                    <button type=\"button\" class=\"btn btn-close-modal\" style=\"margin: 0px;\">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

     <!-- The Modal -->
    <div id=\"errorModal\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
        <!-- Modal content -->
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <span class=\"close close-error\">&times;</span>
                <div id=\"modal-header\">
                    <h3 style=\"color: red;\">Error</h3>
                </div>
            </div>
            <div class=\"modal-body\" id=\"modal-body\">
                <span class='glyphicon glyphicon-remove-sign modal-icon'></span>
                <p class='modal-p'>Algunos campos se encuentran en blanco</p>
                <div id=\"modal-body-error\">
                </div>
            </div>
        </div>
    </div>

    {#<div class=\"col-lg-6\">
        <div class=\"card\">
            <div class=\"card-close\">
                <div class=\"dropdown\">
                    <button type=\"button\" id=\"closeCard\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\" class=\"dropdown-toggle\"><i class=\"fa fa-ellipsis-v\"></i></button>
                    <div aria-labelledby=\"closeCard\" class=\"dropdown-menu has-shadow\"><a href=\"#\" class=\"dropdown-item remove\"> <i class=\"fa fa-times\"></i>Close</a><a href=\"#\" class=\"dropdown-item edit\"> <i class=\"fa fa-gear\"></i>Edit</a></div>
                </div>
            </div>
            <div class=\"card-header d-flex align-items-center\">
                <h3 class=\"h4\">Horizontal Form</h3>
            </div>
            <div class=\"card-body\">
                <p>Lorem ipsum dolor sit amet consectetur.</p>
                <form class=\"form-horizontal\">
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 form-control-label\">Email</label>
                        <div class=\"col-sm-9\">
                            <input id=\"inputHorizontalSuccess\" type=\"email\" placeholder=\"Email Address\" class=\"form-control form-control-success\"><small class=\"form-text\">Example help text that remains unchanged.</small>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 form-control-label\">Password</label>
                        <div class=\"col-sm-9\">
                            <input id=\"inputHorizontalWarning\" type=\"password\" placeholder=\"Pasword\" class=\"form-control form-control-warning\"><small class=\"form-text\">Example help text that remains unchanged.</small>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <div class=\"col-sm-9 offset-sm-3\">
                            <input type=\"submit\" value=\"Signin\" class=\"btn btn-primary\">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>#}

{% endblock %}


{% block stylesheets %}
    {{ parent() }}
    <link rel=\"stylesheet\" href=\"{{ asset('/siteadmin/web/css/crgourmetcoffee.css') }}\">
    <link rel=\"stylesheet\" href=\"{{ asset('/siteadmin/web/css/styles.css') }}\">
{% endblock %}


{% block javascripts %}
    {{ parent() }}
    <script type=\"text/javascript\" src=\"{{ asset('/siteadmin/web/js/products.js') }}\"></script>
{% endblock %}", "FarmBundle:Default:editProduct.html.twig", "C:\\xampp\\htdocs\\siteadmin\\src\\FarmBundle\\Resources\\views\\Default\\editProduct.html.twig");
    }
}
