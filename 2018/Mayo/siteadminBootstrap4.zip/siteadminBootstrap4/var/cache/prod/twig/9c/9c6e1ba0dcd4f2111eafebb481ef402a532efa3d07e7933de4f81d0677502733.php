<?php

/* layout.html.twig */
class __TwigTemplate_8a8bc3ce1965070487f4cb3ca98c8e1c915e98578145921d7213f7ea460e7784 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b9786a5ecf9ca2bd27327a2b94c293a8d06a08582e266e92c584da7f58f678d2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b9786a5ecf9ca2bd27327a2b94c293a8d06a08582e266e92c584da7f58f678d2->enter($__internal_b9786a5ecf9ca2bd27327a2b94c293a8d06a08582e266e92c584da7f58f678d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"es\">
    <head>
        <meta charset=\"UTF-8\"/>
        <title>
            ";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        // line 9
        echo "        </title>
        <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css\"
              integrity=\"sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7\" crossorigin=\"anonymous\">
        ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 13
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/favicon.ico"), "html", null, true);
        echo "\"/>
    </head>
    <body>

        <div class=\"container\">
            ";
        // line 18
        $this->loadTemplate("header.html.twig", "layout.html.twig", 18)->display($context);
        // line 19
        echo "            ";
        $this->displayBlock('body', $context, $blocks);
        // line 20
        echo "        </div>

        <script type=\"text/javascript\" src=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
        ";
        // line 23
        $this->displayBlock('javascripts', $context, $blocks);
        // line 24
        echo "    </body>
</html>";
        
        $__internal_b9786a5ecf9ca2bd27327a2b94c293a8d06a08582e266e92c584da7f58f678d2->leave($__internal_b9786a5ecf9ca2bd27327a2b94c293a8d06a08582e266e92c584da7f58f678d2_prof);

    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        $__internal_f899af66779a6b3be89e002a0c628e68d33f192b7fd7f895c876da8ac318885f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f899af66779a6b3be89e002a0c628e68d33f192b7fd7f895c876da8ac318885f->enter($__internal_f899af66779a6b3be89e002a0c628e68d33f192b7fd7f895c876da8ac318885f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 7
        echo "                Mantenimiento
            ";
        
        $__internal_f899af66779a6b3be89e002a0c628e68d33f192b7fd7f895c876da8ac318885f->leave($__internal_f899af66779a6b3be89e002a0c628e68d33f192b7fd7f895c876da8ac318885f_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_bff28b325d5bd91ec69bb5c1b52aa48034e5544237fa711e558679066a13602b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bff28b325d5bd91ec69bb5c1b52aa48034e5544237fa711e558679066a13602b->enter($__internal_bff28b325d5bd91ec69bb5c1b52aa48034e5544237fa711e558679066a13602b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_bff28b325d5bd91ec69bb5c1b52aa48034e5544237fa711e558679066a13602b->leave($__internal_bff28b325d5bd91ec69bb5c1b52aa48034e5544237fa711e558679066a13602b_prof);

    }

    // line 19
    public function block_body($context, array $blocks = array())
    {
        $__internal_703ab31edbbc3cceec4226ff8d4b9d6ebb133648d178ae6aa7d5ff1e3e55b093 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_703ab31edbbc3cceec4226ff8d4b9d6ebb133648d178ae6aa7d5ff1e3e55b093->enter($__internal_703ab31edbbc3cceec4226ff8d4b9d6ebb133648d178ae6aa7d5ff1e3e55b093_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_703ab31edbbc3cceec4226ff8d4b9d6ebb133648d178ae6aa7d5ff1e3e55b093->leave($__internal_703ab31edbbc3cceec4226ff8d4b9d6ebb133648d178ae6aa7d5ff1e3e55b093_prof);

    }

    // line 23
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_76326ad293e582da41a36951efc6230cba6d9d598703f0edec8eb54f1f586bc3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_76326ad293e582da41a36951efc6230cba6d9d598703f0edec8eb54f1f586bc3->enter($__internal_76326ad293e582da41a36951efc6230cba6d9d598703f0edec8eb54f1f586bc3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_76326ad293e582da41a36951efc6230cba6d9d598703f0edec8eb54f1f586bc3->leave($__internal_76326ad293e582da41a36951efc6230cba6d9d598703f0edec8eb54f1f586bc3_prof);

    }

    public function getTemplateName()
    {
        return "layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  110 => 23,  99 => 19,  88 => 12,  80 => 7,  74 => 6,  66 => 24,  64 => 23,  60 => 22,  56 => 20,  53 => 19,  51 => 18,  42 => 13,  40 => 12,  35 => 9,  33 => 6,  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"es\">
    <head>
        <meta charset=\"UTF-8\"/>
        <title>
            {% block title %}
                Mantenimiento
            {% endblock %}
        </title>
        <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css\"
              integrity=\"sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7\" crossorigin=\"anonymous\">
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('/siteadmin/web/favicon.ico') }}\"/>
    </head>
    <body>

        <div class=\"container\">
            {% include \"header.html.twig\" %}
            {% block body %}{% endblock %}
        </div>

        <script type=\"text/javascript\" src=\"{{ asset('/siteadmin/web/js/jquery-3.2.0.min.js') }}\"></script>
        {% block javascripts %}{% endblock %}
    </body>
</html>", "layout.html.twig", "/Applications/MAMP/htdocs/siteadmin/app/Resources/views/layout.html.twig");
    }
}
