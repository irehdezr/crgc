<?php

/* FarmBundle:Default:editProduct.html.twig */
class __TwigTemplate_d3d9aed355806719100f3c6fe9146b56f17bc6d6213d6e5b46c8cd72652f459b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "FarmBundle:Default:editProduct.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Product Maintenance";
    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        // line 7
        echo "    <div class=\"row col-md-8 col-md-offset-2 custyle\" style=\"margin-top: 20px\">
        <table class=\"table table-striped custab\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"2\">EDIT PRODUCT</th>
            </tr>
            </thead>
            <tbody>
            ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["products"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 16
            echo "                <tr>
                    <th>ID</th>
                    <td> ";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "</td>
                </tr>
                <tr>
                    <th>Name</th>
                    <td><input type=\"text\" name=\"name\" value=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo "\" id=\"name\"></td>
                </tr>
                <tr>
                    <th>Description</th>
                    <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\">";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getDescription", array(), "method"), "html", null, true);
            echo "</textarea></td>
                </tr>
                <tr>
                    <th>Image</th>
                    <td>
                        <img src=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage", array(), "method"), "html", null, true);
            echo "\" class=\"mediana\">
                        <form id=\"myform1\" method=\"post\" style=\"margin-top: 5px;\">
                            <input type=\"button\" id=\"loadFileXml\" value=\"Choose file\" onclick=\"document.getElementById('image').click();\" />
                            <input id=\"image\" style=\"display:none;\" type=\"file\" name=\"upload\" />
                        </form>
                    </td>
                </tr>
                <tr>
                    <th>Farm Name</th>
                    <td>";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["temp"], "getFarm", array(), "method"), "getName", array(), "method"), "html", null, true);
            echo "</td>
                </tr>
                <tr>
                    <th>Cultivar</th>
                    <td>
                        <select name=\"cultivar\" id=\"cultivar\">
                            ";
            // line 46
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["cultivars"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["culti"]) {
                // line 47
                echo "                                ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($context["temp"], "getFarm", array(), "method"), "getCultivars", array(), "method"));
                foreach ($context['_seq'] as $context["_key"] => $context["aux"]) {
                    // line 48
                    echo "                                    ";
                    if (($this->getAttribute($context["aux"], "getId", array(), "method") == $this->getAttribute($context["culti"], "getId", array(), "method"))) {
                        // line 49
                        echo "                                        ";
                        if (($this->getAttribute($this->getAttribute($context["temp"], "getCultivar", array(), "method"), "getId", array(), "method") == $this->getAttribute($context["culti"], "getId", array(), "method"))) {
                            // line 50
                            echo "                                            <option value=\"";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getId", array(), "method"), "html", null, true);
                            echo "\" selected> ";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getDescription", array(), "method"), "html", null, true);
                            echo "</option>
                                        ";
                        } else {
                            // line 52
                            echo "                                            <option value=\"";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getId", array(), "method"), "html", null, true);
                            echo "\"> ";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getDescription", array(), "method"), "html", null, true);
                            echo "</option>
                                        ";
                        }
                        // line 54
                        echo "                                    ";
                    }
                    // line 55
                    echo "                                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['aux'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 56
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['culti'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 57
            echo "                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Grade</th>
                    <td>
                        <select name=\"grade\" id=\"grade\">
                            ";
            // line 64
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["grade"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["gr"]) {
                // line 65
                echo "                                ";
                if (($this->getAttribute($context["gr"], "getId", array(), "method") != 1)) {
                    // line 66
                    echo "                                    ";
                    if (($this->getAttribute($this->getAttribute($context["temp"], "getGrade", array(), "method"), "getId", array(), "method") == $this->getAttribute($context["gr"], "getId", array(), "method"))) {
                        // line 67
                        echo "                                        <option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["gr"], "getId", array(), "method"), "html", null, true);
                        echo "\" selected> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["gr"], "getDescription", array(), "method"), "html", null, true);
                        echo "</option>
                                    ";
                    } else {
                        // line 69
                        echo "                                        <option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["gr"], "getId", array(), "method"), "html", null, true);
                        echo "\"> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["gr"], "getDescription", array(), "method"), "html", null, true);
                        echo "</option>
                                    ";
                    }
                    // line 71
                    echo "                                ";
                }
                // line 72
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['gr'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 73
            echo "                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Processing</th>
                    <td>
                        <select name=\"processing\" id=\"processing\">
                            ";
            // line 80
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["processing"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["pr"]) {
                // line 81
                echo "                                ";
                if (($this->getAttribute($context["pr"], "getId", array(), "method") != 1)) {
                    // line 82
                    echo "                                    ";
                    if (($this->getAttribute($this->getAttribute($context["temp"], "getProcessing", array(), "method"), "getId", array(), "method") == $this->getAttribute($context["pr"], "getId", array(), "method"))) {
                        // line 83
                        echo "                                        <option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["pr"], "getId", array(), "method"), "html", null, true);
                        echo "\" selected> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["pr"], "getDescription", array(), "method"), "html", null, true);
                        echo "</option>
                                    ";
                    } else {
                        // line 85
                        echo "                                        <option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["pr"], "getId", array(), "method"), "html", null, true);
                        echo "\"> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["pr"], "getDescription", array(), "method"), "html", null, true);
                        echo "</option>
                                    ";
                    }
                    // line 87
                    echo "                                ";
                }
                // line 88
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pr'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 89
            echo "                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Flavor</th>
                    <td>
                        <select name=\"flavor\" id=\"flavor\">
                            ";
            // line 96
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["flavor"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["fl"]) {
                // line 97
                echo "                                ";
                if (($this->getAttribute($context["fl"], "getId", array(), "method") != 1)) {
                    // line 98
                    echo "                                    ";
                    if (($this->getAttribute($this->getAttribute($context["temp"], "getFlavor", array(), "method"), "getId", array(), "method") == $this->getAttribute($context["fl"], "getId", array(), "method"))) {
                        // line 99
                        echo "                                        <option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["fl"], "getId", array(), "method"), "html", null, true);
                        echo "\" selected> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["fl"], "notes", array(), "method"), "html", null, true);
                        echo "</option>
                                    ";
                    } else {
                        // line 101
                        echo "                                        <option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["fl"], "getId", array(), "method"), "html", null, true);
                        echo "\"> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["fl"], "notes", array(), "method"), "html", null, true);
                        echo "</option>
                                    ";
                    }
                    // line 103
                    echo "                                ";
                }
                // line 104
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fl'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 105
            echo "                        </select>
                    </td>
                </tr>
                ";
            // line 116
            echo "                <tr>
                    <td class=\"text-center\" colspan=\"2\">
                        <a ";
            // line 118
            echo " class='btn btn-success btn-xs btn-save' id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-save\"></span> Save</a>
                        <a href=\"";
            // line 119
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_product_homepage", array("id" => $this->getAttribute($this->getAttribute($context["temp"], "farm", array()), "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-warning btn-xs\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancel</a>
                    </td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 123
        echo "            </tbody>
        </table>
    </div>
";
    }

    // line 129
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 130
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 131
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/styles.css"), "html", null, true);
        echo "\">
";
    }

    // line 135
    public function block_javascripts($context, array $blocks = array())
    {
        // line 136
        echo "    <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 137
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/js/products.js"), "html", null, true);
        echo "\"></script>
";
    }

    public function getTemplateName()
    {
        return "FarmBundle:Default:editProduct.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  332 => 137,  327 => 136,  324 => 135,  318 => 131,  313 => 130,  310 => 129,  303 => 123,  293 => 119,  288 => 118,  284 => 116,  279 => 105,  273 => 104,  270 => 103,  262 => 101,  254 => 99,  251 => 98,  248 => 97,  244 => 96,  235 => 89,  229 => 88,  226 => 87,  218 => 85,  210 => 83,  207 => 82,  204 => 81,  200 => 80,  191 => 73,  185 => 72,  182 => 71,  174 => 69,  166 => 67,  163 => 66,  160 => 65,  156 => 64,  147 => 57,  141 => 56,  135 => 55,  132 => 54,  124 => 52,  116 => 50,  113 => 49,  110 => 48,  105 => 47,  101 => 46,  92 => 40,  80 => 31,  72 => 26,  65 => 22,  58 => 18,  54 => 16,  50 => 15,  40 => 7,  37 => 6,  31 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "FarmBundle:Default:editProduct.html.twig", "C:\\xampp\\htdocs\\src\\FarmBundle/Resources/views/Default/editProduct.html.twig");
    }
}
