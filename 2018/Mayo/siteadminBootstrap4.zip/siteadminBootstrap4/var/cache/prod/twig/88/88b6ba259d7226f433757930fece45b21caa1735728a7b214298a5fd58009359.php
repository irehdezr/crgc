<?php

/* header.html.twig */
class __TwigTemplate_e5decc5ec9e92d53d067a3f9b7bd38845acdd51a690556a3a011272068be0408 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d224b650b5360e5fc40b787c2fc4625716a7603685c529068e58cdaed1914d9d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d224b650b5360e5fc40b787c2fc4625716a7603685c529068e58cdaed1914d9d->enter($__internal_d224b650b5360e5fc40b787c2fc4625716a7603685c529068e58cdaed1914d9d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "header.html.twig"));

        // line 1
        echo "
    <nav class=\"navbar navbar-dark navbar-expand-md fixed-top nav-siteadmin\">
    <!-- Navbar content -->
        <a class=\"navbar-brand\" href=\"#\">cr<span style=\"font-weight: bold;\">gourmet</span><span style=\"font-weight: bold; color: #ddb26e;\">coffee.com</span></a>
        <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#myNavbar\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
            <span class=\"navbar-toggler-icon\"></span>
        </button>

        <div class=\"collapse navbar-collapse\" id=\"myNavbar\">
            <ul class=\"navbar-nav mr-auto mt-2 mt-lg-0\">
                <li class=\"nav-item\">
                    <a class=\"nav-link text-white\" href=\"";
        // line 12
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_homepage");
        echo "\">Principal</a>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link text-white\" href=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_homepage");
        echo "\">Regiones</a>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link text-white\" href=\"";
        // line 18
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_homepage");
        echo "\">Fincas</a>
                </li>
            </ul>
        </div>
    </nav>
";
        
        $__internal_d224b650b5360e5fc40b787c2fc4625716a7603685c529068e58cdaed1914d9d->leave($__internal_d224b650b5360e5fc40b787c2fc4625716a7603685c529068e58cdaed1914d9d_prof);

    }

    public function getTemplateName()
    {
        return "header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  47 => 18,  41 => 15,  35 => 12,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("
    <nav class=\"navbar navbar-dark navbar-expand-md fixed-top nav-siteadmin\">
    <!-- Navbar content -->
        <a class=\"navbar-brand\" href=\"#\">cr<span style=\"font-weight: bold;\">gourmet</span><span style=\"font-weight: bold; color: #ddb26e;\">coffee.com</span></a>
        <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#myNavbar\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
            <span class=\"navbar-toggler-icon\"></span>
        </button>

        <div class=\"collapse navbar-collapse\" id=\"myNavbar\">
            <ul class=\"navbar-nav mr-auto mt-2 mt-lg-0\">
                <li class=\"nav-item\">
                    <a class=\"nav-link text-white\" href=\"{{ path('app_homepage') }}\">Principal</a>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link text-white\" href=\"{{ path('region_homepage') }}\">Regiones</a>
                </li>
                <li class=\"nav-item\">
                    <a class=\"nav-link text-white\" href=\"{{ path('farm_homepage') }}\">Fincas</a>
                </li>
            </ul>
        </div>
    </nav>
", "header.html.twig", "C:\\xampp\\htdocs\\siteadminBootstrap4\\app\\Resources\\views\\header.html.twig");
    }
}
