<?php

/* @Product/Default/edit.html.twig */
class __TwigTemplate_fcbce1de727eb1bcd7886630a0e73189356a87b37dd5516c480b40417aefbb1f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "@Product/Default/edit.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Product Maintenance";
    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        // line 7
        echo "    <div class=\"row col-md-8 col-md-offset-2 custyle\" style=\"margin-top: 20px\">
        <table class=\"table table-striped custab\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"2\">EDIT PRODUCT</th>
            </tr>
            </thead>
            <tbody>
            ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["products"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 16
            echo "                <tr>
                    <th>ID</th>
                    <td> ";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "</td>
                </tr>
                <tr>
                    <th>Name</th>
                    <td><input type=\"text\" name=\"name\" value=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo "\" id=\"name\"></td>
                </tr>
                <tr>
                    <th>Description</th>
                    <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\">";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getDescription", array(), "method"), "html", null, true);
            echo "</textarea></td>
                </tr>
                <tr>
                    <th>Image</th>
                    <td>
                        <img src=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage", array(), "method"), "html", null, true);
            echo "\" class=\"mediana\">
                        <form id=\"myform1\" method=\"post\" style=\"margin-top: 5px;\">
                            <input type=\"button\" id=\"loadFileXml\" value=\"Choose file\" onclick=\"document.getElementById('image').click();\" />
                            <input id=\"image\" style=\"display:none;\" type=\"file\" name=\"upload\" />
                        </form>
                    </td>
                </tr>
                <tr>
                    <th>Farm Name</th>
                    <td>";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["temp"], "getFarm", array(), "method"), "getName", array(), "method"), "html", null, true);
            echo "
                        ";
            // line 50
            echo "                    </td>
                </tr>
                <tr>
                    <th>Cultivar</th>
                    <td>
                        <select name=\"cultivar\" id=\"cultivar\">
                            ";
            // line 56
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["cultivars"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["culti"]) {
                // line 57
                echo "                                ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($context["temp"], "getFarm", array(), "method"), "getCultivars", array(), "method"));
                foreach ($context['_seq'] as $context["_key"] => $context["aux"]) {
                    // line 58
                    echo "                                    ";
                    if (($this->getAttribute($context["aux"], "getId", array(), "method") == $this->getAttribute($context["culti"], "getId", array(), "method"))) {
                        // line 59
                        echo "                                        ";
                        if (($this->getAttribute($this->getAttribute($context["temp"], "getCultivar", array(), "method"), "getId", array(), "method") == $this->getAttribute($context["culti"], "getId", array(), "method"))) {
                            // line 60
                            echo "                                            <option value=\"";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getId", array(), "method"), "html", null, true);
                            echo "\" selected> ";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getDescription", array(), "method"), "html", null, true);
                            echo "</option>
                                        ";
                        } else {
                            // line 62
                            echo "                                            <option value=\"";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getId", array(), "method"), "html", null, true);
                            echo "\"> ";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getDescription", array(), "method"), "html", null, true);
                            echo "</option>
                                        ";
                        }
                        // line 64
                        echo "                                    ";
                    }
                    // line 65
                    echo "                                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['aux'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 66
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['culti'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 67
            echo "                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Grade</th>
                    <td>
                        <select name=\"grade\" id=\"grade\">
                            ";
            // line 74
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["grade"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["gr"]) {
                // line 75
                echo "                                ";
                if (($this->getAttribute($context["gr"], "getId", array(), "method") != 1)) {
                    // line 76
                    echo "                                    ";
                    if (($this->getAttribute($this->getAttribute($context["temp"], "getGrade", array(), "method"), "getId", array(), "method") == $this->getAttribute($context["gr"], "getId", array(), "method"))) {
                        // line 77
                        echo "                                        <option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["gr"], "getId", array(), "method"), "html", null, true);
                        echo "\" selected> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["gr"], "getDescription", array(), "method"), "html", null, true);
                        echo "</option>
                                    ";
                    } else {
                        // line 79
                        echo "                                        <option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["gr"], "getId", array(), "method"), "html", null, true);
                        echo "\"> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["gr"], "getDescription", array(), "method"), "html", null, true);
                        echo "</option>
                                    ";
                    }
                    // line 81
                    echo "                                ";
                }
                // line 82
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['gr'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 83
            echo "                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Processing</th>
                    <td>
                        <select name=\"processing\" id=\"processing\">
                            ";
            // line 90
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["processing"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["pr"]) {
                // line 91
                echo "                                ";
                if (($this->getAttribute($context["pr"], "getId", array(), "method") != 1)) {
                    // line 92
                    echo "                                    ";
                    if (($this->getAttribute($this->getAttribute($context["temp"], "getProcessing", array(), "method"), "getId", array(), "method") == $this->getAttribute($context["pr"], "getId", array(), "method"))) {
                        // line 93
                        echo "                                        <option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["pr"], "getId", array(), "method"), "html", null, true);
                        echo "\" selected> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["pr"], "getDescription", array(), "method"), "html", null, true);
                        echo "</option>
                                    ";
                    } else {
                        // line 95
                        echo "                                        <option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["pr"], "getId", array(), "method"), "html", null, true);
                        echo "\"> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["pr"], "getDescription", array(), "method"), "html", null, true);
                        echo "</option>
                                    ";
                    }
                    // line 97
                    echo "                                ";
                }
                // line 98
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pr'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 99
            echo "                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Flavor</th>
                    <td>
                        <select name=\"flavor\" id=\"flavor\">
                            ";
            // line 106
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["flavor"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["fl"]) {
                // line 107
                echo "                                ";
                if (($this->getAttribute($context["fl"], "getId", array(), "method") != 1)) {
                    // line 108
                    echo "                                    ";
                    if (($this->getAttribute($this->getAttribute($context["temp"], "getFlavor", array(), "method"), "getId", array(), "method") == $this->getAttribute($context["fl"], "getId", array(), "method"))) {
                        // line 109
                        echo "                                        <option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["fl"], "getId", array(), "method"), "html", null, true);
                        echo "\" selected> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["fl"], "notes", array(), "method"), "html", null, true);
                        echo "</option>
                                    ";
                    } else {
                        // line 111
                        echo "                                        <option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["fl"], "getId", array(), "method"), "html", null, true);
                        echo "\"> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["fl"], "notes", array(), "method"), "html", null, true);
                        echo "</option>
                                    ";
                    }
                    // line 113
                    echo "                                ";
                }
                // line 114
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fl'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 115
            echo "                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Rank</th>
                    <td><input type=\"text\" name=\"rank\" value=\"";
            // line 120
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getRank", array(), "method"), "html", null, true);
            echo "\" id=\"rank\"></td>
                </tr>
                <tr>
                    <th>Reviews</th>
                    <td><input type=\"text\" name=\"review\" value=\"";
            // line 124
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getReviews", array(), "method"), "html", null, true);
            echo "\" id=\"review\"></td>
                </tr>

                <tr>
                    <td class=\"text-center\" colspan=\"2\">
                        <a class='btn btn-success btn-xs btn-save' id=\"";
            // line 129
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-save\"></span> Save</a>
                        <a href=\"";
            // line 130
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("product_homepage");
            echo "\" class=\"btn btn-warning btn-xs\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancel</a>
                    </td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 134
        echo "            </tbody>
        </table>
    </div>
";
    }

    // line 140
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 141
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 142
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/styles.css"), "html", null, true);
        echo "\">
";
    }

    // line 146
    public function block_javascripts($context, array $blocks = array())
    {
        // line 147
        echo "    <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 148
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/js/products.js"), "html", null, true);
        echo "\"></script>
";
    }

    public function getTemplateName()
    {
        return "@Product/Default/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  347 => 148,  342 => 147,  339 => 146,  333 => 142,  328 => 141,  325 => 140,  318 => 134,  308 => 130,  304 => 129,  296 => 124,  289 => 120,  282 => 115,  276 => 114,  273 => 113,  265 => 111,  257 => 109,  254 => 108,  251 => 107,  247 => 106,  238 => 99,  232 => 98,  229 => 97,  221 => 95,  213 => 93,  210 => 92,  207 => 91,  203 => 90,  194 => 83,  188 => 82,  185 => 81,  177 => 79,  169 => 77,  166 => 76,  163 => 75,  159 => 74,  150 => 67,  144 => 66,  138 => 65,  135 => 64,  127 => 62,  119 => 60,  116 => 59,  113 => 58,  108 => 57,  104 => 56,  96 => 50,  92 => 40,  80 => 31,  72 => 26,  65 => 22,  58 => 18,  54 => 16,  50 => 15,  40 => 7,  37 => 6,  31 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Product/Default/edit.html.twig", "C:\\xampp\\htdocs\\src\\ProductBundle\\Resources\\views\\Default\\edit.html.twig");
    }
}
