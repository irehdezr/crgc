<?php

/* FarmBundle:Default:insertProduct.html.twig */
class __TwigTemplate_98bba5208d0688f5b66e31f2bcb5672948c17f31d471d81fa0a988d1a96a70a7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "FarmBundle:Default:insertProduct.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e06b7398c6232206586bc602a57832afdc27c56476c0ec805dfbd5dfc271ec15 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e06b7398c6232206586bc602a57832afdc27c56476c0ec805dfbd5dfc271ec15->enter($__internal_e06b7398c6232206586bc602a57832afdc27c56476c0ec805dfbd5dfc271ec15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FarmBundle:Default:insertProduct.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e06b7398c6232206586bc602a57832afdc27c56476c0ec805dfbd5dfc271ec15->leave($__internal_e06b7398c6232206586bc602a57832afdc27c56476c0ec805dfbd5dfc271ec15_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_d740e6933db7885c6b17ff5cb894dbb41d3810bb88a189249c171648bae0b1fd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d740e6933db7885c6b17ff5cb894dbb41d3810bb88a189249c171648bae0b1fd->enter($__internal_d740e6933db7885c6b17ff5cb894dbb41d3810bb88a189249c171648bae0b1fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Mantenimiento de Productos";
        
        $__internal_d740e6933db7885c6b17ff5cb894dbb41d3810bb88a189249c171648bae0b1fd->leave($__internal_d740e6933db7885c6b17ff5cb894dbb41d3810bb88a189249c171648bae0b1fd_prof);

    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        $__internal_bae0cae1d383d34b8d7e868b9ff3d7930cfe07c0f5f543c2d27f9697a5349bb2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bae0cae1d383d34b8d7e868b9ff3d7930cfe07c0f5f543c2d27f9697a5349bb2->enter($__internal_bae0cae1d383d34b8d7e868b9ff3d7930cfe07c0f5f543c2d27f9697a5349bb2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "    <div class=\"row col-md-8 col-md-offset-2 custyle product-body\" style=\"margin-top: 20px\">
        <table class=\"table table-striped custab\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"2\">AGREGAR PRODUCTOS</th>
            </tr>
            </thead>
            <tbody>
                <tr>
                    <th>Nombre</th>
                    <td><input type=\"text\" name=\"name\" value=\"\" id=\"name\"></td>
                </tr>
                <tr>
                    <th>Descripción</th>
                    <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\"></textarea></td>
                </tr>
                <tr>
                    <th>Imagen</th>
                    <td>
                        <form id=\"myform1\" method=\"post\" style=\"margin-top: 5px;\">
                            <input type=\"button\" id=\"loadFileXml\" value=\"Seleccione un archivo\" onclick=\"document.getElementById('image').click();\" />
                            <input id=\"image\" style=\"display:none;\" type=\"file\" name=\"upload\" />
                        </form>
                        <p id=\"imageError\" style=\"color: red; display: none;\"><small>Selecciona una imagen </small></p>
                        <p id=\"image1Error\" style=\"color: red; display: none;\"><small>Selecciona una imagen con la extensión .jpg, .jpeg, .gif o .png</small></p>
                    </td>
                </tr>
                <tr>
                    <th>Nombre de la finca</th>
                    <td>";
        // line 36
        echo twig_escape_filter($this->env, $this->getAttribute(($context["farm"] ?? $this->getContext($context, "farm")), "getName", array(), "method"), "html", null, true);
        echo "</td>
                </tr>
                <tr>
                    <th>Cultivar</th>
                    <td>
                        <select name=\"cultivar\" id=\"cultivar\">
                            <option value=\"\"> </option>
                            ";
        // line 43
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["cultivars"] ?? $this->getContext($context, "cultivars")));
        foreach ($context['_seq'] as $context["_key"] => $context["culti"]) {
            // line 44
            echo "                                ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["farm"] ?? $this->getContext($context, "farm")), "getCultivars", array(), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["aux"]) {
                // line 45
                echo "                                    ";
                if (($this->getAttribute($context["aux"], "getId", array(), "method") == $this->getAttribute($context["culti"], "getId", array(), "method"))) {
                    // line 46
                    echo "                                        <option value=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getId", array(), "method"), "html", null, true);
                    echo "\"> ";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getDescription", array(), "method"), "html", null, true);
                    echo "</option>
                                    ";
                }
                // line 48
                echo "                                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['aux'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 49
            echo "                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['culti'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 50
        echo "                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Grado</th>
                    <td>
                        <select name=\"grade\" id=\"grade\">
                            <option value=\"\"> </option>
                            ";
        // line 58
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["grade"] ?? $this->getContext($context, "grade")));
        foreach ($context['_seq'] as $context["_key"] => $context["gr"]) {
            // line 59
            echo "                                ";
            if (($this->getAttribute($context["gr"], "getId", array(), "method") != 1)) {
                // line 60
                echo "                                    <option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["gr"], "getId", array(), "method"), "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["gr"], "getDescription", array(), "method"), "html", null, true);
                echo "</option>
                                ";
            }
            // line 62
            echo "                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['gr'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 63
        echo "                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Tratamiento</th>
                    <td>
                        <select name=\"processing\" id=\"processing\">
                            <option value=\"\"> </option>
                            ";
        // line 71
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["processing"] ?? $this->getContext($context, "processing")));
        foreach ($context['_seq'] as $context["_key"] => $context["pr"]) {
            // line 72
            echo "                                ";
            if (($this->getAttribute($context["pr"], "getId", array(), "method") != 1)) {
                // line 73
                echo "                                    <option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["pr"], "getId", array(), "method"), "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["pr"], "getDescription", array(), "method"), "html", null, true);
                echo "</option>
                                ";
            }
            // line 75
            echo "                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pr'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 76
        echo "                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Sabor</th>
                    <td>
                        <select name=\"flavor\" id=\"flavor\">
                            <option value=\"\"> </option>
                            ";
        // line 84
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["flavor"] ?? $this->getContext($context, "flavor")));
        foreach ($context['_seq'] as $context["_key"] => $context["fl"]) {
            // line 85
            echo "                                ";
            if (($this->getAttribute($context["fl"], "getId", array(), "method") != 1)) {
                // line 86
                echo "                                    <option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["fl"], "getId", array(), "method"), "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["fl"], "notes", array(), "method"), "html", null, true);
                echo "</option>
                                ";
            }
            // line 88
            echo "                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fl'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 89
        echo "                        </select>
                    </td>
                </tr>
                <tr>
                    <th class=\"text-center\" colspan=\"2\">
                        PRESENTACIONES
                        <a class=\"btn btn-primary btn-xs pull-right btn-add-presentation\" style=\"margin: 0px;\"><span class=\"glyphicon glyphicon-plus\"></span> Agregar Presentación</a>
                    </th>
                </tr>

                <tr>
                    <td colspan=\"2\">
                        <table class=\"table table-striped custab\" id=\"table-presentations\">
                            <thead>
                                <th>Tostado</th>
                                <th>Molido</th>
                                <th>Peso</th>
                                <th>Precio</th>
                                <th></th>
                            </thead>
                            <tbody id=\"tbody-presentations\">
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td class=\"text-center\" colspan=\"2\">
                        <a class='btn btn-success btn-xs btn-insert' id=\"";
        // line 116
        echo twig_escape_filter($this->env, $this->getAttribute(($context["farm"] ?? $this->getContext($context, "farm")), "getId", array(), "method"), "html", null, true);
        echo "\"><span class=\"glyphicon glyphicon-save\"></span> Guardar</a>
                        <a href=\"";
        // line 117
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_product_homepage", array("id" => $this->getAttribute(($context["farm"] ?? $this->getContext($context, "farm")), "getId", array(), "method"))), "html", null, true);
        echo "\" class=\"btn btn-warning btn-xs\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancelar</a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- The Modal Add Presentations -->
    <div id=\"addPresentation\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
            <!-- Modal content -->
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <span class=\"close\">&times;</span>
                    <h3>Agregar Presentación</h3>
                </div>
                <div class=\"modal-body\" id=\"modal-body\">
                    <form>
                        <div class=\"form-group row\">
                            <label class=\"col-sm-3 form-control-label\">Tostado</label>
                            <div class=\"col-sm-9\">
                                ";
        // line 138
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["roast"] ?? $this->getContext($context, "roast")));
        foreach ($context['_seq'] as $context["_key"] => $context["rt"]) {
            // line 139
            echo "                                    ";
            if (($this->getAttribute($context["rt"], "id", array()) != 1)) {
                // line 140
                echo "                                        <label class=\"radio-inline\" for=\"roast";
                echo twig_escape_filter($this->env, $this->getAttribute($context["rt"], "id", array()), "html", null, true);
                echo "\">
                                            <input type=\"radio\" name=\"roast\" id=\"roast";
                // line 141
                echo twig_escape_filter($this->env, $this->getAttribute($context["rt"], "id", array()), "html", null, true);
                echo "\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["rt"], "id", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["rt"], "description", array()), "html", null, true);
                echo "
                                        </label>
                                    ";
            }
            // line 144
            echo "                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['rt'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 145
        echo "                            </div>
                        </div>
                        <div class=\"form-group row\">
                            <label class=\"col-sm-3 form-control-label\">Molido</label>
                            <div class=\"col-sm-9\">
                                ";
        // line 150
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["grind"] ?? $this->getContext($context, "grind")));
        foreach ($context['_seq'] as $context["_key"] => $context["gd"]) {
            // line 151
            echo "                                    ";
            if (($this->getAttribute($context["gd"], "id", array()) != 1)) {
                // line 152
                echo "                                        <label class=\"radio-inline\" for=\"grind";
                echo twig_escape_filter($this->env, $this->getAttribute($context["gd"], "id", array()), "html", null, true);
                echo "\">
                                            <input type=\"radio\" name=\"grind\" id=\"grind";
                // line 153
                echo twig_escape_filter($this->env, $this->getAttribute($context["gd"], "id", array()), "html", null, true);
                echo "\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["gd"], "id", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["gd"], "description", array()), "html", null, true);
                echo "
                                        </label>
                                    ";
            }
            // line 156
            echo "                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['gd'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 157
        echo "                            </div>
                        </div>
                        <div class=\"form-group\">
                            <label>Peso</label>
                            <input type=\"number\" placeholder=\"Weight\" id=\"weight\" class=\"form-control\" min=\"1\">
                        </div>
                        <div class=\"form-group\">
                            <label>Precio</label>
                            <input type=\"number\" placeholder=\"Price\" id=\"price\" class=\"form-control\" min=\"1\">
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                    <button type=\"button\" class=\"btn btn-primary btn-insert-presentation\">Guardar cambios</button>
                    <button type=\"button\" class=\"btn btn-close-modal\" style=\"margin: 0px;\">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

     <!-- The Modal -->
    <div id=\"errorModal\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
        <!-- Modal content -->
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <span class=\"close close-error\">&times;</span>
                <div id=\"modal-header\">
                    <h3 style=\"color: red;\">Error</h3>
                </div>
            </div>
            <div class=\"modal-body\" id=\"modal-body\">
                <span class='glyphicon glyphicon-remove-sign modal-icon'></span>
                <p class='modal-p'>Algunos campos se encuentran en blanco</p>
                <div id=\"modal-body-error\">
                </div>
            </div>
        </div>
    </div>

";
        
        $__internal_bae0cae1d383d34b8d7e868b9ff3d7930cfe07c0f5f543c2d27f9697a5349bb2->leave($__internal_bae0cae1d383d34b8d7e868b9ff3d7930cfe07c0f5f543c2d27f9697a5349bb2_prof);

    }

    // line 200
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_bfcde5443cea92a6f4778f1cacce0f99acd5456675694e0570914c9e712b5aea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bfcde5443cea92a6f4778f1cacce0f99acd5456675694e0570914c9e712b5aea->enter($__internal_bfcde5443cea92a6f4778f1cacce0f99acd5456675694e0570914c9e712b5aea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 201
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 202
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 203
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/css/styles.css"), "html", null, true);
        echo "\">
";
        
        $__internal_bfcde5443cea92a6f4778f1cacce0f99acd5456675694e0570914c9e712b5aea->leave($__internal_bfcde5443cea92a6f4778f1cacce0f99acd5456675694e0570914c9e712b5aea_prof);

    }

    // line 207
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_40088f6f5ab2285ae51517cfe09e2691de778a789a1db7b0666bd711716a1398 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_40088f6f5ab2285ae51517cfe09e2691de778a789a1db7b0666bd711716a1398->enter($__internal_40088f6f5ab2285ae51517cfe09e2691de778a789a1db7b0666bd711716a1398_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 208
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script type=\"text/javascript\" src=\"";
        // line 209
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/js/products.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_40088f6f5ab2285ae51517cfe09e2691de778a789a1db7b0666bd711716a1398->leave($__internal_40088f6f5ab2285ae51517cfe09e2691de778a789a1db7b0666bd711716a1398_prof);

    }

    public function getTemplateName()
    {
        return "FarmBundle:Default:insertProduct.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  423 => 209,  418 => 208,  412 => 207,  403 => 203,  399 => 202,  394 => 201,  388 => 200,  341 => 157,  335 => 156,  325 => 153,  320 => 152,  317 => 151,  313 => 150,  306 => 145,  300 => 144,  290 => 141,  285 => 140,  282 => 139,  278 => 138,  254 => 117,  250 => 116,  221 => 89,  215 => 88,  207 => 86,  204 => 85,  200 => 84,  190 => 76,  184 => 75,  176 => 73,  173 => 72,  169 => 71,  159 => 63,  153 => 62,  145 => 60,  142 => 59,  138 => 58,  128 => 50,  122 => 49,  116 => 48,  108 => 46,  105 => 45,  100 => 44,  96 => 43,  86 => 36,  55 => 7,  49 => 6,  37 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Mantenimiento de Productos{% endblock %}

{% block body %}
    <div class=\"row col-md-8 col-md-offset-2 custyle product-body\" style=\"margin-top: 20px\">
        <table class=\"table table-striped custab\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"2\">AGREGAR PRODUCTOS</th>
            </tr>
            </thead>
            <tbody>
                <tr>
                    <th>Nombre</th>
                    <td><input type=\"text\" name=\"name\" value=\"\" id=\"name\"></td>
                </tr>
                <tr>
                    <th>Descripción</th>
                    <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\"></textarea></td>
                </tr>
                <tr>
                    <th>Imagen</th>
                    <td>
                        <form id=\"myform1\" method=\"post\" style=\"margin-top: 5px;\">
                            <input type=\"button\" id=\"loadFileXml\" value=\"Seleccione un archivo\" onclick=\"document.getElementById('image').click();\" />
                            <input id=\"image\" style=\"display:none;\" type=\"file\" name=\"upload\" />
                        </form>
                        <p id=\"imageError\" style=\"color: red; display: none;\"><small>Selecciona una imagen </small></p>
                        <p id=\"image1Error\" style=\"color: red; display: none;\"><small>Selecciona una imagen con la extensión .jpg, .jpeg, .gif o .png</small></p>
                    </td>
                </tr>
                <tr>
                    <th>Nombre de la finca</th>
                    <td>{{farm.getName() }}</td>
                </tr>
                <tr>
                    <th>Cultivar</th>
                    <td>
                        <select name=\"cultivar\" id=\"cultivar\">
                            <option value=\"\"> </option>
                            {% for culti in cultivars %}
                                {% for aux in farm.getCultivars() %}
                                    {% if  aux.getId() == culti.getId() %}
                                        <option value=\"{{ culti.getId() }}\"> {{ culti.getDescription() }}</option>
                                    {% endif %}
                                {% endfor %}
                            {% endfor %}
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Grado</th>
                    <td>
                        <select name=\"grade\" id=\"grade\">
                            <option value=\"\"> </option>
                            {% for gr in grade %}
                                {% if  gr.getId() != 1 %}
                                    <option value=\"{{ gr.getId() }}\"> {{ gr.getDescription() }}</option>
                                {% endif %}
                            {% endfor %}
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Tratamiento</th>
                    <td>
                        <select name=\"processing\" id=\"processing\">
                            <option value=\"\"> </option>
                            {% for pr in processing %}
                                {% if  pr.getId() != 1 %}
                                    <option value=\"{{ pr.getId() }}\"> {{ pr.getDescription() }}</option>
                                {% endif %}
                            {% endfor %}
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Sabor</th>
                    <td>
                        <select name=\"flavor\" id=\"flavor\">
                            <option value=\"\"> </option>
                            {% for fl in flavor %}
                                {% if  fl.getId() != 1 %}
                                    <option value=\"{{ fl.getId() }}\"> {{ fl.notes() }}</option>
                                {% endif %}
                            {% endfor %}
                        </select>
                    </td>
                </tr>
                <tr>
                    <th class=\"text-center\" colspan=\"2\">
                        PRESENTACIONES
                        <a class=\"btn btn-primary btn-xs pull-right btn-add-presentation\" style=\"margin: 0px;\"><span class=\"glyphicon glyphicon-plus\"></span> Agregar Presentación</a>
                    </th>
                </tr>

                <tr>
                    <td colspan=\"2\">
                        <table class=\"table table-striped custab\" id=\"table-presentations\">
                            <thead>
                                <th>Tostado</th>
                                <th>Molido</th>
                                <th>Peso</th>
                                <th>Precio</th>
                                <th></th>
                            </thead>
                            <tbody id=\"tbody-presentations\">
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td class=\"text-center\" colspan=\"2\">
                        <a class='btn btn-success btn-xs btn-insert' id=\"{{ farm.getId() }}\"><span class=\"glyphicon glyphicon-save\"></span> Guardar</a>
                        <a href=\"{{ path('farm_product_homepage', {'id': farm.getId()}) }}\" class=\"btn btn-warning btn-xs\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancelar</a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- The Modal Add Presentations -->
    <div id=\"addPresentation\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
            <!-- Modal content -->
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <span class=\"close\">&times;</span>
                    <h3>Agregar Presentación</h3>
                </div>
                <div class=\"modal-body\" id=\"modal-body\">
                    <form>
                        <div class=\"form-group row\">
                            <label class=\"col-sm-3 form-control-label\">Tostado</label>
                            <div class=\"col-sm-9\">
                                {% for rt in roast %}
                                    {% if rt.id != 1 %}
                                        <label class=\"radio-inline\" for=\"roast{{ rt.id }}\">
                                            <input type=\"radio\" name=\"roast\" id=\"roast{{ rt.id }}\" value=\"{{ rt.id }}\">{{ rt.description }}
                                        </label>
                                    {% endif %}
                                {% endfor %}
                            </div>
                        </div>
                        <div class=\"form-group row\">
                            <label class=\"col-sm-3 form-control-label\">Molido</label>
                            <div class=\"col-sm-9\">
                                {% for gd in grind %}
                                    {% if gd.id != 1 %}
                                        <label class=\"radio-inline\" for=\"grind{{ gd.id }}\">
                                            <input type=\"radio\" name=\"grind\" id=\"grind{{ gd.id }}\" value=\"{{ gd.id }}\">{{ gd.description }}
                                        </label>
                                    {% endif %}
                                {% endfor %}
                            </div>
                        </div>
                        <div class=\"form-group\">
                            <label>Peso</label>
                            <input type=\"number\" placeholder=\"Weight\" id=\"weight\" class=\"form-control\" min=\"1\">
                        </div>
                        <div class=\"form-group\">
                            <label>Precio</label>
                            <input type=\"number\" placeholder=\"Price\" id=\"price\" class=\"form-control\" min=\"1\">
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                    <button type=\"button\" class=\"btn btn-primary btn-insert-presentation\">Guardar cambios</button>
                    <button type=\"button\" class=\"btn btn-close-modal\" style=\"margin: 0px;\">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

     <!-- The Modal -->
    <div id=\"errorModal\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
        <!-- Modal content -->
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <span class=\"close close-error\">&times;</span>
                <div id=\"modal-header\">
                    <h3 style=\"color: red;\">Error</h3>
                </div>
            </div>
            <div class=\"modal-body\" id=\"modal-body\">
                <span class='glyphicon glyphicon-remove-sign modal-icon'></span>
                <p class='modal-p'>Algunos campos se encuentran en blanco</p>
                <div id=\"modal-body-error\">
                </div>
            </div>
        </div>
    </div>

{% endblock %}


{% block stylesheets %}
    {{ parent() }}
    <link rel=\"stylesheet\" href=\"{{ asset('/siteadmin/web/css/crgourmetcoffee.css') }}\">
    <link rel=\"stylesheet\" href=\"{{ asset('/siteadmin/web/css/styles.css') }}\">
{% endblock %}


{% block javascripts %}
    {{ parent() }}
    <script type=\"text/javascript\" src=\"{{ asset('/siteadmin/web/js/products.js') }}\"></script>
{% endblock %}", "FarmBundle:Default:insertProduct.html.twig", "C:\\xampp\\htdocs\\siteadmin\\src\\FarmBundle/Resources/views/Default/insertProduct.html.twig");
    }
}
