<?php

/* AppBundle:Default:home.html.twig */
class __TwigTemplate_038e2ca8c02e35007db467a14d2aa0271a7ecee2a00a34f8df09484e57a862c5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "AppBundle:Default:home.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_16ff0bd7a7139f7c6e8e31840fe4920ac6c4298266b994e3598349a23f862d78 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_16ff0bd7a7139f7c6e8e31840fe4920ac6c4298266b994e3598349a23f862d78->enter($__internal_16ff0bd7a7139f7c6e8e31840fe4920ac6c4298266b994e3598349a23f862d78_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Default:home.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_16ff0bd7a7139f7c6e8e31840fe4920ac6c4298266b994e3598349a23f862d78->leave($__internal_16ff0bd7a7139f7c6e8e31840fe4920ac6c4298266b994e3598349a23f862d78_prof);

    }

    // line 4
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_0333c57b0663f0c2e76f7af7ed0e9e6635413d42a28486668f96ad93782d72b0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0333c57b0663f0c2e76f7af7ed0e9e6635413d42a28486668f96ad93782d72b0->enter($__internal_0333c57b0663f0c2e76f7af7ed0e9e6635413d42a28486668f96ad93782d72b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 5
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/css/styles.css"), "html", null, true);
        echo "\">
";
        
        $__internal_0333c57b0663f0c2e76f7af7ed0e9e6635413d42a28486668f96ad93782d72b0->leave($__internal_0333c57b0663f0c2e76f7af7ed0e9e6635413d42a28486668f96ad93782d72b0_prof);

    }

    // line 10
    public function block_title($context, array $blocks = array())
    {
        $__internal_6e685c2753e0c71c36a5766bfeb8b5ebfb66d3223b8b3fe8d9010af226b86c8c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6e685c2753e0c71c36a5766bfeb8b5ebfb66d3223b8b3fe8d9010af226b86c8c->enter($__internal_6e685c2753e0c71c36a5766bfeb8b5ebfb66d3223b8b3fe8d9010af226b86c8c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 11
        echo "    Principal
";
        
        $__internal_6e685c2753e0c71c36a5766bfeb8b5ebfb66d3223b8b3fe8d9010af226b86c8c->leave($__internal_6e685c2753e0c71c36a5766bfeb8b5ebfb66d3223b8b3fe8d9010af226b86c8c_prof);

    }

    // line 14
    public function block_body($context, array $blocks = array())
    {
        $__internal_b006cfa174284dff1c9625c499246e012863f7b8b0bba56c9385b68596ddbad1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b006cfa174284dff1c9625c499246e012863f7b8b0bba56c9385b68596ddbad1->enter($__internal_b006cfa174284dff1c9625c499246e012863f7b8b0bba56c9385b68596ddbad1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 15
        echo "    <div class=\"row col-md-9 col-md-offset-1 custyle\">
        <table class=\"table table-striped custab\" style=\"margin-top: 20px;\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"2\">MANTENIMIENTO</th>
            </tr>
            <tr>
                <th>Título</th>
                <th class=\"text-center\">Acción</th>
            </tr>
            </thead>
            <tr>
                <td>Regiones</td>
                <td class=\"text-center\">
                    <a class='btn btn-primary btn-xs' href=\"";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_homepage");
        echo "\">
                        <span class=\"glyphicon glyphicon-ok\"></span> Seleccionar</a>
                </td>
            </tr>
            <tr>
                <td>Fincas</td>
                <td class=\"text-center\">
                    <a class='btn btn-primary btn-xs' href=\"";
        // line 36
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_homepage");
        echo "\">
                        <span class=\"glyphicon glyphicon-ok\"></span> Seleccionar</a>
                </td>
            </tr>
            ";
        // line 47
        echo "        </table>
    </div>
";
        
        $__internal_b006cfa174284dff1c9625c499246e012863f7b8b0bba56c9385b68596ddbad1->leave($__internal_b006cfa174284dff1c9625c499246e012863f7b8b0bba56c9385b68596ddbad1_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Default:home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  113 => 47,  106 => 36,  96 => 29,  80 => 15,  74 => 14,  66 => 11,  60 => 10,  51 => 7,  47 => 6,  42 => 5,  36 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block stylesheets %}
    {{parent()}}
    <link rel=\"stylesheet\" href=\"{{ asset('/siteadmin/web/css/crgourmetcoffee.css') }}\">
    <link rel=\"stylesheet\" href=\"{{ asset('/siteadmin/web/css/styles.css') }}\">
{% endblock %}

{% block title %}
    Principal
{% endblock %}

{% block body %}
    <div class=\"row col-md-9 col-md-offset-1 custyle\">
        <table class=\"table table-striped custab\" style=\"margin-top: 20px;\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"2\">MANTENIMIENTO</th>
            </tr>
            <tr>
                <th>Título</th>
                <th class=\"text-center\">Acción</th>
            </tr>
            </thead>
            <tr>
                <td>Regiones</td>
                <td class=\"text-center\">
                    <a class='btn btn-primary btn-xs' href=\"{{ path('region_homepage') }}\">
                        <span class=\"glyphicon glyphicon-ok\"></span> Seleccionar</a>
                </td>
            </tr>
            <tr>
                <td>Fincas</td>
                <td class=\"text-center\">
                    <a class='btn btn-primary btn-xs' href=\"{{ path('farm_homepage') }}\">
                        <span class=\"glyphicon glyphicon-ok\"></span> Seleccionar</a>
                </td>
            </tr>
            {# <tr>
                 <td>Products</td>
                 <td class=\"text-center\">
                     <a class='btn btn-primary btn-xs' href=\"{{ path('product_homepage') }}\">
                         <span class=\"glyphicon glyphicon-ok\"></span> Select</a>
                 </td>
             </tr>#}
        </table>
    </div>
{% endblock %}", "AppBundle:Default:home.html.twig", "/Applications/MAMP/htdocs/siteadmin/src/AppBundle/Resources/views/Default/home.html.twig");
    }
}
