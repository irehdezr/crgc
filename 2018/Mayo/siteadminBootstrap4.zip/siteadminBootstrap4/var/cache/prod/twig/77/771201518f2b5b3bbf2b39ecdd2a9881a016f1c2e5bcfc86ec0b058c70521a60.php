<?php

/* ::header.html.twig */
class __TwigTemplate_57a2e20ef3e39c5cd0f1f5d31f937fa96e81a8570b2dd6f1247e049d31218713 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<header class='col-xs-12'>
   <nav id='navBar' class=\"navbar navbar-inverse navbar-fixed-top\">
      <div class=\"container-fluid\">
         <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#myNavbar\">
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>                        
            </button>
            <a class=\"navbar-brand\">cr<span>gourmet</span><span>coffee.com</span></a>
         </div>
         <div class=\"collapse navbar-collapse\" id=\"myNavbar\">
            <ul id='mainMenu' class=\"nav navbar-nav\">
               <li><a href=\"";
        // line 14
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_homepage");
        echo "\">Home</a></li>
               <li><a href=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_homepage");
        echo "\">Regions</a></li>
               <li><a href=\"";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_homepage");
        echo "\">Farms</a></li>
               ";
        // line 27
        echo "            </ul>
         </div>
      </div>
   </nav>
</header>
<div class='clearfix'></div>";
    }

    public function getTemplateName()
    {
        return "::header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  46 => 27,  42 => 16,  38 => 15,  34 => 14,  19 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "::header.html.twig", "C:\\xampp\\htdocs\\app/Resources\\views/header.html.twig");
    }
}
