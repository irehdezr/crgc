<?php

/* layout.html.twig */
class __TwigTemplate_baea91e6f4055e172c8202b688a7709ff7610fa44e044ec5628110687e87b697 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_df60a53cf5f5e4812c202a701782d880a8ab5d6ebf87e6112928e6260163eab4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_df60a53cf5f5e4812c202a701782d880a8ab5d6ebf87e6112928e6260163eab4->enter($__internal_df60a53cf5f5e4812c202a701782d880a8ab5d6ebf87e6112928e6260163eab4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"es\">
    <head>
        <meta charset=\"UTF-8\"/>
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
        <title>
            ";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        // line 10
        echo "        </title>
        <link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css\" integrity=\"sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB\" crossorigin=\"anonymous\">
        <link rel=\"stylesheet\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./css/siteadmin.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./font-awesome/css/font-awesome.min.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./css/fontastic.css"), "html", null, true);
        echo "\">
        ";
        // line 15
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./favicon.ico"), "html", null, true);
        echo "\"/>
    </head>
    <body>
        <header>
            ";
        // line 20
        $this->loadTemplate("header.html.twig", "layout.html.twig", 20)->display($context);
        // line 21
        echo "        </header>
        <div class=\"container\">
            ";
        // line 23
        $this->displayBlock('body', $context, $blocks);
        // line 24
        echo "        </div>

        <script type=\"text/javascript\" src=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
        <script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js\" integrity=\"sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T\" crossorigin=\"anonymous\"></script>
        ";
        // line 28
        $this->displayBlock('javascripts', $context, $blocks);
        // line 29
        echo "    </body>
</html>";
        
        $__internal_df60a53cf5f5e4812c202a701782d880a8ab5d6ebf87e6112928e6260163eab4->leave($__internal_df60a53cf5f5e4812c202a701782d880a8ab5d6ebf87e6112928e6260163eab4_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_817029842560601e26f829f2416e31a271b7460fcf7baac60867852f2b07e166 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_817029842560601e26f829f2416e31a271b7460fcf7baac60867852f2b07e166->enter($__internal_817029842560601e26f829f2416e31a271b7460fcf7baac60867852f2b07e166_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "                Mantenimiento
            ";
        
        $__internal_817029842560601e26f829f2416e31a271b7460fcf7baac60867852f2b07e166->leave($__internal_817029842560601e26f829f2416e31a271b7460fcf7baac60867852f2b07e166_prof);

    }

    // line 15
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_ce85ae9d8f576b51f69b5c53235efb4d9dcf391de0f7ae89b818c7649e2d0eea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ce85ae9d8f576b51f69b5c53235efb4d9dcf391de0f7ae89b818c7649e2d0eea->enter($__internal_ce85ae9d8f576b51f69b5c53235efb4d9dcf391de0f7ae89b818c7649e2d0eea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_ce85ae9d8f576b51f69b5c53235efb4d9dcf391de0f7ae89b818c7649e2d0eea->leave($__internal_ce85ae9d8f576b51f69b5c53235efb4d9dcf391de0f7ae89b818c7649e2d0eea_prof);

    }

    // line 23
    public function block_body($context, array $blocks = array())
    {
        $__internal_d4b5cd93a5b3c7a4be90ebe3c8c9f6fee01621d15cca18ecc95b3b5073f5a91c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d4b5cd93a5b3c7a4be90ebe3c8c9f6fee01621d15cca18ecc95b3b5073f5a91c->enter($__internal_d4b5cd93a5b3c7a4be90ebe3c8c9f6fee01621d15cca18ecc95b3b5073f5a91c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_d4b5cd93a5b3c7a4be90ebe3c8c9f6fee01621d15cca18ecc95b3b5073f5a91c->leave($__internal_d4b5cd93a5b3c7a4be90ebe3c8c9f6fee01621d15cca18ecc95b3b5073f5a91c_prof);

    }

    // line 28
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_8ebc87e22f32590a441c56cc826b79e5f3048fe96cd3ea85566a58172e52f4ae = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ebc87e22f32590a441c56cc826b79e5f3048fe96cd3ea85566a58172e52f4ae->enter($__internal_8ebc87e22f32590a441c56cc826b79e5f3048fe96cd3ea85566a58172e52f4ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_8ebc87e22f32590a441c56cc826b79e5f3048fe96cd3ea85566a58172e52f4ae->leave($__internal_8ebc87e22f32590a441c56cc826b79e5f3048fe96cd3ea85566a58172e52f4ae_prof);

    }

    public function getTemplateName()
    {
        return "layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  125 => 28,  114 => 23,  103 => 15,  95 => 8,  89 => 7,  81 => 29,  79 => 28,  74 => 26,  70 => 24,  68 => 23,  64 => 21,  62 => 20,  54 => 16,  52 => 15,  48 => 14,  44 => 13,  40 => 12,  36 => 10,  34 => 7,  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"es\">
    <head>
        <meta charset=\"UTF-8\"/>
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
        <title>
            {% block title %}
                Mantenimiento
            {% endblock %}
        </title>
        <link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css\" integrity=\"sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB\" crossorigin=\"anonymous\">
        <link rel=\"stylesheet\" href=\"{{ asset('./css/siteadmin.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('./font-awesome/css/font-awesome.min.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('./css/fontastic.css') }}\">
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('./favicon.ico') }}\"/>
    </head>
    <body>
        <header>
            {% include \"header.html.twig\" %}
        </header>
        <div class=\"container\">
            {% block body %}{% endblock %}
        </div>

        <script type=\"text/javascript\" src=\"{{ asset('./js/jquery-3.2.0.min.js') }}\"></script>
        <script src=\"https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js\" integrity=\"sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T\" crossorigin=\"anonymous\"></script>
        {% block javascripts %}{% endblock %}
    </body>
</html>", "layout.html.twig", "C:\\xampp\\htdocs\\siteadminBootstrap4\\app\\Resources\\views\\layout.html.twig");
    }
}
