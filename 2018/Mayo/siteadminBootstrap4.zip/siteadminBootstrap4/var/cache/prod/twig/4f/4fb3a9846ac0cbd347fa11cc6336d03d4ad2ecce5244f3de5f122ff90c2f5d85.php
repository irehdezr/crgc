<?php

/* FarmBundle:Default:farm.html.twig */
class __TwigTemplate_7b008fa2a0b0b3f8bcf429d221c6fb08c4a13ee8a1d9804e8ffe1c567951c3fd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "FarmBundle:Default:farm.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'navbar' => array($this, 'block_navbar'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c4031b72f04a27546f3373f94ae663fb19a3e339101c4e17182da143271da63c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c4031b72f04a27546f3373f94ae663fb19a3e339101c4e17182da143271da63c->enter($__internal_c4031b72f04a27546f3373f94ae663fb19a3e339101c4e17182da143271da63c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FarmBundle:Default:farm.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c4031b72f04a27546f3373f94ae663fb19a3e339101c4e17182da143271da63c->leave($__internal_c4031b72f04a27546f3373f94ae663fb19a3e339101c4e17182da143271da63c_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_08fce179f200dc735bd0091014f21951e42bf80e14c3f59ab3076adfd419aff6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_08fce179f200dc735bd0091014f21951e42bf80e14c3f59ab3076adfd419aff6->enter($__internal_08fce179f200dc735bd0091014f21951e42bf80e14c3f59ab3076adfd419aff6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Mantenimiento de fincas";
        
        $__internal_08fce179f200dc735bd0091014f21951e42bf80e14c3f59ab3076adfd419aff6->leave($__internal_08fce179f200dc735bd0091014f21951e42bf80e14c3f59ab3076adfd419aff6_prof);

    }

    // line 6
    public function block_navbar($context, array $blocks = array())
    {
        $__internal_0bbc5f67c49f1440f4a337b3595ae68535022a368d53cbb5e97b5bee2ad61f1c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0bbc5f67c49f1440f4a337b3595ae68535022a368d53cbb5e97b5bee2ad61f1c->enter($__internal_0bbc5f67c49f1440f4a337b3595ae68535022a368d53cbb5e97b5bee2ad61f1c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        echo "Mantenimiento de fincas";
        
        $__internal_0bbc5f67c49f1440f4a337b3595ae68535022a368d53cbb5e97b5bee2ad61f1c->leave($__internal_0bbc5f67c49f1440f4a337b3595ae68535022a368d53cbb5e97b5bee2ad61f1c_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_694bdfbed4a48f0f627f46836fd6aed3510c0861f74a4979bd5e958622d68428 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_694bdfbed4a48f0f627f46836fd6aed3510c0861f74a4979bd5e958622d68428->enter($__internal_694bdfbed4a48f0f627f46836fd6aed3510c0861f74a4979bd5e958622d68428_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo "<section>
    <div class=\"bg-white\">
        <div class=\"text-center\">
            <h2 class=\"text-light-brown\"><strong>FINCAS</strong></h2>
        </div>
        <br>
        <div class=\"row\">
            <div class=\"col-md-auto\"></div>
            <div class=\"col\">
                <div class=\"pull-right mb-1\">
                    <a href=\"";
        // line 19
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_add");
        echo "\" class=\"btn btn-info btn-sm\"><i class=\"fa fa-plus-circle\" aria-hidden=\"true\"></i> Agregar</a>
                </div>
                <table class=\"table table-hover table-responsive\">
                    <thead class=\"thead-dark\">
                        <tr>
                            <th scope=\"col\">#</th>
                            <th scope=\"col\">Nombre</th>
                            <th scope=\"col\">Imagen</th>
                            <th scope=\"col\">Descripción</th>
                            <th scope=\"col\"></th>
                        </tr>
                    </thead>
                    <tbody>
                        ";
        // line 32
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["farms"] ?? $this->getContext($context, "farms")));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 33
            echo "                            <tr ondblclick=\"document.getElementById('btn-";
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "').click();\">
                                <th scope='row'>";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "</th>
                                <td>";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo "</td>
                                <td><img src=\"";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage", array(), "method"), "html", null, true);
            echo "\" class=\"mediana\"></td>
                                <td class=\"text-justify\"><p>";
            // line 37
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getDescription", array(), "method"), "html", null, true);
            echo "</p></td>
                                <td>
                                    <a href=\"";
            // line 39
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_edit", array("id" => $this->getAttribute($context["temp"], "getId", array(), "method"))), "html", null, true);
            echo "\" class='btn-hidden' id=\"btn-";
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\"> Editar</a>
                                    <button type=\"button\" class=\"btn btn-danger btn-sm\"><i class=\"fa fa-trash\" aria-hidden=\"true\"></i> Eliminar</button>
                                </td>
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 44
        echo "                    </tbody>
                </table>
            </div>
            <div class=\"col-md-auto\"></div>
        </div>
    </div>
</section>




    <!-- The Modal Delete Confirmation -->
    <div id=\"deleteConfirmation\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
            <!-- Modal content -->
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h3>Eliminar Fincas</h3>
                </div>
                <div class=\"modal-body\" id=\"modal-body\">
                    <form>
                        <div class=\"form-group row div-body\" id=\"div-body\">
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_694bdfbed4a48f0f627f46836fd6aed3510c0861f74a4979bd5e958622d68428->leave($__internal_694bdfbed4a48f0f627f46836fd6aed3510c0861f74a4979bd5e958622d68428_prof);

    }

    // line 77
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_567e26c335d836bf3a2fcfff8f5195c13e97101c58fbf75fc62c0c3d206432ee = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_567e26c335d836bf3a2fcfff8f5195c13e97101c58fbf75fc62c0c3d206432ee->enter($__internal_567e26c335d836bf3a2fcfff8f5195c13e97101c58fbf75fc62c0c3d206432ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 78
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
";
        
        $__internal_567e26c335d836bf3a2fcfff8f5195c13e97101c58fbf75fc62c0c3d206432ee->leave($__internal_567e26c335d836bf3a2fcfff8f5195c13e97101c58fbf75fc62c0c3d206432ee_prof);

    }

    // line 81
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_d379eae1090dde69f7ea1b4f1bd4972f71c64b5635451717213cada5e79356b3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d379eae1090dde69f7ea1b4f1bd4972f71c64b5635451717213cada5e79356b3->enter($__internal_d379eae1090dde69f7ea1b4f1bd4972f71c64b5635451717213cada5e79356b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 82
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script type=\"text/javascript\" src=\"";
        // line 83
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadminBootstrap4/web/js/farm.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_d379eae1090dde69f7ea1b4f1bd4972f71c64b5635451717213cada5e79356b3->leave($__internal_d379eae1090dde69f7ea1b4f1bd4972f71c64b5635451717213cada5e79356b3_prof);

    }

    public function getTemplateName()
    {
        return "FarmBundle:Default:farm.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  199 => 83,  194 => 82,  188 => 81,  178 => 78,  172 => 77,  135 => 44,  122 => 39,  117 => 37,  113 => 36,  109 => 35,  105 => 34,  100 => 33,  96 => 32,  80 => 19,  68 => 9,  62 => 8,  50 => 6,  38 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Mantenimiento de fincas{% endblock %}

{% block navbar %}Mantenimiento de fincas{% endblock %}

{% block body %}
<section>
    <div class=\"bg-white\">
        <div class=\"text-center\">
            <h2 class=\"text-light-brown\"><strong>FINCAS</strong></h2>
        </div>
        <br>
        <div class=\"row\">
            <div class=\"col-md-auto\"></div>
            <div class=\"col\">
                <div class=\"pull-right mb-1\">
                    <a href=\"{{ path('farm_add') }}\" class=\"btn btn-info btn-sm\"><i class=\"fa fa-plus-circle\" aria-hidden=\"true\"></i> Agregar</a>
                </div>
                <table class=\"table table-hover table-responsive\">
                    <thead class=\"thead-dark\">
                        <tr>
                            <th scope=\"col\">#</th>
                            <th scope=\"col\">Nombre</th>
                            <th scope=\"col\">Imagen</th>
                            <th scope=\"col\">Descripción</th>
                            <th scope=\"col\"></th>
                        </tr>
                    </thead>
                    <tbody>
                        {% for temp in farms %}
                            <tr ondblclick=\"document.getElementById('btn-{{ temp.getId() }}').click();\">
                                <th scope='row'>{{ temp.getId() }}</th>
                                <td>{{ temp.getName() }}</td>
                                <td><img src=\"{{ temp.getImage() }}\" class=\"mediana\"></td>
                                <td class=\"text-justify\"><p>{{ temp.getDescription() }}</p></td>
                                <td>
                                    <a href=\"{{ path('farm_edit', {'id': temp.getId() }) }}\" class='btn-hidden' id=\"btn-{{ temp.getId() }}\"> Editar</a>
                                    <button type=\"button\" class=\"btn btn-danger btn-sm\"><i class=\"fa fa-trash\" aria-hidden=\"true\"></i> Eliminar</button>
                                </td>
                            </tr>
                        {% endfor %}
                    </tbody>
                </table>
            </div>
            <div class=\"col-md-auto\"></div>
        </div>
    </div>
</section>




    <!-- The Modal Delete Confirmation -->
    <div id=\"deleteConfirmation\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
            <!-- Modal content -->
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h3>Eliminar Fincas</h3>
                </div>
                <div class=\"modal-body\" id=\"modal-body\">
                    <form>
                        <div class=\"form-group row div-body\" id=\"div-body\">
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                </div>
            </div>
        </div>
    </div>
{% endblock %}


{% block stylesheets %}
    {{ parent() }}
{% endblock %}

{% block javascripts %}
    {{ parent() }}
    <script type=\"text/javascript\" src=\"{{ asset('/siteadminBootstrap4/web/js/farm.js') }}\"></script>
{% endblock %}

", "FarmBundle:Default:farm.html.twig", "C:\\xampp\\htdocs\\siteadminBootstrap4\\src\\FarmBundle\\Resources\\views\\Default\\farm.html.twig");
    }
}
