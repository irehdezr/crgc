<?php

/* RegionBundle:Default:region.html.twig */
class __TwigTemplate_008cea48c95b80f9ebcb3d764244a97e0acdf7fb1ad6cdf37d54d9a7a5cdac73 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "RegionBundle:Default:region.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a05e7ad23872645558f6afdbfeac9a40475a68417611c5c2cf889224a6b3bb02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a05e7ad23872645558f6afdbfeac9a40475a68417611c5c2cf889224a6b3bb02->enter($__internal_a05e7ad23872645558f6afdbfeac9a40475a68417611c5c2cf889224a6b3bb02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "RegionBundle:Default:region.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a05e7ad23872645558f6afdbfeac9a40475a68417611c5c2cf889224a6b3bb02->leave($__internal_a05e7ad23872645558f6afdbfeac9a40475a68417611c5c2cf889224a6b3bb02_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_724a58206674cd9bbdc397bd057ab0118995ba29ca90a4facd68792c748a30aa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_724a58206674cd9bbdc397bd057ab0118995ba29ca90a4facd68792c748a30aa->enter($__internal_724a58206674cd9bbdc397bd057ab0118995ba29ca90a4facd68792c748a30aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Mantenimiento de regiones";
        
        $__internal_724a58206674cd9bbdc397bd057ab0118995ba29ca90a4facd68792c748a30aa->leave($__internal_724a58206674cd9bbdc397bd057ab0118995ba29ca90a4facd68792c748a30aa_prof);

    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        $__internal_8ee3a1be543cdf48614a56a1cd1f5911eac8b61ccde4037e7c08724d15b1d6e7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ee3a1be543cdf48614a56a1cd1f5911eac8b61ccde4037e7c08724d15b1d6e7->enter($__internal_8ee3a1be543cdf48614a56a1cd1f5911eac8b61ccde4037e7c08724d15b1d6e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "<section>
    <div class=\"bg-white\">
        <div class=\"text-center\">
            <h2 class=\"text-light-brown\"><strong>REGIONES</strong></h2>
        </div>
        <br>
        <div class=\"row\">
            <div class=\"col-md-auto\"></div>
            <div class=\"col\">
                <div class=\"pull-right mb-1\">
                    <a href=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_new");
        echo "\" class=\"btn btn-info btn-sm\"><i class=\"fa fa-plus-circle\" aria-hidden=\"true\"></i> Agregar</a>
                </div>
                <table class=\"table table-hover table-responsive\">
                    <thead class=\"thead-dark\">
                        <tr>
                            <th scope=\"col\">#</th>
                            <th scope=\"col\">Nombre</th>
                            <th scope=\"col\">Imagen</th>
                            <th scope=\"col\">Descripción</th>
                            <th scope=\"col\"></th>
                        </tr>
                    </thead>
                    <tbody>
                        ";
        // line 30
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["regions"] ?? $this->getContext($context, "regions")));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 31
            echo "                            <tr ondblclick=\"document.getElementById('btn-";
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "').click();\">
                                <th scope='row'>";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "</th>
                                <td>";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo "</td>
                                <td><img src=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage1", array(), "method"), "html", null, true);
            echo "\" class=\"mediana\"></td>
                                <td class=\"text-justify\"><p>";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getDescription", array(), "method"), "html", null, true);
            echo "</p></td>
                                <td>
                                    <a href=\"";
            // line 37
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_edit", array("id" => $this->getAttribute($context["temp"], "getId", array(), "method"))), "html", null, true);
            echo "\" class='btn-hidden' id=\"btn-";
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\"> Editar</a>
                                    <button type=\"button\" class=\"btn btn-danger btn-sm\"><i class=\"fa fa-trash\" aria-hidden=\"true\"></i> Eliminar</button>
                                </td>
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 42
        echo "                    </tbody>
                </table>
            </div>
            <div class=\"col-md-auto\"></div>
        </div>
    </div>
</section>
";
        
        $__internal_8ee3a1be543cdf48614a56a1cd1f5911eac8b61ccde4037e7c08724d15b1d6e7->leave($__internal_8ee3a1be543cdf48614a56a1cd1f5911eac8b61ccde4037e7c08724d15b1d6e7_prof);

    }

    // line 52
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_0eadc8ff205398b366f1a8a5244f218810a93a7a3c850a5895fc16eaab873d15 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0eadc8ff205398b366f1a8a5244f218810a93a7a3c850a5895fc16eaab873d15->enter($__internal_0eadc8ff205398b366f1a8a5244f218810a93a7a3c850a5895fc16eaab873d15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 53
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
";
        
        $__internal_0eadc8ff205398b366f1a8a5244f218810a93a7a3c850a5895fc16eaab873d15->leave($__internal_0eadc8ff205398b366f1a8a5244f218810a93a7a3c850a5895fc16eaab873d15_prof);

    }

    // line 56
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_89323da550681363a41888667b4e69355ebe09869b681cfc4c983f1a80b90d30 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_89323da550681363a41888667b4e69355ebe09869b681cfc4c983f1a80b90d30->enter($__internal_89323da550681363a41888667b4e69355ebe09869b681cfc4c983f1a80b90d30_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 57
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
";
        
        $__internal_89323da550681363a41888667b4e69355ebe09869b681cfc4c983f1a80b90d30->leave($__internal_89323da550681363a41888667b4e69355ebe09869b681cfc4c983f1a80b90d30_prof);

    }

    public function getTemplateName()
    {
        return "RegionBundle:Default:region.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  158 => 57,  152 => 56,  142 => 53,  136 => 52,  122 => 42,  109 => 37,  104 => 35,  100 => 34,  96 => 33,  92 => 32,  87 => 31,  83 => 30,  67 => 17,  55 => 7,  49 => 6,  37 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Mantenimiento de regiones{% endblock %}

{% block body %}
<section>
    <div class=\"bg-white\">
        <div class=\"text-center\">
            <h2 class=\"text-light-brown\"><strong>REGIONES</strong></h2>
        </div>
        <br>
        <div class=\"row\">
            <div class=\"col-md-auto\"></div>
            <div class=\"col\">
                <div class=\"pull-right mb-1\">
                    <a href=\"{{ path('region_new') }}\" class=\"btn btn-info btn-sm\"><i class=\"fa fa-plus-circle\" aria-hidden=\"true\"></i> Agregar</a>
                </div>
                <table class=\"table table-hover table-responsive\">
                    <thead class=\"thead-dark\">
                        <tr>
                            <th scope=\"col\">#</th>
                            <th scope=\"col\">Nombre</th>
                            <th scope=\"col\">Imagen</th>
                            <th scope=\"col\">Descripción</th>
                            <th scope=\"col\"></th>
                        </tr>
                    </thead>
                    <tbody>
                        {% for temp in regions %}
                            <tr ondblclick=\"document.getElementById('btn-{{ temp.getId() }}').click();\">
                                <th scope='row'>{{ temp.getId() }}</th>
                                <td>{{ temp.getName() }}</td>
                                <td><img src=\"{{ temp.getImage1() }}\" class=\"mediana\"></td>
                                <td class=\"text-justify\"><p>{{ temp.getDescription() }}</p></td>
                                <td>
                                    <a href=\"{{ path('region_edit', {'id': temp.getId() }) }}\" class='btn-hidden' id=\"btn-{{ temp.getId() }}\"> Editar</a>
                                    <button type=\"button\" class=\"btn btn-danger btn-sm\"><i class=\"fa fa-trash\" aria-hidden=\"true\"></i> Eliminar</button>
                                </td>
                            </tr>
                        {% endfor %}
                    </tbody>
                </table>
            </div>
            <div class=\"col-md-auto\"></div>
        </div>
    </div>
</section>
{% endblock %}


{% block stylesheets %}
    {{ parent() }}
{% endblock %}

{% block javascripts %}
    {{ parent() }}
{% endblock %}
", "RegionBundle:Default:region.html.twig", "C:\\xampp\\htdocs\\siteadminBootstrap4\\src\\RegionBundle\\Resources\\views\\Default\\region.html.twig");
    }
}
