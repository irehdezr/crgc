<?php

/* RegionBundle:Default:edit.html.twig */
class __TwigTemplate_437667416082d29eb2c8f9416f8a100238b861c6fc3891ed253533582b95aa7e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "RegionBundle:Default:edit.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_60d6dd927dc8e875ae7fd26a8dc5772f64758d968b9bb31f06986d894e8354f2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_60d6dd927dc8e875ae7fd26a8dc5772f64758d968b9bb31f06986d894e8354f2->enter($__internal_60d6dd927dc8e875ae7fd26a8dc5772f64758d968b9bb31f06986d894e8354f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "RegionBundle:Default:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_60d6dd927dc8e875ae7fd26a8dc5772f64758d968b9bb31f06986d894e8354f2->leave($__internal_60d6dd927dc8e875ae7fd26a8dc5772f64758d968b9bb31f06986d894e8354f2_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_9a8c80d69696b74e513a599c0b13ee2d7600c1f4491930095a8af725ebeaed8d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9a8c80d69696b74e513a599c0b13ee2d7600c1f4491930095a8af725ebeaed8d->enter($__internal_9a8c80d69696b74e513a599c0b13ee2d7600c1f4491930095a8af725ebeaed8d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Editar regiones";
        
        $__internal_9a8c80d69696b74e513a599c0b13ee2d7600c1f4491930095a8af725ebeaed8d->leave($__internal_9a8c80d69696b74e513a599c0b13ee2d7600c1f4491930095a8af725ebeaed8d_prof);

    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        $__internal_984db128d7e615cfd23917b8a8b34b72d34513e5afb8cd55ec9e47e2534e2cd6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_984db128d7e615cfd23917b8a8b34b72d34513e5afb8cd55ec9e47e2534e2cd6->enter($__internal_984db128d7e615cfd23917b8a8b34b72d34513e5afb8cd55ec9e47e2534e2cd6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "<section>
    <div class=\"bg-white\">
        <div class=\"text-center\">
            <h2 class=\"text-light-brown\"><strong>EDITAR REGIÓN</strong></h2>
        </div>
        <br>
        <div class=\"row\">
            <div class=\"col-auto\"></div>
            <div class=\"col\">
                    ";
        // line 16
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_start', array("attr" => array("novalidate" => "novalidate")));
        echo "
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 18
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "name", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            ";
        // line 20
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "name", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Nombre de la región")));
        echo "  
                            <span class=\"text-danger\">";
        // line 21
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "name", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 25
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image1", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            <img src=\"";
        // line 27
        echo twig_escape_filter($this->env, ($context["image1"] ?? $this->getContext($context, "image1")), "html", null, true);
        echo "\" class=\"mediana\">
                            ";
        // line 28
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image1", array()), 'widget', array("attr" => array("class" => "margin-left")));
        echo "  
                            <span class=\"text-danger\">";
        // line 29
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image1", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 33
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image_description1", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            ";
        // line 35
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image_description1", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Descripción de la imagen 1")));
        echo "  
                            <span class=\"text-danger\">";
        // line 36
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image_description1", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 40
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image2", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            <img src=\"";
        // line 42
        echo twig_escape_filter($this->env, ($context["image2"] ?? $this->getContext($context, "image2")), "html", null, true);
        echo "\" class=\"mediana\">
                            ";
        // line 43
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image2", array()), 'widget', array("attr" => array("class" => "margin-left")));
        echo "  
                            <span class=\"text-danger\">";
        // line 44
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image2", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 48
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image_description2", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            ";
        // line 50
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image_description2", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Descripción de la imagen 2")));
        echo "  
                            <span class=\"text-danger\">";
        // line 51
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image_description2", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 55
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image3", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            <img src=\"";
        // line 57
        echo twig_escape_filter($this->env, ($context["image3"] ?? $this->getContext($context, "image3")), "html", null, true);
        echo "\" class=\"mediana\">
                            ";
        // line 58
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image3", array()), 'widget', array("attr" => array("class" => "margin-left")));
        echo "  
                            <span class=\"text-danger\">";
        // line 59
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image3", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 63
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image_description3", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            ";
        // line 65
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image_description3", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Descripción de la imagen 3")));
        echo "  
                            <span class=\"text-danger\">";
        // line 66
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "image_description3", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 70
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "description", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            ";
        // line 72
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "description", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Descripción de la región", "rows" => "7", "cols" => "45")));
        echo "  
                            <span class=\"text-danger\">";
        // line 73
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "description", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 77
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "organoleptic_characteristics", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            ";
        // line 79
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "organoleptic_characteristics", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Características organolépticas de la región", "rows" => "7", "cols" => "45")));
        echo "  
                            <span class=\"text-danger\">";
        // line 80
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "organoleptic_characteristics", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 84
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "information", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            ";
        // line 86
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "information", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Información de la región", "rows" => "7", "cols" => "45")));
        echo "  
                            <span class=\"text-danger\">";
        // line 87
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "information", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 91
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "latitude", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            ";
        // line 93
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "latitude", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Latitud")));
        echo "  
                            <span class=\"text-danger\">";
        // line 94
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "latitude", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 98
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "longitude", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            ";
        // line 100
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "longitude", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Longitud")));
        echo "  
                            <span class=\"text-danger\">";
        // line 101
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "longitude", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">";
        // line 105
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "zoom", array()), 'label');
        echo "</label>
                        <div class=\"col-sm-8\">
                            ";
        // line 107
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "zoom", array()), 'widget', array("attr" => array("class" => "form-control", "placeholder" => "Zoom")));
        echo "  
                            <span class=\"text-danger\">";
        // line 108
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "zoom", array()), 'errors');
        echo "</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <div class=\"col-sm-10\">
                            <a href=\"";
        // line 113
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_homepage");
        echo "\" class=\"btn btn-dark btn-xs pull-right\"><i class=\"fa fa-ban\" aria-hidden=\"true\"></i> Cancelar</a>
                            ";
        // line 114
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "save", array()), 'widget', array("attr" => array("class" => "pull-right btn btn-success btn-margin", "fa" => "fa-floppy-o", "right" => true)));
        echo " ";
        // line 115
        echo "                        </div>
                    </div>
                    ";
        // line 117
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock(($context["form"] ?? $this->getContext($context, "form")), 'form_end');
        echo "
            </div>
            <div class=\"col-auto\"></div>
        </div>
    </div>
</section>

";
        
        $__internal_984db128d7e615cfd23917b8a8b34b72d34513e5afb8cd55ec9e47e2534e2cd6->leave($__internal_984db128d7e615cfd23917b8a8b34b72d34513e5afb8cd55ec9e47e2534e2cd6_prof);

    }

    // line 127
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_ea14f3f01a0ccaa670582b7f532232303c41e55f446de5a87750680b5023b10e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ea14f3f01a0ccaa670582b7f532232303c41e55f446de5a87750680b5023b10e->enter($__internal_ea14f3f01a0ccaa670582b7f532232303c41e55f446de5a87750680b5023b10e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 128
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
";
        
        $__internal_ea14f3f01a0ccaa670582b7f532232303c41e55f446de5a87750680b5023b10e->leave($__internal_ea14f3f01a0ccaa670582b7f532232303c41e55f446de5a87750680b5023b10e_prof);

    }

    // line 132
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_90ca86c4e5e1cfc141ca6e164dce9ce8afd31e2f70e1c4fcae659252bbeb94ba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_90ca86c4e5e1cfc141ca6e164dce9ce8afd31e2f70e1c4fcae659252bbeb94ba->enter($__internal_90ca86c4e5e1cfc141ca6e164dce9ce8afd31e2f70e1c4fcae659252bbeb94ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 133
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
";
        
        $__internal_90ca86c4e5e1cfc141ca6e164dce9ce8afd31e2f70e1c4fcae659252bbeb94ba->leave($__internal_90ca86c4e5e1cfc141ca6e164dce9ce8afd31e2f70e1c4fcae659252bbeb94ba_prof);

    }

    public function getTemplateName()
    {
        return "RegionBundle:Default:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  340 => 133,  334 => 132,  324 => 128,  318 => 127,  303 => 117,  299 => 115,  296 => 114,  292 => 113,  284 => 108,  280 => 107,  275 => 105,  268 => 101,  264 => 100,  259 => 98,  252 => 94,  248 => 93,  243 => 91,  236 => 87,  232 => 86,  227 => 84,  220 => 80,  216 => 79,  211 => 77,  204 => 73,  200 => 72,  195 => 70,  188 => 66,  184 => 65,  179 => 63,  172 => 59,  168 => 58,  164 => 57,  159 => 55,  152 => 51,  148 => 50,  143 => 48,  136 => 44,  132 => 43,  128 => 42,  123 => 40,  116 => 36,  112 => 35,  107 => 33,  100 => 29,  96 => 28,  92 => 27,  87 => 25,  80 => 21,  76 => 20,  71 => 18,  66 => 16,  55 => 7,  49 => 6,  37 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Editar regiones{% endblock %}

{% block body %}
<section>
    <div class=\"bg-white\">
        <div class=\"text-center\">
            <h2 class=\"text-light-brown\"><strong>EDITAR REGIÓN</strong></h2>
        </div>
        <br>
        <div class=\"row\">
            <div class=\"col-auto\"></div>
            <div class=\"col\">
                    {{ form_start(form, {'attr': {'novalidate': 'novalidate'}} ) }}
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.name) }}</label>
                        <div class=\"col-sm-8\">
                            {{ form_widget(form.name, { \"attr\": {\"class\": \"form-control\", \"placeholder\": \"Nombre de la región\"} }) }}  
                            <span class=\"text-danger\">{{ form_errors(form.name) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.image1) }}</label>
                        <div class=\"col-sm-8\">
                            <img src=\"{{ image1 }}\" class=\"mediana\">
                            {{ form_widget(form.image1, { \"attr\": {\"class\": \"margin-left\"} }) }}  
                            <span class=\"text-danger\">{{ form_errors(form.image1) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.image_description1) }}</label>
                        <div class=\"col-sm-8\">
                            {{ form_widget(form.image_description1, { \"attr\": {\"class\": \"form-control\", \"placeholder\": \"Descripción de la imagen 1\"} }) }}  
                            <span class=\"text-danger\">{{ form_errors(form.image_description1) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.image2) }}</label>
                        <div class=\"col-sm-8\">
                            <img src=\"{{ image2 }}\" class=\"mediana\">
                            {{ form_widget(form.image2, { \"attr\": {\"class\": \"margin-left\"} }) }}  
                            <span class=\"text-danger\">{{ form_errors(form.image2) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.image_description2) }}</label>
                        <div class=\"col-sm-8\">
                            {{ form_widget(form.image_description2, { \"attr\": {\"class\": \"form-control\", \"placeholder\": \"Descripción de la imagen 2\"} }) }}  
                            <span class=\"text-danger\">{{ form_errors(form.image_description2) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.image3) }}</label>
                        <div class=\"col-sm-8\">
                            <img src=\"{{ image3 }}\" class=\"mediana\">
                            {{ form_widget(form.image3, { \"attr\": {\"class\": \"margin-left\"} }) }}  
                            <span class=\"text-danger\">{{ form_errors(form.image3) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.image_description3) }}</label>
                        <div class=\"col-sm-8\">
                            {{ form_widget(form.image_description3, { \"attr\": {\"class\": \"form-control\", \"placeholder\": \"Descripción de la imagen 3\"} }) }}  
                            <span class=\"text-danger\">{{ form_errors(form.image_description3) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.description) }}</label>
                        <div class=\"col-sm-8\">
                            {{ form_widget(form.description, { \"attr\": {\"class\": \"form-control\", \"placeholder\": \"Descripción de la región\", \"rows\": \"7\", \"cols\": \"45\" } }) }}  
                            <span class=\"text-danger\">{{ form_errors(form.description) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.organoleptic_characteristics) }}</label>
                        <div class=\"col-sm-8\">
                            {{ form_widget(form.organoleptic_characteristics, { \"attr\": {\"class\": \"form-control\", \"placeholder\": \"Características organolépticas de la región\", \"rows\": \"7\", \"cols\": \"45\" } }) }}  
                            <span class=\"text-danger\">{{ form_errors(form.organoleptic_characteristics) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.information) }}</label>
                        <div class=\"col-sm-8\">
                            {{ form_widget(form.information, { \"attr\": {\"class\": \"form-control\", \"placeholder\": \"Información de la región\", \"rows\": \"7\", \"cols\": \"45\" } }) }}  
                            <span class=\"text-danger\">{{ form_errors(form.information) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.latitude) }}</label>
                        <div class=\"col-sm-8\">
                            {{ form_widget(form.latitude, { \"attr\": {\"class\": \"form-control\", \"placeholder\": \"Latitud\"} }) }}  
                            <span class=\"text-danger\">{{ form_errors(form.latitude) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.longitude) }}</label>
                        <div class=\"col-sm-8\">
                            {{ form_widget(form.longitude, { \"attr\": {\"class\": \"form-control\", \"placeholder\": \"Longitud\"} }) }}  
                            <span class=\"text-danger\">{{ form_errors(form.longitude) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 col-form-label\">{{ form_label(form.zoom) }}</label>
                        <div class=\"col-sm-8\">
                            {{ form_widget(form.zoom, { \"attr\": {\"class\": \"form-control\", \"placeholder\": \"Zoom\"} }) }}  
                            <span class=\"text-danger\">{{ form_errors(form.zoom) }}</span>  
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <div class=\"col-sm-10\">
                            <a href=\"{{ path('region_homepage') }}\" class=\"btn btn-dark btn-xs pull-right\"><i class=\"fa fa-ban\" aria-hidden=\"true\"></i> Cancelar</a>
                            {{ form_widget(form.save, {\"attr\": { \"class\": \"pull-right btn btn-success btn-margin\",'fa' : 'fa-floppy-o','right' : true} }) }} {#<i class=\"fa fa-floppy-o\" aria-hidden=\"true\"></i>#}
                        </div>
                    </div>
                    {{ form_end(form) }}
            </div>
            <div class=\"col-auto\"></div>
        </div>
    </div>
</section>

{% endblock %}


{% block stylesheets %}
    {{ parent() }}
{% endblock %}


{% block javascripts %}
    {{ parent() }}
{% endblock %}
", "RegionBundle:Default:edit.html.twig", "C:\\xampp\\htdocs\\siteadminBootstrap4\\src\\RegionBundle\\Resources\\views\\Default\\edit.html.twig");
    }
}
