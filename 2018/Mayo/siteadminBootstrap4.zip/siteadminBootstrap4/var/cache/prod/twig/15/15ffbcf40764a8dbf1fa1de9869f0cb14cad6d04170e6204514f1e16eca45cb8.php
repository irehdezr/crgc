<?php

/* RegionBundle:Default:edit.html.twig */
class __TwigTemplate_2a1fb1e22175ccf66bceb35ad929932c710b9e4b04d7f53826e9c2982681d805 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "RegionBundle:Default:edit.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_403b04f6da68f91d0eccb3b023214ae4a2e36f6c98600b3ec61594e28d1c439b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_403b04f6da68f91d0eccb3b023214ae4a2e36f6c98600b3ec61594e28d1c439b->enter($__internal_403b04f6da68f91d0eccb3b023214ae4a2e36f6c98600b3ec61594e28d1c439b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "RegionBundle:Default:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_403b04f6da68f91d0eccb3b023214ae4a2e36f6c98600b3ec61594e28d1c439b->leave($__internal_403b04f6da68f91d0eccb3b023214ae4a2e36f6c98600b3ec61594e28d1c439b_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_9809925ef438f7b5ae5800e87cbdabb776676057fbc07edfe4357e16a1202b79 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9809925ef438f7b5ae5800e87cbdabb776676057fbc07edfe4357e16a1202b79->enter($__internal_9809925ef438f7b5ae5800e87cbdabb776676057fbc07edfe4357e16a1202b79_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Editar regiones";
        
        $__internal_9809925ef438f7b5ae5800e87cbdabb776676057fbc07edfe4357e16a1202b79->leave($__internal_9809925ef438f7b5ae5800e87cbdabb776676057fbc07edfe4357e16a1202b79_prof);

    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        $__internal_f588133cb8887db486688d00b9cc1e9816b513b5aeea04150252dd0bded55221 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f588133cb8887db486688d00b9cc1e9816b513b5aeea04150252dd0bded55221->enter($__internal_f588133cb8887db486688d00b9cc1e9816b513b5aeea04150252dd0bded55221_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "<div class=\"row col-md-8 col-md-offset-2 custyle\" style=\"margin-top: 20px;\">
    <table class=\"table table-striped custab\">
        <thead>
        <tr>
            <th class=\"text-center\" colspan=\"2\">EDICIÓN DE REGIONES</th>
        </tr>
        </thead>
        <tbody>
        ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["regions"] ?? $this->getContext($context, "regions")));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 16
            echo "            <tr>
                <th>ID</th>
                <td> ";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "</td>
            </tr>
            <tr>
                <th>Nombre</th>
                <td><input type=\"text\" name=\"name\" value=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo "\" id=\"name\"></td>
            </tr>
            <tr>
                <th>Imagen 1</th>
                <td>
                    <img src=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage1", array(), "method"), "html", null, true);
            echo "\" class=\"mediana\">
                    <form id=\"myform1\" method=\"post\" style=\"margin-top: 5px;\">
                        <input type=\"button\" id=\"loadFileXml\" value=\"Seleccione un archivo\"
                               onclick=\"document.getElementById('image1').click();\"/>
                        <input id=\"image1\" style=\"display:none;\" type=\"file\" name=\"upload\"/>
                    </form>
                    <p id=\"image1Error\" style=\"color: red; display: none;\">
                        <small>Selecciona una imagen</small>
                    </p>
                    <p id=\"image1-1Error\" style=\"color: red; display: none;\">
                        <small>Selecciona una imagen con la extensión .jpg, .jpeg, .gif o .png</small>
                    </p>
                </td>
            </tr>
            <tr>
                <th>Descripción de la imagen 1</th>
                <td><input type=\"text\" name=\"description-img1\" value=\"";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImageDescription1", array(), "method"), "html", null, true);
            echo "\"
                           id=\"description-img1\"></td>
            </tr>
            <tr>
                <th>Imagen 2</th>
                <td>
                    <img src=\"";
            // line 49
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage2", array(), "method"), "html", null, true);
            echo "\" class=\"mediana\">
                    <form id=\"myform2\" method=\"post\" style=\"margin-top: 5px;\">
                        <input type=\"button\" id=\"loadFileXml\" value=\"Seleccione un archivo\"
                               onclick=\"document.getElementById('image2').click();\"/>
                        <input id=\"image2\" style=\"display:none;\" type=\"file\" name=\"upload\"/>
                    </form>
                    <p id=\"image2Error\" style=\"color: red; display: none;\">
                        <small>Selecciona una imagen</small>
                    </p>
                    <p id=\"image2-2Error\" style=\"color: red; display: none;\">
                        <small>Selecciona una imagen con la extensión .jpg, .jpeg, .gif o .png</small>
                    </p>
                </td>
            </tr>
            <tr>
                <th>Descripción de la imagen2</th>
                <td><input type=\"text\" name=\"description-img2\" value=\"";
            // line 65
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImageDescription2", array(), "method"), "html", null, true);
            echo "\"
                           id=\"description-img2\"></td>
            </tr>
            <tr>
                <th>Imagen 3</th>
                <td>
                    <img src=\"";
            // line 71
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage3", array(), "method"), "html", null, true);
            echo "\" class=\"mediana\">
                    <form id=\"myform3\" method=\"post\" style=\"margin-top: 5px;\">
                        <input type=\"button\" id=\"loadFileXml\" value=\"Seleccione un archivo\"
                               onclick=\"document.getElementById('image3').click();\"/>
                        <input id=\"image3\" style=\"display:none;\" type=\"file\" name=\"upload\"/>
                    </form>
                    <p id=\"image3Error\" style=\"color: red; display: none;\">
                        <small>Selecciona una imagen</small>
                    </p>
                    <p id=\"image3-3Error\" style=\"color: red; display: none;\">
                        <small>Selecciona una imagen con la extensión .jpg, .jpeg, .gif o .png</small>
                    </p>
                </td>
            </tr>
            <tr>
                <th>Descripción de la imagen 3</th>
                <td><input type=\"text\" name=\"description-img3\" value=\"";
            // line 87
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImageDescription3", array(), "method"), "html", null, true);
            echo "\"
                           id=\"description-img3\"></td>
            </tr>
            <tr>
                <th>Descripción (en inglés)</th>
                <td><textarea name=\"description\" rows=\"10\" cols=\"55\"
                              id=\"description\">";
            // line 93
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getDescription", array(), "method"), "html", null, true);
            echo "</textarea></td>
            </tr>
            <tr>
                <th>Características organolépticas (en inglés)</th>
                <td><textarea name=\"organoleptic\" rows=\"10\" cols=\"55\"
                              id=\"organoleptic\">";
            // line 98
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getOrganolepticCharacteristics", array(), "method"), "html", null, true);
            echo "</textarea></td>
            </tr>
            <tr>
                <th>Información (en inglés)</th>
                <td><textarea name=\"information\" rows=\"10\" cols=\"55\"
                              id=\"information\">";
            // line 103
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getInformation", array(), "method"), "html", null, true);
            echo "</textarea></td>
            </tr>
            <tr>
                <th>Latitud</th>
                <td><input type=\"text\" name=\"latitude\" value=\"";
            // line 107
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getLatitude", array(), "method"), "html", null, true);
            echo "\" id=\"latitude\"></td>
            </tr>
            <tr>
                <th>Longitud</th>
                <td><input type=\"text\" name=\"longitude\" value=\"";
            // line 111
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getLongitude", array(), "method"), "html", null, true);
            echo "\" id=\"longitude\"></td>
            </tr>
            <tr>
                <th>Zoom</th>
                <td>
                    <input type=\"text\" name=\"zoom\" value=\"";
            // line 116
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getZoom", array(), "method"), "html", null, true);
            echo "\" id=\"zoom\">
                    <p id=\"zoomError\" style=\"color: red; display: none;\">
                        <small>El zoom no puede ser un número de más de dos dígitos</small>
                    </p>
                </td>
            </tr>
            <tr>
                <td class=\"text-center\" colspan=\"2\">
                    <a class='btn btn-success btn-xs btn-save' id=\"";
            // line 124
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\"><span
                                class=\"glyphicon glyphicon-save\"></span> Guardar</a>
                    <a href=\"";
            // line 126
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_homepage");
            echo "\" class=\"btn btn-warning btn-xs\"><span
                                class=\"glyphicon glyphicon-ban-circle\"></span> Cancelar</a>
                </td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 131
        echo "        </tbody>
    </table>
</div>

<!-- The Modal -->
<div id=\"errorModal\" class=\"modal\" role=\"dialog\">
    <div class=\"modal-dialog modal-lg\">
        <!-- Modal content -->
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <span class=\"close\">&times;</span>
                <div id=\"modal-header\">
                    <h3 style=\"color: red;\">Error</h3>
                </div>
            </div>
            <div class=\"modal-body\" id=\"modal-body\">
                <span class='glyphicon glyphicon-remove-sign modal-icon'></span>
                <p class='modal-p'>Algunos campos se encuentran en blanco</p>
            </div>
        </div>
    </div>
    ";
        
        $__internal_f588133cb8887db486688d00b9cc1e9816b513b5aeea04150252dd0bded55221->leave($__internal_f588133cb8887db486688d00b9cc1e9816b513b5aeea04150252dd0bded55221_prof);

    }

    // line 155
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_aec96f7d075cf52a7ef4df26e6b790c457aee06e3810b74d8e1712844204a4f5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aec96f7d075cf52a7ef4df26e6b790c457aee06e3810b74d8e1712844204a4f5->enter($__internal_aec96f7d075cf52a7ef4df26e6b790c457aee06e3810b74d8e1712844204a4f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 156
        echo "        ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
        <link rel=\"stylesheet\" href=\"";
        // line 157
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 158
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/css/styles.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_aec96f7d075cf52a7ef4df26e6b790c457aee06e3810b74d8e1712844204a4f5->leave($__internal_aec96f7d075cf52a7ef4df26e6b790c457aee06e3810b74d8e1712844204a4f5_prof);

    }

    // line 162
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_46a336b30433ab67d4f6591db36e411bfd6355efef162ec903f7e4c123513c81 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_46a336b30433ab67d4f6591db36e411bfd6355efef162ec903f7e4c123513c81->enter($__internal_46a336b30433ab67d4f6591db36e411bfd6355efef162ec903f7e4c123513c81_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 163
        echo "        ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
        <script type=\"text/javascript\" src=\"";
        // line 164
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 165
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/js/regions.js"), "html", null, true);
        echo "\"></script>
    ";
        
        $__internal_46a336b30433ab67d4f6591db36e411bfd6355efef162ec903f7e4c123513c81->leave($__internal_46a336b30433ab67d4f6591db36e411bfd6355efef162ec903f7e4c123513c81_prof);

    }

    public function getTemplateName()
    {
        return "RegionBundle:Default:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  304 => 165,  300 => 164,  295 => 163,  289 => 162,  280 => 158,  276 => 157,  271 => 156,  265 => 155,  237 => 131,  226 => 126,  221 => 124,  210 => 116,  202 => 111,  195 => 107,  188 => 103,  180 => 98,  172 => 93,  163 => 87,  144 => 71,  135 => 65,  116 => 49,  107 => 43,  88 => 27,  80 => 22,  73 => 18,  69 => 16,  65 => 15,  55 => 7,  49 => 6,  37 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Editar regiones{% endblock %}

{% block body %}
<div class=\"row col-md-8 col-md-offset-2 custyle\" style=\"margin-top: 20px;\">
    <table class=\"table table-striped custab\">
        <thead>
        <tr>
            <th class=\"text-center\" colspan=\"2\">EDICIÓN DE REGIONES</th>
        </tr>
        </thead>
        <tbody>
        {% for temp in regions %}
            <tr>
                <th>ID</th>
                <td> {{ temp.getId() }}</td>
            </tr>
            <tr>
                <th>Nombre</th>
                <td><input type=\"text\" name=\"name\" value=\"{{ temp.getName() }}\" id=\"name\"></td>
            </tr>
            <tr>
                <th>Imagen 1</th>
                <td>
                    <img src=\"{{ temp.getImage1() }}\" class=\"mediana\">
                    <form id=\"myform1\" method=\"post\" style=\"margin-top: 5px;\">
                        <input type=\"button\" id=\"loadFileXml\" value=\"Seleccione un archivo\"
                               onclick=\"document.getElementById('image1').click();\"/>
                        <input id=\"image1\" style=\"display:none;\" type=\"file\" name=\"upload\"/>
                    </form>
                    <p id=\"image1Error\" style=\"color: red; display: none;\">
                        <small>Selecciona una imagen</small>
                    </p>
                    <p id=\"image1-1Error\" style=\"color: red; display: none;\">
                        <small>Selecciona una imagen con la extensión .jpg, .jpeg, .gif o .png</small>
                    </p>
                </td>
            </tr>
            <tr>
                <th>Descripción de la imagen 1</th>
                <td><input type=\"text\" name=\"description-img1\" value=\"{{ temp.getImageDescription1() }}\"
                           id=\"description-img1\"></td>
            </tr>
            <tr>
                <th>Imagen 2</th>
                <td>
                    <img src=\"{{ temp.getImage2() }}\" class=\"mediana\">
                    <form id=\"myform2\" method=\"post\" style=\"margin-top: 5px;\">
                        <input type=\"button\" id=\"loadFileXml\" value=\"Seleccione un archivo\"
                               onclick=\"document.getElementById('image2').click();\"/>
                        <input id=\"image2\" style=\"display:none;\" type=\"file\" name=\"upload\"/>
                    </form>
                    <p id=\"image2Error\" style=\"color: red; display: none;\">
                        <small>Selecciona una imagen</small>
                    </p>
                    <p id=\"image2-2Error\" style=\"color: red; display: none;\">
                        <small>Selecciona una imagen con la extensión .jpg, .jpeg, .gif o .png</small>
                    </p>
                </td>
            </tr>
            <tr>
                <th>Descripción de la imagen2</th>
                <td><input type=\"text\" name=\"description-img2\" value=\"{{ temp.getImageDescription2() }}\"
                           id=\"description-img2\"></td>
            </tr>
            <tr>
                <th>Imagen 3</th>
                <td>
                    <img src=\"{{ temp.getImage3() }}\" class=\"mediana\">
                    <form id=\"myform3\" method=\"post\" style=\"margin-top: 5px;\">
                        <input type=\"button\" id=\"loadFileXml\" value=\"Seleccione un archivo\"
                               onclick=\"document.getElementById('image3').click();\"/>
                        <input id=\"image3\" style=\"display:none;\" type=\"file\" name=\"upload\"/>
                    </form>
                    <p id=\"image3Error\" style=\"color: red; display: none;\">
                        <small>Selecciona una imagen</small>
                    </p>
                    <p id=\"image3-3Error\" style=\"color: red; display: none;\">
                        <small>Selecciona una imagen con la extensión .jpg, .jpeg, .gif o .png</small>
                    </p>
                </td>
            </tr>
            <tr>
                <th>Descripción de la imagen 3</th>
                <td><input type=\"text\" name=\"description-img3\" value=\"{{ temp.getImageDescription3() }}\"
                           id=\"description-img3\"></td>
            </tr>
            <tr>
                <th>Descripción (en inglés)</th>
                <td><textarea name=\"description\" rows=\"10\" cols=\"55\"
                              id=\"description\">{{ temp.getDescription() }}</textarea></td>
            </tr>
            <tr>
                <th>Características organolépticas (en inglés)</th>
                <td><textarea name=\"organoleptic\" rows=\"10\" cols=\"55\"
                              id=\"organoleptic\">{{ temp.getOrganolepticCharacteristics() }}</textarea></td>
            </tr>
            <tr>
                <th>Información (en inglés)</th>
                <td><textarea name=\"information\" rows=\"10\" cols=\"55\"
                              id=\"information\">{{ temp.getInformation() }}</textarea></td>
            </tr>
            <tr>
                <th>Latitud</th>
                <td><input type=\"text\" name=\"latitude\" value=\"{{ temp.getLatitude() }}\" id=\"latitude\"></td>
            </tr>
            <tr>
                <th>Longitud</th>
                <td><input type=\"text\" name=\"longitude\" value=\"{{ temp.getLongitude() }}\" id=\"longitude\"></td>
            </tr>
            <tr>
                <th>Zoom</th>
                <td>
                    <input type=\"text\" name=\"zoom\" value=\"{{ temp.getZoom() }}\" id=\"zoom\">
                    <p id=\"zoomError\" style=\"color: red; display: none;\">
                        <small>El zoom no puede ser un número de más de dos dígitos</small>
                    </p>
                </td>
            </tr>
            <tr>
                <td class=\"text-center\" colspan=\"2\">
                    <a class='btn btn-success btn-xs btn-save' id=\"{{ temp.getId() }}\"><span
                                class=\"glyphicon glyphicon-save\"></span> Guardar</a>
                    <a href=\"{{ path('region_homepage') }}\" class=\"btn btn-warning btn-xs\"><span
                                class=\"glyphicon glyphicon-ban-circle\"></span> Cancelar</a>
                </td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
</div>

<!-- The Modal -->
<div id=\"errorModal\" class=\"modal\" role=\"dialog\">
    <div class=\"modal-dialog modal-lg\">
        <!-- Modal content -->
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <span class=\"close\">&times;</span>
                <div id=\"modal-header\">
                    <h3 style=\"color: red;\">Error</h3>
                </div>
            </div>
            <div class=\"modal-body\" id=\"modal-body\">
                <span class='glyphicon glyphicon-remove-sign modal-icon'></span>
                <p class='modal-p'>Algunos campos se encuentran en blanco</p>
            </div>
        </div>
    </div>
    {% endblock %}


    {% block stylesheets %}
        {{ parent() }}
        <link rel=\"stylesheet\" href=\"{{ asset('/siteadmin/web/css/crgourmetcoffee.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('/siteadmin/web/css/styles.css') }}\">
    {% endblock %}


    {% block javascripts %}
        {{ parent() }}
        <script type=\"text/javascript\" src=\"{{ asset('/siteadmin/web/js/jquery-3.2.0.min.js') }}\"></script>
        <script type=\"text/javascript\" src=\"{{ asset('/siteadmin/web/js/regions.js') }}\"></script>
    {% endblock %}
", "RegionBundle:Default:edit.html.twig", "/Applications/MAMP/htdocs/siteadmin/src/RegionBundle/Resources/views/Default/edit.html.twig");
    }
}
