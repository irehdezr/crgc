<?php

// TwigBundle:Exception:exception.html.twig
return array (
);
