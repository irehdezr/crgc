<?php

// TwigBundle:Exception:error.rdf.twig
return array (
);
