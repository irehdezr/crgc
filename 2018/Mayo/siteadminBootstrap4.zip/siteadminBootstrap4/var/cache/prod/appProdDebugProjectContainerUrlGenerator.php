<?php

use Symfony\Component\Routing\RequestContext;
use Symfony\Component\Routing\Exception\RouteNotFoundException;
use Psr\Log\LoggerInterface;

/**
 * appProdDebugProjectContainerUrlGenerator
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdDebugProjectContainerUrlGenerator extends Symfony\Component\Routing\Generator\UrlGenerator
{
    private static $declaredRoutes;

    /**
     * Constructor.
     */
    public function __construct(RequestContext $context, LoggerInterface $logger = null)
    {
        $this->context = $context;
        $this->logger = $logger;
        if (null === self::$declaredRoutes) {
            self::$declaredRoutes = array(
        'farm_homepage' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\DefaultController::indexAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/farm/',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'farm_edit' => array (  0 =>   array (    0 => 'id',  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\DefaultController::editAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'id',    ),    1 =>     array (      0 => 'text',      1 => '/farm/edit',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'farm_save' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\DefaultController::saveAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/farm/save',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'farm_add' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\DefaultController::addAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/farm/add',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'farm_insert' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\DefaultController::insertAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/farm/insert',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'farm_delete' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\DefaultController::deleteAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/farm/delete',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'farm_image' => array (  0 =>   array (    0 => 'id',  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\DefaultController::imageAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'id',    ),    1 =>     array (      0 => 'text',      1 => '/farm/image',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'farm_add_cultivar' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\DefaultController::addCultivarAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/farm/addCultivar',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'farm_delete_cultivar' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\DefaultController::deleteCultivarAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/farm/deleteCultivar',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'farm_add_certifications' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\DefaultController::addCertificationsAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/farm/addCertifications',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'farm_delete_certifications' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\DefaultController::deleteCertificationsAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/farm/deleteCertifications',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'farm_add_awards' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\DefaultController::addAwardsAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/farm/addAwards',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'farm_delete_awards' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\DefaultController::deleteAwardsAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/farm/deleteAwards',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'farm_search' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\DefaultController::searchAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/farm/search',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'farm_product_homepage' => array (  0 =>   array (    0 => 'id',  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\ProductController::indexAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'id',    ),    1 =>     array (      0 => 'text',      1 => '/farm/products',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'farm_product_edit' => array (  0 =>   array (    0 => 'id',  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\ProductController::editViewAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'id',    ),    1 =>     array (      0 => 'text',      1 => '/farm/products/edit',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'farm_product_save' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\ProductController::saveAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/farm/save/products',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'farm_product_add_presentations' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\ProductController::addPresentationsAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/farm/addPresentation/products',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'farm_product_delete_presentations' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\ProductController::deletePresentationsAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/farm/presentationDelete/products',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'farm_product_add' => array (  0 =>   array (    0 => 'id',  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\ProductController::addAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'id',    ),    1 =>     array (      0 => 'text',      1 => '/farm/products/add',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'farm_product_insert' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\ProductController::insertAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/farm/products/insert/save',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'farm_product_image' => array (  0 =>   array (    0 => 'id',  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\ProductController::imageAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'id',    ),    1 =>     array (      0 => 'text',      1 => '/farm/image/product',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'farm_product_search' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\ProductController::searchAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/farm/product/search',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'farm_product_delete' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\ProductController::deleteAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/farm/product/delete',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'farm_award_pdf' => array (  0 =>   array (    0 => 'id',    1 => 'place',    2 => 'year',  ),  1 =>   array (    '_controller' => 'FarmBundle\\Controller\\DefaultController::pdfAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'year',    ),    1 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'place',    ),    2 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'id',    ),    3 =>     array (      0 => 'text',      1 => '/farm/pdf',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'region_homepage' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'RegionBundle\\Controller\\DefaultController::indexAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/region/',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'region_edit' => array (  0 =>   array (    0 => 'id',  ),  1 =>   array (    '_controller' => 'RegionBundle\\Controller\\DefaultController::editAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'id',    ),    1 =>     array (      0 => 'text',      1 => '/region/edit',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'region_new' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'RegionBundle\\Controller\\DefaultController::newAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/region/new',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'region_delete' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'RegionBundle\\Controller\\DefaultController::deleteAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/region/delete',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'app_homepage' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
    );
        }
    }

    public function generate($name, $parameters = array(), $referenceType = self::ABSOLUTE_PATH)
    {
        if (!isset(self::$declaredRoutes[$name])) {
            throw new RouteNotFoundException(sprintf('Unable to generate a URL for the named route "%s" as such route does not exist.', $name));
        }

        list($variables, $defaults, $requirements, $tokens, $hostTokens, $requiredSchemes) = self::$declaredRoutes[$name];

        return $this->doGenerate($variables, $defaults, $requirements, $tokens, $parameters, $name, $referenceType, $hostTokens, $requiredSchemes);
    }
}
