<?php

/* AppBundle:Default:home.html.twig */
class __TwigTemplate_aa1aefe1a53b811368de2dcf739ad6582b54e2ed14d3d04561e89cd08b3efd9e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "AppBundle:Default:home.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7b00636eb15daebeccacc16d311c2fbe8b92584565bcb543e5db0c9f0918d0bf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7b00636eb15daebeccacc16d311c2fbe8b92584565bcb543e5db0c9f0918d0bf->enter($__internal_7b00636eb15daebeccacc16d311c2fbe8b92584565bcb543e5db0c9f0918d0bf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Default:home.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7b00636eb15daebeccacc16d311c2fbe8b92584565bcb543e5db0c9f0918d0bf->leave($__internal_7b00636eb15daebeccacc16d311c2fbe8b92584565bcb543e5db0c9f0918d0bf_prof);

    }

    // line 4
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_3a4a107138696636b348ec6c6c1410ce51e231cfb936d8d82549b622bdf6469d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3a4a107138696636b348ec6c6c1410ce51e231cfb936d8d82549b622bdf6469d->enter($__internal_3a4a107138696636b348ec6c6c1410ce51e231cfb936d8d82549b622bdf6469d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 5
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/css/styles.css"), "html", null, true);
        echo "\">
";
        
        $__internal_3a4a107138696636b348ec6c6c1410ce51e231cfb936d8d82549b622bdf6469d->leave($__internal_3a4a107138696636b348ec6c6c1410ce51e231cfb936d8d82549b622bdf6469d_prof);

    }

    // line 10
    public function block_title($context, array $blocks = array())
    {
        $__internal_efcb33961561616a2c57d19924c35b767206e62b57b66409591e1e8578bf359e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_efcb33961561616a2c57d19924c35b767206e62b57b66409591e1e8578bf359e->enter($__internal_efcb33961561616a2c57d19924c35b767206e62b57b66409591e1e8578bf359e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 11
        echo "    Principal
";
        
        $__internal_efcb33961561616a2c57d19924c35b767206e62b57b66409591e1e8578bf359e->leave($__internal_efcb33961561616a2c57d19924c35b767206e62b57b66409591e1e8578bf359e_prof);

    }

    // line 14
    public function block_body($context, array $blocks = array())
    {
        $__internal_f44e78b93a996599d4b2f9a5c06cc7db92fc552ea47eee0d34a8dab773c3bcef = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f44e78b93a996599d4b2f9a5c06cc7db92fc552ea47eee0d34a8dab773c3bcef->enter($__internal_f44e78b93a996599d4b2f9a5c06cc7db92fc552ea47eee0d34a8dab773c3bcef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 15
        echo "    <div class=\"row col-md-9 col-md-offset-1 custyle\">
        <table class=\"table table-striped custab\" style=\"margin-top: 20px;\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"2\">MANTENIMIENTO</th>
            </tr>
            <tr>
                <th>Título</th>
                <th class=\"text-center\">Acción</th>
            </tr>
            </thead>
            <tr>
                <td>Regiones</td>
                <td class=\"text-center\">
                    <a class='btn btn-primary btn-xs' href=\"";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_homepage");
        echo "\">
                        <span class=\"glyphicon glyphicon-ok\"></span> Seleccionar</a>
                </td>
            </tr>
            <tr>
                <td>Fincas</td>
                <td class=\"text-center\">
                    <a class='btn btn-primary btn-xs' href=\"";
        // line 36
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_homepage");
        echo "\">
                        <span class=\"glyphicon glyphicon-ok\"></span> Seleccionar</a>
                </td>
            </tr>
            ";
        // line 47
        echo "        </table>
    </div>
";
        
        $__internal_f44e78b93a996599d4b2f9a5c06cc7db92fc552ea47eee0d34a8dab773c3bcef->leave($__internal_f44e78b93a996599d4b2f9a5c06cc7db92fc552ea47eee0d34a8dab773c3bcef_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Default:home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  113 => 47,  106 => 36,  96 => 29,  80 => 15,  74 => 14,  66 => 11,  60 => 10,  51 => 7,  47 => 6,  42 => 5,  36 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "AppBundle:Default:home.html.twig", "C:\\xampp\\htdocs\\siteadmin\\src\\AppBundle/Resources/views/Default/home.html.twig");
    }
}
