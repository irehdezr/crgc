<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_55324aca6eb7f607455c5a8ae6bc52ee1793161c0b28061d12da0466111662d1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bc2ad2561c3d977e228bfa25a2487caf29c31e45e55f42609443e76430acb774 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bc2ad2561c3d977e228bfa25a2487caf29c31e45e55f42609443e76430acb774->enter($__internal_bc2ad2561c3d977e228bfa25a2487caf29c31e45e55f42609443e76430acb774_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bc2ad2561c3d977e228bfa25a2487caf29c31e45e55f42609443e76430acb774->leave($__internal_bc2ad2561c3d977e228bfa25a2487caf29c31e45e55f42609443e76430acb774_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_8afadeccfda4ee37c5fec0be9f1e3c4d8cdef2d16ef7feca4e233173b01c74d7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8afadeccfda4ee37c5fec0be9f1e3c4d8cdef2d16ef7feca4e233173b01c74d7->enter($__internal_8afadeccfda4ee37c5fec0be9f1e3c4d8cdef2d16ef7feca4e233173b01c74d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_8afadeccfda4ee37c5fec0be9f1e3c4d8cdef2d16ef7feca4e233173b01c74d7->leave($__internal_8afadeccfda4ee37c5fec0be9f1e3c4d8cdef2d16ef7feca4e233173b01c74d7_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_a99b78839c233e647c3f32ca6f778594d8cdc53150dc34bcf121fc33195c7e37 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a99b78839c233e647c3f32ca6f778594d8cdc53150dc34bcf121fc33195c7e37->enter($__internal_a99b78839c233e647c3f32ca6f778594d8cdc53150dc34bcf121fc33195c7e37_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_a99b78839c233e647c3f32ca6f778594d8cdc53150dc34bcf121fc33195c7e37->leave($__internal_a99b78839c233e647c3f32ca6f778594d8cdc53150dc34bcf121fc33195c7e37_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_4177607d0dd68fa446621a253b3739fe7b0911fe4174a87ffa976ae4eec24a22 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4177607d0dd68fa446621a253b3739fe7b0911fe4174a87ffa976ae4eec24a22->enter($__internal_4177607d0dd68fa446621a253b3739fe7b0911fe4174a87ffa976ae4eec24a22_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? null))));
        echo "
";
        
        $__internal_4177607d0dd68fa446621a253b3739fe7b0911fe4174a87ffa976ae4eec24a22->leave($__internal_4177607d0dd68fa446621a253b3739fe7b0911fe4174a87ffa976ae4eec24a22_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@WebProfiler/Collector/router.html.twig", "C:\\xampp\\htdocs\\siteadmin\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
