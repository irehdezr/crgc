$.ajaxSetup({

    error: function( jqXHR, textStatus, errorThrown ) {

        if (jqXHR.status === 0) {

            alert('Not connect: Verify Network.');

        } else if (jqXHR.status === 404) {

            alert('Requested page not found [404]');

        } else if (jqXHR.status === 500) {

            alert('Internal Server Error [500].');

        } else if (textStatus === 'parsererror') {

            alert('Requested JSON parse failed.');

        } else if (textStatus === 'timeout') {

            alert('Time out error.');

        } else if (textStatus === 'abort') {

            alert('Ajax request aborted.');

        } else {

            alert('Uncaught Error: ' + jqXHR.responseText);

        }

    }
});

$(document).ready(function () {
   $('.btn-edit').click(function( e ) {
        e.preventDefault();
        doEdit(this.id);
   });
   $('.btn-save').click(function( e ) {
        e.preventDefault();
        doSave(this.id);
   });
   $('.btn-insert').click(function( e ) {
        e.preventDefault();
        doInsert();
   });
   $('#harvest-begin').change(function (e) {
       e.preventDefault();
       harvestBegin();
   });
   $('#harvest-end').change(function (e) {
        e.preventDefault();
        harvestEnd();
   });
   $('#elevation-Min').change(function (e) {
        e.preventDefault();
        elevationMin();
   });
   $('#elevation-Max').change(function (e) {
        e.preventDefault();
        elevationMax();
   });
   $('.btn-add-award').click(function( e ) {
        e.preventDefault();
        awardAdd(this.id);
   });
   $('.btn-delete-award').click(function( e ) {
        e.preventDefault();
        awardDelete(this.id);
   });
   $('.btn-delete').click(function (e) {
       e.preventDefault();
       deleteConfirmationPopUp(this.id, this.name);
   });
   $('.btn-delete-confirmation').click(function (e) {
       e.preventDefault();
       $('#deleteConfirmation').hide();
       doDelete(this.id);
   });
    $('.btn-delete-pdf').click(function (e) {
        e.preventDefault();
        alert("Eliminar pdf");
        pdfDelete(this.id);
    });
});


// --------------------- Edit ----------------------------
function doEdit(id){
    var result = edit(id);
    if(result){
        location.href = result;
    }
}

function edit(id){
    var url = "/siteadmin/web/farm/edit";
    var response = null;
    $.post({
            url: url,
            async: false,
            data: {id: id}
        },
        function(result) {
            response = result;
        });
    return response;
}


// --------------------- Save/Update ----------------------------
function doSave(id){
    var name = $('#name').val();
    var description = $('#description').val();
    var elevation = $('#elevation').text();
    var harvest = $('#harvest').text();
    var latitude = $('#latitude').val();
    var longitude = $('#longitude').val();
    if(fieldsValidation("",name,description,elevation,harvest,latitude,longitude)) {
        image(id);
        if(longitude.search("-") === -1){
            longitude = "-"+longitude;
        }
        var result = save(id, name, description, elevation, harvest, latitude, longitude);
        var cultivar = document.forms[1];
        for (var i = 0; i < cultivar.length; i++) {
            if (cultivar[i].checked) {
                addCultivar(cultivar[i].value, id);
            }
        }
        var certification = document.forms[2];
        for (var j = 0; j < certification.length; j++) {
            if (certification[j].checked) {
                addCertifications(certification[j].value, id);
            }
        }
        var numRows = document.getElementById("tbody-awards").rows.length;
        for (var k = 1; k < numRows+1; k++) {
            var id_award = $(".award-description-" + k).attr("id");
            var place = $(".award-place-" + k).text();
            var year = $(".award-year-" + k).text();
            doAddAward(id_award, id, place, year);
            if($('#myform'+k).length > 0) {
                uploadPDF(id, place, year, k);
            }
        }
        if (result) {
           location.href = result;
        }
    }
}

function save(id,name,description,elevation,harvest,latitude,longitude){
    var url = "/siteadmin/web/farm/save";
    $.post({
            url: url,
            async: false,
            data: {id: id, name:name, description:description, elevation:elevation,
                harvest:harvest, latitude:latitude, longitude:longitude}
        }).done(function(result) {
            response = result;
        });
    return response;
}


// --------------------- Insert ----------------------------
function doInsert(){
    var name = $('#name').val();
    var description = $('#description').val();
    var elevation = $('#elevation').text();
    var harvest = $('#harvest').text();
    var latitude = $('#latitude').val();
    var longitude = $('#longitude').val();
    if(fieldsValidation("insert",name,description,elevation,harvest,latitude,longitude)) {
        if(longitude.search("-") === -1){
            longitude = "-"+longitude;
        }
        var resultado = insert(name, description, $('#region').val(), elevation, harvest, latitude, longitude);
        var id = search(name, description, $('#region').val(), elevation, harvest);
        image(id);
        var cultivar = document.forms[1];
        for (var i = 0; i < cultivar.length; i++) {
            if (cultivar[i].checked) {
                addCultivar(cultivar[i].value, id);
            }
        }
        var certification = document.forms[2];
        for (var j = 0; j < certification.length; j++) {
            if (certification[j].checked) {
                addCertifications(certification[j].value, id);
            }
        }
        var numRows = document.getElementById("tbody-awards").rows.length;
        for (var k = 1; k < numRows+1; k++) {
            var id_award = $(".award-description-" + k).attr("id");
            var place = $(".award-place-" + k).text();
            var year = $(".award-year-" + k).text();
            doAddAward(id_award, id, place, year);
            if($('#myform'+k).length > 0) {
                uploadPDF(id, place, year, k);
            }
        }
        if (resultado) {
            location.href = "/siteadmin/web/farm/products/"+id;
        }
    }
}

function insert(name,description,region,elevation,harvest,latitude,longitude){
    var url = "/siteadmin/web/farm/insert";
    $.post({
            url: url,
            async: false,
            data: {name:name, description:description,region:region, elevation:elevation, harvest:harvest, latitude:latitude, longitude:longitude}
        }).done(function(result) {
            response = result;
        });
    return response;
}

// --------------------- Delete ----------------------------
function doDelete(id){
    var resultado = deleteFarm(id);
    //alert(resultado);
    if(resultado){
        location.href = resultado;
    }
}

function deleteFarm(id) {
    var url = "/siteadmin/web/farm/delete";
    $.post({
        url: url,
        async: false,
        data: {id:id}
    }).done(function(result) {
        response = result;
    });
    return response;
}

// --------------------- Elevation ----------------------------
function elevationMin() {
    if($('#elevation-Min').val() !== "0") {
        var elevation = $('#elevation').text();
        var end = elevation.substr(elevation.search("-") + 1, elevation.length);
        $('#elevationError-min').hide();
        $('#elevationError-max').hide();
        $('#elevationError').hide();
        if (elevation !== "min-max") {
            var min = parseInt($('#elevation-Min').val());
            var max = parseInt(end);
            if (min < max) {
                $('#elevation').text($('#elevation-Min').val() + "-" + end);
            } else
                $('#elevationError-min').show();
        } else
            $('#elevation').text($('#elevation-Min').val() + "-" + end);
    }else
        $('#elevationError').show();
}

function elevationMax() {
    if($('#elevation-Max').val() !== "0") {
        var elevation = $('#elevation').text();
        var begin = elevation.substr(0, elevation.search("-"));
        $('#elevationError-min').hide();
        $('#elevationError-max').hide();
        $('#elevationError').hide();
        if (elevation !== "min-max") {
            var min = parseInt(begin);
            var max = parseInt($('#elevation-Max').val());
            if (min < max) {
                $('#elevation').text(begin + "-" + $('#elevation-Max').val());
            } else
                $('#elevationError-max').show();
        } else
            $('#elevation').text(begin + "-" + $('#elevation-Max').val());
    }else
        $('#elevationError').show();
}

// --------------------- Harvest ----------------------------
function harvestBegin() {
    if($('#harvest-begin').val() !== "0") {
        var harvest = $('#harvest').text();
        var end = harvest.substr(harvest.search("-") + 1, harvest.length);
        $('#harvestError-begin').hide();
        $('#harvestError-end').hide();
        $('#harvestError').hide();
        if (harvest !== "begin-end") {
            if ($('#harvest-begin').val() !== end) {
                $('#harvest').text($('#harvest-begin').val() + "-" + end);
            } else
                $('#harvestError-begin').show();
        } else
            $('#harvest').text($('#harvest-begin').val() + "-" + end);
    }else
        $('#harvestError').show();
}

function harvestEnd() {
    if($('#harvest-end').val() !== "0") {
        var harvest = $('#harvest').text();
        var begin = harvest.substr(0, harvest.search("-"));
        $('#harvestError-begin').hide();
        $('#harvestError-end').hide();
        $('#harvestError').hide();
        if (harvest !== "begin-end") {
            if (begin !== $('#harvest-end').val()) {
                $('#harvest').text(begin + "-" + $('#harvest-end').val());
            } else
                $('#harvestError-end').show();
        } else
            $('#harvest').text(begin + "-" + $('#harvest-end').val());
    }else
        $('#harvestError').show();
}

// --------------------- Save/Update/Insert Images ----------------------------
function image(id){
    var form = document.getElementById("myform");

    $.ajax({
        url:"/siteadmin/web/farm/image/"+id,
        data: new FormData(form),
        type:"post",
        contentType:false,
        processData:false,
        cache:false,
        dataType:"json",
        error:function(err){
            console.error(err);
        },
        success:function(data){
            console.log(data);
        },
        complete:function(){
            console.log("Request finished.");
        }
    });
}

// --------------------- Add/Delete Cultivar ----------------------------
function cultivar(element) {
    if (element.checked) {
        addCultivar(element.value,element.id);
    } else {
        deleteCultivar(element.value,element.id);
    }
}

function addCultivar(id,id_farm){
    var url = "/siteadmin/web/farm/addCultivar";
    $.post({
        url: url,
        async: false,
        data: {id: id, id_farm:id_farm}
    }).done(function(result) {
        response = result;
    });
    return response;
}

function deleteCultivar(id,id_farm){
    var url = "/siteadmin/web/farm/deleteCultivar";
    $.post({
        url: url,
        async: false,
        data: {id: id, id_farm:id_farm}
    }).done(function(result) {
        response = result;
    });
    return response;
}

// --------------------- Add/Delete Certifications ----------------------------
function certifications(element) {
    if (element.checked) {
        addCertifications(element.value,element.id);
    } else {
        deleteCertifications(element.value,element.id);
    }
}

function addCertifications(id,id_farm){
    var url = "/siteadmin/web/farm/addCertifications";
    $.post({
        url: url,
        async: false,
        data: {id: id, id_farm:id_farm}
    }).done(function(result) {
        response = result;
    });
    return response;
}

function deleteCertifications(id,id_farm){
    var url = "/siteadmin/web/farm/deleteCertifications";
    $.post({
        url: url,
        async: false,
        data: {id: id, id_farm:id_farm}
    }).done(function(result) {
        response = result;
    });
    return response;
}

// --------------------- Add/Delete Award ----------------------------
function awardAdd(id_farm){
    var id = $('.award-description-add').attr("id");
    var place = $('#place').val();
    var year = $('#year').val();
    var flag = false;
    var numRows = document.getElementById("tbody-awards").rows.length;
    for (var k = 1; k < numRows+1; k++) {
        var place1 = $(".award-place-" + k).text();
        var year1 = $(".award-year-" + k).text();
        if(place1 === place && year1 === year){
            flag = true;
        }
    }
    if(flag){
        /*var modal = $('#modal-body-error');
        modal.empty();
        var br = "<br>";
        modal.append(br);
        modal.append(br);
        var p = "<p>El lugar y el año del premio ya ha sido seleccionado, por favor escoja otro</p>";
        modal.append(p);*/
        errorPopUp();
    }else{
        var row = "<tr id=" + (numRows+1) + ">" +
            "<td id='" + id + "' class='award-description-" + (numRows+1) + "'>Cup of excellence</td>" +
            "<td class='award-place-" + (numRows+1) + "'>" + place + "" +"</td>" +
            "<td class='award-year-" + (numRows+1) + "'>"+ year + "</td>" +
            "<td><form id='myform" + (numRows+1) +"' method='post' style='margin: 5px;'>\n" +
            "<button type='button' class='btn btn-success btn-xs' id='loadFileXml' onclick=\"document.getElementById('pdf" + (numRows+1) +"').click();\"><span class=\"glyphicon glyphicon-plus\"></span> PDF</button>\n" +
            "<input id='pdf" + (numRows+1) +"' style='display:none;' type='file' name='upload' />\n</form><p id='pdfError"+(numRows+1)+"' class='text-error'>" +
            "<small>Adjunte un archivo en formato pdf</small></p></td>" +
            "<td><a class='btn btn-danger btn-xs btn-ins-del-award' id=" + id_farm + "-" + (numRows+1) + "><span class='glyphicon glyphicon-minus'></span> Eliminar</a></td>" +
            "</tr>";
        $("#tbody-awards").append(row);
        $('.btn-ins-del-award').click(function( e ) {
            e.preventDefault();
            var id = this.id;
            var row = id.substr(id.search("-")+1,id.length);
            $('#'+row).remove();
        });
    }
}

$('.btn-insert-award').click(function( e ) {
    e.preventDefault();
    var id = $('.award-description-add').attr("id");
    var place = $('#place').val();
    var year = $('#year').val();
    var flag = false;
    var numRows = document.getElementById("tbody-awards").rows.length;
    for (var k = 1; k < numRows+1; k++) {
        var place1 = $(".award-place-" + k).text();
        var year1 = $(".award-year-" + k).text();
        if(place1 === place && year1 === year){
            flag = true;
        }
    }
    if(flag){
       /* var modal = $('#modal-body-error');
        modal.empty();
        var br = "<br>";
        modal.append(br);
        modal.append(br);
        var p = "<p>El lugar y el año del premio ya ha sido seleccionado, por favor escoja otro</p>";
        modal.append(p);*/
        errorPopUp();
    }else{
        var row = "<tr id=" + (numRows+1) + ">" +
            "<td id=" + id + " class='award-description-" + (numRows+1) + "'>Cup of excellence</td>" +
            "<td class='award-place-" + (numRows+1) + "'>" + place + "" +"</td>" +
            "<td class='award-year-" + (numRows+1) + "'>"+ year + "</td>" +
            "<td><form id='myform" + (numRows+1) +"' method='post' style='margin: 5px;'>\n" +
            "<button type='button' class='btn btn-success btn-xs' id='loadFileXml' onclick=\"document.getElementById('pdf" + (numRows+1) +"').click();\"><span class=\"glyphicon glyphicon-plus\"></span> PDF</button>\n" +
            "<input id='pdf" + (numRows+1) +"' style='display:none;' type='file' name='upload' />\n</form><p id='pdfError"+(numRows+1)+"' class='text-error'>" +
            "<small>Adjunte un archivo en formato pdf</small></p></td>" +
            "<td><a class='btn btn-danger btn-xs btn-ins-del-award' style='margin: 0px;' id=" + (numRows+1) + "><span class='glyphicon glyphicon-minus'></span> Eliminar</a></td>" +
            "</tr>";
        $("#tbody-awards").append(row);
        $('.btn-ins-del-award').click(function( e ) {
            e.preventDefault();
            $('#'+this.id).remove();
        });
    }
});

function doAddAward(id,id_farm,place,year) {
    var url = "/siteadmin/web/farm/addAwards";
    $.post({
        url: url,
        async: false,
        data: {id: id, id_farm:id_farm, place:place, year:year}
    }).done(function(result) {
        response = result;
    });
    return response;
}

function awardDelete(id_farm){
    var numF = id_farm.substr(id_farm.search("-"),id_farm.length);
    id_farm = id_farm.substr(0,id_farm.search("-"));
    var place = $('.award-place'+numF).text();
    var year = $('.award-year'+numF).text();
    var response = doDeleteAward(id_farm,place,year);
    numF = numF.substr(numF.search('-')+1,numF.length);
    $('#'+numF).remove();
    return response;
}

function doDeleteAward(id_farm,place,year) {
    var url = "/siteadmin/web/farm/deleteAwards";
    $.post({
        url: url,
        async: false,
        data: {id_farm:id_farm, place:place, year:year}
    }).done(function(result) {
        response = result;
    });
    return response;
}

// --------------------- Save PDFs ----------------------------
function uploadPDF(id,place,year,num){
    var form = document.getElementById("myform"+num);

    $.ajax({
        url:"/siteadmin/web/farm/pdf/"+id+"/"+place+"/"+year,
        data: new FormData(form),
        type:"post",
        contentType:false,
        processData:false,
        cache:false,
        dataType:"json",
        error:function(err){
            console.error(err);
        },
        success:function(data){
            console.log(data);
        },
        complete:function(){
            console.log("Request finished.");
        }
    });
}

// --------------------- Search a farm ---------------------
function search(name,description,region,elevation,harvest){
    var url = "/siteadmin/web/farm/search";
    var response = "null";
    $.post({
        url: url,
        async: false,
        data: {name:name,description:description,region:region,
            elevation:elevation,harvest:harvest}
    }).done(function(result) {
        response = result;
    });
    return response;
}

// --------------------- Validation ---------------------------------
function fieldsValidation(action,name,description,elevation,harvest,latitude,longitude) {
    var flag = true;
    var exp2 = /^[a-zA-ZñÑáéíóúÁÉÍÓÚ ]*$/;
    var exp3 = /^.*\.(jpg|jpeg|gif|JPG|png|PNG)$/;
    var exp4 = /^.*\.(pdf)$/;
    var cultivar = document.forms[1];
    var certification = document.forms[2];
    var cantidad = 0;
    var numRows = document.getElementById("tbody-awards").rows.length;

    for (var k = 1; k < numRows+1; k++) {
        if($('#myform'+k).length > 0) {
            $('#pdfError'+k).hide();
            if ($('#pdf' + k).val() === "" || !exp4.test($('#pdf' + k).val())) {
                cantidad++;
                $('#pdfError'+k).show();
            }
        }
    }
    if(cantidad !== 0) {
        flag = false;
        /*var div = $('#modal-body-error');
        var p = "<p>Algunos premios no cuentan con su certificado en PDF o el formato del archivo adjuntado no corresponde a PDF.</p>";
        div.empty();
        div.append(p);*/
    }else {
        $('#name').removeClass('errorClass');
        if (name === "" || !exp2.test(name)) {
            $('#name').addClass('errorClass');
            flag = false;
        }
        $('#description').removeClass('errorClass');
        if (description === "") {
            $('#description').addClass('errorClass');
            flag = false;
        }
        $('#latitude').removeClass('errorClass');
        if (latitude === "") {
            $('#latitude').addClass('errorClass');
            flag = false;
        }
        $('#longitude').removeClass('errorClass');
        if (longitude === "") {
            $('#longitude').addClass('errorClass');
            flag = false;
        }
        $('#elevationError').hide();
        if (elevation === "min-max" || elevation === "-" || elevation.substr(0, elevation.search("-") + 1) === "min-" || elevation.substr(elevation.search("-"), elevation.length) === "-max") {
            $('#elevationError').show();
            flag = false;
        }
        $('#harvestError').hide();
        if (harvest === "begin-end" || harvest === "-" || harvest.substr(0, harvest.search("-") + 1) === "begin-" || harvest.substr(harvest.search("-"), harvest.length) === "-end") {
            $('#harvestError').show();
            flag = false;
        }

        for (var i = 0; i < cultivar.length; i++) {
            if (!cultivar[i].checked) {
                cantidad++;
            }
        }
        $('#cultivarError').hide();
        if (cantidad === cultivar.length) {
            $('#cultivarError').show();
            flag = false;
        }

        cantidad = 0;
        for (var i = 0; i < certification.length; i++) {
            if (!certification[i].checked) {
                cantidad++;
            }
        }
        $('#certificationError').hide();
        if (cantidad === certification.length) {
            $('#certificationError').show();
            flag = false;
        }

        if (action === "insert") {
            $('#regionError').hide();
            if ($('#region').val() === "0") {
                $('#regionError').show();
                flag = false;
            }
            $('#imageError').hide();
            if ($('#image').val() === "") {
                $('#imageError').show();
                flag = false;
            }
            $('#image1Error').hide();
            if ($('#image').val() !== "" && !exp3.test($('#image').val())) {
                $('#imageError').hide();
                $('#image1Error').show();
                flag = false;
            }
        } else {
            $('#image1Error').hide();
            if ($('#image').val() !== "" && !exp3.test($('#image').val())) {
                $('#imageError').hide();
                $('#image1Error').show();
                flag = false;
            }
        }
    }

    if(!flag){
        errorPopUp();
    }

    return flag;
}

// --------------------- Error Pop Up ---------------------------------
function errorPopUp(){
    var modal = document.getElementById('errorModal');
    var span = document.getElementsByClassName("close")[0];
    span.onclick = function() {
        modal.style.display = "none";
    };
    window.onclick = function(event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    };

    modal.style.display = "block";
}

// --------------------- Delete Confirmation Pop Up ---------------------------------
function deleteConfirmationPopUp(id, name){
    var modal = document.getElementById('deleteConfirmation');
    var div = $('#div-body');
    var modal_footer = $('.modal-footer');
    var p = "<p class='modal-p'>¿Esta seguro de eliminar la finca <b>"+name+"</b>?</p>";

    div.empty();
    div.append(p);
    modal_footer.empty();
    var footer = "<button type='button' class='btn btn-primary btn-delete-confirmation' id='" + id + "'>Si</button>" +
        "<button type='button' class='btn btn-close-modal' style='margin: 0px;'>No</button>";
    modal_footer.append(footer);

    $('.btn-close-modal').click(function (e) {
        e.preventDefault();
        $('#deleteConfirmation').hide();
        $('body').removeClass('modal-open');
    });
    $('.btn-delete-confirmation').click(function( e ) {
        e.preventDefault();
        $('#deleteConfirmation').hide();
        doDelete(this.id);
    });

    $('body').addClass('modal-open');
    modal.style.display = "block";
}


// -------------------------- Delete PDF ------------------------
function pdfDelete(id) {
    var td = document.getElementById('td-pdf-'+id);
    //td.empty();
    // language=HTML
    td.innerHTML = "<form id='myform" + id + "' method='post' style='margin: 5px;'>\n" +
        "<button type='button' class='btn btn-success btn-xs' id='loadFileXml' onclick=\"document.getElementById('pdf" + id + "').click();\"><span class=\"glyphicon glyphicon-plus\"></span> PDF</button>\n" +
        "<input id='pdf" + id + "' style='display:none;' type='file' name='upload' />\n</form><p id='pdfError" + id + "' class='text-error'>" +
        "<small>Adjunte un archivo en formato pdf</small></p>";
}