$.ajaxSetup({

    error: function( jqXHR, textStatus, errorThrown ) {

        if (jqXHR.status === 0) {

            alert('Not connect: Verify Network.');

        } else if (jqXHR.status == 404) {

            alert('Requested page not found [404]');

        } else if (jqXHR.status == 500) {

            alert('Internal Server Error [500].');

        } else if (textStatus === 'parsererror') {

            alert('Requested JSON parse failed.');

        } else if (textStatus === 'timeout') {

            alert('Time out error.');

        } else if (textStatus === 'abort') {

            alert('Ajax request aborted.');

        } else {

            alert('Uncaught Error: ' + jqXHR.responseText);

        }

    }
});

$(document).ready(function () {
   $('.btn-save').click(function( e ) {
        e.preventDefault();
        doSave(this.id);
   });
    $('.btn-add-presentation').click(function( e ) {
        e.preventDefault();
        addPresentationPopUp();
    });
    $('.btn-insert').click(function( e ) {
         e.preventDefault();
         doInsert(this.id);
    });
    $('.btn-save-presentation').click(function( e ) {
         e.preventDefault();
         presentationAdd();
    });
    $('.btn-delete-presentation').click(function( e ) {
         e.preventDefault();
         presentationDelete(this.id, this.name);
    });
    $('.btn-delete').click(function( e ) {
        e.preventDefault();
        deleteConfirmationPopUp(this.id, this.name);
    });
    $('.btn-delete-confirmation').click(function( e ) {
        e.preventDefault();
        $('#deleteConfirmation').hide();
        doDelete(this.id);
    });
    $('input[name=onzas]').click(function (e) {
        $('#weight').prop('disabled', false);
    });
});

// --------------------- Save/Update ----------------------------
function doSave(id){
    var name = $('#name').val();
    var description = $('#description').val();
    var cultivar = $('#cultivar').val();
    var grade = $('#grade').val();
    var processing = $('#processing').val();
    var flavor = $('#flavor').val();
    var numRows = document.getElementById("tbody-presentations").rows.length;
    if(fieldsValidation("",name,description,cultivar,grade,processing,flavor,numRows)) {
        image(id);
        var result = save(id, name, description, cultivar, grade, processing, flavor);
        for (var i = 1; i < numRows + 1; i++) {
            var roast_id = $(".presentation-roast-" + i).attr("id");
            var grind_id = $(".presentation-grind-" + i).attr("id");
            var weight = $(".presentation-weight-" + i).text();
            var price = $(".presentation-price-" + i).text();
            var newPrice;
            newPrice = price.substr(1, price.length);
            doAddPresentation(id, roast_id, grind_id, newPrice, weight);
        }
        if (result) {
           location.href = result;
        }
    }
}

function save(id,name,description,cultivar,grade,processing,flavor){
    var url = "/siteadmin/web/farm/save/products";
    $.post({
            url: url,
            async: false,
            data: {id: id, name:name, description:description,cultivar:cultivar,grade:grade,
                processing:processing,flavor:flavor}
        }).done(function(result) {
            response = result;
        });
    return response;
}

// --------------------- Insert ----------------------------
function doInsert(id_farm){
    var name = $('#name').val();
    var description = $('#description').val();
    var cultivar = $('#cultivar').val();
    var grade = $('#grade').val();
    var processing = $('#processing').val();
    var flavor = $('#flavor').val();
    var numRows = document.getElementById("tbody-presentations").rows.length;
    if(fieldsValidation("insert",name,description,cultivar,grade,processing,flavor,numRows)) {
        var result = insert(id_farm, name, description, cultivar, grade, processing, flavor);
        var id = search(id_farm,name,description,cultivar, grade, processing, flavor);
        image(id);
        for (var i = 1; i < numRows + 1; i++) {
            var roast_id = $(".presentation-roast-" + i).attr("id");
            var grind_id = $(".presentation-grind-" + i).attr("id");
            var weight = $(".presentation-weight-" + i).text();
            var price = $(".presentation-price-" + i).text();
            var newPrice;
            newPrice = price.substr(1, price.length);
            doAddPresentation(id, roast_id, grind_id, newPrice, weight);
        }
        if(result){
            location.href = result;
        }
    }
}


function insert(id_farm, name, description, cultivar, grade, processing, flavor){
    var url = "/siteadmin/web/farm/products/insert/save";
    $.post({
            url: url,
            async: false,
            data: {id_farm:id_farm,name:name,description:description,cultivar:cultivar,grade:grade,processing:processing,flavor:flavor}
        }).done(function(result) {
            response = result;
        });
    return response;
}

// --------------------- Save/Update/Insert Images ----------------------------
function image(id){
    var form = document.getElementById("myform1");

    $.ajax({
        url:"/siteadmin/web/farm/image/product/"+id,
        data: new FormData(form),
        type:"post",
        contentType:false,
        processData:false,
        cache:false,
        dataType:"json",
        error:function(err){
            console.error(err);
        },
        success:function(data){
            console.log(data);
        },
        complete:function(){
            console.log("Request finished.");
        }
    });
}

// --------------------- Delete ----------------------------
function doDelete(id){
    var resultado = deleteProduct(id);
    if(resultado){
        location.href = resultado;
    }
}

function deleteProduct(id) {
    var url = "/siteadmin/web/farm/product/delete";
    $.post({
        url: url,
        async: false,
        data: {id:id}
    }).done(function(result) {
        response = result;
    });
    return response;
}

// --------------------- Search a presentation ---------------------
function search(id_farm,name,description,cultivar, grade, processing, flavor){
    var url = "/siteadmin/web/farm/product/search";
    var response = "null";
    $.post({
        url: url,
        async: false,
        data: {id_farm:id_farm,name:name,description:description,cultivar:cultivar,grade:grade,processing:processing,flavor:flavor}
    }).done(function(result) {
        response = result;
    });
    return response;
}

// --------------------- Add/Delete Presentations ----------------------------
function presentationAdd(){
    var roast_id = $('input[name=roast]:checked').val();
    var roast = $('label[for=roast'+roast_id+']').text();
    var grind_id = $('input[name=grind]:checked').val();
    var grind = $('label[for=grind'+grind_id+']').text();
    var weight = $('#weight').val();
    var price = $('#price').val();
    var tipoWeight = $('input[name=onzas]:checked').val();
    if(!validatePresentation(roast,grind,weight,price)) {
        var flag = false;
        if(tipoWeight === "oz"){
            weight = redondeo(weight * 28.3495231,2);
        }
        var numRows = document.getElementById("tbody-presentations").rows.length;
        for (var k = 1; k < numRows + 1; k++) {
            var roast1 = $(".presentation-roast-" + k).attr("id");
            var grind1 = $(".presentation-grind-" + k).attr("id");
            var weight1 = $(".presentation-weight-" + k).text();
            if (roast1 === roast_id && grind1 === grind_id && weight1 === weight) {
                flag = true;
            }
        }
        if (flag) {
            var modal = $('#modal-body-error');
            modal.empty();
            errorPopUp();
            var br = "<br>";
            modal.append(br);
            modal.append(br);
            var p = "<p>La combinación de tostado, molido y peso ya ha sido seleccionada, por facor escoja otra combinación</p>";
            modal.append(p);
        } else {
            var row = "<tr id=" + (numRows + 1) + ">" +
                "<td class='presentation-roast-" + (numRows + 1) + "' id='" + roast_id + "'>" + roast + "</td>" +
                "<td class='presentation-grind-" + (numRows + 1) + "' id='" + grind_id + "' >" + grind + "" + "</td>" +
                "<td class='presentation-weight-" + (numRows + 1) + "'>" + weight + "</td>" +
                "<td class='presentation-price-" + (numRows + 1) + "'>$" + price + "</td>" +
                "<td><a class='btn btn-danger btn-xs btn-presentation-erase' style='margin: 0px;' id=" + (numRows + 1) + "><span class=\"glyphicon glyphicon-minus\"></span> Eliminar</a></td>" +
                "</tr>";
            $("#tbody-presentations").append(row);
            clearModal();
            $('.btn-presentation-erase').click(function (e) {
                e.preventDefault();
                var row = this.id;
                $('#' + row).remove();
            });
        }
    }
}

function redondeo(numero, decimales)
{
    var flotante = parseFloat(numero);
    var resultado = Math.round(flotante*Math.pow(10,decimales))/Math.pow(10,decimales);
    return resultado;
}

function doAddPresentation(product_id,roast_id,grind_id,price,weight) {
    var url = "/siteadmin/web/farm/addPresentation/products";
    $.post({
        url: url,
        async: false,
        data: {product_id:product_id,roast_id:roast_id,grind_id:grind_id,price:price,weight:weight}
    }).done(function(result) {
        response = result;
    });
    return response;
}

$('.btn-insert-presentation').click(function( e ) {
    e.preventDefault();
    var roast_id = $('input[name=roast]:checked').val();
    var roast = $('label[for=roast'+roast_id+']').text();
    var grind_id = $('input[name=grind]:checked').val();
    var grind = $('label[for=grind'+grind_id+']').text();
    var weight = $('#weight').val();
    var price = $('#price').val();
    var tipoWeight = $('input[name=onzas]:checked').val();
    if(!validatePresentation(roast,grind,weight,price)) {
        var flag = false;
        if(tipoWeight === "oz"){
            weight = redondeo(weight * 28.3495231,2);
        }
        var numRows = document.getElementById("tbody-presentations").rows.length;
        for (var k = 1; k < numRows + 1; k++) {
            var roast1 = $(".presentation-roast-" + k).attr("id");
            var grind1 = $(".presentation-grind-" + k).attr("id");
            var weight1 = $(".presentation-weight-" + k).text();
            if (roast1 === roast_id && grind1 === grind_id && weight1 === weight) {
                flag = true;
            }
        }
        if (flag) {
            var modal = $('#modal-body-error');
            modal.empty();
            errorPopUp();
            var br = "<br>";
            modal.append(br);
            modal.append(br);
            var p = "<p>La combinación de tostado, molido y peso ya ha sido seleccionada, por facor escoja otra combinación</p>";
            modal.append(p);
        } else {
            var row = "<tr id=" + (numRows + 1) + ">" +
                "<td class='presentation-roast-" + (numRows + 1) + "' id='" + roast_id + "'>" + roast + "</td>" +
                "<td class='presentation-grind-" + (numRows + 1) + "' id='" + grind_id + "' >" + grind + "" + "</td>" +
                "<td class='presentation-weight-" + (numRows + 1) + "'>" + weight + "</td>" +
                "<td class='presentation-price-" + (numRows + 1) + "'>$" + price + "</td>" +
                "<td><a class='btn btn-danger btn-xs btn-presentation-erase' style='margin: 0px;' id=" + (numRows + 1) + "><span class=\"glyphicon glyphicon-minus\"></span> Eliminar</a></td>" +
                "</tr>";
            $("#tbody-presentations").append(row);
            clearModal();
            $('.btn-presentation-erase').click(function (e) {
                e.preventDefault();
                var row = this.id;
                $('#' + row).remove();
            });
        }
    }
});

function presentationDelete(id_product, id_presentation){
    var numF = id_product.substr(id_product.search("-")+1,id_product.length);
    id_product = id_product.substr(0,id_product.search("-"));
    var response = doDeletePresentation(id_presentation,id_product);
    alert(response);
    //$('#'+numF).parent("tr").remove();
    $('#'+numF).remove();
    return response;
}

function doDeletePresentation(id_presentation,id_product) {
    var url = "/siteadmin/web/farm/presentationDelete/products";
    $.post({
        url: url,
        async: false,
        data: {id_presentation:id_presentation,id_product:id_product}
    }).done(function(result) {
        response = result;
    });
    return response;
}

// --------------------- Add Presentation Pop Up ---------------------------------
function addPresentationPopUp(){
    var modal = document.getElementById('addPresentation');
    var span = document.getElementsByClassName("close")[0];
    span.onclick = function() {
        modal.style.display = "none";
        $('body').removeClass('modal-open');
    };
    $('.btn-close-modal').click(function (e) {
        e.preventDefault();
        $('#addPresentation').hide();
        $('body').removeClass('modal-open');
    });

    $('body').addClass('modal-open');
    modal.style.display = "block";
}

function clearModal() {
    $('#weight').val('');
    $('#price').val('');
    $('input[name=roast]').prop('checked', false);
    $('input[name=grind]').prop('checked', false);
    $('input[name=onzas]').prop('checked', false);
    $('#weight').prop('disabled', true);
    $('#addPresentation').hide();
    $('body').removeClass('modal-open');
}

// --------------------- Error Pop Up ---------------------------------
function errorPopUp(){
    var modal = document.getElementById('errorModal');
    var span = document.getElementsByClassName("close-error")[0];
    span.onclick = function() {
        modal.style.display = "none";
    };
    window.onclick = function(event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    };

    modal.style.display = "block";
}

// --------------------- Delete Confirmation Pop Up ---------------------------------
function deleteConfirmationPopUp(id,name){
    var modal = document.getElementById('deleteConfirmation');
    var div = $('#div-body');
    var modal_footer = $('.modal-footer');
    var p = "<p class='modal-p'>¿Esta seguro de eliminar el producto <b>"+name+"</b>?</p>";

    div.empty();
    div.append(p);

    modal_footer.empty();
    var footer = "<button type='button' class='btn btn-primary btn-delete-confirmation' id='" + id + "'>Si</button>" +
        "<button type='button' class='btn btn-close-modal' style='margin: 0px;'>No</button>";
    modal_footer.append(footer);

    $('.btn-close-modal').click(function (e) {
        e.preventDefault();
        $('#deleteConfirmation').hide();
        $('body').removeClass('modal-open');
    });
    $('.btn-delete-confirmation').click(function( e ) {
        e.preventDefault();
        $('#deleteConfirmation').hide();
        doDelete(this.id);
    });

    $('body').addClass('modal-open');
    modal.style.display = "block";
}

// --------------------- Validation ---------------------------------
function fieldsValidation(action,name,description,cultivar,grade,processing,flavor,numRows) {
    var flag = true;
    var exp2 = /^[a-zA-ZñÑáéíóúÁÉÍÓÚ ]*$/;
    var exp3 = /^.*\.(jpg|jpeg|gif|JPG|png|PNG)$/;

    $('#name').removeClass('errorClass');
    if(name === "" || !exp2.test(name)){
        $('#name').addClass('errorClass');
        flag = false;
    }
    $('#description').removeClass('errorClass');
    if(description === ""){
        $('#description').addClass('errorClass');
        flag = false;
    }
    $('#cultivar').removeClass('errorClass');
    if(cultivar === ""){
        $('#cultivar').addClass('errorClass');
        flag = false;
    }
    $('#grade').removeClass('errorClass');
    if(grade === ""){
        $('#grade').addClass('errorClass');
        flag = false;
    }
    $('#processing').removeClass('errorClass');
    if(processing === ""){
        $('#processing').addClass('errorClass');
        flag = false;
    }
    $('#flavor').removeClass('errorClass');
    if(flavor === ""){
        $('#flavor').addClass('errorClass');
        flag = false;
    }
    if(numRows === 0){
        flag = false;
        var modal = $('#modal-body-error');
        modal.empty();
        var br = "<br>";
        modal.append(br);
        modal.append(br);
        var p = "<p>El producto debe de taner al menos una presentación</p>";
        modal.append(p);
    }

    if(action === "insert"){
        $('#imageError').hide();
        if ($('#image').val() === "") {
            $('#imageError').show();
            flag = false;
        }
        $('#image1Error').hide();
        if ($('#image').val() !== "" && !exp3.test($('#image').val())) {
            $('#imageError').hide();
            $('#image1Error').show();
            flag = false;
        }
    }else{
        $('#image1Error').hide();
        if ($('#image').val() !== "" && !exp3.test($('#image').val())) {
            $('#imageError').hide();
            $('#image1Error').show();
            flag = false;
        }
    }

    if(!flag){
        errorPopUp();
    }

    return flag;
}

function validatePresentation(roast,grind,weight,price){
    var flag = false;
    $('#roastError').hide();
    if(roast === ""){
        flag = true;
        $('#roastError').show();
    }
    $('#grindError').hide();
    if(grind === ""){
        flag = true;
        $('#grindError').show();
    }
    $('#weightError').hide();
    if(weight === ""){
        flag = true;
        $('#weightError').show();
    }
    $('#priceError').hide();
    if(price === ""){
        flag = true;
        $('#priceError').show();
    }
    return flag;
}