<?php

namespace PageBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PageBundle extends Bundle
{
}
