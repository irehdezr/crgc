<?php

namespace RegionBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class RegionBundle extends Bundle
{
}
