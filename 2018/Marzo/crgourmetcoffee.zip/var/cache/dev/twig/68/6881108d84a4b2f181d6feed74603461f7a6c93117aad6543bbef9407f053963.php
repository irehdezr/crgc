<?php

/* PageBundle:Default:onDevelopment.html.twig */
class __TwigTemplate_3734aba987fb7fbfab06ced25b718af2a68127b42adaf44d0090f377c8202445 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "PageBundle:Default:onDevelopment.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7f5720692f1daff83e8c4ffef6e7b570679bf64f5add0fe39ce216197057fa43 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7f5720692f1daff83e8c4ffef6e7b570679bf64f5add0fe39ce216197057fa43->enter($__internal_7f5720692f1daff83e8c4ffef6e7b570679bf64f5add0fe39ce216197057fa43_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PageBundle:Default:onDevelopment.html.twig"));

        $__internal_b6af24ccae95f49293f721406e3c2b74bb31c0c96560338c8e1b945258ee8e0d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b6af24ccae95f49293f721406e3c2b74bb31c0c96560338c8e1b945258ee8e0d->enter($__internal_b6af24ccae95f49293f721406e3c2b74bb31c0c96560338c8e1b945258ee8e0d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PageBundle:Default:onDevelopment.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_7f5720692f1daff83e8c4ffef6e7b570679bf64f5add0fe39ce216197057fa43->leave($__internal_7f5720692f1daff83e8c4ffef6e7b570679bf64f5add0fe39ce216197057fa43_prof);

        
        $__internal_b6af24ccae95f49293f721406e3c2b74bb31c0c96560338c8e1b945258ee8e0d->leave($__internal_b6af24ccae95f49293f721406e3c2b74bb31c0c96560338c8e1b945258ee8e0d_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_d8cd77bf81bae63d5f0034c223a39c5ee7a554988976e92ace4f97523aed19b4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d8cd77bf81bae63d5f0034c223a39c5ee7a554988976e92ace4f97523aed19b4->enter($__internal_d8cd77bf81bae63d5f0034c223a39c5ee7a554988976e92ace4f97523aed19b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_dd8b35b65836488765f7a7815c34be7bc6557f347329c17bc251c1e55015aaa7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dd8b35b65836488765f7a7815c34be7bc6557f347329c17bc251c1e55015aaa7->enter($__internal_dd8b35b65836488765f7a7815c34be7bc6557f347329c17bc251c1e55015aaa7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "On Development";
        
        $__internal_dd8b35b65836488765f7a7815c34be7bc6557f347329c17bc251c1e55015aaa7->leave($__internal_dd8b35b65836488765f7a7815c34be7bc6557f347329c17bc251c1e55015aaa7_prof);

        
        $__internal_d8cd77bf81bae63d5f0034c223a39c5ee7a554988976e92ace4f97523aed19b4->leave($__internal_d8cd77bf81bae63d5f0034c223a39c5ee7a554988976e92ace4f97523aed19b4_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_74041e1dd333e4f5e51606ecda3ca7435cc083f2f778df2a601cb6237fbb8fea = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_74041e1dd333e4f5e51606ecda3ca7435cc083f2f778df2a601cb6237fbb8fea->enter($__internal_74041e1dd333e4f5e51606ecda3ca7435cc083f2f778df2a601cb6237fbb8fea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_2e6409349717a11e49539691477b7cc047f9c2e96eb7ef1ecbdb5e3191859829 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2e6409349717a11e49539691477b7cc047f9c2e96eb7ef1ecbdb5e3191859829->enter($__internal_2e6409349717a11e49539691477b7cc047f9c2e96eb7ef1ecbdb5e3191859829_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "<main>
\t<center>
\t    <h2>
\t        <br/>Oooops...<br/>
\t        This page is under development....
\t    </h2>
    </center>
</main>
";
        
        $__internal_2e6409349717a11e49539691477b7cc047f9c2e96eb7ef1ecbdb5e3191859829->leave($__internal_2e6409349717a11e49539691477b7cc047f9c2e96eb7ef1ecbdb5e3191859829_prof);

        
        $__internal_74041e1dd333e4f5e51606ecda3ca7435cc083f2f778df2a601cb6237fbb8fea->leave($__internal_74041e1dd333e4f5e51606ecda3ca7435cc083f2f778df2a601cb6237fbb8fea_prof);

    }

    public function getTemplateName()
    {
        return "PageBundle:Default:onDevelopment.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 5,  59 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layout.html.twig\" %}

{% block title%}On Development{% endblock %}
{% block body %}
<main>
\t<center>
\t    <h2>
\t        <br/>Oooops...<br/>
\t        This page is under development....
\t    </h2>
    </center>
</main>
{% endblock %}", "PageBundle:Default:onDevelopment.html.twig", "C:\\xampp\\htdocs\\crgc\\var\\cache\\dev/../../../src/PageBundle/Resources/views/Default/onDevelopment.html.twig");
    }
}
