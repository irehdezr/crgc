<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_0f5b1344dfd5548ca5267cdc1d92a7ac188eeacb506779cbd46ab2133eba698a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c18cced1f780e480a89a6905c4ca52c8632428d86309d1cb26dab50eb4e764e3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c18cced1f780e480a89a6905c4ca52c8632428d86309d1cb26dab50eb4e764e3->enter($__internal_c18cced1f780e480a89a6905c4ca52c8632428d86309d1cb26dab50eb4e764e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        $__internal_4f430aeb24de60f130e1d218e9f44c7464530ce60055dc45fe835da944af66ff = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4f430aeb24de60f130e1d218e9f44c7464530ce60055dc45fe835da944af66ff->enter($__internal_4f430aeb24de60f130e1d218e9f44c7464530ce60055dc45fe835da944af66ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_c18cced1f780e480a89a6905c4ca52c8632428d86309d1cb26dab50eb4e764e3->leave($__internal_c18cced1f780e480a89a6905c4ca52c8632428d86309d1cb26dab50eb4e764e3_prof);

        
        $__internal_4f430aeb24de60f130e1d218e9f44c7464530ce60055dc45fe835da944af66ff->leave($__internal_4f430aeb24de60f130e1d218e9f44c7464530ce60055dc45fe835da944af66ff_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "C:\\xampp\\htdocs\\crgc\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_label.html.php");
    }
}
