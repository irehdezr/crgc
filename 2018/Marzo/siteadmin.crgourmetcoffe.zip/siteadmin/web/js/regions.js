$.ajaxSetup({

    error: function( jqXHR, textStatus, errorThrown ) {

        if (jqXHR.status === 0) {

            alert('Not connect: Verify Network.');

        } else if (jqXHR.status === 404) {

            alert('Requested page not found [404]');

        } else if (jqXHR.status === 500) {

            alert('Internal Server Error [500].');

        } else if (textStatus === 'parsererror') {

            alert('Requested JSON parse failed.');

        } else if (textStatus === 'timeout') {

            alert('Time out error.');

        } else if (textStatus === 'abort') {

            alert('Ajax request aborted.');

        } else {

            alert('Uncaught Error: ' + jqXHR.responseText);

        }

    }
});


$(document).ready(function () {
    $('.btn-edit').click(function( e ) {
        e.preventDefault();
        doEdit(this.id);
    });
    $('.btn-save').click(function( e ) {
        e.preventDefault();
        doSave(this.id);
    });
    $('.btn-insert').click(function( e ) {
        e.preventDefault();
        doInsert();
    });
    $('.btn-delete').click(function( e ) {
        e.preventDefault();
        deleteConfirmationPopUp(this.id, this.name);
    });
    $('.btn-delete-confirmation').click(function( e ) {
        e.preventDefault();
        $('#deleteConfirmation').hide();
        doDelete(this.id);
    });
});

// --------------------- Edit ----------------------------
function doEdit(id){
    var resultado = edit(id);
    if(resultado){
        location.href = resultado;
    }
}

function edit(id){
    var url = "/siteadmin/web/region/edit";
    var response = null;
    $.post({
            url: url,
            async: false,
            data: {id: id}
        },
        function(result) {
            response = result;
        });
    return response;
}

// --------------------- Save/Update ----------------------------
function doSave(id){
    var name = $('#name').val();
    var description_img1 = $('#description-img1').val();
    var description_img2 = $('#description-img2').val();
    var description_img3 = $('#description-img3').val();
    var description = $('#description').val();
    var organoleptic = $('#organoleptic').val();
    var information = $('#information').val();
    var latitude = $('#latitude').val();
    var longitude = $('#longitude').val();
    var zoom = $('#zoom').val();
    if(fieldsValidation(name,description_img1,description_img2,description_img3,description,organoleptic,information,latitude,longitude,zoom,"")) {
        if(longitude.search("-") === -1){
            longitude = "-"+longitude;
        }
        image1(id);
        image2(id);
        image3(id);
        var resultado = save(id, name, description_img1, description_img2, description_img3, description, organoleptic, information, latitude, longitude, zoom);
        if (resultado) {
            location.href = resultado;
        }
    }
}

function save(id,name,descriptionimg1,descriptionimg2,descriptionimg3,description,organoleptic,
              information,latitude,longitude,zoom){
    var url = "/siteadmin/web/region/save";
    var response = "null";
    $.post({
        url: url,
        async: false,
        data: {id: id, name:name,descriptionimg1:descriptionimg1,descriptionimg2:descriptionimg2,
            descriptionimg3:descriptionimg3,description:description,organoleptic:organoleptic,
            information:information,latitude:latitude,longitude:longitude,zoom:zoom}
    }).done(function(result) {
        response = result;
    });
    return response;
}


// --------------------- Insert ----------------------------
function doInsert(){
    var name = $('#name').val();
    var description_img1 = $('#description-img1').val();
    var description_img2 = $('#description-img2').val();
    var description_img3 = $('#description-img3').val();
    var description = $('#description').val();
    var organoleptic = $('#organoleptic').val();
    var information = $('#information').val();
    var latitude = $('#latitude').val();
    var longitude = $('#longitude').val();
    var zoom = $('#zoom').val();
    if(fieldsValidation(name,description_img1,description_img2,description_img3,description,organoleptic,information,latitude,longitude,zoom,"insert")) {
        if(longitude.search("-") === -1){
            longitude = "-"+longitude;
        }
        var resultado = insert(name,description_img1,description_img2,description_img3,description,organoleptic,information,latitude,longitude,zoom);
        var id = search(name,description,organoleptic,information);
        image1(id);
        image2(id);
        image3(id);
        if(resultado){
            location.href = resultado;
        }
    }
}


function insert(name,descriptionimg1,descriptionimg2,descriptionimg3,description,organoleptic,
                information,latitude,longitude,zoom){
    var url = "/siteadmin/web/region/insert";
    var response = "null";
    $.post({
        url: url,
        async: false,
        data: {name:name,descriptionimg1:descriptionimg1,descriptionimg2:descriptionimg2,
            descriptionimg3:descriptionimg3,description:description,organoleptic:organoleptic,
            information:information,latitude:latitude,longitude:longitude,zoom:zoom}
    }).done(function(result) {
        response = result;
    });
    return response;
}

// --------------------- Delete ----------------------------
function doDelete(id){
    var resultado = deleteRegion(id);
    if(resultado){
         location.href = resultado;
    }
}

function deleteRegion(id) {
    var url = "/siteadmin/web/region/delete";
    $.post({
        url: url,
        async: false,
        data: {id:id}
    }).done(function(result) {
        response = result;
    });
    return response;
}

// --------------------- Save/Update/Insert Images ----------------------------
function image1(id){
    var form = document.getElementById("myform1");
    $.ajax({
        url:"/siteadmin/web/region/image/"+id+"/1",
        data: new FormData(form),
        type:"post",
        contentType:false,
        processData:false,
        cache:false,
        dataType:"json",
        error:function(err){
            console.error(err);
        },
        success:function(data){
            console.log(data);
        },
        complete:function(){
            console.log("Request finished.");
        }
    });
}

function image2(id){
    var form = document.getElementById("myform2");
    $.ajax({
        url:"/siteadmin/web/region/image/"+id+"/2",
        data: new FormData(form),
        type:"post",
        contentType:false,
        processData:false,
        cache:false,
        dataType:"json",
        error:function(err){
            console.error(err);
        },
        success:function(data){
            console.log(data);
        },
        complete:function(){
            console.log("Request finished.");
        }
    });
}

function image3(id){
    var form = document.getElementById("myform3");
    $.ajax({
        url:"/siteadmin/web/region/image/"+id+"/3",
        data: new FormData(form),
        type:"post",
        contentType:false,
        processData:false,
        cache:false,
        dataType:"json",
        error:function(err){
            console.error(err);
        },
        success:function(data){
            console.log(data);
        },
        complete:function(){
            console.log("Request finished.");
        }
    });
}

// --------------------- Search a region ------------------------------
function search(name,description,organoleptic, information){
    var url = "/siteadmin/web/region/search";
    var response = "null";
    $.post({
        url: url,
        async: false,
        data: {name:name,description:description,organoleptic:organoleptic,information:information}
    }).done(function(result) {
        response = result;
    });
    return response;
}

// --------------------- Validation ---------------------------------
function fieldsValidation(name,description_img1,description_img2,description_img3,description,organoleptic,information,latitude,longitude,zoom,action) {
    var flag = true;
    var exp1 = /^(\d|-)?(\d|,)*\.?\d*$/;
    var exp2 = /^[a-zA-ZñÑáéíóúÁÉÍÓÚ/ ]*$/;
    var exp3 = /^.*\.(jpg|jpeg|gif|JPG|png|PNG)$/;

    $('#name').removeClass('errorClass');
    if(name === "" || !exp2.test(name)){
        $('#name').addClass('errorClass');
        flag = false;
    }
    $('#description-img1').removeClass('errorClass');
    if(description_img1 === "" || !exp2.test(description_img1)){
        $('#description-img1').addClass('errorClass');
        flag = false;
    }
    $('#description-img2').removeClass('errorClass');
    if(description_img2 === "" || !exp2.test(description_img2)){
        $('#description-img2').addClass('errorClass');
        flag = false;
    }
    $('#description-img3').removeClass('errorClass');
    if(description_img3 === "" || !exp2.test(description_img3)){
        $('#description-img3').addClass('errorClass');
        flag = false;
    }
    $('#description').removeClass('errorClass');
    if(description === ""){
        $('#description').addClass('errorClass');
        flag = false;
    }
    $('#organoleptic').removeClass('errorClass');
    if(organoleptic === ""){
        $('#organoleptic').addClass('errorClass');
        flag = false;
    }
    $('#information').removeClass('errorClass');
    if(information === ""){
        $('#information').addClass('errorClass');
        flag = false;
    }
    $('#latitude').removeClass('errorClass');
    if(latitude === "" || !exp1.test(latitude)){
        $('#latitude').addClass('errorClass');
        flag = false;
    }
    $('#longitude').removeClass('errorClass');
    if(longitude === "" || !exp1.test(longitude)){
        $('#longitude').addClass('errorClass');
        flag = false;
    }
    $('#zoom').removeClass('errorClass');
    if(zoom === "" || isNaN(zoom)){
        $('#zoom').addClass('errorClass');
        flag = false;
    }
    $('#zoomError').hide();
    if(zoom.length > 2){
        $('#zoom').addClass('errorClass');
        $('#zoomError').show();
        flag = false;
    }

    if(action === "insert") {
        $('#image1Error').hide();
        if ($('#image1').val() === "" || !exp3.test($('#image1').val())) {
            $('#image1Error').show();
            flag = false;
        }
        $('#image1-1Error').hide();
        if ($('#image1').val() !== "" && !exp3.test($('#image1').val())) {
            $('#image1Error').hide();
            $('#image1-1Error').show();
            flag = false;
        }
        $('#image2Error').hide();
        if ($('#image2').val() === "" || !exp3.test($('#image2').val())) {
            $('#image2Error').show();
            flag = false;
        }
        $('#image2-2Error').hide();
        if ($('#image2').val() !== "" && !exp3.test($('#image2').val())) {
            $('#image2Error').hide();
            $('#image2-2Error').show();
            flag = false;
        }
        $('#image3Error').hide();
        if ($('#image3').val() === "" || !exp3.test($('#image3').val())) {
            $('#image3Error').show();
            flag = false;
        }
        $('#image3-3Error').hide();
        if ($('#image3').val() !== "" && !exp3.test($('#image3').val())) {
            $('#image3Error').hide();
            $('#image3-3Error').show();
            flag = false;
        }
    }else{
        $('#image1-1Error').hide();
        if ($('#image1').val() !== "" && !exp3.test($('#image1').val())) {
            $('#image1Error').hide();
            $('#image1-1Error').show();
            flag = false;
        }
        $('#image2-2Error').hide();
        if ($('#image2').val() !== "" && !exp3.test($('#image2').val())) {
            $('#image2Error').hide();
            $('#image2-2Error').show();
            flag = false;
        }
        $('#image3-3Error').hide();
        if ($('#image3').val() !== "" && !exp3.test($('#image3').val())) {
            $('#image3Error').hide();
            $('#image3-3Error').show();
            flag = false;
        }
    }



    if(!flag){
        errorPopUp();
    }
    return flag;
}

// --------------------- Error Pop Up ---------------------------------
function errorPopUp(){
    var modal = document.getElementById('errorModal');
    var span = document.getElementsByClassName("close")[0];
    span.onclick = function() {
        modal.style.display = "none";
    }
    window.onclick = function(event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    }

    modal.style.display = "block";
}

// --------------------- Delete Confirmation Pop Up ---------------------------------
function deleteConfirmationPopUp(id, name){
    var modal = document.getElementById('deleteConfirmation');
    var div = $('#div-body');
    var modal_footer = $('.modal-footer');
    var p = "<p class='modal-p'>¿Esta seguro de eliminar la región <b>"+name+"</b>?</p>";

    div.empty();
    div.append(p);
    modal_footer.empty();
    var footer = "<button type='button' class='btn btn-primary btn-delete-confirmation' id='" + id + "'>Si</button>" +
        "<button type='button' class='btn btn-close-modal' style='margin: 0px;'>No</button>";
    modal_footer.append(footer);

    $('.btn-close-modal').click(function (e) {
        e.preventDefault();
        $('#deleteConfirmation').hide();
        $('body').removeClass('modal-open');
    });
    $('.btn-delete-confirmation').click(function( e ) {
        e.preventDefault();
        $('#deleteConfirmation').hide();
        doDelete(this.id);
    });

    $('body').addClass('modal-open');
    modal.style.display = "block";
}