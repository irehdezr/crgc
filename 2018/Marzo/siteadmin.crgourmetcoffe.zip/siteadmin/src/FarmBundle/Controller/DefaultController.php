<?php

namespace FarmBundle\Controller;

use FarmBundle\Entity\Farm_Award;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use FarmBundle\Entity\Farm_I;

class DefaultController extends Controller
{
    public function indexAction()
    {
        $em = $this->getDoctrine()->getManager();
        $farm_repo = $em->getRepository("FarmBundle:Farm_I");
        $farms = $farm_repo->findBy([], ['id' => 'ASC']);
        return $this->render('FarmBundle:Default:farm.html.twig', [
            'farms'=>$farms
        ]);
    }

    // --------------------- Edit ----------------------------
    public function editAction(Request $request)
    {
        $response = 'false';
        if($request->isXMLHttpRequest()) {
            $id = $request->request->get('id');
            $response = $this->generateUrl('farm_edit_view',array('id'=>$id));
        }
        return new Response($response);
    }

    public function editViewAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $farm_repo = $em->getRepository("FarmBundle:Farm_I");
        $farms = $farm_repo->findBy(array('id'=>$id));
        $regions = $em->getRepository("FarmBundle:Region")->findBy([], ['id' => 'ASC']);
        $cultivars = $em->getRepository("FarmBundle:Cultivar")->findBy([], ['id' => 'ASC']);
        $certifications = $em->getRepository("FarmBundle:Certification")->findBy([], ['id' => 'ASC']);
        return $this->render('FarmBundle:Default:edit.html.twig', [
            'farms'=>$farms, 'regions'=>$regions, 'cultivars'=>$cultivars,
            'certifications'=>$certifications
        ]);
    }

    // --------------------- Save/Update ----------------------------
    public function saveAction(Request $request)
    {
        $response = 'false';
        if($request->isXMLHttpRequest()){
            $id = $request->request->get('id');
            $name = $request->request->get('name');
            $description = $request->request->get('description');
            $elevation = $request->request->get('elevation');
            $harvest = $request->request->get('harvest');
            $latitude = $request->request->get('latitude');
            $longitude = $request->request->get('longitude');

            $em = $this->getDoctrine()->getManager();
            $farm = $em->getRepository("FarmBundle:Farm_I")->find($id);
            $farm ->setName($name);
            $farm ->setDescription($description);
            $farm ->setElevation($elevation);
            $farm ->setHarvest($harvest);
            $farm ->setLatitude($latitude);
            $farm ->setLongitude($longitude);
            $em->flush();
            $response = $this->generateUrl('farm_homepage');
        }
        return new Response($response);
    }

    public function addAction()
    {
        $em = $this->getDoctrine()->getManager();
        $regions = $em->getRepository("FarmBundle:Region")->findBy([], ['id' => 'ASC']);
        $cultivars = $em->getRepository("FarmBundle:Cultivar")->findBy([], ['id' => 'ASC']);
        $certifications = $em->getRepository("FarmBundle:Certification")->findBy([], ['id' => 'ASC']);
        return $this->render('FarmBundle:Default:insert.html.twig',[
            'regions'=>$regions, 'cultivars'=>$cultivars, 'certifications'=>$certifications
        ]);
    }

    // --------------------- Insert ----------------------------
    public function insertAction(Request $request){
         $response = 'false'; 
        if($request->isXMLHttpRequest()){
            $em = $this->get('doctrine')->getManager();

            $name = $request->request->get('name');
            $description = $request->request->get('description');
            $region_id = $request->request->get('region');
            $elevation = $request->request->get('elevation');
            $harvest = $request->request->get('harvest');
            $latitude = $request->request->get('latitude');
            $longitude = $request->request->get('longitude');

            $region = $em->getRepository("FarmBundle:Region")->find($region_id);

            $farm = new Farm_I();
            $farm ->setName($name);
            $farm ->setDescription($description);
            $farm->setRegion($region);
            $farm ->setElevation($elevation);
            $farm ->setHarvest($harvest);
            $farm ->setLatitude($latitude);
            $farm ->setLongitude($longitude);
            $farm->setImage("");

            $em->merge($farm);
            $em->flush();
            $response = $this->generateUrl('farm_homepage');
        }
        return new Response($response);
    }

    // --------------------- Delete ----------------------------
    public function deleteAction(Request $request)
    {
        $response = 'false';
        if($request->isXMLHttpRequest()) {
            $em = $this->getDoctrine()->getManager();
            $farm_repo = $em->getRepository("FarmBundle:Farm_I");
            $id = $request->request->get('id');
            $farm = $farm_repo->find($id);

            if (!empty($farm->getProducts())) {
                $response = 'tiene productos';
                foreach ($farm->getProducts() as $product) {
                    $product = $em->getRepository("FarmBundle:Product_I")->find($product->getId());
                    if (!empty($product->getPresentations())) {
                        $response = 'tiene presentaciones';
                        // --------------------- Presentation -----------------------
                        foreach ($product->getPresentations() as $presentation) {
                            $em->remove($presentation);
                        }
                    }
                    // --------------------- Product -----------------------
                    $em->remove($product);
                }
            }

            $em->remove($farm);
            $em->flush();
            $response = $this->generateUrl('farm_homepage');
        }
        return new Response($response);
    }

    // --------------------- Images ----------------------------
    public function imageAction(Request $request, $id)
    {
        $file = $request->files->get('upload');
        $status = array('status' => "success", "fileUploaded" => false);

        // If a file was uploaded
        if (!is_null($file)) {
            // generate a random name for the file but keep the extension
            //$filename = uniqid() . "." . $file->getClientOriginalExtension();

            $em = $this->getDoctrine()->getManager();
            $farm = $em->getRepository("FarmBundle:Farm_I")->find($id);
            $filename = $farm->getName()."-".$file->getClientOriginalName();
            //Lower case everything
            $filename = strtolower($filename);
            //Clean up multiple dashes or whitespaces
            $filename = preg_replace("/[\s-]+/", " ", $filename);
            //Convert whitespaces and underscore to dash
            $filename = preg_replace("/[\s_]/", "-", $filename);
            $path = "C:/xampp/htdocs/siteadmin/web/common/imgs/farms/";
            //$path = "common/imgs";
            $file->move($path, $filename); // move the file to a path
            $name = "/siteadmin/web/common/imgs/farms/".$filename;
            //$name = "http://www.siteadmin.crgourmetcoffee.com/web/".$path."/".$filename;
            $status = array('status' => "success", "fileUploaded" => true, 'path' => $name);
            $farm->setImage($name);
            $em->flush();
        }

        return new JsonResponse($status);
    }

    // --------------------- Add Cultivar ----------------------------
    public function addCultivarAction(Request $request)
    {
        $response = 'false';
        if($request->isXMLHttpRequest()){
            $id = $request->request->get('id');
            $id_farm = $request->request->get('id_farm');

            $em = $this->getDoctrine()->getManager();
            $cultivar = $em->getRepository("FarmBundle:Cultivar")->find($id);
            $farm = $em->getRepository("FarmBundle:Farm_I")->find($id_farm);

            $i = 0;
            foreach ($farm->getCultivars() as $culti){
                if($culti->getId() == $id){
                    $i = 1;
                }
            }
            if($i == 0){
                $farm->addCultivar($cultivar);
            }

            $em->flush();
            $response = $this->generateUrl('farm_homepage');
        }
        return new Response($response);
    }

    // --------------------- Delete Cultivar ----------------------------
    public function deleteCultivarAction(Request $request)
    {
        $response = 'false';
        if($request->isXMLHttpRequest()){
            $id = $request->request->get('id');
            $id_farm = $request->request->get('id_farm');

            $em = $this->getDoctrine()->getManager();
            $cultivar = $em->getRepository("FarmBundle:Cultivar")->find($id);
            $farm = $em->getRepository("FarmBundle:Farm_I")->find($id_farm);

            $i = 0;
            foreach ($farm->getCultivars() as $culti){
                if($culti->getId() == $id){
                    $i = 1;
                }
            }
            if($i == 1){
                $farm->removeCultivar($cultivar);
            }

            $em->flush();
            $response = $this->generateUrl('farm_homepage');
        }
        return new Response($response);
    }

    // --------------------- Add Certifications ----------------------------
    public function addCertificationsAction(Request $request)
    {
        $response = 'false';
        if($request->isXMLHttpRequest()){
            $id = $request->request->get('id');
            $id_farm = $request->request->get('id_farm');

            $em = $this->getDoctrine()->getManager();
            $certifications = $em->getRepository("FarmBundle:Certification")->find($id);
            $farm = $em->getRepository("FarmBundle:Farm_I")->find($id_farm);

            $i = 0;
            $aux = 0;
            foreach ($farm->getCertifications() as $certi){
                if($certi->getId() == $id){
                    $i = 1;
                }
                if($certi->getId() == 1){
                    $aux = 1;
                }
            }
            if($i == 0){
                $farm->addCertification($certifications);
            }
            if($aux == 1){
                $certifications = $em->getRepository("FarmBundle:Certification")->find(1);
                $farm->removeCertification($certifications);
            }

            $em->flush();
            $response = $this->generateUrl('farm_homepage');
        }
        return new Response($response);
    }

    // --------------------- Delete Certifications ----------------------------
    public function deleteCertificationsAction(Request $request)
    {
        $response = 'false';
        if($request->isXMLHttpRequest()){
            $id = $request->request->get('id');
            $id_farm = $request->request->get('id_farm');

            $em = $this->getDoctrine()->getManager();
            $certifications = $em->getRepository("FarmBundle:Certification")->find($id);
            $farm = $em->getRepository("FarmBundle:Farm_I")->find($id_farm);

            $i = 0;
            foreach ($farm->getCertifications() as $certi){
                if($certi->getId() == $id){
                    $i = 1;
                }
            }
            if($i == 1){
                $farm->removeCertification($certifications);
            }

            $em->flush();
            $response = $this->generateUrl('farm_homepage');
        }
        return new Response($response);
    }

    // --------------------- Add Awards ----------------------------
    public function addAwardsAction(Request $request)
    {
        $response = 'false';
        if($request->isXMLHttpRequest()){
            $id = $request->request->get('id');
            $id_farm = $request->request->get('id_farm');
            $place = $request->request->get('place');
            $year = $request->request->get('year');

            $em = $this->getDoctrine()->getManager();
            $award = $em->getRepository("FarmBundle:Award")->find($id);
            $farm = $em->getRepository("FarmBundle:Farm_I")->find($id_farm);

            $flag = false;
            foreach ($farm->getFarmAwards() as $awards) {
                if ($awards->getPlace() == $place && $awards->getYear() == $year) {
                    $flag = true;
                    break;
                }
            }

            if(!$flag) {
                $farm_award = new Farm_Award();
                $farm_award->setAward($award);
                $farm_award->setFarm($farm);
                $farm_award->setPlace($place);
                $farm_award->setYear($year);
                $farm->addFarmAward($farm_award);
                $em->persist($farm_award);
                $em->persist($farm);
                $em->flush();
                $response = 'true';
            }

        }
        return new Response($response);
    }

    // --------------------- Delete Awards ----------------------------
    public function deleteAwardsAction(Request $request)
    {
        $response = 'false';
        if($request->isXMLHttpRequest()){
            $id_farm = $request->request->get('id_farm');
            $place = $request->request->get('place');
            $year = $request->request->get('year');

            $em = $this->getDoctrine()->getManager();
            $farm = $em->getRepository("FarmBundle:Farm_I")->find($id_farm);

            $i = 0;
            foreach ($farm->getFarmAwards() as $awards) {
                if ($awards->getPlace() == $place && $awards->getYear() == $year) {
                    $farm_award = $awards;
                    $i = 1;
                }
            }
            if($i == 1){;
                $farm->removeFarmAward($farm_award);
            }

            $em->remove($farm_award);
            $em->flush();
            $response = 'true';
        }
        return new Response($response);
    }

    // --------------------- Search Farms ----------------------------
    public function searchAction(Request $request)
    {
        $status = 'false';
        if($request->isXMLHttpRequest()) {
            $name = $request->request->get('name');
            $description = $request->request->get('description');
            $region = $request->request->get('region');
            $elevation = $request->request->get('elevation');
            $harvest = $request->request->get('harvest');

            $em = $this->getDoctrine()->getManager();
            $farm_repo = $em->getRepository("FarmBundle:Farm_I");
            $farms = $farm_repo->findAll();

            for ($i = 0; $i < count($farms); $i++) {
                $farm = $farms[$i];
                if($farm->getName() == $name && $farm->getDescription() == $description && $farm->getRegion()->getId() == $region
                    && $farm->getElevation() == $elevation && $farm->getHarvest() == $harvest){
                    $status = $farm->getId();
                    break;
                }
            }
        }

        return new JsonResponse($status);
    }

    // --------------------- PDFs ----------------------------
    public function pdfAction(Request $request, $place, $year)
    {
        $file = $request->files->get('upload');
        $status = array('status' => "success", "fileUploaded" => false);

        if (!is_null($file)) {
            $em = $this->getDoctrine()->getManager();
            $farm = $em->getRepository("FarmBundle:Farm_I")->find($id);
            $filename = $farm->getName()."-certification-".$file->getClientOriginalName();
            //Lower case everything
            $filename = strtolower($filename);
            //Clean up multiple dashes or whitespaces
            $filename = preg_replace("/[\s-]+/", " ", $filename);
            //Convert whitespaces and underscore to dash
            $filename = preg_replace("/[\s_]/", "-", $filename);
            $path = "C:/xampp/htdocs/siteadmin/web/common/cofe/";
            //$path = "common/imgs";
            $file->move($path, $filename); // move the file to a path
            $name = "/siteadmin/web/common/cofe/".$filename;
            //$name = "http://www.siteadmin.crgourmetcoffee.com/web/".$path."/".$filename;
            $status = array('status' => "success", "fileUploaded" => true, 'path' => $name);
            $farm->setImage($name);
            $em->flush();
        }
        return new JsonResponse($status);
    }
}