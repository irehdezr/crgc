<?php

namespace RegionBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use RegionBundle\Entity\Region;
use Symfony\Component\HttpFoundation\JsonResponse;

class DefaultController extends Controller
{
    public function indexAction()
    {
        $em = $this->getDoctrine()->getManager(); 
        $region_repo = $em->getRepository("RegionBundle:Region");
        $regions = $region_repo->findAll();
        return $this->render('RegionBundle:Default:region.html.twig', [
            'regions'=>$regions
        ]);
    }

    // --------------------- Edit ----------------------------
    public function editAction(Request $request)
    {
        $response = 'false';
        if($request->isXMLHttpRequest()) {
            $id = $request->request->get('id');
            $response = $this->generateUrl('region_edit_view',array('id'=>$id));
            
        }
        return new Response($response);
    }

    public function editViewAction($id)
    {
        $em = $this->getDoctrine()->getManager();
        $region_repo = $em->getRepository("RegionBundle:Region");
        $regions = $region_repo->findBy(array('id'=>$id));
        return $this->render('RegionBundle:Default:edit.html.twig', [
            'regions'=>$regions
        ]);
    }

    // --------------------- Save/Update ----------------------------
    public function saveAction(Request $request){
        $response = 'false'; 
        if($request->isXMLHttpRequest()){
            $id = $request->request->get('id');
            $name = $request->request->get('name');
            $descriptionimg1 = $request->request->get('descriptionimg1');
            $descriptionimg2 = $request->request->get('descriptionimg2');
            $descriptionimg3 = $request->request->get('descriptionimg3');
            $description = $request->request->get('description');
            $organoleptic = $request->request->get('organoleptic');
            $information = $request->request->get('information');
            $latitude = $request->request->get('latitude');
            $longitude = $request->request->get('longitude');
            $zoom = $request->request->get('zoom');

            $em = $this->getDoctrine()->getManager();
            $region = $em->getRepository("RegionBundle:Region")->find($id);

            $region->setName($name);
            $region->setImageDescription1($descriptionimg1);
            $region->setImageDescription2($descriptionimg2);
            $region->setImageDescription3($descriptionimg3);
            $region->setDescription($description);
            $region->setOrganolepticCharacteristics($organoleptic);
            $region->setInformation($information);
            $region->setLatitude($latitude);
            $region->setLongitude($longitude);
            $region->setZoom($zoom);
            $em->flush();
            $response = $this->generateUrl('region_homepage');
        }
        return new Response($response);
    }

    // --------------------- Insert ----------------------------
    public function addAction()
    {
        return $this->render('RegionBundle:Default:insert.html.twig');
    }

    public function insertAction(Request $request){
        $response = 'false'; 
        if($request->isXMLHttpRequest()){
            $name = $request->request->get('name');
            $descriptionimg1 = $request->request->get('descriptionimg1');
            $descriptionimg2 = $request->request->get('descriptionimg2');
            $descriptionimg3 = $request->request->get('descriptionimg3');
            $description = $request->request->get('description');
            $organoleptic = $request->request->get('organoleptic');
            $information = $request->request->get('information');
            $latitude = $request->request->get('latitude');
            $longitude = $request->request->get('longitude');
            $zoom = $request->request->get('zoom');

            $region = new Region();
            $region->setName($name);
            $region->setImage1("");
            $region->setImageDescription1($descriptionimg1);
            $region->setImage2("");
            $region->setImageDescription2($descriptionimg2);
            $region->setImage3("");
            $region->setImageDescription3($descriptionimg3);
            $region->setDescription($description);
            $region->setOrganolepticCharacteristics($organoleptic);
            $region->setInformation($information);
            $region->setLatitude($latitude);
            $region->setLongitude($longitude);
            $region->setZoom($zoom);

            $em = $this->get('doctrine')->getManager();
            $em->persist($region);
            $em->flush();
            $response = $this->generateUrl('region_homepage');
        }
        return new Response($response);
    }

    // --------------------- Delete ----------------------------
    public function deleteAction(Request $request)
    {
        $response = 'false';
        if($request->isXMLHttpRequest()) {
            $em = $this->getDoctrine()->getManager();
            $id = $request->request->get('id');
            $region = $em->getRepository("FarmBundle:Region")->find($id);
            $response = 'entro if';

            if (!empty($region->getFarms())) {
                $response = 'tiene farms';
                foreach ($region->getFarms() as $farm) {
                    $farm = $em->getRepository("FarmBundle:Farm_I")->find($farm->getId());
                    if (!empty($farm->getProducts())) {
                        $response = 'tiene productos';
                        foreach ($farm->getProducts() as $product) {
                            $product = $em->getRepository("FarmBundle:Product_I")->find($product->getId());
                            if (!empty($product->getPresentations())) {
                                $response = 'tiene presentaciones';
                                // --------------------- Presentation -----------------------
                                foreach ($product->getPresentations() as $presentation) {
                                    $em->remove($presentation);
                                }
                            }
                            // --------------------- Product -----------------------
                            $em->remove($product);
                        }
                    }
                    if (!empty($farm->getFarmAwards())) {
                        // --------------------- Award -----------------------
                        foreach ($farm->getFarmAwards() as $award) {
                            $em->remove($award);
                        }
                    }
                    // --------------------- Farm -----------------------
                    $em->remove($farm);
                }
            }
            // --------------------- Region -----------------------
            $em->remove($region);

            $em->flush();
            $response = $this->generateUrl('region_homepage');
        }
        return new Response($response);
    }

    // --------------------- Images ----------------------------
    public function imageAction(Request $request, $id, $num)
    {
        $file = $request->files->get('upload');
        $status = array('status' => "success", "fileUploaded" => false);

        // If a file was uploaded
        if (!is_null($file)) {
            // generate a random name for the file but keep the extension
            //$filename = uniqid() . "." . $file->getClientOriginalExtension();

            $em = $this->getDoctrine()->getManager();
            $region = $em->getRepository("RegionBundle:Region")->find($id);
            $filename = $region->getName()."-".$file->getClientOriginalName();
            //Lower case everything
            $filename = strtolower($filename);
            //Clean up multiple dashes or whitespaces
            $filename = preg_replace("/[\s-]+/", " ", $filename);
            //Convert whitespaces and underscore to dash
            $filename = preg_replace("/[\s_]/", "-", $filename);
            $path = "C:/xampp/htdocs/siteadmin/web/common/imgs/regions/";
            //$path = "common/imgs";
            $file->move($path, $filename); // move the file to a path
            $name = "/siteadmin/web/common/imgs/regions/".$filename;
            //$name = "http://www.siteadmin.crgourmetcoffee.com/web/".$path."/".$filename;
            $status = array('status' => "success", "fileUploaded" => true, 'path' => $name);
            if($num == 1) {
                $region->setImage1($name);
            }
            if($num == 2) {
                $region->setImage2($name);
            }
            if($num == 3) {
                $region->setImage3($name);
            }
            $em->flush();
        }

        return new JsonResponse($status);
    }

    public function searchAction(Request $request)
    {
        $status = 'false';
        if($request->isXMLHttpRequest()) {
            $name = $request->request->get('name');
            $description = $request->request->get('description');
            $organoleptic = $request->request->get('organoleptic');
            $information = $request->request->get('information');

            $em = $this->getDoctrine()->getManager();
            $region_repo = $em->getRepository("RegionBundle:Region");
            $regions = $region_repo->findAll();

            for ($i = 0; $i < count($regions); $i++) {
                $region = $regions[$i];
                if($region->getName() == $name && $region->getDescription() == $description
                    && $region->getInformation() == $information && $region->getOrganolepticCharacteristics() == $organoleptic){
                    $status = $region->getId();
                    break;
                }
            }
        }

        return new JsonResponse($status);
    }
}
