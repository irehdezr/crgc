<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appProdDebugProjectContainerUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/farm')) {
            // farm_homepage
            if (rtrim($pathinfo, '/') === '/farm') {
                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'farm_homepage');
                }

                return array (  '_controller' => 'FarmBundle\\Controller\\DefaultController::indexAction',  '_route' => 'farm_homepage',);
            }

            if (0 === strpos($pathinfo, '/farm/edit')) {
                // farm_edit
                if ($pathinfo === '/farm/edit') {
                    return array (  '_controller' => 'FarmBundle\\Controller\\DefaultController::editAction',  '_route' => 'farm_edit',);
                }

                // farm_edit_view
                if (preg_match('#^/farm/edit/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'farm_edit_view')), array (  '_controller' => 'FarmBundle\\Controller\\DefaultController::editViewAction',));
                }

            }

            // farm_save
            if ($pathinfo === '/farm/save') {
                return array (  '_controller' => 'FarmBundle\\Controller\\DefaultController::saveAction',  '_route' => 'farm_save',);
            }

            // farm_add
            if ($pathinfo === '/farm/add') {
                return array (  '_controller' => 'FarmBundle\\Controller\\DefaultController::addAction',  '_route' => 'farm_add',);
            }

            // farm_insert
            if ($pathinfo === '/farm/insert') {
                return array (  '_controller' => 'FarmBundle\\Controller\\DefaultController::insertAction',  '_route' => 'farm_insert',);
            }

            // farm_delete
            if ($pathinfo === '/farm/delete') {
                return array (  '_controller' => 'FarmBundle\\Controller\\DefaultController::deleteAction',  '_route' => 'farm_delete',);
            }

            // farm_image
            if (0 === strpos($pathinfo, '/farm/image') && preg_match('#^/farm/image/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'farm_image')), array (  '_controller' => 'FarmBundle\\Controller\\DefaultController::imageAction',));
            }

            // farm_add_cultivar
            if ($pathinfo === '/farm/addCultivar') {
                return array (  '_controller' => 'FarmBundle\\Controller\\DefaultController::addCultivarAction',  '_route' => 'farm_add_cultivar',);
            }

            // farm_delete_cultivar
            if ($pathinfo === '/farm/deleteCultivar') {
                return array (  '_controller' => 'FarmBundle\\Controller\\DefaultController::deleteCultivarAction',  '_route' => 'farm_delete_cultivar',);
            }

            // farm_add_certifications
            if ($pathinfo === '/farm/addCertifications') {
                return array (  '_controller' => 'FarmBundle\\Controller\\DefaultController::addCertificationsAction',  '_route' => 'farm_add_certifications',);
            }

            // farm_delete_certifications
            if ($pathinfo === '/farm/deleteCertifications') {
                return array (  '_controller' => 'FarmBundle\\Controller\\DefaultController::deleteCertificationsAction',  '_route' => 'farm_delete_certifications',);
            }

            // farm_add_awards
            if ($pathinfo === '/farm/addAwards') {
                return array (  '_controller' => 'FarmBundle\\Controller\\DefaultController::addAwardsAction',  '_route' => 'farm_add_awards',);
            }

            // farm_delete_awards
            if ($pathinfo === '/farm/deleteAwards') {
                return array (  '_controller' => 'FarmBundle\\Controller\\DefaultController::deleteAwardsAction',  '_route' => 'farm_delete_awards',);
            }

            // farm_search
            if ($pathinfo === '/farm/search') {
                return array (  '_controller' => 'FarmBundle\\Controller\\DefaultController::searchAction',  '_route' => 'farm_search',);
            }

            if (0 === strpos($pathinfo, '/farm/products')) {
                // farm_product_homepage
                if (preg_match('#^/farm/products/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'farm_product_homepage')), array (  '_controller' => 'FarmBundle\\Controller\\ProductController::indexAction',));
                }

                // farm_product_edit
                if (0 === strpos($pathinfo, '/farm/products/edit') && preg_match('#^/farm/products/edit/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'farm_product_edit')), array (  '_controller' => 'FarmBundle\\Controller\\ProductController::editViewAction',));
                }

            }

            // farm_product_save
            if ($pathinfo === '/farm/save/products') {
                return array (  '_controller' => 'FarmBundle\\Controller\\ProductController::saveAction',  '_route' => 'farm_product_save',);
            }

            // farm_product_add_presentations
            if ($pathinfo === '/farm/addPresentation/products') {
                return array (  '_controller' => 'FarmBundle\\Controller\\ProductController::addPresentationsAction',  '_route' => 'farm_product_add_presentations',);
            }

            if (0 === strpos($pathinfo, '/farm/pr')) {
                // farm_product_delete_presentations
                if ($pathinfo === '/farm/presentationDelete/products') {
                    return array (  '_controller' => 'FarmBundle\\Controller\\ProductController::deletePresentationsAction',  '_route' => 'farm_product_delete_presentations',);
                }

                if (0 === strpos($pathinfo, '/farm/products')) {
                    // farm_product_add
                    if (0 === strpos($pathinfo, '/farm/products/add') && preg_match('#^/farm/products/add/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'farm_product_add')), array (  '_controller' => 'FarmBundle\\Controller\\ProductController::addAction',));
                    }

                    // farm_product_insert
                    if ($pathinfo === '/farm/products/insert/save') {
                        return array (  '_controller' => 'FarmBundle\\Controller\\ProductController::insertAction',  '_route' => 'farm_product_insert',);
                    }

                }

            }

            // farm_product_image
            if (0 === strpos($pathinfo, '/farm/image/product') && preg_match('#^/farm/image/product/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'farm_product_image')), array (  '_controller' => 'FarmBundle\\Controller\\ProductController::imageAction',));
            }

            if (0 === strpos($pathinfo, '/farm/p')) {
                if (0 === strpos($pathinfo, '/farm/product')) {
                    // farm_product_search
                    if ($pathinfo === '/farm/product/search') {
                        return array (  '_controller' => 'FarmBundle\\Controller\\ProductController::searchAction',  '_route' => 'farm_product_search',);
                    }

                    // farm_product_delete
                    if ($pathinfo === '/farm/product/delete') {
                        return array (  '_controller' => 'FarmBundle\\Controller\\ProductController::deleteAction',  '_route' => 'farm_product_delete',);
                    }

                }

                // farm_award_pdf
                if (0 === strpos($pathinfo, '/farm/pdf') && preg_match('#^/farm/pdf/(?P<place>[^/]++)/(?P<year>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'farm_award_pdf')), array (  '_controller' => 'FarmBundle\\Controller\\DefaultController::pdfAction',));
                }

            }

        }

        if (0 === strpos($pathinfo, '/region')) {
            // region_homepage
            if (rtrim($pathinfo, '/') === '/region') {
                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'region_homepage');
                }

                return array (  '_controller' => 'RegionBundle\\Controller\\DefaultController::indexAction',  '_route' => 'region_homepage',);
            }

            if (0 === strpos($pathinfo, '/region/edit')) {
                // region_edit
                if ($pathinfo === '/region/edit') {
                    return array (  '_controller' => 'RegionBundle\\Controller\\DefaultController::editAction',  '_route' => 'region_edit',);
                }

                // region_edit_view
                if (preg_match('#^/region/edit/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'region_edit_view')), array (  '_controller' => 'RegionBundle\\Controller\\DefaultController::editViewAction',));
                }

            }

            // region_save
            if ($pathinfo === '/region/save') {
                return array (  '_controller' => 'RegionBundle\\Controller\\DefaultController::saveAction',  '_route' => 'region_save',);
            }

            // region_add
            if ($pathinfo === '/region/add') {
                return array (  '_controller' => 'RegionBundle\\Controller\\DefaultController::addAction',  '_route' => 'region_add',);
            }

            // region_insert
            if ($pathinfo === '/region/insert') {
                return array (  '_controller' => 'RegionBundle\\Controller\\DefaultController::insertAction',  '_route' => 'region_insert',);
            }

            // region_delete
            if ($pathinfo === '/region/delete') {
                return array (  '_controller' => 'RegionBundle\\Controller\\DefaultController::deleteAction',  '_route' => 'region_delete',);
            }

            // region_image
            if (0 === strpos($pathinfo, '/region/image') && preg_match('#^/region/image/(?P<id>[^/]++)/(?P<num>[^/]++)$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'region_image')), array (  '_controller' => 'RegionBundle\\Controller\\DefaultController::imageAction',));
            }

            // region_search
            if ($pathinfo === '/region/search') {
                return array (  '_controller' => 'RegionBundle\\Controller\\DefaultController::searchAction',  '_route' => 'region_search',);
            }

        }

        // app_homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'app_homepage');
            }

            return array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'app_homepage',);
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
