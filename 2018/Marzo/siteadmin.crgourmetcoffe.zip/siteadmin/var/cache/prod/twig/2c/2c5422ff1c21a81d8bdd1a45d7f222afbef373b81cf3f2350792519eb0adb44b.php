<?php

/* RegionBundle:Default:region.html.twig */
class __TwigTemplate_008cea48c95b80f9ebcb3d764244a97e0acdf7fb1ad6cdf37d54d9a7a5cdac73 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "RegionBundle:Default:region.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4dfd35037fcbaa1eea3c45662725d084f6ff7b855392728966c3db22b25c9743 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4dfd35037fcbaa1eea3c45662725d084f6ff7b855392728966c3db22b25c9743->enter($__internal_4dfd35037fcbaa1eea3c45662725d084f6ff7b855392728966c3db22b25c9743_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "RegionBundle:Default:region.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4dfd35037fcbaa1eea3c45662725d084f6ff7b855392728966c3db22b25c9743->leave($__internal_4dfd35037fcbaa1eea3c45662725d084f6ff7b855392728966c3db22b25c9743_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_c6a1666bc680af07a7ebf87e67ec52dcd682d87d1ef0ba9ab45f070a51f208f6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c6a1666bc680af07a7ebf87e67ec52dcd682d87d1ef0ba9ab45f070a51f208f6->enter($__internal_c6a1666bc680af07a7ebf87e67ec52dcd682d87d1ef0ba9ab45f070a51f208f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Mantenimiento de regiones";
        
        $__internal_c6a1666bc680af07a7ebf87e67ec52dcd682d87d1ef0ba9ab45f070a51f208f6->leave($__internal_c6a1666bc680af07a7ebf87e67ec52dcd682d87d1ef0ba9ab45f070a51f208f6_prof);

    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        $__internal_efc23506d6958c70367529130cdab16a743f1a518c8a6ecfae0955c1d63ced53 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_efc23506d6958c70367529130cdab16a743f1a518c8a6ecfae0955c1d63ced53->enter($__internal_efc23506d6958c70367529130cdab16a743f1a518c8a6ecfae0955c1d63ced53_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "    <div class=\"row col-md-20 col-md-offset-0 custyle\">
        <a href=\"";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_add");
        echo "\" class=\"btn btn-primary btn-xs pull-right\"><span
                    class=\"glyphicon glyphicon-plus\"></span> Agregar</a>
        <div>
            <table class=\"table table-striped custab\">
                <thead>
                <tr>
                    <th class=\"text-center\" colspan=\"5\">REGIONES</th>
                </tr>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Imagen 1</th>
                    <th>Descripción</th>
                    <th class=\"text-center\">Acción</th>
                </tr>
                </thead>
                <tbody>
                ";
        // line 25
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["regions"] ?? $this->getContext($context, "regions")));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 26
            echo "                    <tr>
                        <td> ";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "</td>
                        <td> ";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo " </td>
                        <td><img src=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage1", array(), "method"), "html", null, true);
            echo "\" class=\"mediana\"></td>
                        <td class=\"text-area\" style=\"text-align: justify\">";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getDescription", array(), "method"), "html", null, true);
            echo " </td>
                        <td class=\"text-center\">
                            <a class='btn btn-info btn-xs btn-edit' id=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-edit\"></span> Editar</a>
                            <a id=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\" name=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo "\" class=\"btn btn-danger btn-xs btn-delete\"><span class=\"glyphicon glyphicon-remove\"></span> Eliminar</a>
                        </td>
                    </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 37
        echo "                </tbody>
            </table>
        </div>
    </div>

    <!-- The Modal Delete Confirmation -->
    <div id=\"deleteConfirmation\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
            <!-- Modal content -->
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h3>Eliminar Regiones</h3>
                </div>
                <div class=\"modal-body\" id=\"modal-body\">
                    <form>
                        <div class=\"form-group row div-body\" id=\"div-body\">
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_efc23506d6958c70367529130cdab16a743f1a518c8a6ecfae0955c1d63ced53->leave($__internal_efc23506d6958c70367529130cdab16a743f1a518c8a6ecfae0955c1d63ced53_prof);

    }

    // line 64
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_eb9124cad9c6e15bf6295e580a0a956e62f32eae3705a4acbd68403ac88006cc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eb9124cad9c6e15bf6295e580a0a956e62f32eae3705a4acbd68403ac88006cc->enter($__internal_eb9124cad9c6e15bf6295e580a0a956e62f32eae3705a4acbd68403ac88006cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 65
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 66
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 67
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/css/styles.css"), "html", null, true);
        echo "\">
";
        
        $__internal_eb9124cad9c6e15bf6295e580a0a956e62f32eae3705a4acbd68403ac88006cc->leave($__internal_eb9124cad9c6e15bf6295e580a0a956e62f32eae3705a4acbd68403ac88006cc_prof);

    }

    // line 70
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_e4a27242bf0384242fd1b61b8709ab6f9227af8e8dfb8419a8aac832d41b0e73 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e4a27242bf0384242fd1b61b8709ab6f9227af8e8dfb8419a8aac832d41b0e73->enter($__internal_e4a27242bf0384242fd1b61b8709ab6f9227af8e8dfb8419a8aac832d41b0e73_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 71
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 72
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/js/regions.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_e4a27242bf0384242fd1b61b8709ab6f9227af8e8dfb8419a8aac832d41b0e73->leave($__internal_e4a27242bf0384242fd1b61b8709ab6f9227af8e8dfb8419a8aac832d41b0e73_prof);

    }

    public function getTemplateName()
    {
        return "RegionBundle:Default:region.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  184 => 72,  179 => 71,  173 => 70,  164 => 67,  160 => 66,  155 => 65,  149 => 64,  118 => 37,  106 => 33,  102 => 32,  97 => 30,  93 => 29,  89 => 28,  85 => 27,  82 => 26,  78 => 25,  58 => 8,  55 => 7,  49 => 6,  37 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Mantenimiento de regiones{% endblock %}

{% block body %}
    <div class=\"row col-md-20 col-md-offset-0 custyle\">
        <a href=\"{{ path('region_add') }}\" class=\"btn btn-primary btn-xs pull-right\"><span
                    class=\"glyphicon glyphicon-plus\"></span> Agregar</a>
        <div>
            <table class=\"table table-striped custab\">
                <thead>
                <tr>
                    <th class=\"text-center\" colspan=\"5\">REGIONES</th>
                </tr>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Imagen 1</th>
                    <th>Descripción</th>
                    <th class=\"text-center\">Acción</th>
                </tr>
                </thead>
                <tbody>
                {% for temp in regions %}
                    <tr>
                        <td> {{ temp.getId() }}</td>
                        <td> {{ temp.getName() }} </td>
                        <td><img src=\"{{ temp.getImage1() }}\" class=\"mediana\"></td>
                        <td class=\"text-area\" style=\"text-align: justify\">{{ temp.getDescription() }} </td>
                        <td class=\"text-center\">
                            <a class='btn btn-info btn-xs btn-edit' id=\"{{ temp.getId() }}\"><span class=\"glyphicon glyphicon-edit\"></span> Editar</a>
                            <a id=\"{{ temp.getId() }}\" name=\"{{ temp.getName() }}\" class=\"btn btn-danger btn-xs btn-delete\"><span class=\"glyphicon glyphicon-remove\"></span> Eliminar</a>
                        </td>
                    </tr>
                {% endfor %}
                </tbody>
            </table>
        </div>
    </div>

    <!-- The Modal Delete Confirmation -->
    <div id=\"deleteConfirmation\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
            <!-- Modal content -->
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h3>Eliminar Regiones</h3>
                </div>
                <div class=\"modal-body\" id=\"modal-body\">
                    <form>
                        <div class=\"form-group row div-body\" id=\"div-body\">
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                </div>
            </div>
        </div>
    </div>
{% endblock %}


{% block stylesheets %}
    {{ parent() }}
    <link rel=\"stylesheet\" href=\"{{ asset('/siteadmin/web/css/crgourmetcoffee.css') }}\">
    <link rel=\"stylesheet\" href=\"{{ asset('/siteadmin/web/css/styles.css') }}\">
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('/siteadmin/web/js/jquery-3.2.0.min.js') }}\"></script>
    <script src=\"{{ asset('/siteadmin/web/js/regions.js') }}\"></script>
{% endblock %}
", "RegionBundle:Default:region.html.twig", "C:\\xampp\\htdocs\\siteadmin\\src\\RegionBundle\\Resources\\views\\Default\\region.html.twig");
    }
}
