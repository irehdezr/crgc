<?php

/* RegionBundle:Default:region.html.twig */
class __TwigTemplate_ab02fccfb96f24c8d40f51b40ad2f109700db4853845e3340cca14a5cba79703 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "RegionBundle:Default:region.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_eeec92cccdffe9d2de799d2a5db0e11a56f089225387d9a46f8fe985c4df0da7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eeec92cccdffe9d2de799d2a5db0e11a56f089225387d9a46f8fe985c4df0da7->enter($__internal_eeec92cccdffe9d2de799d2a5db0e11a56f089225387d9a46f8fe985c4df0da7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "RegionBundle:Default:region.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_eeec92cccdffe9d2de799d2a5db0e11a56f089225387d9a46f8fe985c4df0da7->leave($__internal_eeec92cccdffe9d2de799d2a5db0e11a56f089225387d9a46f8fe985c4df0da7_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_65587e9f4a3d72c1f7b0252a156df182c8bf4c51c51c35a07633056de588f3cf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_65587e9f4a3d72c1f7b0252a156df182c8bf4c51c51c35a07633056de588f3cf->enter($__internal_65587e9f4a3d72c1f7b0252a156df182c8bf4c51c51c35a07633056de588f3cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Mantenimiento de regiones";
        
        $__internal_65587e9f4a3d72c1f7b0252a156df182c8bf4c51c51c35a07633056de588f3cf->leave($__internal_65587e9f4a3d72c1f7b0252a156df182c8bf4c51c51c35a07633056de588f3cf_prof);

    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        $__internal_ac5503d5a2f60c100e68aa49428b7caaf4aa8e7a885f59d1ac6b0f000a4bf140 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ac5503d5a2f60c100e68aa49428b7caaf4aa8e7a885f59d1ac6b0f000a4bf140->enter($__internal_ac5503d5a2f60c100e68aa49428b7caaf4aa8e7a885f59d1ac6b0f000a4bf140_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "    <div class=\"row col-md-20 col-md-offset-0 custyle\">
        <a href=\"";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_add");
        echo "\" class=\"btn btn-primary btn-xs pull-right\"><span
                    class=\"glyphicon glyphicon-plus\"></span> Agregar</a>
        <div>
            <table class=\"table table-striped custab\">
                <thead>
                <tr>
                    <th class=\"text-center\" colspan=\"5\">REGIONES</th>
                </tr>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Imagen 1</th>
                    <th>Descripción</th>
                    <th class=\"text-center\">Acción</th>
                </tr>
                </thead>
                <tbody>
                ";
        // line 25
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["regions"] ?? $this->getContext($context, "regions")));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 26
            echo "                    <tr>
                        <td> ";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "</td>
                        <td> ";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo " </td>
                        <td><img src=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage1", array(), "method"), "html", null, true);
            echo "\" class=\"mediana\"></td>
                        <td class=\"text-area\" style=\"text-align: justify\">";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getDescription", array(), "method"), "html", null, true);
            echo " </td>
                        <td class=\"text-center\">
                            <a class='btn btn-info btn-xs btn-edit' id=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-edit\"></span> Editar</a>
                            <a id=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\" name=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo "\" class=\"btn btn-danger btn-xs btn-delete\"><span class=\"glyphicon glyphicon-remove\"></span> Eliminar</a>
                        </td>
                    </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 37
        echo "                </tbody>
            </table>
        </div>
    </div>

    <!-- The Modal Delete Confirmation -->
    <div id=\"deleteConfirmation\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
            <!-- Modal content -->
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h3>Eliminar Regiones</h3>
                </div>
                <div class=\"modal-body\" id=\"modal-body\">
                    <form>
                        <div class=\"form-group row div-body\" id=\"div-body\">
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_ac5503d5a2f60c100e68aa49428b7caaf4aa8e7a885f59d1ac6b0f000a4bf140->leave($__internal_ac5503d5a2f60c100e68aa49428b7caaf4aa8e7a885f59d1ac6b0f000a4bf140_prof);

    }

    // line 64
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_89a2b92c85565de0aa5902b2a8c549e8511f83dec4e210b708750abc0f40ab25 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_89a2b92c85565de0aa5902b2a8c549e8511f83dec4e210b708750abc0f40ab25->enter($__internal_89a2b92c85565de0aa5902b2a8c549e8511f83dec4e210b708750abc0f40ab25_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 65
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 66
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 67
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/css/styles.css"), "html", null, true);
        echo "\">
";
        
        $__internal_89a2b92c85565de0aa5902b2a8c549e8511f83dec4e210b708750abc0f40ab25->leave($__internal_89a2b92c85565de0aa5902b2a8c549e8511f83dec4e210b708750abc0f40ab25_prof);

    }

    // line 70
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_e345f92b92d910ded75887fdcca691257a7dd01779edf60c0ff7924b850187dd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e345f92b92d910ded75887fdcca691257a7dd01779edf60c0ff7924b850187dd->enter($__internal_e345f92b92d910ded75887fdcca691257a7dd01779edf60c0ff7924b850187dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 71
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 72
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/js/regions.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_e345f92b92d910ded75887fdcca691257a7dd01779edf60c0ff7924b850187dd->leave($__internal_e345f92b92d910ded75887fdcca691257a7dd01779edf60c0ff7924b850187dd_prof);

    }

    public function getTemplateName()
    {
        return "RegionBundle:Default:region.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  184 => 72,  179 => 71,  173 => 70,  164 => 67,  160 => 66,  155 => 65,  149 => 64,  118 => 37,  106 => 33,  102 => 32,  97 => 30,  93 => 29,  89 => 28,  85 => 27,  82 => 26,  78 => 25,  58 => 8,  55 => 7,  49 => 6,  37 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Mantenimiento de regiones{% endblock %}

{% block body %}
    <div class=\"row col-md-20 col-md-offset-0 custyle\">
        <a href=\"{{ path('region_add') }}\" class=\"btn btn-primary btn-xs pull-right\"><span
                    class=\"glyphicon glyphicon-plus\"></span> Agregar</a>
        <div>
            <table class=\"table table-striped custab\">
                <thead>
                <tr>
                    <th class=\"text-center\" colspan=\"5\">REGIONES</th>
                </tr>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Imagen 1</th>
                    <th>Descripción</th>
                    <th class=\"text-center\">Acción</th>
                </tr>
                </thead>
                <tbody>
                {% for temp in regions %}
                    <tr>
                        <td> {{ temp.getId() }}</td>
                        <td> {{ temp.getName() }} </td>
                        <td><img src=\"{{ temp.getImage1() }}\" class=\"mediana\"></td>
                        <td class=\"text-area\" style=\"text-align: justify\">{{ temp.getDescription() }} </td>
                        <td class=\"text-center\">
                            <a class='btn btn-info btn-xs btn-edit' id=\"{{ temp.getId() }}\"><span class=\"glyphicon glyphicon-edit\"></span> Editar</a>
                            <a id=\"{{ temp.getId() }}\" name=\"{{ temp.getName() }}\" class=\"btn btn-danger btn-xs btn-delete\"><span class=\"glyphicon glyphicon-remove\"></span> Eliminar</a>
                        </td>
                    </tr>
                {% endfor %}
                </tbody>
            </table>
        </div>
    </div>

    <!-- The Modal Delete Confirmation -->
    <div id=\"deleteConfirmation\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
            <!-- Modal content -->
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h3>Eliminar Regiones</h3>
                </div>
                <div class=\"modal-body\" id=\"modal-body\">
                    <form>
                        <div class=\"form-group row div-body\" id=\"div-body\">
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                </div>
            </div>
        </div>
    </div>
{% endblock %}


{% block stylesheets %}
    {{ parent() }}
    <link rel=\"stylesheet\" href=\"{{ asset('/siteadmin/web/css/crgourmetcoffee.css') }}\">
    <link rel=\"stylesheet\" href=\"{{ asset('/siteadmin/web/css/styles.css') }}\">
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('/siteadmin/web/js/jquery-3.2.0.min.js') }}\"></script>
    <script src=\"{{ asset('/siteadmin/web/js/regions.js') }}\"></script>
{% endblock %}
", "RegionBundle:Default:region.html.twig", "/Applications/MAMP/htdocs/siteadmin/src/RegionBundle/Resources/views/Default/region.html.twig");
    }
}
