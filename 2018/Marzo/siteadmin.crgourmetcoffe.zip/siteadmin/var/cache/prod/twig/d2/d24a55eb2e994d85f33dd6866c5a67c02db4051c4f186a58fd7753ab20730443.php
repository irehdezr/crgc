<?php

/* @Product/Default/insert.html.twig */
class __TwigTemplate_eb8e27ccf0ece5d5a4dcc112a0ab9325c06d28c15c10b4a56d30a671531c3e5b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "@Product/Default/insert.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Product Maintenance";
    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        // line 7
        echo "    <div class=\"row col-md-8 col-md-offset-2 custyle\" style=\"margin-top: 20px\">
        <table class=\"table table-striped custab\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"2\">EDIT PRODUCT</th>
            </tr>
            </thead>
            <tbody>
                <tr>
                    <th>Name</th>
                    <td><input type=\"text\" name=\"name\" value=\"\" id=\"name\"></td>
                </tr>
                <tr>
                    <th>Description</th>
                    <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\"></textarea></td>
                </tr>
                <tr>
                    <th>Image</th>
                    <td>
                        <form id=\"myform1\" method=\"post\" style=\"margin-top: 5px;\">
                            <input type=\"button\" id=\"loadFileXml\" value=\"Choose file\" onclick=\"document.getElementById('image').click();\" />
                            <input id=\"image\" style=\"display:none;\" type=\"file\" name=\"upload\" />
                        </form>
                    </td>
                </tr>
                <tr>
                    <th>Farm Name</th>
                    <td>
                        ";
        // line 44
        echo "                    </td>
                </tr>
                <tr>
                    <th>Cultivar</th>
                    <td>
                        ";
        // line 62
        echo "                    </td>
                </tr>
                <tr>
                    <th>Grade</th>
                    <td>
                        <select name=\"grade\" id=\"grade\">
                            ";
        // line 68
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["grade"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["gr"]) {
            // line 69
            echo "                                ";
            if (($this->getAttribute($context["gr"], "getId", array(), "method") != 1)) {
                // line 70
                echo "                                    <option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["gr"], "getId", array(), "method"), "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["gr"], "getDescription", array(), "method"), "html", null, true);
                echo "</option>
                                ";
            }
            // line 72
            echo "                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['gr'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 73
        echo "                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Processing</th>
                    <td>
                        <select name=\"processing\" id=\"processing\">
                            ";
        // line 80
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["processing"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["pr"]) {
            // line 81
            echo "                                ";
            if (($this->getAttribute($context["pr"], "getId", array(), "method") != 1)) {
                // line 82
                echo "                                    <option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["pr"], "getId", array(), "method"), "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["pr"], "getDescription", array(), "method"), "html", null, true);
                echo "</option>
                                ";
            }
            // line 84
            echo "                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pr'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 85
        echo "                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Flavor</th>
                    <td>
                        <select name=\"flavor\" id=\"flavor\">
                            ";
        // line 92
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["flavor"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["fl"]) {
            // line 93
            echo "                                ";
            if (($this->getAttribute($context["fl"], "getId", array(), "method") != 1)) {
                // line 94
                echo "                                    <option value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["fl"], "getId", array(), "method"), "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["fl"], "notes", array(), "method"), "html", null, true);
                echo "</option>
                                ";
            }
            // line 96
            echo "                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fl'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 97
        echo "                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Rank</th>
                    <td><input type=\"text\" name=\"rank\" value=\"\" id=\"rank\"></td>
                </tr>
                <tr>
                    <th>Reviews</th>
                    <td><input type=\"text\" name=\"review\" value=\"\" id=\"review\"></td>
                </tr>

                <tr>
                    <td class=\"text-center\" colspan=\"2\">
                        <a class='btn btn-success btn-xs btn-save' id=\"\"><span class=\"glyphicon glyphicon-save\"></span> Save</a>
                        <a href=\"";
        // line 112
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("product_homepage");
        echo "\" class=\"btn btn-warning btn-xs\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancel</a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
";
    }

    // line 121
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 122
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 123
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/styles.css"), "html", null, true);
        echo "\">
";
    }

    // line 127
    public function block_javascripts($context, array $blocks = array())
    {
        // line 128
        echo "    <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 129
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/js/products.js"), "html", null, true);
        echo "\"></script>
";
    }

    public function getTemplateName()
    {
        return "@Product/Default/insert.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  216 => 129,  211 => 128,  208 => 127,  202 => 123,  197 => 122,  194 => 121,  183 => 112,  166 => 97,  160 => 96,  152 => 94,  149 => 93,  145 => 92,  136 => 85,  130 => 84,  122 => 82,  119 => 81,  115 => 80,  106 => 73,  100 => 72,  92 => 70,  89 => 69,  85 => 68,  77 => 62,  70 => 44,  40 => 7,  37 => 6,  31 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Product/Default/insert.html.twig", "C:\\xampp\\htdocs\\src\\ProductBundle\\Resources\\views\\Default\\insert.html.twig");
    }
}
