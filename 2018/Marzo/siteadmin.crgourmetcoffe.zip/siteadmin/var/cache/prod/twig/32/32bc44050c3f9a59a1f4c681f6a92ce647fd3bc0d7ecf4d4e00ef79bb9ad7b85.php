<?php

/* FarmBundle:Default:insert.html.twig */
class __TwigTemplate_c2be7cd28f202a602cd03bf707b699f023f01834e7cdaa1a1275e538af8fd3ca extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "FarmBundle:Default:insert.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'navbar' => array($this, 'block_navbar'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dbc8ad6ef2582a47fbbf274ec9d7b9789865f96f50e431dc7d89808098cb6d60 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dbc8ad6ef2582a47fbbf274ec9d7b9789865f96f50e431dc7d89808098cb6d60->enter($__internal_dbc8ad6ef2582a47fbbf274ec9d7b9789865f96f50e431dc7d89808098cb6d60_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FarmBundle:Default:insert.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_dbc8ad6ef2582a47fbbf274ec9d7b9789865f96f50e431dc7d89808098cb6d60->leave($__internal_dbc8ad6ef2582a47fbbf274ec9d7b9789865f96f50e431dc7d89808098cb6d60_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_ab2892a0e109cdacd1ffb1156f8e655d4f31d5ea4e6e693478219feb0f827f5c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ab2892a0e109cdacd1ffb1156f8e655d4f31d5ea4e6e693478219feb0f827f5c->enter($__internal_ab2892a0e109cdacd1ffb1156f8e655d4f31d5ea4e6e693478219feb0f827f5c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Mantenimiento de fincas";
        
        $__internal_ab2892a0e109cdacd1ffb1156f8e655d4f31d5ea4e6e693478219feb0f827f5c->leave($__internal_ab2892a0e109cdacd1ffb1156f8e655d4f31d5ea4e6e693478219feb0f827f5c_prof);

    }

    // line 6
    public function block_navbar($context, array $blocks = array())
    {
        $__internal_592212f617f3fd6393cbdb323cc836fbb265511e50a3c5ada5739fd6c45a1275 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_592212f617f3fd6393cbdb323cc836fbb265511e50a3c5ada5739fd6c45a1275->enter($__internal_592212f617f3fd6393cbdb323cc836fbb265511e50a3c5ada5739fd6c45a1275_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        echo "Mantenimiento de fincas - Agregar";
        
        $__internal_592212f617f3fd6393cbdb323cc836fbb265511e50a3c5ada5739fd6c45a1275->leave($__internal_592212f617f3fd6393cbdb323cc836fbb265511e50a3c5ada5739fd6c45a1275_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_e03e26251b8e8134fabeae651d9c404dac12c624b82cb3c7b54de521fc3d3c26 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e03e26251b8e8134fabeae651d9c404dac12c624b82cb3c7b54de521fc3d3c26->enter($__internal_e03e26251b8e8134fabeae651d9c404dac12c624b82cb3c7b54de521fc3d3c26_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo "    <div class=\"row col-md-8 col-md-offset-2 custyle\" style=\"margin-top: 20px\">
        <table class=\"table table-striped custab\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"2\">Agregar Fincas</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <th>Nombre (en inglés)</th>
                <td><input type=\"text\" name=\"name\" value=\"\" id=\"name\"></td>
            </tr>
            <tr>
                <th>Descripción (en inglés)</th>
                <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\"></textarea></td>
            </tr>
            <tr>
                <th>Imagen</th>
                <td>
                    <form id=\"myform1\" method=\"post\" style=\"margin-top: 5px;\">
                        <input type=\"button\" id=\"loadFileXml\" value=\"Seleccione un archivo\"
                               onclick=\"document.getElementById('image').click();\"/>
                        <input id=\"image\" style=\"display:none;\" type=\"file\" name=\"upload\"/>
                    </form>
                    <p id=\"imageError\" style=\"color: red; display: none;\">
                        <small>Selecciona una imagen</small>
                    </p>
                    <p id=\"image1Error\" style=\"color: red; display: none;\">
                        <small>Selecciona una imagen con la extensión .jpg, .jpeg, .gif o .png</small>
                    </p>
                </td>
            </tr>
            <tr>
                <th>Nombre de la region</th>
                <td>
                    <select name=\"region\" id=\"region\">
                        <option value=\"0\" selected></option>
                        ";
        // line 46
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["regions"] ?? $this->getContext($context, "regions")));
        foreach ($context['_seq'] as $context["_key"] => $context["reg"]) {
            // line 47
            echo "                            <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["reg"], "id", array(), "method"), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["reg"], "name", array(), "method"), "html", null, true);
            echo "</option>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['reg'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 49
        echo "                    </select>
                    <p id=\"regionError\" style=\"color: red; display: none;\">
                        <small>Selecciona una opción</small>
                    </p>
                </td>
            </tr>
            <tr>
                <th>Elevación</th>
                <td>
                    <p name=\"elevation\" id=\"elevation\">min-max</p>
                    <label>Min:</label>
                    <select name=\"elevation-Min\" id=\"elevation-Min\">
                        <option value=\"0\" selected></option>
                        ";
        // line 62
        $context["ele"] = 500;
        // line 63
        echo "                        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(1, 16));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 64
            echo "                            <option value=\"";
            echo twig_escape_filter($this->env, ($context["ele"] ?? $this->getContext($context, "ele")), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, ($context["ele"] ?? $this->getContext($context, "ele")), "html", null, true);
            echo "</option>
                            ";
            // line 65
            $context["ele"] = (($context["ele"] ?? $this->getContext($context, "ele")) + 100);
            // line 66
            echo "                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 67
        echo "                    </select>
                    <label>Max:</label>
                    <select name=\"elevation-Max\" id=\"elevation-Max\">
                        <option value=\"0\" selected></option>
                        ";
        // line 71
        $context["ele"] = 2000;
        // line 72
        echo "                        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(1, 16));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 73
            echo "                            <option value=\"";
            echo twig_escape_filter($this->env, ($context["ele"] ?? $this->getContext($context, "ele")), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, ($context["ele"] ?? $this->getContext($context, "ele")), "html", null, true);
            echo "</option>
                            ";
            // line 74
            $context["ele"] = (($context["ele"] ?? $this->getContext($context, "ele")) - 100);
            // line 75
            echo "                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 76
        echo "                    </select>
                    <p id=\"elevationError\" style=\"color: red; display: none;\">
                        <small>Seleccione un valor mínimo o máximo</small>
                    </p>
                    <p id=\"elevationError-min\" style=\"color: red; display: none;\">
                        <small>El valor mínimo no puede ser mayor o igual al valor máximo</small>
                    </p>
                    <p id=\"elevationError-max\" style=\"color: red; display: none;\">
                        <small>El valor máximo no puede ser menor o igual al valor mínimo</small>
                    </p>
                </td>
            </tr>
            <tr>
                <th>Cosecha</th>
                <td>
                    <p name=\"harvest\" id=\"harvest\">begin-end</p>
                    <label>Empieza:</label>
                    <select name=\"harvest-begin\" id=\"harvest-begin\">
                        <option value=\"0\" selected></option>
                        <option value=\"January\">January</option>
                        <option value=\"February\">February</option>
                        <option value=\"March\">March</option>
                        <option value=\"April\">April</option>
                        <option value=\"May\">May</option>
                        <option value=\"June\">June</option>
                        <option value=\"July\">July</option>
                        <option value=\"August\">August</option>
                        <option value=\"September\">September</option>
                        <option value=\"October\">October</option>
                        <option value=\"November\">November</option>
                        <option value=\"December\">December </option>
                    </select>
                    <label>Termina:</label>
                    <select name=\"harvest-end\" id=\"harvest-end\">
                        <option value=\"0\" selected></option>
                        <option value=\"December\">December </option>
                        <option value=\"November\">November</option>
                        <option value=\"October\">October</option>
                        <option value=\"September\">September</option>
                        <option value=\"August\">August</option>
                        <option value=\"July\">July</option>
                        <option value=\"June\">June</option>
                        <option value=\"May\">May</option>
                        <option value=\"April\">April</option>
                        <option value=\"March\">March</option>
                        <option value=\"February\">February</option>
                        <option value=\"January\">January</option>
                    </select>
                    <p id=\"harvestError\" style=\"color: red; display: none;\">
                        <small>Indique el valor para cuado empiza o termina la cosecha</small>
                    </p>
                    <p id=\"harvestError-begin\" style=\"color: red; display: none;\">
                        <small>El mes en el empieza la cosecha no puede ser igual al mes en que termina</small>
                    </p>
                    <p id=\"harvestError-end\" style=\"color: red; display: none;\">
                        <small>El mes en el termina la cosecha no puede ser igual al mes en que empieza</small>
                    </p>
                </td>
            </tr>
            <tr>
                <th>Cultivar</th>
                <td>
                    <form>
                        ";
        // line 139
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["cultivars"] ?? $this->getContext($context, "cultivars")));
        foreach ($context['_seq'] as $context["_key"] => $context["culti"]) {
            // line 140
            echo "                            ";
            if (($this->getAttribute($context["culti"], "getId", array(), "method") != 1)) {
                // line 141
                echo "                                <input type=\"checkbox\" name=\"cultivars\"
                                       value=\"";
                // line 142
                echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getId", array(), "method"), "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getDescription", array(), "method"), "html", null, true);
                echo "</br>
                            ";
            }
            // line 144
            echo "                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['culti'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 145
        echo "                    </form>
                    <p id=\"cultivarError\" style=\"color: red; display: none;\">
                        <small>Seleccione una opción</small>
                    </p>
                </td>
            </tr>
            <tr>
                <th>Certificaciones</th>
                <td>
                    <form>
                        ";
        // line 155
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["certifications"] ?? $this->getContext($context, "certifications")));
        foreach ($context['_seq'] as $context["_key"] => $context["certi"]) {
            // line 156
            echo "                            ";
            if (($this->getAttribute($context["certi"], "getId", array(), "method") != 1)) {
                // line 157
                echo "                                <input type=\"checkbox\" name=\"certifications\"
                                       value=\"";
                // line 158
                echo twig_escape_filter($this->env, $this->getAttribute($context["certi"], "getId", array(), "method"), "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["certi"], "getDescription", array(), "method"), "html", null, true);
                echo "</br>
                            ";
            }
            // line 160
            echo "                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['certi'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 161
        echo "                    </form>
                    <p id=\"certificationError\" style=\"color: red; display: none;\">
                        <small>Seleccione una opción</small>
                    </p>
                </td>
            </tr>
            <tr>
                <th>Premios</th>
                <td>
                    <table class=\"table table-striped custab\" id=\"table-awards\">
                        <thead>
                        <th></th>
                        <th>Lugar</th>
                        <th>Año</th>
                        <th></th>
                        </thead>
                        <tbody id=\"tbody-awards\"></tbody>
                        <tfoot>
                        <tr>
                            <td class=\"award-description-add\" id=\"2\">Cup of Excellence</td>
                            <td><input type=\"number\" name=\"place\" value=\"1\" id=\"place\" min=\"1\"></td>
                            <td>
                                <select name=\"year\" id=\"year\">
                                    ";
        // line 184
        $context["year"] = twig_date_format_filter($this->env, "now", "Y");
        // line 185
        echo "                                    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(2007, ($context["year"] ?? $this->getContext($context, "year"))));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 186
            echo "                                        ";
            if (($context["i"] != 2010)) {
                // line 187
                echo "                                            <option value=\"";
                echo twig_escape_filter($this->env, $context["i"], "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $context["i"], "html", null, true);
                echo "</option>
                                        ";
            }
            // line 189
            echo "                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 190
        echo "                                </select>
                            </td>
                            <td>
                                <a class=\"btn btn-info btn-xs btn-insert-award\" style=\"margin: 0px;\">Agregar</a>
                            </td>
                        </tr>
                        </tfoot>
                    </table>
                </td>
            </tr>
            <tr>
                <th>Latitud</th>
                <td><input type=\"number\" name=\"latitude\" value=\"\" id=\"latitude\" min=\"0\"></td>
            </tr>
            <tr>
                <th>Longitud</th>
                <td><input type=\"number\" name=\"longitude\" value=\"\" id=\"longitude\" min=\"0\"></td>
            </tr>
            <tr>
                <td class=\"text-center\" colspan=\"2\">
                    <a class='btn btn-success btn-xs btn-insert' style=\"margin-top: 10px\"><span
                                class=\"glyphicon glyphicon-save\"></span> Guardar</a>
                    <a href=\"";
        // line 212
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_homepage");
        echo "\" class=\"btn btn-warning btn-xs\" style=\"margin-top: 10px\"><span
                                class=\"glyphicon glyphicon-ban-circle\"></span> Cancelar</a>
                </td>
            </tr>
            </tbody>
        </table>
    </div>

    <!-- The Modal -->
    <div id=\"errorModal\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
            <!-- Modal content -->
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <span class=\"close\">&times;</span>
                    <div id=\"modal-header\">
                        <h3 style=\"color: red;\">Error</h3>
                    </div>
                </div>
                <div class=\"modal-body\" id=\"modal-body\">
                    <span class='glyphicon glyphicon-remove-sign modal-icon'></span>
                    <p class='modal-p'>Algunos campos se encuentran en blanco</p>
                    <div id=\"modal-body-error\">
                    </div>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_e03e26251b8e8134fabeae651d9c404dac12c624b82cb3c7b54de521fc3d3c26->leave($__internal_e03e26251b8e8134fabeae651d9c404dac12c624b82cb3c7b54de521fc3d3c26_prof);

    }

    // line 243
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_2443f56edd17f7947ac8962195ccb986b29b656666621cf99466ca124033dd23 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2443f56edd17f7947ac8962195ccb986b29b656666621cf99466ca124033dd23->enter($__internal_2443f56edd17f7947ac8962195ccb986b29b656666621cf99466ca124033dd23_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 244
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 245
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 246
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/css/styles.css"), "html", null, true);
        echo "\">
";
        
        $__internal_2443f56edd17f7947ac8962195ccb986b29b656666621cf99466ca124033dd23->leave($__internal_2443f56edd17f7947ac8962195ccb986b29b656666621cf99466ca124033dd23_prof);

    }

    // line 249
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_a21a9e20864d82c2d778bfab5850d1bd889e07867eb35ada656bdedebdafee03 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a21a9e20864d82c2d778bfab5850d1bd889e07867eb35ada656bdedebdafee03->enter($__internal_a21a9e20864d82c2d778bfab5850d1bd889e07867eb35ada656bdedebdafee03_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 250
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script type=\"text/javascript\" src=\"";
        // line 251
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/js/farm.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_a21a9e20864d82c2d778bfab5850d1bd889e07867eb35ada656bdedebdafee03->leave($__internal_a21a9e20864d82c2d778bfab5850d1bd889e07867eb35ada656bdedebdafee03_prof);

    }

    public function getTemplateName()
    {
        return "FarmBundle:Default:insert.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  454 => 251,  449 => 250,  443 => 249,  434 => 246,  430 => 245,  425 => 244,  419 => 243,  383 => 212,  359 => 190,  353 => 189,  345 => 187,  342 => 186,  337 => 185,  335 => 184,  310 => 161,  304 => 160,  297 => 158,  294 => 157,  291 => 156,  287 => 155,  275 => 145,  269 => 144,  262 => 142,  259 => 141,  256 => 140,  252 => 139,  187 => 76,  181 => 75,  179 => 74,  172 => 73,  167 => 72,  165 => 71,  159 => 67,  153 => 66,  151 => 65,  144 => 64,  139 => 63,  137 => 62,  122 => 49,  111 => 47,  107 => 46,  68 => 9,  62 => 8,  50 => 6,  38 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Mantenimiento de fincas{% endblock %}

{% block navbar %}Mantenimiento de fincas - Agregar{% endblock %}

{% block body %}
    <div class=\"row col-md-8 col-md-offset-2 custyle\" style=\"margin-top: 20px\">
        <table class=\"table table-striped custab\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"2\">Agregar Fincas</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <th>Nombre (en inglés)</th>
                <td><input type=\"text\" name=\"name\" value=\"\" id=\"name\"></td>
            </tr>
            <tr>
                <th>Descripción (en inglés)</th>
                <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\"></textarea></td>
            </tr>
            <tr>
                <th>Imagen</th>
                <td>
                    <form id=\"myform1\" method=\"post\" style=\"margin-top: 5px;\">
                        <input type=\"button\" id=\"loadFileXml\" value=\"Seleccione un archivo\"
                               onclick=\"document.getElementById('image').click();\"/>
                        <input id=\"image\" style=\"display:none;\" type=\"file\" name=\"upload\"/>
                    </form>
                    <p id=\"imageError\" style=\"color: red; display: none;\">
                        <small>Selecciona una imagen</small>
                    </p>
                    <p id=\"image1Error\" style=\"color: red; display: none;\">
                        <small>Selecciona una imagen con la extensión .jpg, .jpeg, .gif o .png</small>
                    </p>
                </td>
            </tr>
            <tr>
                <th>Nombre de la region</th>
                <td>
                    <select name=\"region\" id=\"region\">
                        <option value=\"0\" selected></option>
                        {% for reg in regions %}
                            <option value=\"{{ reg.id() }}\">{{ reg.name() }}</option>
                        {% endfor %}
                    </select>
                    <p id=\"regionError\" style=\"color: red; display: none;\">
                        <small>Selecciona una opción</small>
                    </p>
                </td>
            </tr>
            <tr>
                <th>Elevación</th>
                <td>
                    <p name=\"elevation\" id=\"elevation\">min-max</p>
                    <label>Min:</label>
                    <select name=\"elevation-Min\" id=\"elevation-Min\">
                        <option value=\"0\" selected></option>
                        {% set ele = 500 %}
                        {% for i in 1..16 %}
                            <option value=\"{{ ele }}\">{{ ele }}</option>
                            {% set ele = ele+100 %}
                        {% endfor %}
                    </select>
                    <label>Max:</label>
                    <select name=\"elevation-Max\" id=\"elevation-Max\">
                        <option value=\"0\" selected></option>
                        {% set ele = 2000 %}
                        {% for i in 1..16 %}
                            <option value=\"{{ ele }}\">{{ ele }}</option>
                            {% set ele = ele-100 %}
                        {% endfor %}
                    </select>
                    <p id=\"elevationError\" style=\"color: red; display: none;\">
                        <small>Seleccione un valor mínimo o máximo</small>
                    </p>
                    <p id=\"elevationError-min\" style=\"color: red; display: none;\">
                        <small>El valor mínimo no puede ser mayor o igual al valor máximo</small>
                    </p>
                    <p id=\"elevationError-max\" style=\"color: red; display: none;\">
                        <small>El valor máximo no puede ser menor o igual al valor mínimo</small>
                    </p>
                </td>
            </tr>
            <tr>
                <th>Cosecha</th>
                <td>
                    <p name=\"harvest\" id=\"harvest\">begin-end</p>
                    <label>Empieza:</label>
                    <select name=\"harvest-begin\" id=\"harvest-begin\">
                        <option value=\"0\" selected></option>
                        <option value=\"January\">January</option>
                        <option value=\"February\">February</option>
                        <option value=\"March\">March</option>
                        <option value=\"April\">April</option>
                        <option value=\"May\">May</option>
                        <option value=\"June\">June</option>
                        <option value=\"July\">July</option>
                        <option value=\"August\">August</option>
                        <option value=\"September\">September</option>
                        <option value=\"October\">October</option>
                        <option value=\"November\">November</option>
                        <option value=\"December\">December </option>
                    </select>
                    <label>Termina:</label>
                    <select name=\"harvest-end\" id=\"harvest-end\">
                        <option value=\"0\" selected></option>
                        <option value=\"December\">December </option>
                        <option value=\"November\">November</option>
                        <option value=\"October\">October</option>
                        <option value=\"September\">September</option>
                        <option value=\"August\">August</option>
                        <option value=\"July\">July</option>
                        <option value=\"June\">June</option>
                        <option value=\"May\">May</option>
                        <option value=\"April\">April</option>
                        <option value=\"March\">March</option>
                        <option value=\"February\">February</option>
                        <option value=\"January\">January</option>
                    </select>
                    <p id=\"harvestError\" style=\"color: red; display: none;\">
                        <small>Indique el valor para cuado empiza o termina la cosecha</small>
                    </p>
                    <p id=\"harvestError-begin\" style=\"color: red; display: none;\">
                        <small>El mes en el empieza la cosecha no puede ser igual al mes en que termina</small>
                    </p>
                    <p id=\"harvestError-end\" style=\"color: red; display: none;\">
                        <small>El mes en el termina la cosecha no puede ser igual al mes en que empieza</small>
                    </p>
                </td>
            </tr>
            <tr>
                <th>Cultivar</th>
                <td>
                    <form>
                        {% for culti in cultivars %}
                            {% if culti.getId() != 1 %}
                                <input type=\"checkbox\" name=\"cultivars\"
                                       value=\"{{ culti.getId() }}\"> {{ culti.getDescription() }}</br>
                            {% endif %}
                        {% endfor %}
                    </form>
                    <p id=\"cultivarError\" style=\"color: red; display: none;\">
                        <small>Seleccione una opción</small>
                    </p>
                </td>
            </tr>
            <tr>
                <th>Certificaciones</th>
                <td>
                    <form>
                        {% for certi in certifications %}
                            {% if certi.getId() != 1 %}
                                <input type=\"checkbox\" name=\"certifications\"
                                       value=\"{{ certi.getId() }}\"> {{ certi.getDescription() }}</br>
                            {% endif %}
                        {% endfor %}
                    </form>
                    <p id=\"certificationError\" style=\"color: red; display: none;\">
                        <small>Seleccione una opción</small>
                    </p>
                </td>
            </tr>
            <tr>
                <th>Premios</th>
                <td>
                    <table class=\"table table-striped custab\" id=\"table-awards\">
                        <thead>
                        <th></th>
                        <th>Lugar</th>
                        <th>Año</th>
                        <th></th>
                        </thead>
                        <tbody id=\"tbody-awards\"></tbody>
                        <tfoot>
                        <tr>
                            <td class=\"award-description-add\" id=\"2\">Cup of Excellence</td>
                            <td><input type=\"number\" name=\"place\" value=\"1\" id=\"place\" min=\"1\"></td>
                            <td>
                                <select name=\"year\" id=\"year\">
                                    {% set year= \"now\"|date(\"Y\") %}
                                    {% for i in 2007..year %}
                                        {% if i != 2010 %}
                                            <option value=\"{{ i }}\">{{ i }}</option>
                                        {% endif %}
                                    {% endfor %}
                                </select>
                            </td>
                            <td>
                                <a class=\"btn btn-info btn-xs btn-insert-award\" style=\"margin: 0px;\">Agregar</a>
                            </td>
                        </tr>
                        </tfoot>
                    </table>
                </td>
            </tr>
            <tr>
                <th>Latitud</th>
                <td><input type=\"number\" name=\"latitude\" value=\"\" id=\"latitude\" min=\"0\"></td>
            </tr>
            <tr>
                <th>Longitud</th>
                <td><input type=\"number\" name=\"longitude\" value=\"\" id=\"longitude\" min=\"0\"></td>
            </tr>
            <tr>
                <td class=\"text-center\" colspan=\"2\">
                    <a class='btn btn-success btn-xs btn-insert' style=\"margin-top: 10px\"><span
                                class=\"glyphicon glyphicon-save\"></span> Guardar</a>
                    <a href=\"{{ path('farm_homepage') }}\" class=\"btn btn-warning btn-xs\" style=\"margin-top: 10px\"><span
                                class=\"glyphicon glyphicon-ban-circle\"></span> Cancelar</a>
                </td>
            </tr>
            </tbody>
        </table>
    </div>

    <!-- The Modal -->
    <div id=\"errorModal\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
            <!-- Modal content -->
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <span class=\"close\">&times;</span>
                    <div id=\"modal-header\">
                        <h3 style=\"color: red;\">Error</h3>
                    </div>
                </div>
                <div class=\"modal-body\" id=\"modal-body\">
                    <span class='glyphicon glyphicon-remove-sign modal-icon'></span>
                    <p class='modal-p'>Algunos campos se encuentran en blanco</p>
                    <div id=\"modal-body-error\">
                    </div>
                </div>
            </div>
        </div>
    </div>
{% endblock %}


{% block stylesheets %}
    {{ parent() }}
    <link rel=\"stylesheet\" href=\"{{ asset('/siteadmin/web/css/crgourmetcoffee.css') }}\">
    <link rel=\"stylesheet\" href=\"{{ asset('/siteadmin/web/css/styles.css') }}\">
{% endblock %}

{% block javascripts %}
    {{ parent() }}
    <script type=\"text/javascript\" src=\"{{ asset('/siteadmin/web/js/farm.js') }}\"></script>
{% endblock %}", "FarmBundle:Default:insert.html.twig", "C:\\xampp\\htdocs\\siteadmin\\src\\FarmBundle\\Resources\\views\\Default\\insert.html.twig");
    }
}
