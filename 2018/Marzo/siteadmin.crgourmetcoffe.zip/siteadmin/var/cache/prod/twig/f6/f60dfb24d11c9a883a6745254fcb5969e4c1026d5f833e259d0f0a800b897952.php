<?php

/* @Farm/Default/edit.html.twig */
class __TwigTemplate_4988eb312c2b6475e266914d11327ce29c093c2405fc59feed0077694cc9e8ef extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "@Farm/Default/edit.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'navbar' => array($this, 'block_navbar'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Farm Maintenance";
    }

    // line 6
    public function block_navbar($context, array $blocks = array())
    {
        echo "Farm Maintenance - Edit";
    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        // line 9
        echo "    <div class=\"row col-md-8 col-md-offset-2 custyle\" style=\"margin-top: 20px\">
        <table class=\"table table-striped custab\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"2\">EDIT FARM</th>
            </tr>
            </thead>
            <tbody>
            ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["farms"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 18
            echo "                <tr>
                    <th>ID</th>
                    <td> ";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "</td>
                </tr>
                <tr>
                    <th>Name</th>
                    <td><input type=\"text\" name=\"name\" value=\"";
            // line 24
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo "\" id=\"name\"></td>
                </tr>
                <tr>
                    <th>Description</th>
                    <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\">";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getDescription", array(), "method"), "html", null, true);
            echo "</textarea></td>
                </tr>
                <tr>
                    <th>Image</th>
                    <td>
                        <img src=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage", array(), "method"), "html", null, true);
            echo "\" class=\"mediana\">
                        <form id=\"myform1\" method=\"post\" style=\"margin-top: 5px;\">
                            <input type=\"button\" id=\"loadFileXml\" value=\"Choose file\" onclick=\"document.getElementById('image').click();\" />
                            <input id=\"image\" style=\"display:none;\" type=\"file\" name=\"upload\" />
                        </form>
                    </td>
                </tr>
                <tr>
                    <th>Region Name</th>
                    <td>";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["temp"], "region", array()), "name", array()), "html", null, true);
            echo "
                        ";
            // line 52
            echo "                    </td>
                </tr>
                <tr>
                    <th>Elevation</th>
                    <td>
                        <p name=\"elevation\" id=\"elevation\">";
            // line 57
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getElevation", array(), "method"), "html", null, true);
            echo "</p>
                        <label>Min:</label>
                        <select name=\"elevation-Min\" id=\"elevation-Min\">
                            ";
            // line 60
            $context["ele"] = 500;
            // line 61
            echo "                            ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(range(1, 16));
            foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
                // line 62
                echo "                                <option value=\"";
                echo twig_escape_filter($this->env, ($context["ele"] ?? null), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, ($context["ele"] ?? null), "html", null, true);
                echo "</option>
                                ";
                // line 63
                $context["ele"] = (($context["ele"] ?? null) + 100);
                // line 64
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 65
            echo "                        </select>
                        <label>Max:</label>
                        <select name=\"elevation-Max\" id=\"elevation-Max\">
                            ";
            // line 68
            $context["ele"] = 2000;
            // line 69
            echo "                            ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(range(1, 16));
            foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
                // line 70
                echo "                                <option value=\"";
                echo twig_escape_filter($this->env, ($context["ele"] ?? null), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, ($context["ele"] ?? null), "html", null, true);
                echo "</option>
                                ";
                // line 71
                $context["ele"] = (($context["ele"] ?? null) - 100);
                // line 72
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 73
            echo "                        </select>
                        <p id=\"elevationError\" style=\"color: red; display: none;\"><small>Choose a minimum or maximum value</small></p>
                        <p id=\"elevationError-min\" style=\"color: red; display: none;\"><small>The minimum value can't be greater than or equal to the maximum value</small></p>
                        <p id=\"elevationError-max\" style=\"color: red; display: none;\"><small>The maximum value can't be less than or equal to the minimum value</small></p>
                    </td>
                </tr>
                <tr>
                    <th>Harvest</th>
                    <td>
                       <p name=\"harvest\" id=\"harvest\">";
            // line 82
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getHarvest", array(), "method"), "html", null, true);
            echo "</p>
                       <label>Begin:</label>
                       <select name=\"harvest-begin\" id=\"harvest-begin\">
                           <option value=\"January\">January</option>
                           <option value=\"February\">February</option>
                           <option value=\"March\">March</option>
                           <option value=\"April\">April</option>
                           <option value=\"May\">May</option>
                           <option value=\"June\">June</option>
                           <option value=\"July\">July</option>
                           <option value=\"August\">August</option>
                           <option value=\"September\">September</option>
                           <option value=\"October\">October</option>
                           <option value=\"November\">November</option>
                           <option value=\"December\">December </option>
                       </select>
                       <label>End:</label>
                       <select name=\"harvest-end\" id=\"harvest-end\">
                            <option value=\"January\">January</option>
                            <option value=\"February\">February</option>
                            <option value=\"March\">March</option>
                            <option value=\"April\">April</option>
                            <option value=\"May\">May</option>
                            <option value=\"June\">June</option>
                            <option value=\"July\">July</option>
                            <option value=\"August\">August</option>
                            <option value=\"September\">September</option>
                            <option value=\"October\">October</option>
                            <option value=\"November\">November</option>
                            <option value=\"December\">December </option>
                       </select>
                        <p id=\"harvestError\" style=\"color: red; display: none;\"><small>Choose a begin or end value</small></p>
                        <p id=\"harvestError-begin\" style=\"color: red; display: none;\"><small>The begin month can't be equal to the end month</small></p>
                        <p id=\"harvestError-end\" style=\"color: red; display: none;\"><small>The end month can't be equal to the begin month</small></p>
                    </td>
                </tr>
                <tr>
                    <th>Cultivar</th>
                    <td>
                        <form>
                            ";
            // line 122
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["cultivars"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["culti"]) {
                // line 123
                echo "                                ";
                $context["flag"] = 0;
                // line 124
                echo "                                ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["temp"], "cultivars", array(), "method"));
                foreach ($context['_seq'] as $context["_key"] => $context["aux"]) {
                    // line 125
                    echo "                                    ";
                    if (($this->getAttribute($context["aux"], "getId", array(), "method") == $this->getAttribute($context["culti"], "getId", array(), "method"))) {
                        // line 126
                        echo "                                        ";
                        if (($this->getAttribute($context["culti"], "getId", array(), "method") != 1)) {
                            // line 127
                            echo "                                            <input type=\"checkbox\" name=\"cultivar\" id=\"";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
                            echo "\" value=\"";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getId", array(), "method"), "html", null, true);
                            echo "\" checked> ";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getDescription", array(), "method"), "html", null, true);
                            echo "</br>
                                            ";
                            // line 128
                            $context["flag"] = 1;
                            // line 129
                            echo "                                        ";
                        }
                        // line 130
                        echo "                                    ";
                    }
                    // line 131
                    echo "                                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['aux'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 132
                echo "                                ";
                if ((($context["flag"] ?? null) == 0)) {
                    // line 133
                    echo "                                    ";
                    if (($this->getAttribute($context["culti"], "getId", array(), "method") != 1)) {
                        // line 134
                        echo "                                        <input type=\"checkbox\" name=\"cultivar\" id=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
                        echo "\" value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getId", array(), "method"), "html", null, true);
                        echo "\"> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getDescription", array(), "method"), "html", null, true);
                        echo "</br>
                                    ";
                    }
                    // line 136
                    echo "                                 ";
                }
                // line 137
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['culti'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 138
            echo "                        </form>
                        <p id=\"cultivarError\" style=\"color: red; display: none;\"><small>Choose an option</small></p>
                    </td>
                </tr>
                <tr>
                    <th>Certifications</th>
                    <td>
                        <form>
                            ";
            // line 146
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["certifications"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["certi"]) {
                // line 147
                echo "                                ";
                $context["flag"] = 0;
                // line 148
                echo "                                ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["temp"], "certifications", array(), "method"));
                foreach ($context['_seq'] as $context["_key"] => $context["aux"]) {
                    // line 149
                    echo "                                    ";
                    if (($this->getAttribute($context["aux"], "getId", array(), "method") == $this->getAttribute($context["certi"], "getId", array(), "method"))) {
                        // line 150
                        echo "                                        ";
                        if (($this->getAttribute($context["certi"], "getId", array(), "method") != 1)) {
                            // line 151
                            echo "                                            <input type=\"checkbox\" name=\"certification\" id=\"";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
                            echo "\" value=\"";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["certi"], "getId", array(), "method"), "html", null, true);
                            echo "\" checked> ";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["certi"], "getDescription", array(), "method"), "html", null, true);
                            echo "</br>
                                            ";
                            // line 152
                            $context["flag"] = 1;
                            // line 153
                            echo "                                        ";
                        }
                        // line 154
                        echo "                                    ";
                    }
                    // line 155
                    echo "                                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['aux'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 156
                echo "                                ";
                if ((($context["flag"] ?? null) == 0)) {
                    // line 157
                    echo "                                    ";
                    if (($this->getAttribute($context["certi"], "getId", array(), "method") != 1)) {
                        // line 158
                        echo "                                        <input type=\"checkbox\" name=\"certification\" id=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
                        echo "\" value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["certi"], "getId", array(), "method"), "html", null, true);
                        echo "\" > ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["certi"], "getDescription", array(), "method"), "html", null, true);
                        echo "</br>
                                    ";
                    }
                    // line 160
                    echo "                                ";
                }
                // line 161
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['certi'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 162
            echo "                        </form>
                        <p id=\"certificationError\" style=\"color: red; display: none;\"><small>Choose an option</small></p>
                    </td>
                </tr>
                <tr>
                    <th>Awards</th>
                    <td>
                        <table class=\"table table-striped custab\" id=\"table-awards\">
                            <thead>
                                <th></th>
                                <th>Place</th>
                                <th>Year</th>
                                <th></th>
                            </thead>
                            <tbody id=\"tbody-awards\">
                                ";
            // line 177
            $context["num"] = 1;
            // line 178
            echo "                                ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["temp"], "GetfarmAwards", array(), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["award"]) {
                // line 179
                echo "                                    <tr id=\"";
                echo twig_escape_filter($this->env, ($context["num"] ?? null), "html", null, true);
                echo "\">
                                        <td class=\"award-description-";
                // line 180
                echo twig_escape_filter($this->env, ($context["num"] ?? null), "html", null, true);
                echo "\" id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["award"], "getAward", array(), "method"), "getId", array(), "method"), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["award"], "getAward", array(), "method"), "getDescription", array(), "method"), "html", null, true);
                echo "</td>
                                        <td class=\"award-place-";
                // line 181
                echo twig_escape_filter($this->env, ($context["num"] ?? null), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["award"], "getPlace", array(), "method"), "html", null, true);
                echo "</td>
                                        <td class=\"award-year-";
                // line 182
                echo twig_escape_filter($this->env, ($context["num"] ?? null), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["award"], "getYear", array(), "method"), "html", null, true);
                echo "</td>
                                        <td><a class=\"btn btn-xs btn-delete-award\" style=\"color: red; margin: 0px;\" id=\"";
                // line 183
                echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
                echo "-";
                echo twig_escape_filter($this->env, ($context["num"] ?? null), "html", null, true);
                echo "\"><span class=\"glyphicon glyphicon-minus\"></span></a></td>
                                    </tr>
                                    ";
                // line 185
                $context["num"] = (($context["num"] ?? null) + 1);
                // line 186
                echo "                                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['award'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 187
            echo "                            </tbody>
                            <tfoot>
                                <tr>
                                    <td class=\"award-description-add\" id=\"2\">Cup of Excellence</td>
                                    <td><input type=\"number\" name=\"place\" value=\"1\" id=\"place\" min=\"1\"></td>
                                    <td>
                                        <select name=\"year\" id=\"year\">
                                            ";
            // line 194
            $context["year"] = twig_date_format_filter($this->env, "now", "Y");
            // line 195
            echo "                                            ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(range(2007, ($context["year"] ?? null)));
            foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
                // line 196
                echo "                                                ";
                if (($context["i"] != 2010)) {
                    // line 197
                    echo "                                                    <option value=\"";
                    echo twig_escape_filter($this->env, $context["i"], "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $context["i"], "html", null, true);
                    echo "</option>
                                                ";
                }
                // line 199
                echo "                                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 200
            echo "                                        </select>
                                    </td>
                                    <td><a class=\"btn btn-xs btn-add-award\" style=\"margin: 0px;\" id=\"";
            // line 202
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-plus\"></span></a></td>
                                </tr>
                            </tfoot>
                        </table>
                    </td>
                </tr>
                <tr>
                    <th>Latitude</th>
                    <td><input type=\"text\" name=\"latitude\" value=\"";
            // line 210
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getLatitude", array(), "method"), "html", null, true);
            echo "\" id=\"latitude\"></td>
                </tr>
                <tr>
                    <th>Longitude</th>
                    <td><input type=\"text\" name=\"longitude\" value=\"";
            // line 214
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getLongitude", array(), "method"), "html", null, true);
            echo "\" id=\"longitude\"><p><small>*Don't forget to include the minus (-) symbol</small></p></td>
                </tr>

                <tr>
                    <td class=\"text-center\" colspan=\"2\">
                        <a class='btn btn-success btn-xs btn-save' id=\"";
            // line 219
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-save\"></span> Save</a>
                        <a href=\"";
            // line 220
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_homepage");
            echo "\" class=\"btn btn-warning btn-xs\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancel</a>
                        <a href=\"";
            // line 221
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_product_homepage", array("id" => $this->getAttribute($context["temp"], "getId", array(), "method"))), "html", null, true);
            echo "\" class=\"btn btn-info btn-xs\"><span class=\"glyphicon glyphicon-plus\"></span> Edit Products</a>
                    </td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 225
        echo "            </tbody>
        </table>
    </div>

    <!-- The Modal -->
    <div id=\"myModal\" class=\"modal\">
        <!-- Modal content -->
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <span class=\"close\">&times;</span>
                <div id=\"modal-header\">
                    <h3>Error</h3>
                </div>
            </div>
            <div class=\"modal-body\" id=\"modal-body\">
                <span class='glyphicon glyphicon-remove-sign modal-icon'></span>
                <p class='modal-p'>Some fields are missing or blank</p>
            </div>
        </div>
    </div>
";
    }

    // line 248
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 249
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 250
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/styles.css"), "html", null, true);
        echo "\">
";
    }

    // line 254
    public function block_javascripts($context, array $blocks = array())
    {
        // line 255
        echo "    <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 256
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/js/farm.js"), "html", null, true);
        echo "\"></script>
";
    }

    public function getTemplateName()
    {
        return "@Farm/Default/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  552 => 256,  547 => 255,  544 => 254,  538 => 250,  533 => 249,  530 => 248,  506 => 225,  496 => 221,  492 => 220,  488 => 219,  480 => 214,  473 => 210,  462 => 202,  458 => 200,  452 => 199,  444 => 197,  441 => 196,  436 => 195,  434 => 194,  425 => 187,  419 => 186,  417 => 185,  410 => 183,  404 => 182,  398 => 181,  390 => 180,  385 => 179,  380 => 178,  378 => 177,  361 => 162,  355 => 161,  352 => 160,  342 => 158,  339 => 157,  336 => 156,  330 => 155,  327 => 154,  324 => 153,  322 => 152,  313 => 151,  310 => 150,  307 => 149,  302 => 148,  299 => 147,  295 => 146,  285 => 138,  279 => 137,  276 => 136,  266 => 134,  263 => 133,  260 => 132,  254 => 131,  251 => 130,  248 => 129,  246 => 128,  237 => 127,  234 => 126,  231 => 125,  226 => 124,  223 => 123,  219 => 122,  176 => 82,  165 => 73,  159 => 72,  157 => 71,  150 => 70,  145 => 69,  143 => 68,  138 => 65,  132 => 64,  130 => 63,  123 => 62,  118 => 61,  116 => 60,  110 => 57,  103 => 52,  99 => 42,  87 => 33,  79 => 28,  72 => 24,  65 => 20,  61 => 18,  57 => 17,  47 => 9,  44 => 8,  38 => 6,  32 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Farm/Default/edit.html.twig", "C:\\xampp\\htdocs\\src\\FarmBundle\\Resources\\views\\Default\\edit.html.twig");
    }
}
