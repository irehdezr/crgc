<?php

/* layout.html.twig */
class __TwigTemplate_baea91e6f4055e172c8202b688a7709ff7610fa44e044ec5628110687e87b697 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8dc2a4ba34fc3c098ab8575aff1d93110a0171811733464cf91c79209bf9867d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8dc2a4ba34fc3c098ab8575aff1d93110a0171811733464cf91c79209bf9867d->enter($__internal_8dc2a4ba34fc3c098ab8575aff1d93110a0171811733464cf91c79209bf9867d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"es\">
    <head>
        <meta charset=\"UTF-8\"/>
        <title>
            ";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        // line 9
        echo "        </title>
        <link rel=\"stylesheet\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./css/bootstrap.min.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./css/styles.css"), "html", null, true);
        echo "\">
        ";
        // line 13
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 14
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./favicon.ico"), "html", null, true);
        echo "\"/>
    </head>
    <body>

        <div class=\"container\">
            ";
        // line 19
        $this->loadTemplate("header.html.twig", "layout.html.twig", 19)->display($context);
        // line 20
        echo "            ";
        $this->displayBlock('body', $context, $blocks);
        // line 21
        echo "        </div>

        <script type=\"text/javascript\" src=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
        ";
        // line 24
        $this->displayBlock('javascripts', $context, $blocks);
        // line 25
        echo "    </body>
</html>";
        
        $__internal_8dc2a4ba34fc3c098ab8575aff1d93110a0171811733464cf91c79209bf9867d->leave($__internal_8dc2a4ba34fc3c098ab8575aff1d93110a0171811733464cf91c79209bf9867d_prof);

    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        $__internal_49b78c82fcd1235105725ae8a856c34b426e3960853d8a7833e36d2960641583 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_49b78c82fcd1235105725ae8a856c34b426e3960853d8a7833e36d2960641583->enter($__internal_49b78c82fcd1235105725ae8a856c34b426e3960853d8a7833e36d2960641583_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 7
        echo "                Mantenimiento
            ";
        
        $__internal_49b78c82fcd1235105725ae8a856c34b426e3960853d8a7833e36d2960641583->leave($__internal_49b78c82fcd1235105725ae8a856c34b426e3960853d8a7833e36d2960641583_prof);

    }

    // line 13
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_1ca9cd58dd52191cd5de6e8fef401a17475f89b8c45ab84d6fad30404f852053 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1ca9cd58dd52191cd5de6e8fef401a17475f89b8c45ab84d6fad30404f852053->enter($__internal_1ca9cd58dd52191cd5de6e8fef401a17475f89b8c45ab84d6fad30404f852053_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_1ca9cd58dd52191cd5de6e8fef401a17475f89b8c45ab84d6fad30404f852053->leave($__internal_1ca9cd58dd52191cd5de6e8fef401a17475f89b8c45ab84d6fad30404f852053_prof);

    }

    // line 20
    public function block_body($context, array $blocks = array())
    {
        $__internal_7317c55ed59df50f68976347e6def376c5682e52b34b978b9d160428632a769a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7317c55ed59df50f68976347e6def376c5682e52b34b978b9d160428632a769a->enter($__internal_7317c55ed59df50f68976347e6def376c5682e52b34b978b9d160428632a769a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_7317c55ed59df50f68976347e6def376c5682e52b34b978b9d160428632a769a->leave($__internal_7317c55ed59df50f68976347e6def376c5682e52b34b978b9d160428632a769a_prof);

    }

    // line 24
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_4f2d95b6a9a40d073ef1a420e6440736ddca1f5fdb73026f0e1375671804437e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4f2d95b6a9a40d073ef1a420e6440736ddca1f5fdb73026f0e1375671804437e->enter($__internal_4f2d95b6a9a40d073ef1a420e6440736ddca1f5fdb73026f0e1375671804437e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_4f2d95b6a9a40d073ef1a420e6440736ddca1f5fdb73026f0e1375671804437e->leave($__internal_4f2d95b6a9a40d073ef1a420e6440736ddca1f5fdb73026f0e1375671804437e_prof);

    }

    public function getTemplateName()
    {
        return "layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  120 => 24,  109 => 20,  98 => 13,  90 => 7,  84 => 6,  76 => 25,  74 => 24,  70 => 23,  66 => 21,  63 => 20,  61 => 19,  52 => 14,  50 => 13,  46 => 12,  42 => 11,  38 => 10,  35 => 9,  33 => 6,  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"es\">
    <head>
        <meta charset=\"UTF-8\"/>
        <title>
            {% block title %}
                Mantenimiento
            {% endblock %}
        </title>
        <link rel=\"stylesheet\" href=\"{{ asset('./css/bootstrap.min.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('./css/crgourmetcoffee.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('./css/styles.css') }}\">
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('./favicon.ico') }}\"/>
    </head>
    <body>

        <div class=\"container\">
            {% include \"header.html.twig\" %}
            {% block body %}{% endblock %}
        </div>

        <script type=\"text/javascript\" src=\"{{ asset('./js/jquery-3.2.0.min.js') }}\"></script>
        {% block javascripts %}{% endblock %}
    </body>
</html>", "layout.html.twig", "C:\\xampp\\htdocs\\siteadmin\\app\\Resources\\views\\layout.html.twig");
    }
}
