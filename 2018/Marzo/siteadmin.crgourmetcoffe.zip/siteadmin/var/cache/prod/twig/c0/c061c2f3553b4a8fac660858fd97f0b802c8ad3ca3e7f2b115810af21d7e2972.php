<?php

/* @Region/Default/insert.html.twig */
class __TwigTemplate_0a41b2ff4921efa5824b96e4cc41555a114a2301750d55ed3f3ecc07293f7cfe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "@Region/Default/insert.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Region Add";
    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        // line 7
        echo "    <div class=\"row col-md-8 col-md-offset-2 custyle\" style=\"margin-top: 20px;\">
        <table class=\"table table-striped custab\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"2\">ADD REGION</th>
            </tr>
            </thead>
            <tbody>
                <tr>
                    <th>Name</th>
                    <td><input type=\"text\" name=\"name\" value=\"\" id=\"name\"></td>
                </tr>
                <tr>
                    <th>Image 1</th>
                    <td>
                        <form id=\"myform1\" method=\"post\">
                            <input type=\"button\" id=\"loadFileXml\" value=\"Choose file\" onclick=\"document.getElementById('image1').click();\" />
                            <input id=\"image1\" style=\"display:none;\" type=\"file\" name=\"upload\" />
                        </form>
                        <p id=\"image1Error\" style=\"color: red; display: none;\"><small>Select an image </small></p>
                        <p id=\"image1-1Error\" style=\"color: red; display: none;\"><small>Choose an image with extension .jpg, .jpeg, .gif or .png</small></p>
                    </td>
                </tr>
                <tr>
                    <th>Description image 1</th>
                    <td><input type=\"text\" name=\"description-img1\" value=\"\" id=\"description-img1\"></td>
                </tr>
                <tr>
                    <th>Image 2</th>
                    <td>
                        <form id=\"myform2\" method=\"post\">
                            <input type=\"button\" id=\"loadFileXml\" value=\"Choose file\" onclick=\"document.getElementById('image2').click();\" />
                            <input id=\"image2\" style=\"display:none;\" type=\"file\" name=\"upload\" />
                        </form>
                        <p id=\"image2Error\" style=\"color: red; display: none;\"><small>Select an image </small></p>
                        <p id=\"image2-2Error\" style=\"color: red; display: none;\"><small>Choose an image with extension .jpg, .jpeg, .gif or .png</small></p>
                    </td>
                </tr>
                <tr>
                    <th>Description image 2</th>
                    <td><input type=\"text\" name=\"description-img2\" value=\"\" id=\"description-img2\"></td>
                </tr>
                <tr>
                    <th>Image 3</th>
                    <td>
                        <form id=\"myform3\" method=\"post\">
                            <input type=\"button\" id=\"loadFileXml\" value=\"Choose file\" onclick=\"document.getElementById('image3').click();\" />
                            <input id=\"image3\" style=\"display:none;\" type=\"file\" name=\"upload\" />
                        </form>
                        <p id=\"image3Error\" style=\"color: red; display: none;\"><small>Select an image </small></p>
                        <p id=\"image3-3Error\" style=\"color: red; display: none;\"><small>Choose an image with extension .jpg, .jpeg, .gif or .png</small></p>
                    </td>
                </tr>
                <tr>
                    <th>Description image 3</th>
                    <td><input type=\"text\" name=\"description-img3\" value=\"\" id=\"description-img3\"></td>
                </tr>
                <tr>
                    <th>Description</th>
                    <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\"></textarea></td>
                </tr>
                <tr>
                    <th>Organoleptic characteristics</th>
                    <td><textarea name=\"organoleptic\" rows=\"7\" cols=\"45\" id=\"organoleptic\"></textarea></td>
                </tr>
                <tr>
                    <th>Information</th>
                    <td><textarea name=\"information\" rows=\"7\" cols=\"45\" id=\"information\"></textarea></td>
                </tr>
                <tr>
                    <th>Latitude</th>
                    <td><input type=\"text\" name=\"latitude\" value=\"\" id=\"latitude\"></td>
                </tr>
                <tr>
                    <th>Longitude</th>
                    <td><input type=\"text\" name=\"longitude\" value=\"\" id=\"longitude\"></td>
                </tr>
                <tr>
                    <th>Zoom</th>
                    <td>
                        <input type=\"text\" name=\"zoom\" value=\"\" id=\"zoom\">
                        <p id=\"zoomError\" style=\"color: red; display: none;\"><small>The zoom can't be longer than two digits</small></p>
                    </td>
                </tr>
                <tr>
                    <td class=\"text-center\" colspan=\"2\">
                        <a class='btn btn-success btn-xs btn-insert'><span class=\"glyphicon glyphicon-save\"></span> Save</a>
                        <a href=\"";
        // line 94
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_homepage");
        echo "\" class=\"btn btn-warning btn-xs\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancel</a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- The Modal -->
    <div id=\"myModal\" class=\"modal\">
        <!-- Modal content -->
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <span class=\"close\">&times;</span>
                <div id=\"modal-header\">
                    <h3>Error</h3>
                </div>
            </div>
            <div class=\"modal-body\" id=\"modal-body\">
                <span class='glyphicon glyphicon-remove-sign modal-icon'></span>
                <p class='modal-p'>Some fields are missing or blank</p>
            </div>
        </div>
    </div>
";
    }

    // line 120
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 121
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 122
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 123
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/styles.css"), "html", null, true);
        echo "\">
";
    }

    // line 126
    public function block_javascripts($context, array $blocks = array())
    {
        // line 127
        echo "    <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 128
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/js/regions.js"), "html", null, true);
        echo "\"></script>
";
    }

    public function getTemplateName()
    {
        return "@Region/Default/insert.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  183 => 128,  178 => 127,  175 => 126,  169 => 123,  165 => 122,  160 => 121,  157 => 120,  129 => 94,  40 => 7,  37 => 6,  31 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Region/Default/insert.html.twig", "C:\\xampp\\htdocs\\src\\RegionBundle\\Resources\\views\\Default\\insert.html.twig");
    }
}
