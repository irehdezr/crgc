<?php

/* @Farm/Default/insert.html.twig */
class __TwigTemplate_2f5c15b2c5408b8253fac48cfc459b8d400a08bcd3415535710002d3952f2e67 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "@Farm/Default/insert.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'navbar' => array($this, 'block_navbar'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Farm Maintenance";
    }

    // line 6
    public function block_navbar($context, array $blocks = array())
    {
        echo "Farm Maintenance - Add";
    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        // line 9
        echo "    <div class=\"row col-md-8 col-md-offset-2 custyle\" style=\"margin-top: 20px\">
        <table class=\"table table-striped custab\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"2\">ADD FARM</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <th>Name</th>
                <td><input type=\"text\" name=\"name\" value=\"\" id=\"name\"></td>
            </tr>
            <tr>
                <th>Description</th>
                <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\"></textarea></td>
            </tr>
            <tr>
                <th>Image</th>
                <td>
                    <form id=\"myform1\" method=\"post\" style=\"margin-top: 5px;\">
                        <input type=\"button\" id=\"loadFileXml\" value=\"Choose file\" onclick=\"document.getElementById('image').click();\" />
                        <input id=\"image\" style=\"display:none;\" type=\"file\" name=\"upload\" />
                    </form>
                </td>
            </tr>
            <tr>
                <th>Region Name</th>
                <td>
                    <select name=\"region\" id=\"region\">
                        <option value=\"0\" selected></option>
                        ";
        // line 39
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["regions"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["reg"]) {
            // line 40
            echo "                            <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["reg"], "id", array(), "method"), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["reg"], "name", array(), "method"), "html", null, true);
            echo "</option>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['reg'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 42
        echo "                    </select>
                    <p id=\"regionError\" style=\"color: red; display: none;\"><small>Choose an option</small></p>
                </td>
            </tr>
            <tr>
                <th>Elevation</th>
                <td>
                    <p name=\"elevation\" id=\"elevation\">min-max</p>
                    <label>Min:</label>
                    <select name=\"elevation-Min\" id=\"elevation-Min\">
                        <option value=\"0\" selected></option>
                        ";
        // line 53
        $context["ele"] = 500;
        // line 54
        echo "                        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(1, 16));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 55
            echo "                            <option value=\"";
            echo twig_escape_filter($this->env, ($context["ele"] ?? null), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, ($context["ele"] ?? null), "html", null, true);
            echo "</option>
                            ";
            // line 56
            $context["ele"] = (($context["ele"] ?? null) + 100);
            // line 57
            echo "                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 58
        echo "                    </select>
                    <label>Max:</label>
                    <select name=\"elevation-Max\" id=\"elevation-Max\">
                        <option value=\"0\" selected></option>
                        ";
        // line 62
        $context["ele"] = 2000;
        // line 63
        echo "                        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(1, 16));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 64
            echo "                            <option value=\"";
            echo twig_escape_filter($this->env, ($context["ele"] ?? null), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, ($context["ele"] ?? null), "html", null, true);
            echo "</option>
                            ";
            // line 65
            $context["ele"] = (($context["ele"] ?? null) - 100);
            // line 66
            echo "                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 67
        echo "                    </select>
                    <p id=\"elevationError\" style=\"color: red; display: none;\"><small>Choose a minimum or maximum value</small></p>
                    <p id=\"elevationError-min\" style=\"color: red; display: none;\"><small>The minimum value can't be greater than or equal to the maximum value</small></p>
                    <p id=\"elevationError-max\" style=\"color: red; display: none;\"><small>The maximum value can't be less than or equal to the minimum value</small></p>
                </td>
            </tr>
            <tr>
                <th>Harvest</th>
                <td>
                    <p name=\"harvest\" id=\"harvest\">begin-end</p>
                    <label>Begin:</label>
                    <select name=\"harvest-begin\" id=\"harvest-begin\">
                        <option value=\"0\" selected></option>
                        <option value=\"January\">January</option>
                        <option value=\"February\">February</option>
                        <option value=\"March\">March</option>
                        <option value=\"April\">April</option>
                        <option value=\"May\">May</option>
                        <option value=\"June\">June</option>
                        <option value=\"July\">July</option>
                        <option value=\"August\">August</option>
                        <option value=\"September\">September</option>
                        <option value=\"October\">October</option>
                        <option value=\"November\">November</option>
                        <option value=\"December\">December </option>
                    </select>
                    <label>End:</label>
                    <select name=\"harvest-end\" id=\"harvest-end\">
                        <option value=\"0\" selected></option>
                        <option value=\"December\">December </option>
                        <option value=\"November\">November</option>
                        <option value=\"October\">October</option>
                        <option value=\"September\">September</option>
                        <option value=\"August\">August</option>
                        <option value=\"July\">July</option>
                        <option value=\"June\">June</option>
                        <option value=\"May\">May</option>
                        <option value=\"April\">April</option>
                        <option value=\"March\">March</option>
                        <option value=\"February\">February</option>
                        <option value=\"January\">January</option>
                    </select>
                    <p id=\"harvestError\" style=\"color: red; display: none;\"><small>Choose a begin or end value</small></p>
                    <p id=\"harvestError-begin\" style=\"color: red; display: none;\"><small>The begin month can't be equal to the end month</small></p>
                    <p id=\"harvestError-end\" style=\"color: red; display: none;\"><small>The end month can't be equal to the begin month</small></p>
                </td>
            </tr>
            <tr>
                <th>Cultivar</th>
                <td>
                    <form>
                        ";
        // line 118
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["cultivars"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["culti"]) {
            // line 119
            echo "                            ";
            if (($this->getAttribute($context["culti"], "getId", array(), "method") != 1)) {
                // line 120
                echo "                                <input type=\"checkbox\" name=\"cultivars\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getId", array(), "method"), "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getDescription", array(), "method"), "html", null, true);
                echo "</br>
                            ";
            }
            // line 122
            echo "                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['culti'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 123
        echo "                    </form>
                    <p id=\"cultivarError\" style=\"color: red; display: none;\"><small>Choose an option</small></p>
                </td>
            </tr>
            <tr>
                <th>Certifications</th>
                <td>
                    <form>
                        ";
        // line 131
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["certifications"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["certi"]) {
            // line 132
            echo "                            ";
            if (($this->getAttribute($context["certi"], "getId", array(), "method") != 1)) {
                // line 133
                echo "                                <input type=\"checkbox\" name=\"certifications\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["certi"], "getId", array(), "method"), "html", null, true);
                echo "\"> ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["certi"], "getDescription", array(), "method"), "html", null, true);
                echo "</br>
                            ";
            }
            // line 135
            echo "                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['certi'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 136
        echo "                    </form>
                    <p id=\"certificationError\" style=\"color: red; display: none;\"><small>Choose an option</small></p>
                </td>
            </tr>
            <tr>
                <th>Awards</th>
                <td>
                    <table class=\"table table-striped custab\" id=\"table-awards\">
                        <thead>
                        <th></th>
                        <th>Place</th>
                        <th>Year</th>
                        <th></th>
                        </thead>
                        <tbody id=\"tbody-awards\"></tbody>
                        <tfoot>
                        <tr>
                            <td class=\"award-description-add\" id=\"2\">Cup of Excellence</td>
                            <td><input type=\"number\" name=\"place\" value=\"1\" id=\"place\" min=\"1\"></td>
                            <td>
                                <select name=\"year\" id=\"year\">
                                    ";
        // line 157
        $context["year"] = twig_date_format_filter($this->env, "now", "Y");
        // line 158
        echo "                                    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(range(2007, ($context["year"] ?? null)));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 159
            echo "                                        ";
            if (($context["i"] != 2010)) {
                // line 160
                echo "                                            <option value=\"";
                echo twig_escape_filter($this->env, $context["i"], "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $context["i"], "html", null, true);
                echo "</option>
                                        ";
            }
            // line 162
            echo "                                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 163
        echo "                                </select>
                            </td>
                            <td><a class=\"btn btn-xs btn-insert-award\" style=\"margin: 0px;\"><span class=\"glyphicon glyphicon-plus\"></span></a></td>
                        </tr>
                        </tfoot>
                    </table>
                </td>
            </tr>
            <tr>
                <th>Latitude</th>
                <td><input type=\"text\" name=\"latitude\" value=\"\" id=\"latitude\"></td>
            </tr>
            <tr>
                <th>Longitude</th>
                <td><input type=\"text\" name=\"longitude\" value=\"\" id=\"longitude\"><p><small>*Don't forget to include the minus (-) symbol</small></p></td>
            </tr>
            <tr>
                <td class=\"text-center\" colspan=\"2\">
                    <a class='btn btn-success btn-xs btn-insert' style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-save\"></span> Save</a>
                    <a href=\"";
        // line 182
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_homepage");
        echo "\" class=\"btn btn-warning btn-xs\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancel</a>
                </td>
            </tr>
            </tbody>
        </table>
    </div>

    <!-- The Modal -->
    <div id=\"myModal\" class=\"modal\">
        <!-- Modal content -->
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <span class=\"close\">&times;</span>
                <div id=\"modal-header\">
                    <h3>Error</h3>
                </div>
            </div>
            <div class=\"modal-body\" id=\"modal-body\">
                <span class='glyphicon glyphicon-remove-sign modal-icon'></span>
                <p class='modal-p'>Some fields are missing or blank</p>
            </div>
        </div>
    </div>
";
    }

    // line 208
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 209
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 210
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/styles.css"), "html", null, true);
        echo "\">
";
    }

    // line 213
    public function block_javascripts($context, array $blocks = array())
    {
        // line 214
        echo "    <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 215
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/js/farm.js"), "html", null, true);
        echo "\"></script>
";
    }

    public function getTemplateName()
    {
        return "@Farm/Default/insert.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  380 => 215,  375 => 214,  372 => 213,  366 => 210,  361 => 209,  358 => 208,  330 => 182,  309 => 163,  303 => 162,  295 => 160,  292 => 159,  287 => 158,  285 => 157,  262 => 136,  256 => 135,  248 => 133,  245 => 132,  241 => 131,  231 => 123,  225 => 122,  217 => 120,  214 => 119,  210 => 118,  157 => 67,  151 => 66,  149 => 65,  142 => 64,  137 => 63,  135 => 62,  129 => 58,  123 => 57,  121 => 56,  114 => 55,  109 => 54,  107 => 53,  94 => 42,  83 => 40,  79 => 39,  47 => 9,  44 => 8,  38 => 6,  32 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Farm/Default/insert.html.twig", "C:\\xampp\\htdocs\\src\\FarmBundle\\Resources\\views\\Default\\insert.html.twig");
    }
}
