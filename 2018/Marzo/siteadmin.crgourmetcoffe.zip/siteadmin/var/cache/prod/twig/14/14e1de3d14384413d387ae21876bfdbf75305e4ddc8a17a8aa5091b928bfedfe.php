<?php

/* AppBundle:Default:home.html.twig */
class __TwigTemplate_dd5a524ce693a69621118671bea53125799b4b24ddaf87b9d26f4d31d198a310 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "AppBundle:Default:home.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8bd28b5ff25e75917bd117a7c6d1ede3615a955bac2af9f9f5756535882ec474 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8bd28b5ff25e75917bd117a7c6d1ede3615a955bac2af9f9f5756535882ec474->enter($__internal_8bd28b5ff25e75917bd117a7c6d1ede3615a955bac2af9f9f5756535882ec474_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Default:home.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8bd28b5ff25e75917bd117a7c6d1ede3615a955bac2af9f9f5756535882ec474->leave($__internal_8bd28b5ff25e75917bd117a7c6d1ede3615a955bac2af9f9f5756535882ec474_prof);

    }

    // line 4
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_e04997017443341ba2f0b5792192bbf574d20ccf7d106c3693139b25215735b5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e04997017443341ba2f0b5792192bbf574d20ccf7d106c3693139b25215735b5->enter($__internal_e04997017443341ba2f0b5792192bbf574d20ccf7d106c3693139b25215735b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 5
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
";
        
        $__internal_e04997017443341ba2f0b5792192bbf574d20ccf7d106c3693139b25215735b5->leave($__internal_e04997017443341ba2f0b5792192bbf574d20ccf7d106c3693139b25215735b5_prof);

    }

    // line 8
    public function block_title($context, array $blocks = array())
    {
        $__internal_5a0826e62d8300f63cd5ef617da164b42b04be59adb20ac2dba743df8864fc7a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5a0826e62d8300f63cd5ef617da164b42b04be59adb20ac2dba743df8864fc7a->enter($__internal_5a0826e62d8300f63cd5ef617da164b42b04be59adb20ac2dba743df8864fc7a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 9
        echo "    Principal
";
        
        $__internal_5a0826e62d8300f63cd5ef617da164b42b04be59adb20ac2dba743df8864fc7a->leave($__internal_5a0826e62d8300f63cd5ef617da164b42b04be59adb20ac2dba743df8864fc7a_prof);

    }

    // line 12
    public function block_body($context, array $blocks = array())
    {
        $__internal_2f36058fd52668228f2635f92acaac8cc86a7b31c916fbe309c36002f8120013 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2f36058fd52668228f2635f92acaac8cc86a7b31c916fbe309c36002f8120013->enter($__internal_2f36058fd52668228f2635f92acaac8cc86a7b31c916fbe309c36002f8120013_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 13
        echo "    <div class=\"row col-md-9 col-md-offset-1 custyle\">
        <table class=\"table table-striped custab\" style=\"margin-top: 20px;\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"2\">MANTENIMIENTO</th>
            </tr>
            <tr>
                <th>Título</th>
                <th class=\"text-center\">Acción</th>
            </tr>
            </thead>
            <tr>
                <td>Regiones</td>
                <td class=\"text-center\">
                    <a class='btn btn-primary btn-xs' href=\"";
        // line 27
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_homepage");
        echo "\">
                        <span class=\"glyphicon glyphicon-ok\"></span> Seleccionar</a>
                </td>
            </tr>
            <tr>
                <td>Fincas</td>
                <td class=\"text-center\">
                    <a class='btn btn-primary btn-xs' href=\"";
        // line 34
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_homepage");
        echo "\">
                        <span class=\"glyphicon glyphicon-ok\"></span> Seleccionar</a>
                </td>
            </tr>
            ";
        // line 45
        echo "        </table>
    </div>
";
        
        $__internal_2f36058fd52668228f2635f92acaac8cc86a7b31c916fbe309c36002f8120013->leave($__internal_2f36058fd52668228f2635f92acaac8cc86a7b31c916fbe309c36002f8120013_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Default:home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  105 => 45,  98 => 34,  88 => 27,  72 => 13,  66 => 12,  58 => 9,  52 => 8,  42 => 5,  36 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block stylesheets %}
    {{parent()}}
{% endblock %}

{% block title %}
    Principal
{% endblock %}

{% block body %}
    <div class=\"row col-md-9 col-md-offset-1 custyle\">
        <table class=\"table table-striped custab\" style=\"margin-top: 20px;\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"2\">MANTENIMIENTO</th>
            </tr>
            <tr>
                <th>Título</th>
                <th class=\"text-center\">Acción</th>
            </tr>
            </thead>
            <tr>
                <td>Regiones</td>
                <td class=\"text-center\">
                    <a class='btn btn-primary btn-xs' href=\"{{ path('region_homepage') }}\">
                        <span class=\"glyphicon glyphicon-ok\"></span> Seleccionar</a>
                </td>
            </tr>
            <tr>
                <td>Fincas</td>
                <td class=\"text-center\">
                    <a class='btn btn-primary btn-xs' href=\"{{ path('farm_homepage') }}\">
                        <span class=\"glyphicon glyphicon-ok\"></span> Seleccionar</a>
                </td>
            </tr>
            {# <tr>
                 <td>Products</td>
                 <td class=\"text-center\">
                     <a class='btn btn-primary btn-xs' href=\"{{ path('product_homepage') }}\">
                         <span class=\"glyphicon glyphicon-ok\"></span> Select</a>
                 </td>
             </tr>#}
        </table>
    </div>
{% endblock %}", "AppBundle:Default:home.html.twig", "C:\\xampp\\htdocs\\siteadmin\\src\\AppBundle\\Resources\\views\\Default\\home.html.twig");
    }
}
