<?php

/* FarmBundle:Default:product.html.twig */
class __TwigTemplate_20e1dedc4d1faed172eb905d8f238322292e6a281e49dca54432903d8f325e91 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "FarmBundle:Default:product.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_16c4f3ba53012d1f2dcb5cecf0903f09bc7cc59cb2e359f6ddba173d89a88561 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_16c4f3ba53012d1f2dcb5cecf0903f09bc7cc59cb2e359f6ddba173d89a88561->enter($__internal_16c4f3ba53012d1f2dcb5cecf0903f09bc7cc59cb2e359f6ddba173d89a88561_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FarmBundle:Default:product.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_16c4f3ba53012d1f2dcb5cecf0903f09bc7cc59cb2e359f6ddba173d89a88561->leave($__internal_16c4f3ba53012d1f2dcb5cecf0903f09bc7cc59cb2e359f6ddba173d89a88561_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_1c381ddf93460210d56b6f501aceab65984d46152562f72e6741874103d071cf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1c381ddf93460210d56b6f501aceab65984d46152562f72e6741874103d071cf->enter($__internal_1c381ddf93460210d56b6f501aceab65984d46152562f72e6741874103d071cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Mantenimiento de los productos de la finca";
        
        $__internal_1c381ddf93460210d56b6f501aceab65984d46152562f72e6741874103d071cf->leave($__internal_1c381ddf93460210d56b6f501aceab65984d46152562f72e6741874103d071cf_prof);

    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        $__internal_582fdab747a4aaa0012bb92b8b5d8e5d3fe8f46ca339fd2060611baa8027d692 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_582fdab747a4aaa0012bb92b8b5d8e5d3fe8f46ca339fd2060611baa8027d692->enter($__internal_582fdab747a4aaa0012bb92b8b5d8e5d3fe8f46ca339fd2060611baa8027d692_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "    <div class=\"row col-md-9 col-md-offset-1 custyle\">
        <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_product_add", array("id" => ($context["farm_id"] ?? $this->getContext($context, "farm_id")))), "html", null, true);
        echo "\" class=\"btn btn-primary btn-xs pull-right\"><span class=\"glyphicon glyphicon-plus\"></span> Agregar</a>
        <a href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_edit_view", array("id" => ($context["farm_id"] ?? $this->getContext($context, "farm_id")))), "html", null, true);
        echo "\" class=\"btn btn-warning btn-xs pull-right\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancelar</a>
        <table class=\"table table-striped custab\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"5\">PRODUCTOS DE LA FINCA</th>
            </tr>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Imagen</th>
                <th>Información</th>
                <th class=\"text-center\">Acción</th>
            </tr>
            </thead>
            <tbody>
            ";
        // line 24
        if ((($context["empty"] ?? $this->getContext($context, "empty")) == "true")) {
            // line 25
            echo "                <tr>
                    <th class=\"text-center\" colspan=\"5\">Esta finca no tiene productos</th>
                </tr>
            ";
        } else {
            // line 29
            echo "                ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["products"] ?? $this->getContext($context, "products")));
            foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
                // line 30
                echo "                    <tr>
                        <td> ";
                // line 31
                echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
                echo "</td>
                        <td> ";
                // line 32
                echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
                echo " </td>
                        <td> <img src=\"";
                // line 33
                echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage", array(), "method"), "html", null, true);
                echo "\" class=\"mediana\"></td>
                        <td>
                            <label style=\"padding-right: 3px;\">Cultivar: </label>";
                // line 35
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["temp"], "getCultivar", array(), "method"), "getDescription", array(), "method"), "html", null, true);
                echo " <br>
                            <label style=\"padding-right: 3px;\">Grado: </label>";
                // line 36
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["temp"], "getGrade", array(), "method"), "getDescription", array(), "method"), "html", null, true);
                echo " <br>
                            <label style=\"padding-right: 3px;\">Tratamiento: </label>";
                // line 37
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["temp"], "getProcessing", array(), "method"), "getDescription", array(), "method"), "html", null, true);
                echo " <br>
                            <label style=\"padding-right: 3px;\">Notas sobre el sabor: </label>";
                // line 38
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["temp"], "getFlavor", array(), "method"), "getNotes", array(), "method"), "html", null, true);
                echo " <br>
                        </td>
                        <td class=\"text-center\">
                            <a href=\"";
                // line 41
                echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_product_edit", array("id" => $this->getAttribute($context["temp"], "getId", array(), "method"))), "html", null, true);
                echo "\" class='btn btn-info btn-xs' style=\"margin-top: 10px\" id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
                echo "\"><span class=\"glyphicon glyphicon-edit\"></span> Editar</a>
                            <a class=\"btn btn-danger btn-xs btn-delete\" id=\"";
                // line 42
                echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
                echo "\" name=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
                echo "\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-remove\"></span> Eliminar</a>
                        </td>
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 46
            echo "            ";
        }
        // line 47
        echo "            </tbody>
        </table>
    </div>

    <!-- The Modal Delete Confirmation -->
    <div id=\"deleteConfirmation\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
            <!-- Modal content -->
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h3>Eliminar Productos</h3>
                </div>
                <div class=\"modal-body\" id=\"modal-body\">
                    <form>
                        <div class=\"form-group row div-body\" id=\"div-body\">
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_582fdab747a4aaa0012bb92b8b5d8e5d3fe8f46ca339fd2060611baa8027d692->leave($__internal_582fdab747a4aaa0012bb92b8b5d8e5d3fe8f46ca339fd2060611baa8027d692_prof);

    }

    // line 73
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_b285c39f0126300c51597fc199ea4ac4ccf8169ea20fcf25504fa2e89270f726 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b285c39f0126300c51597fc199ea4ac4ccf8169ea20fcf25504fa2e89270f726->enter($__internal_b285c39f0126300c51597fc199ea4ac4ccf8169ea20fcf25504fa2e89270f726_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 74
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 75
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 76
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/css/styles.css"), "html", null, true);
        echo "\">
";
        
        $__internal_b285c39f0126300c51597fc199ea4ac4ccf8169ea20fcf25504fa2e89270f726->leave($__internal_b285c39f0126300c51597fc199ea4ac4ccf8169ea20fcf25504fa2e89270f726_prof);

    }

    // line 79
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_bd22dda3183c57d98f120169f517af1969504ffc8d3318457863d0a0991833e3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bd22dda3183c57d98f120169f517af1969504ffc8d3318457863d0a0991833e3->enter($__internal_bd22dda3183c57d98f120169f517af1969504ffc8d3318457863d0a0991833e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 80
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script type=\"text/javascript\" src=\"";
        // line 81
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/js/products.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_bd22dda3183c57d98f120169f517af1969504ffc8d3318457863d0a0991833e3->leave($__internal_bd22dda3183c57d98f120169f517af1969504ffc8d3318457863d0a0991833e3_prof);

    }

    public function getTemplateName()
    {
        return "FarmBundle:Default:product.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  213 => 81,  208 => 80,  202 => 79,  193 => 76,  189 => 75,  184 => 74,  178 => 73,  148 => 47,  145 => 46,  133 => 42,  127 => 41,  121 => 38,  117 => 37,  113 => 36,  109 => 35,  104 => 33,  100 => 32,  96 => 31,  93 => 30,  88 => 29,  82 => 25,  80 => 24,  62 => 9,  58 => 8,  55 => 7,  49 => 6,  37 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Mantenimiento de los productos de la finca{% endblock %}

{% block body %}
    <div class=\"row col-md-9 col-md-offset-1 custyle\">
        <a href=\"{{ path('farm_product_add', {'id': farm_id}) }}\" class=\"btn btn-primary btn-xs pull-right\"><span class=\"glyphicon glyphicon-plus\"></span> Agregar</a>
        <a href=\"{{ path('farm_edit_view', {'id': farm_id}) }}\" class=\"btn btn-warning btn-xs pull-right\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancelar</a>
        <table class=\"table table-striped custab\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"5\">PRODUCTOS DE LA FINCA</th>
            </tr>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Imagen</th>
                <th>Información</th>
                <th class=\"text-center\">Acción</th>
            </tr>
            </thead>
            <tbody>
            {% if  empty == 'true' %}
                <tr>
                    <th class=\"text-center\" colspan=\"5\">Esta finca no tiene productos</th>
                </tr>
            {% else %}
                {% for temp in products %}
                    <tr>
                        <td> {{ temp.getId() }}</td>
                        <td> {{ temp.getName() }} </td>
                        <td> <img src=\"{{ temp.getImage() }}\" class=\"mediana\"></td>
                        <td>
                            <label style=\"padding-right: 3px;\">Cultivar: </label>{{ temp.getCultivar().getDescription() }} <br>
                            <label style=\"padding-right: 3px;\">Grado: </label>{{ temp.getGrade().getDescription() }} <br>
                            <label style=\"padding-right: 3px;\">Tratamiento: </label>{{ temp.getProcessing().getDescription() }} <br>
                            <label style=\"padding-right: 3px;\">Notas sobre el sabor: </label>{{ temp.getFlavor().getNotes() }} <br>
                        </td>
                        <td class=\"text-center\">
                            <a href=\"{{ path('farm_product_edit',{'id': temp.getId()}) }}\" class='btn btn-info btn-xs' style=\"margin-top: 10px\" id=\"{{ temp.getId() }}\"><span class=\"glyphicon glyphicon-edit\"></span> Editar</a>
                            <a class=\"btn btn-danger btn-xs btn-delete\" id=\"{{ temp.getId() }}\" name=\"{{ temp.getName() }}\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-remove\"></span> Eliminar</a>
                        </td>
                    </tr>
                {% endfor %}
            {% endif %}
            </tbody>
        </table>
    </div>

    <!-- The Modal Delete Confirmation -->
    <div id=\"deleteConfirmation\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
            <!-- Modal content -->
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h3>Eliminar Productos</h3>
                </div>
                <div class=\"modal-body\" id=\"modal-body\">
                    <form>
                        <div class=\"form-group row div-body\" id=\"div-body\">
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                </div>
            </div>
        </div>
    </div>
{% endblock %}


{% block stylesheets %}
    {{ parent() }}
    <link rel=\"stylesheet\" href=\"{{ asset('/siteadmin/web/css/crgourmetcoffee.css') }}\">
    <link rel=\"stylesheet\" href=\"{{ asset('/siteadmin/web/css/styles.css') }}\">
{% endblock %}

{% block javascripts %}
    {{ parent() }}
    <script type=\"text/javascript\" src=\"{{ asset('/siteadmin/web/js/products.js') }}\"></script>
{% endblock %}", "FarmBundle:Default:product.html.twig", "/Applications/MAMP/htdocs/siteadmin/src/FarmBundle/Resources/views/Default/product.html.twig");
    }
}
