<?php

/* FarmBundle:Default:farm.html.twig */
class __TwigTemplate_7b008fa2a0b0b3f8bcf429d221c6fb08c4a13ee8a1d9804e8ffe1c567951c3fd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "FarmBundle:Default:farm.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'navbar' => array($this, 'block_navbar'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_22598aad8605e2003465a862f1f1d8f1fef94170ef84695c65bbeb131717b77d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_22598aad8605e2003465a862f1f1d8f1fef94170ef84695c65bbeb131717b77d->enter($__internal_22598aad8605e2003465a862f1f1d8f1fef94170ef84695c65bbeb131717b77d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FarmBundle:Default:farm.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_22598aad8605e2003465a862f1f1d8f1fef94170ef84695c65bbeb131717b77d->leave($__internal_22598aad8605e2003465a862f1f1d8f1fef94170ef84695c65bbeb131717b77d_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_9fca63f965e46b17863ca2ac5a7328adc6a53814f424f7609e3a579d0c17037c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9fca63f965e46b17863ca2ac5a7328adc6a53814f424f7609e3a579d0c17037c->enter($__internal_9fca63f965e46b17863ca2ac5a7328adc6a53814f424f7609e3a579d0c17037c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Mantenimiento de fincas";
        
        $__internal_9fca63f965e46b17863ca2ac5a7328adc6a53814f424f7609e3a579d0c17037c->leave($__internal_9fca63f965e46b17863ca2ac5a7328adc6a53814f424f7609e3a579d0c17037c_prof);

    }

    // line 6
    public function block_navbar($context, array $blocks = array())
    {
        $__internal_b28e16fc2c69473da6485ab59811ef92e785862a72c679b680e76b521ff5af21 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b28e16fc2c69473da6485ab59811ef92e785862a72c679b680e76b521ff5af21->enter($__internal_b28e16fc2c69473da6485ab59811ef92e785862a72c679b680e76b521ff5af21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        echo "Mantenimiento de fincas";
        
        $__internal_b28e16fc2c69473da6485ab59811ef92e785862a72c679b680e76b521ff5af21->leave($__internal_b28e16fc2c69473da6485ab59811ef92e785862a72c679b680e76b521ff5af21_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_0857f353abf62b7c7a55e24ed1130b618482eaad1467891bfe860cc7f54e9e4a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0857f353abf62b7c7a55e24ed1130b618482eaad1467891bfe860cc7f54e9e4a->enter($__internal_0857f353abf62b7c7a55e24ed1130b618482eaad1467891bfe860cc7f54e9e4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo "    <div class=\"row col-md-20 col-md-offset-0 custyle\">
        <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_add");
        echo "\" class=\"btn btn-primary btn-xs pull-right\"><span class=\"glyphicon glyphicon-plus\"></span> Agregar</a>
        <table class=\"table table-striped custab\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"5\">FINCAS</th>
            </tr>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Imagen</th>
                <th class=\"text-center\">Acción</th>
            </tr>
            </thead>
            <tbody>
            ";
        // line 25
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["farms"] ?? $this->getContext($context, "farms")));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 26
            echo "                <tr>
                    <td> ";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "</td>
                    <td> ";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo " </td>
                    <td class=\"text-area\" style=\"text-align: justify\">";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getDescription", array(), "method"), "html", null, true);
            echo " </td>
                    <td> <img src=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage", array(), "method"), "html", null, true);
            echo "\" class=\"mediana\"></td>
                    <td class=\"text-center\">
                        <a class='btn btn-info btn-xs btn-edit' style=\"margin-top: 10px\" id=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-edit\"></span> Editar</a>
                        <a id=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\" name=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo "\" class=\"btn btn-danger btn-xs btn-delete\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-remove\"></span> Eliminar</a>
                    </td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 37
        echo "            </tbody>
        </table>
    </div>

    <!-- The Modal Delete Confirmation -->
    <div id=\"deleteConfirmation\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
            <!-- Modal content -->
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h3>Eliminar Fincas</h3>
                </div>
                <div class=\"modal-body\" id=\"modal-body\">
                    <form>
                        <div class=\"form-group row div-body\" id=\"div-body\">
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_0857f353abf62b7c7a55e24ed1130b618482eaad1467891bfe860cc7f54e9e4a->leave($__internal_0857f353abf62b7c7a55e24ed1130b618482eaad1467891bfe860cc7f54e9e4a_prof);

    }

    // line 63
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_9cdcd71300cc4f74c9fef8c123cae00c7f0d852d749c17785e7e714c4bbc5b72 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9cdcd71300cc4f74c9fef8c123cae00c7f0d852d749c17785e7e714c4bbc5b72->enter($__internal_9cdcd71300cc4f74c9fef8c123cae00c7f0d852d749c17785e7e714c4bbc5b72_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 64
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 65
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 66
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/css/styles.css"), "html", null, true);
        echo "\">
";
        
        $__internal_9cdcd71300cc4f74c9fef8c123cae00c7f0d852d749c17785e7e714c4bbc5b72->leave($__internal_9cdcd71300cc4f74c9fef8c123cae00c7f0d852d749c17785e7e714c4bbc5b72_prof);

    }

    // line 69
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_8bc14190526c458292a410d1c28fb968ba45e4b8ffc4925d346e6d511730920a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8bc14190526c458292a410d1c28fb968ba45e4b8ffc4925d346e6d511730920a->enter($__internal_8bc14190526c458292a410d1c28fb968ba45e4b8ffc4925d346e6d511730920a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 70
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script type=\"text/javascript\" src=\"";
        // line 71
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/js/farm.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_8bc14190526c458292a410d1c28fb968ba45e4b8ffc4925d346e6d511730920a->leave($__internal_8bc14190526c458292a410d1c28fb968ba45e4b8ffc4925d346e6d511730920a_prof);

    }

    public function getTemplateName()
    {
        return "FarmBundle:Default:farm.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  194 => 71,  189 => 70,  183 => 69,  174 => 66,  170 => 65,  165 => 64,  159 => 63,  129 => 37,  117 => 33,  113 => 32,  108 => 30,  104 => 29,  100 => 28,  96 => 27,  93 => 26,  89 => 25,  71 => 10,  68 => 9,  62 => 8,  50 => 6,  38 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Mantenimiento de fincas{% endblock %}

{% block navbar %}Mantenimiento de fincas{% endblock %}

{% block body %}
    <div class=\"row col-md-20 col-md-offset-0 custyle\">
        <a href=\"{{ path('farm_add') }}\" class=\"btn btn-primary btn-xs pull-right\"><span class=\"glyphicon glyphicon-plus\"></span> Agregar</a>
        <table class=\"table table-striped custab\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"5\">FINCAS</th>
            </tr>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Imagen</th>
                <th class=\"text-center\">Acción</th>
            </tr>
            </thead>
            <tbody>
            {% for temp in farms %}
                <tr>
                    <td> {{ temp.getId() }}</td>
                    <td> {{ temp.getName() }} </td>
                    <td class=\"text-area\" style=\"text-align: justify\">{{ temp.getDescription() }} </td>
                    <td> <img src=\"{{ temp.getImage() }}\" class=\"mediana\"></td>
                    <td class=\"text-center\">
                        <a class='btn btn-info btn-xs btn-edit' style=\"margin-top: 10px\" id=\"{{ temp.getId() }}\"><span class=\"glyphicon glyphicon-edit\"></span> Editar</a>
                        <a id=\"{{ temp.getId() }}\" name=\"{{ temp.getName() }}\" class=\"btn btn-danger btn-xs btn-delete\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-remove\"></span> Eliminar</a>
                    </td>
                </tr>
            {% endfor %}
            </tbody>
        </table>
    </div>

    <!-- The Modal Delete Confirmation -->
    <div id=\"deleteConfirmation\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
            <!-- Modal content -->
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h3>Eliminar Fincas</h3>
                </div>
                <div class=\"modal-body\" id=\"modal-body\">
                    <form>
                        <div class=\"form-group row div-body\" id=\"div-body\">
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                </div>
            </div>
        </div>
    </div>
{% endblock %}


{% block stylesheets %}
    {{ parent() }}
    <link rel=\"stylesheet\" href=\"{{ asset('/siteadmin/web/css/crgourmetcoffee.css') }}\">
    <link rel=\"stylesheet\" href=\"{{ asset('/siteadmin/web/css/styles.css') }}\">
{% endblock %}

{% block javascripts %}
    {{ parent() }}
    <script type=\"text/javascript\" src=\"{{ asset('/siteadmin/web/js/farm.js') }}\"></script>
{% endblock %}

", "FarmBundle:Default:farm.html.twig", "C:\\xampp\\htdocs\\siteadmin\\src\\FarmBundle\\Resources\\views\\Default\\farm.html.twig");
    }
}
