<?php

/* @Farm/Default/product.html.twig */
class __TwigTemplate_3fffef5c3773f133520e3c2c4b1c277be04668849c55afd394e5df73fe519956 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "@Farm/Default/product.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        echo "Farm Product Maintenance";
    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        // line 7
        echo "    <div class=\"row col-md-9 col-md-offset-1 custyle\">
        <a ";
        // line 8
        echo " class=\"btn btn-primary btn-xs pull-right\"><span class=\"glyphicon glyphicon-plus\"></span> Add</a>
        <a href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_edit_view", array("id" => ($context["farm_id"] ?? null))), "html", null, true);
        echo "\" class=\"btn btn-warning btn-xs pull-right\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancel</a>
        <table class=\"table table-striped custab\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"4\">FARM PRODUCTS</th>
            </tr>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Image</th>
                <th class=\"text-center\">Action</th>
            </tr>
            </thead>
            <tbody>
            ";
        // line 23
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["products"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 24
            echo "                <tr>
                    <td> ";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "</td>
                    <td> ";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo " </td>
                    <td> <img src=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage", array(), "method"), "html", null, true);
            echo "\" class=\"mediana\"></td>
                    <td class=\"text-center\">
                        <a href=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_product_edit", array("id" => $this->getAttribute($context["temp"], "getId", array(), "method"))), "html", null, true);
            echo "\" class='btn btn-info btn-xs' style=\"margin-top: 10px\" id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-edit\"></span> Edit</a>
                        <a ";
            // line 30
            echo " class=\"btn btn-danger btn-xs\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-remove\"></span> Delete</a>
                    </td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 34
        echo "            </tbody>
        </table>
    </div>
";
    }

    // line 40
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 41
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 42
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/styles.css"), "html", null, true);
        echo "\">
";
    }

    // line 45
    public function block_javascripts($context, array $blocks = array())
    {
        // line 46
        echo "    <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 47
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/js/products.js"), "html", null, true);
        echo "\"></script>
";
    }

    public function getTemplateName()
    {
        return "@Farm/Default/product.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  127 => 47,  122 => 46,  119 => 45,  113 => 42,  108 => 41,  105 => 40,  98 => 34,  89 => 30,  83 => 29,  78 => 27,  74 => 26,  70 => 25,  67 => 24,  63 => 23,  46 => 9,  43 => 8,  40 => 7,  37 => 6,  31 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Farm/Default/product.html.twig", "C:\\xampp\\htdocs\\src\\FarmBundle\\Resources\\views\\Default\\product.html.twig");
    }
}
