<?php

// ProductBundle:Default:product.html.twig
return array (
);
