<?php

// FarmBundle:Default:product.html.twig
return array (
);
