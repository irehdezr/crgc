<?php

// RegionBundle:Default:region.html.twig
return array (
);
