<?php

// TwigBundle:Exception:traces_text.html.twig
return array (
);
