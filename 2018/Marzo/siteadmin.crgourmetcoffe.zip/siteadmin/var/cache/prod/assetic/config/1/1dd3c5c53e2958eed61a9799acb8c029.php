<?php

// FarmBundle:Default:insertProduct.html.twig
return array (
);
