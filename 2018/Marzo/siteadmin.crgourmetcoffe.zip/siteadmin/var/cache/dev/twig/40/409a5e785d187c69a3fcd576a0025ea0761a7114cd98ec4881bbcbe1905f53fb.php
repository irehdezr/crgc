<?php

/* layout.html.twig */
class __TwigTemplate_5ea361a92e9276e54e1845c19692cb812827945c6d1e574669b7c969e3ff33f8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ca5779efe664a2f011ac31f5a0eb9509d77e86b5ab38ede636e237735faa9984 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ca5779efe664a2f011ac31f5a0eb9509d77e86b5ab38ede636e237735faa9984->enter($__internal_ca5779efe664a2f011ac31f5a0eb9509d77e86b5ab38ede636e237735faa9984_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"es\">
    <head>
        <meta charset=\"UTF-8\"/>
        <title>
            ";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        // line 9
        echo "        </title>
        <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css\"
              integrity=\"sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7\" crossorigin=\"anonymous\">
        ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 13
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/favicon.ico"), "html", null, true);
        echo "\"/>
    </head>
    <body>

        <div class=\"container\">
            ";
        // line 18
        $this->loadTemplate("header.html.twig", "layout.html.twig", 18)->display($context);
        // line 19
        echo "            ";
        $this->displayBlock('body', $context, $blocks);
        // line 20
        echo "        </div>

        <script type=\"text/javascript\" src=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/siteadmin/web/js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
        ";
        // line 23
        $this->displayBlock('javascripts', $context, $blocks);
        // line 24
        echo "    </body>
</html>";
        
        $__internal_ca5779efe664a2f011ac31f5a0eb9509d77e86b5ab38ede636e237735faa9984->leave($__internal_ca5779efe664a2f011ac31f5a0eb9509d77e86b5ab38ede636e237735faa9984_prof);

    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        $__internal_bda643c1133b3829e6565381142743c55e851366f2328be3612e67f6aa7a7a71 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bda643c1133b3829e6565381142743c55e851366f2328be3612e67f6aa7a7a71->enter($__internal_bda643c1133b3829e6565381142743c55e851366f2328be3612e67f6aa7a7a71_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 7
        echo "                Mantenimiento
            ";
        
        $__internal_bda643c1133b3829e6565381142743c55e851366f2328be3612e67f6aa7a7a71->leave($__internal_bda643c1133b3829e6565381142743c55e851366f2328be3612e67f6aa7a7a71_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_8daddc88ce85482ea6679a035ac4408f1e3df75a2d357702d9110212f99d7164 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8daddc88ce85482ea6679a035ac4408f1e3df75a2d357702d9110212f99d7164->enter($__internal_8daddc88ce85482ea6679a035ac4408f1e3df75a2d357702d9110212f99d7164_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_8daddc88ce85482ea6679a035ac4408f1e3df75a2d357702d9110212f99d7164->leave($__internal_8daddc88ce85482ea6679a035ac4408f1e3df75a2d357702d9110212f99d7164_prof);

    }

    // line 19
    public function block_body($context, array $blocks = array())
    {
        $__internal_19e30ca791a7cfcfc9595db9d3c977572cae261ecb99fd1acbe3339ef06830e8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_19e30ca791a7cfcfc9595db9d3c977572cae261ecb99fd1acbe3339ef06830e8->enter($__internal_19e30ca791a7cfcfc9595db9d3c977572cae261ecb99fd1acbe3339ef06830e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_19e30ca791a7cfcfc9595db9d3c977572cae261ecb99fd1acbe3339ef06830e8->leave($__internal_19e30ca791a7cfcfc9595db9d3c977572cae261ecb99fd1acbe3339ef06830e8_prof);

    }

    // line 23
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_5df120fa91b76582392f893d32fcbe08e1a772b9bf427162d609e412988944a5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5df120fa91b76582392f893d32fcbe08e1a772b9bf427162d609e412988944a5->enter($__internal_5df120fa91b76582392f893d32fcbe08e1a772b9bf427162d609e412988944a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_5df120fa91b76582392f893d32fcbe08e1a772b9bf427162d609e412988944a5->leave($__internal_5df120fa91b76582392f893d32fcbe08e1a772b9bf427162d609e412988944a5_prof);

    }

    public function getTemplateName()
    {
        return "layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  110 => 23,  99 => 19,  88 => 12,  80 => 7,  74 => 6,  66 => 24,  64 => 23,  60 => 22,  56 => 20,  53 => 19,  51 => 18,  42 => 13,  40 => 12,  35 => 9,  33 => 6,  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "layout.html.twig", "C:\\xampp\\htdocs\\siteadmin\\app\\Resources\\views\\layout.html.twig");
    }
}
