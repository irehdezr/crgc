<?php

/* header.html.twig */
class __TwigTemplate_a63231d8b331b538bf0602071096be46f5cdf53582bb105d5e6f7306f83b8e99 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8e7e27b1dcaee1efb185aafdbda8232b51c37b7a7b9c8cd89eb4048fe70dc42a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8e7e27b1dcaee1efb185aafdbda8232b51c37b7a7b9c8cd89eb4048fe70dc42a->enter($__internal_8e7e27b1dcaee1efb185aafdbda8232b51c37b7a7b9c8cd89eb4048fe70dc42a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "header.html.twig"));

        // line 1
        echo "<header class='col-xs-12'>
    <nav id='navBar' class=\"navbar navbar-inverse navbar-fixed-top\">
        <div class=\"container-fluid\">
            <div class=\"navbar-header\">
                <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#myNavbar\">
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                </button>
                <a class=\"navbar-brand\">cr<span>gourmet</span><span>coffee.com</span></a>
            </div>
            <div class=\"collapse navbar-collapse\" id=\"myNavbar\">
                <ul id='mainMenu' class=\"nav navbar-nav\">
                    <li><a href=\"";
        // line 14
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_homepage");
        echo "\">Principal</a></li>
                    <li><a href=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_homepage");
        echo "\">Regiones</a></li>
                    <li><a href=\"";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_homepage");
        echo "\">Fincas</a></li>
                    ";
        // line 27
        echo "                </ul>
            </div>
        </div>
    </nav>
</header>
<div class='clearfix'></div>";
        
        $__internal_8e7e27b1dcaee1efb185aafdbda8232b51c37b7a7b9c8cd89eb4048fe70dc42a->leave($__internal_8e7e27b1dcaee1efb185aafdbda8232b51c37b7a7b9c8cd89eb4048fe70dc42a_prof);

    }

    public function getTemplateName()
    {
        return "header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 27,  45 => 16,  41 => 15,  37 => 14,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "header.html.twig", "C:\\xampp\\htdocs\\siteadmin\\app\\Resources\\views\\header.html.twig");
    }
}
