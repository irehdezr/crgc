<?php

/* layout.html.twig */
class __TwigTemplate_5655d43fb9167f2a36ce30f206ca2359c0d834643e3b51b40a3ae80a7e835396 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'navbar' => array($this, 'block_navbar'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7d147e29aa21d1f49ad84c66e014797dac69db553cadb8995f432f7e196755b1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7d147e29aa21d1f49ad84c66e014797dac69db553cadb8995f432f7e196755b1->enter($__internal_7d147e29aa21d1f49ad84c66e014797dac69db553cadb8995f432f7e196755b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout.html.twig"));

        $__internal_1f2078ddb1ab7687d573ca50c16d1ffaa0f308b349effe606d01764dd4ad849c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1f2078ddb1ab7687d573ca50c16d1ffaa0f308b349effe606d01764dd4ad849c->enter($__internal_1f2078ddb1ab7687d573ca50c16d1ffaa0f308b349effe606d01764dd4ad849c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css\" integrity=\"sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7\" crossorigin=\"anonymous\">
        ";
        // line 7
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 8
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
    <nav class=\"navbar navbar-default navbar-fixed-top\">
        <div class=\"container\">
            <div class=\"navbar-header\">
                <a class=\"navbar-brand\" href=\"#\">";
        // line 14
        $this->displayBlock('navbar', $context, $blocks);
        echo "</a>
            </div>
        </div>
    </nav>

    <div class=\"container\">
                ";
        // line 20
        $this->displayBlock('body', $context, $blocks);
        // line 21
        echo "    </div><!-- /.container -->
    ";
        // line 22
        $this->displayBlock('javascripts', $context, $blocks);
        // line 23
        echo "    </body>
</html>
";
        
        $__internal_7d147e29aa21d1f49ad84c66e014797dac69db553cadb8995f432f7e196755b1->leave($__internal_7d147e29aa21d1f49ad84c66e014797dac69db553cadb8995f432f7e196755b1_prof);

        
        $__internal_1f2078ddb1ab7687d573ca50c16d1ffaa0f308b349effe606d01764dd4ad849c->leave($__internal_1f2078ddb1ab7687d573ca50c16d1ffaa0f308b349effe606d01764dd4ad849c_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_f9e551fedd52654b6276b66a397d4426a2fcac0c8315da14549c1809a3bff8ed = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f9e551fedd52654b6276b66a397d4426a2fcac0c8315da14549c1809a3bff8ed->enter($__internal_f9e551fedd52654b6276b66a397d4426a2fcac0c8315da14549c1809a3bff8ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_a8c024a00fcf71d60f199e12a958a99871d1f7555e89e2944c99593d21d44558 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a8c024a00fcf71d60f199e12a958a99871d1f7555e89e2944c99593d21d44558->enter($__internal_a8c024a00fcf71d60f199e12a958a99871d1f7555e89e2944c99593d21d44558_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Maintenance";
        
        $__internal_a8c024a00fcf71d60f199e12a958a99871d1f7555e89e2944c99593d21d44558->leave($__internal_a8c024a00fcf71d60f199e12a958a99871d1f7555e89e2944c99593d21d44558_prof);

        
        $__internal_f9e551fedd52654b6276b66a397d4426a2fcac0c8315da14549c1809a3bff8ed->leave($__internal_f9e551fedd52654b6276b66a397d4426a2fcac0c8315da14549c1809a3bff8ed_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_e4534dc685311e37fe5521388564b6c69e0f8b537414c24d117225627e5a466c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e4534dc685311e37fe5521388564b6c69e0f8b537414c24d117225627e5a466c->enter($__internal_e4534dc685311e37fe5521388564b6c69e0f8b537414c24d117225627e5a466c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_52672c33dac94e23fa055977fb498e835bf1506b1ee307adf6b386694d514734 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_52672c33dac94e23fa055977fb498e835bf1506b1ee307adf6b386694d514734->enter($__internal_52672c33dac94e23fa055977fb498e835bf1506b1ee307adf6b386694d514734_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_52672c33dac94e23fa055977fb498e835bf1506b1ee307adf6b386694d514734->leave($__internal_52672c33dac94e23fa055977fb498e835bf1506b1ee307adf6b386694d514734_prof);

        
        $__internal_e4534dc685311e37fe5521388564b6c69e0f8b537414c24d117225627e5a466c->leave($__internal_e4534dc685311e37fe5521388564b6c69e0f8b537414c24d117225627e5a466c_prof);

    }

    // line 14
    public function block_navbar($context, array $blocks = array())
    {
        $__internal_8cbaa99d0f07f30cdd2bfc32ae7458d3af211c782f3076edfad332720d0446b7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8cbaa99d0f07f30cdd2bfc32ae7458d3af211c782f3076edfad332720d0446b7->enter($__internal_8cbaa99d0f07f30cdd2bfc32ae7458d3af211c782f3076edfad332720d0446b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        $__internal_80aae9798e54a24029766722d2c62ca71017873e09958243b04552182a2cd597 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_80aae9798e54a24029766722d2c62ca71017873e09958243b04552182a2cd597->enter($__internal_80aae9798e54a24029766722d2c62ca71017873e09958243b04552182a2cd597_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        echo "Maintenance";
        
        $__internal_80aae9798e54a24029766722d2c62ca71017873e09958243b04552182a2cd597->leave($__internal_80aae9798e54a24029766722d2c62ca71017873e09958243b04552182a2cd597_prof);

        
        $__internal_8cbaa99d0f07f30cdd2bfc32ae7458d3af211c782f3076edfad332720d0446b7->leave($__internal_8cbaa99d0f07f30cdd2bfc32ae7458d3af211c782f3076edfad332720d0446b7_prof);

    }

    // line 20
    public function block_body($context, array $blocks = array())
    {
        $__internal_a764948e5bd01527f1c0fe2d3c277083af31617531266ed7bf7c51bd2dffde43 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a764948e5bd01527f1c0fe2d3c277083af31617531266ed7bf7c51bd2dffde43->enter($__internal_a764948e5bd01527f1c0fe2d3c277083af31617531266ed7bf7c51bd2dffde43_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_892a182ecfeb5c43cab439f9642fc59ef00e3de00caa49d8a4aecae6f473d178 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_892a182ecfeb5c43cab439f9642fc59ef00e3de00caa49d8a4aecae6f473d178->enter($__internal_892a182ecfeb5c43cab439f9642fc59ef00e3de00caa49d8a4aecae6f473d178_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_892a182ecfeb5c43cab439f9642fc59ef00e3de00caa49d8a4aecae6f473d178->leave($__internal_892a182ecfeb5c43cab439f9642fc59ef00e3de00caa49d8a4aecae6f473d178_prof);

        
        $__internal_a764948e5bd01527f1c0fe2d3c277083af31617531266ed7bf7c51bd2dffde43->leave($__internal_a764948e5bd01527f1c0fe2d3c277083af31617531266ed7bf7c51bd2dffde43_prof);

    }

    // line 22
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_d5a1810f7096bb34c23706e1651ac0a18b56525aab11d634b5b1f3b69e29ea53 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d5a1810f7096bb34c23706e1651ac0a18b56525aab11d634b5b1f3b69e29ea53->enter($__internal_d5a1810f7096bb34c23706e1651ac0a18b56525aab11d634b5b1f3b69e29ea53_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_ba110b29150d2704480f4b3c456802c4b5558cb1b90a54620ee9414be4b2f9bb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ba110b29150d2704480f4b3c456802c4b5558cb1b90a54620ee9414be4b2f9bb->enter($__internal_ba110b29150d2704480f4b3c456802c4b5558cb1b90a54620ee9414be4b2f9bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_ba110b29150d2704480f4b3c456802c4b5558cb1b90a54620ee9414be4b2f9bb->leave($__internal_ba110b29150d2704480f4b3c456802c4b5558cb1b90a54620ee9414be4b2f9bb_prof);

        
        $__internal_d5a1810f7096bb34c23706e1651ac0a18b56525aab11d634b5b1f3b69e29ea53->leave($__internal_d5a1810f7096bb34c23706e1651ac0a18b56525aab11d634b5b1f3b69e29ea53_prof);

    }

    public function getTemplateName()
    {
        return "layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  151 => 22,  134 => 20,  116 => 14,  99 => 7,  81 => 5,  69 => 23,  67 => 22,  64 => 21,  62 => 20,  53 => 14,  43 => 8,  41 => 7,  36 => 5,  30 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Maintenance{% endblock %}</title>
        <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css\" integrity=\"sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7\" crossorigin=\"anonymous\">
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
    <nav class=\"navbar navbar-default navbar-fixed-top\">
        <div class=\"container\">
            <div class=\"navbar-header\">
                <a class=\"navbar-brand\" href=\"#\">{% block navbar %}Maintenance{% endblock %}</a>
            </div>
        </div>
    </nav>

    <div class=\"container\">
                {% block body %}{% endblock %}
    </div><!-- /.container -->
    {% block javascripts %}{% endblock %}
    </body>
</html>
", "layout.html.twig", "C:\\xampp\\htdocs\\Maintenance\\app\\Resources\\views\\layout.html.twig");
    }
}
