<?php

/* base.html.twig */
class __TwigTemplate_d729328c7e90570bce8f1b31d2d88b65b7ee333fe584c0b4c35aa3c5447c14ac extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c9c45de39b0854daf080e2dee5f1ec82cbfc9d1c80ed0ed1a55bb2e0c0b1937e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c9c45de39b0854daf080e2dee5f1ec82cbfc9d1c80ed0ed1a55bb2e0c0b1937e->enter($__internal_c9c45de39b0854daf080e2dee5f1ec82cbfc9d1c80ed0ed1a55bb2e0c0b1937e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_7655af9cdb9ea2c021daad4174c435d02f776621876857955c149cb1334defe2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7655af9cdb9ea2c021daad4174c435d02f776621876857955c149cb1334defe2->enter($__internal_7655af9cdb9ea2c021daad4174c435d02f776621876857955c149cb1334defe2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_c9c45de39b0854daf080e2dee5f1ec82cbfc9d1c80ed0ed1a55bb2e0c0b1937e->leave($__internal_c9c45de39b0854daf080e2dee5f1ec82cbfc9d1c80ed0ed1a55bb2e0c0b1937e_prof);

        
        $__internal_7655af9cdb9ea2c021daad4174c435d02f776621876857955c149cb1334defe2->leave($__internal_7655af9cdb9ea2c021daad4174c435d02f776621876857955c149cb1334defe2_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_532be5b79911c19ddeb5c0d90de39ef1a91aa4694e6d891c79c12eefe0f4ab41 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_532be5b79911c19ddeb5c0d90de39ef1a91aa4694e6d891c79c12eefe0f4ab41->enter($__internal_532be5b79911c19ddeb5c0d90de39ef1a91aa4694e6d891c79c12eefe0f4ab41_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_fa56e89c68b654fcd68b863c2e6604e189fac89612892dfade43b0ce25ee2d39 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fa56e89c68b654fcd68b863c2e6604e189fac89612892dfade43b0ce25ee2d39->enter($__internal_fa56e89c68b654fcd68b863c2e6604e189fac89612892dfade43b0ce25ee2d39_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_fa56e89c68b654fcd68b863c2e6604e189fac89612892dfade43b0ce25ee2d39->leave($__internal_fa56e89c68b654fcd68b863c2e6604e189fac89612892dfade43b0ce25ee2d39_prof);

        
        $__internal_532be5b79911c19ddeb5c0d90de39ef1a91aa4694e6d891c79c12eefe0f4ab41->leave($__internal_532be5b79911c19ddeb5c0d90de39ef1a91aa4694e6d891c79c12eefe0f4ab41_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_5ed64f50303c020dfec9672108ca0cfa2371b4a3879429ac0186fb3bda3840b9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5ed64f50303c020dfec9672108ca0cfa2371b4a3879429ac0186fb3bda3840b9->enter($__internal_5ed64f50303c020dfec9672108ca0cfa2371b4a3879429ac0186fb3bda3840b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_53b3e4a4527784dd37ab2d92592caca06c872bbcadc01b6a873e623998f8905e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_53b3e4a4527784dd37ab2d92592caca06c872bbcadc01b6a873e623998f8905e->enter($__internal_53b3e4a4527784dd37ab2d92592caca06c872bbcadc01b6a873e623998f8905e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_53b3e4a4527784dd37ab2d92592caca06c872bbcadc01b6a873e623998f8905e->leave($__internal_53b3e4a4527784dd37ab2d92592caca06c872bbcadc01b6a873e623998f8905e_prof);

        
        $__internal_5ed64f50303c020dfec9672108ca0cfa2371b4a3879429ac0186fb3bda3840b9->leave($__internal_5ed64f50303c020dfec9672108ca0cfa2371b4a3879429ac0186fb3bda3840b9_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_925590feb810ef47581a97ad12482997d230229faf5e61a6806adb82ef37de78 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_925590feb810ef47581a97ad12482997d230229faf5e61a6806adb82ef37de78->enter($__internal_925590feb810ef47581a97ad12482997d230229faf5e61a6806adb82ef37de78_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_1d7361a20071b5e197c7fd6565c24a25d1a179a25406088df6eb79e67d6b24aa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1d7361a20071b5e197c7fd6565c24a25d1a179a25406088df6eb79e67d6b24aa->enter($__internal_1d7361a20071b5e197c7fd6565c24a25d1a179a25406088df6eb79e67d6b24aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_1d7361a20071b5e197c7fd6565c24a25d1a179a25406088df6eb79e67d6b24aa->leave($__internal_1d7361a20071b5e197c7fd6565c24a25d1a179a25406088df6eb79e67d6b24aa_prof);

        
        $__internal_925590feb810ef47581a97ad12482997d230229faf5e61a6806adb82ef37de78->leave($__internal_925590feb810ef47581a97ad12482997d230229faf5e61a6806adb82ef37de78_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_932e1f737d47f0d6135c9ea1a7a71f678c51801911907ce04596806aad9bc4df = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_932e1f737d47f0d6135c9ea1a7a71f678c51801911907ce04596806aad9bc4df->enter($__internal_932e1f737d47f0d6135c9ea1a7a71f678c51801911907ce04596806aad9bc4df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_dd96b90080060fc93f267f38137bcac3d22183a7fcca87813c48012380396c1f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dd96b90080060fc93f267f38137bcac3d22183a7fcca87813c48012380396c1f->enter($__internal_dd96b90080060fc93f267f38137bcac3d22183a7fcca87813c48012380396c1f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_dd96b90080060fc93f267f38137bcac3d22183a7fcca87813c48012380396c1f->leave($__internal_dd96b90080060fc93f267f38137bcac3d22183a7fcca87813c48012380396c1f_prof);

        
        $__internal_932e1f737d47f0d6135c9ea1a7a71f678c51801911907ce04596806aad9bc4df->leave($__internal_932e1f737d47f0d6135c9ea1a7a71f678c51801911907ce04596806aad9bc4df_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 11,  100 => 10,  83 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "C:\\xampp\\htdocs\\Maintenance\\app\\Resources\\views\\base.html.twig");
    }
}
