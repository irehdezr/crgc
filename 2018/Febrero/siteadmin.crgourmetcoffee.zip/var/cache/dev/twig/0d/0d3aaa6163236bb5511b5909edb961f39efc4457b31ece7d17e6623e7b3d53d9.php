<?php

/* FarmBundle:Default:insert.html.twig */
class __TwigTemplate_70cf4b9c160542e4c7a9bcbe3e08016496d076ab0b31773fa4f7c5fb46c376f0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "FarmBundle:Default:insert.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'navbar' => array($this, 'block_navbar'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b8d866811a14cf8ede4d4e14ef14febac742468a20e7c122cc58f9c03c65bb68 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b8d866811a14cf8ede4d4e14ef14febac742468a20e7c122cc58f9c03c65bb68->enter($__internal_b8d866811a14cf8ede4d4e14ef14febac742468a20e7c122cc58f9c03c65bb68_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FarmBundle:Default:insert.html.twig"));

        $__internal_9903c77f71722554309b22e3ef08957d808d39977c1af67184c4c3f9148065a8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9903c77f71722554309b22e3ef08957d808d39977c1af67184c4c3f9148065a8->enter($__internal_9903c77f71722554309b22e3ef08957d808d39977c1af67184c4c3f9148065a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FarmBundle:Default:insert.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b8d866811a14cf8ede4d4e14ef14febac742468a20e7c122cc58f9c03c65bb68->leave($__internal_b8d866811a14cf8ede4d4e14ef14febac742468a20e7c122cc58f9c03c65bb68_prof);

        
        $__internal_9903c77f71722554309b22e3ef08957d808d39977c1af67184c4c3f9148065a8->leave($__internal_9903c77f71722554309b22e3ef08957d808d39977c1af67184c4c3f9148065a8_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_181819ca1200883ec5aecde3006662f5e5e15af2bb4fde5ebe42ee36040b3a33 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_181819ca1200883ec5aecde3006662f5e5e15af2bb4fde5ebe42ee36040b3a33->enter($__internal_181819ca1200883ec5aecde3006662f5e5e15af2bb4fde5ebe42ee36040b3a33_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_5079372fa8d1ceb2c39c6e510e67afae2334676015826d087cf9da76f02e56ab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5079372fa8d1ceb2c39c6e510e67afae2334676015826d087cf9da76f02e56ab->enter($__internal_5079372fa8d1ceb2c39c6e510e67afae2334676015826d087cf9da76f02e56ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Farm Maintenance";
        
        $__internal_5079372fa8d1ceb2c39c6e510e67afae2334676015826d087cf9da76f02e56ab->leave($__internal_5079372fa8d1ceb2c39c6e510e67afae2334676015826d087cf9da76f02e56ab_prof);

        
        $__internal_181819ca1200883ec5aecde3006662f5e5e15af2bb4fde5ebe42ee36040b3a33->leave($__internal_181819ca1200883ec5aecde3006662f5e5e15af2bb4fde5ebe42ee36040b3a33_prof);

    }

    // line 6
    public function block_navbar($context, array $blocks = array())
    {
        $__internal_8eadf292bb88c86a921e1298ca161cbf249b27cb7b78c4eada1044e1bc2cd5c1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8eadf292bb88c86a921e1298ca161cbf249b27cb7b78c4eada1044e1bc2cd5c1->enter($__internal_8eadf292bb88c86a921e1298ca161cbf249b27cb7b78c4eada1044e1bc2cd5c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        $__internal_5cfce66cbbec13cfff6d6bffa9c944fab804a1ba92d02e497c37d46da0617a65 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5cfce66cbbec13cfff6d6bffa9c944fab804a1ba92d02e497c37d46da0617a65->enter($__internal_5cfce66cbbec13cfff6d6bffa9c944fab804a1ba92d02e497c37d46da0617a65_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        echo "Farm Maintenance - Add";
        
        $__internal_5cfce66cbbec13cfff6d6bffa9c944fab804a1ba92d02e497c37d46da0617a65->leave($__internal_5cfce66cbbec13cfff6d6bffa9c944fab804a1ba92d02e497c37d46da0617a65_prof);

        
        $__internal_8eadf292bb88c86a921e1298ca161cbf249b27cb7b78c4eada1044e1bc2cd5c1->leave($__internal_8eadf292bb88c86a921e1298ca161cbf249b27cb7b78c4eada1044e1bc2cd5c1_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_6df7a5973656fe4ff4504b91da356a37dc6f70b1f19cba71fb7a139be24cf1e8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6df7a5973656fe4ff4504b91da356a37dc6f70b1f19cba71fb7a139be24cf1e8->enter($__internal_6df7a5973656fe4ff4504b91da356a37dc6f70b1f19cba71fb7a139be24cf1e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_8a43eae3defad4a0df6a834c82daad063c3ea165e36d249714d2f47184c999b7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8a43eae3defad4a0df6a834c82daad063c3ea165e36d249714d2f47184c999b7->enter($__internal_8a43eae3defad4a0df6a834c82daad063c3ea165e36d249714d2f47184c999b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo "    <div class=\"row col-md-8 col-md-offset-2 custyle\" style=\"margin-top: 20px\">
        <table class=\"table table-striped custab\">
            <tbody>
            <tr>
                <th>Name</th>
                <td><input type=\"text\" name=\"name\" value=\"\" id=\"name\"></td>
            </tr>
            <tr>
                <th>Description</th>
                <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\"></textarea></td>
            </tr>
            <tr>
                <th>Image</th>
                <td> imagen</td>
            </tr>
            <tr>
                <th>Elevation</th>
                <td><input type=\"text\" name=\"elevation\" value=\"\" id=\"elevation\"></td>
            </tr>
            <tr>
                <th>Harvest</th>
                <td><input type=\"text\" name=\"harvest\" value=\"\" id=\"harvest\"></td>
            </tr>
            <tr>
                <th>Latitude</th>
                <td><input type=\"text\" name=\"latitude\" value=\"\" id=\"latitude\"></td>
            </tr>
            <tr>
                <th>Longitude</th>
                <td><input type=\"text\" name=\"longitude\" value=\"\" id=\"longitude\"></td>
            </tr>
            <tr>
                <td class=\"text-center\" colspan=\"2\">
                    <a class='btn btn-success btn-xs btn-insert' style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-save\"></span> Save</a>
                    <a href=\"";
        // line 43
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_homepage");
        echo "\" class=\"btn btn-warning btn-xs\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancel</a>
                </td>
            </tr>
            </tbody>
        </table>
    </div>
";
        
        $__internal_8a43eae3defad4a0df6a834c82daad063c3ea165e36d249714d2f47184c999b7->leave($__internal_8a43eae3defad4a0df6a834c82daad063c3ea165e36d249714d2f47184c999b7_prof);

        
        $__internal_6df7a5973656fe4ff4504b91da356a37dc6f70b1f19cba71fb7a139be24cf1e8->leave($__internal_6df7a5973656fe4ff4504b91da356a37dc6f70b1f19cba71fb7a139be24cf1e8_prof);

    }

    // line 52
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_01e799e8b638628f3355b756363d51fb98b155752923d42f79c2e9530132ecd7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_01e799e8b638628f3355b756363d51fb98b155752923d42f79c2e9530132ecd7->enter($__internal_01e799e8b638628f3355b756363d51fb98b155752923d42f79c2e9530132ecd7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_78cd525480cb10526cf12231e2bba6942d98beafe9be5ec35826166be4919495 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_78cd525480cb10526cf12231e2bba6942d98beafe9be5ec35826166be4919495->enter($__internal_78cd525480cb10526cf12231e2bba6942d98beafe9be5ec35826166be4919495_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 53
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/styles.css"), "html", null, true);
        echo "\">
";
        
        $__internal_78cd525480cb10526cf12231e2bba6942d98beafe9be5ec35826166be4919495->leave($__internal_78cd525480cb10526cf12231e2bba6942d98beafe9be5ec35826166be4919495_prof);

        
        $__internal_01e799e8b638628f3355b756363d51fb98b155752923d42f79c2e9530132ecd7->leave($__internal_01e799e8b638628f3355b756363d51fb98b155752923d42f79c2e9530132ecd7_prof);

    }

    // line 56
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_6ca7da23617d01f9bc3e9a0f2345d3879d9c7f1c34613289eb07d50d4829138b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6ca7da23617d01f9bc3e9a0f2345d3879d9c7f1c34613289eb07d50d4829138b->enter($__internal_6ca7da23617d01f9bc3e9a0f2345d3879d9c7f1c34613289eb07d50d4829138b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_df55ef5b7fc8411b74bdfdbf85dd1da7404ce2363a08b174e59d66266fb4b23f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_df55ef5b7fc8411b74bdfdbf85dd1da7404ce2363a08b174e59d66266fb4b23f->enter($__internal_df55ef5b7fc8411b74bdfdbf85dd1da7404ce2363a08b174e59d66266fb4b23f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 57
        echo "    <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 58
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./js/farm.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_df55ef5b7fc8411b74bdfdbf85dd1da7404ce2363a08b174e59d66266fb4b23f->leave($__internal_df55ef5b7fc8411b74bdfdbf85dd1da7404ce2363a08b174e59d66266fb4b23f_prof);

        
        $__internal_6ca7da23617d01f9bc3e9a0f2345d3879d9c7f1c34613289eb07d50d4829138b->leave($__internal_6ca7da23617d01f9bc3e9a0f2345d3879d9c7f1c34613289eb07d50d4829138b_prof);

    }

    public function getTemplateName()
    {
        return "FarmBundle:Default:insert.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  178 => 58,  173 => 57,  164 => 56,  151 => 53,  142 => 52,  125 => 43,  89 => 9,  80 => 8,  62 => 6,  44 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Farm Maintenance{% endblock %}

{% block navbar %}Farm Maintenance - Add{% endblock %}

{% block body %}
    <div class=\"row col-md-8 col-md-offset-2 custyle\" style=\"margin-top: 20px\">
        <table class=\"table table-striped custab\">
            <tbody>
            <tr>
                <th>Name</th>
                <td><input type=\"text\" name=\"name\" value=\"\" id=\"name\"></td>
            </tr>
            <tr>
                <th>Description</th>
                <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\"></textarea></td>
            </tr>
            <tr>
                <th>Image</th>
                <td> imagen</td>
            </tr>
            <tr>
                <th>Elevation</th>
                <td><input type=\"text\" name=\"elevation\" value=\"\" id=\"elevation\"></td>
            </tr>
            <tr>
                <th>Harvest</th>
                <td><input type=\"text\" name=\"harvest\" value=\"\" id=\"harvest\"></td>
            </tr>
            <tr>
                <th>Latitude</th>
                <td><input type=\"text\" name=\"latitude\" value=\"\" id=\"latitude\"></td>
            </tr>
            <tr>
                <th>Longitude</th>
                <td><input type=\"text\" name=\"longitude\" value=\"\" id=\"longitude\"></td>
            </tr>
            <tr>
                <td class=\"text-center\" colspan=\"2\">
                    <a class='btn btn-success btn-xs btn-insert' style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-save\"></span> Save</a>
                    <a href=\"{{ path('farm_homepage') }}\" class=\"btn btn-warning btn-xs\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancel</a>
                </td>
            </tr>
            </tbody>
        </table>
    </div>
{% endblock %}


{% block stylesheets %}
    <link rel=\"stylesheet\" href=\"{{ asset('css/styles.css') }}\">
{% endblock %}

{% block javascripts %}
    <script type=\"text/javascript\" src=\"{{ asset('./js/jquery-3.2.0.min.js') }}\"></script>
    <script type=\"text/javascript\" src=\"{{ asset('./js/farm.js') }}\"></script>
{% endblock %}", "FarmBundle:Default:insert.html.twig", "C:\\xampp\\htdocs\\Maintenance\\src\\FarmBundle/Resources/views/Default/insert.html.twig");
    }
}
