<?php

/* @WebProfiler/Profiler/open.html.twig */
class __TwigTemplate_d1210ded42540a029420d10b9a5f918a2a68323d37e61c50375d1094b8ba7d26 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "@WebProfiler/Profiler/open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b8e21711abe9db9e008617104ac9138e7df7ee52cd7bb848c94e04a3c0b3caa1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b8e21711abe9db9e008617104ac9138e7df7ee52cd7bb848c94e04a3c0b3caa1->enter($__internal_b8e21711abe9db9e008617104ac9138e7df7ee52cd7bb848c94e04a3c0b3caa1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $__internal_0b96e34a808db5dabb64f823967c5a222cccb9b5c2052024b6bea7ca135572df = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0b96e34a808db5dabb64f823967c5a222cccb9b5c2052024b6bea7ca135572df->enter($__internal_0b96e34a808db5dabb64f823967c5a222cccb9b5c2052024b6bea7ca135572df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b8e21711abe9db9e008617104ac9138e7df7ee52cd7bb848c94e04a3c0b3caa1->leave($__internal_b8e21711abe9db9e008617104ac9138e7df7ee52cd7bb848c94e04a3c0b3caa1_prof);

        
        $__internal_0b96e34a808db5dabb64f823967c5a222cccb9b5c2052024b6bea7ca135572df->leave($__internal_0b96e34a808db5dabb64f823967c5a222cccb9b5c2052024b6bea7ca135572df_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_54aab6424d3da874f9cbdf9f965b97d7227223fc580eae9ccf1a3c0e80dee9ea = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_54aab6424d3da874f9cbdf9f965b97d7227223fc580eae9ccf1a3c0e80dee9ea->enter($__internal_54aab6424d3da874f9cbdf9f965b97d7227223fc580eae9ccf1a3c0e80dee9ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_ad103d83fd13df1633f4d22a4183549616e506eb4d36c95cb9add3344ceb5a51 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ad103d83fd13df1633f4d22a4183549616e506eb4d36c95cb9add3344ceb5a51->enter($__internal_ad103d83fd13df1633f4d22a4183549616e506eb4d36c95cb9add3344ceb5a51_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_ad103d83fd13df1633f4d22a4183549616e506eb4d36c95cb9add3344ceb5a51->leave($__internal_ad103d83fd13df1633f4d22a4183549616e506eb4d36c95cb9add3344ceb5a51_prof);

        
        $__internal_54aab6424d3da874f9cbdf9f965b97d7227223fc580eae9ccf1a3c0e80dee9ea->leave($__internal_54aab6424d3da874f9cbdf9f965b97d7227223fc580eae9ccf1a3c0e80dee9ea_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_95d28d04023161e4f84a29d918b3df4f6adc75d7642bce3c23dfb0619a9a25f0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_95d28d04023161e4f84a29d918b3df4f6adc75d7642bce3c23dfb0619a9a25f0->enter($__internal_95d28d04023161e4f84a29d918b3df4f6adc75d7642bce3c23dfb0619a9a25f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_91e57a8c747447d22ae040d85be8fd9e2a1ff8f099e459599647c77f6d906a37 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_91e57a8c747447d22ae040d85be8fd9e2a1ff8f099e459599647c77f6d906a37->enter($__internal_91e57a8c747447d22ae040d85be8fd9e2a1ff8f099e459599647c77f6d906a37_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, ($context["file"] ?? $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, ($context["line"] ?? $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt(($context["filename"] ?? $this->getContext($context, "filename")), ($context["line"] ?? $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_91e57a8c747447d22ae040d85be8fd9e2a1ff8f099e459599647c77f6d906a37->leave($__internal_91e57a8c747447d22ae040d85be8fd9e2a1ff8f099e459599647c77f6d906a37_prof);

        
        $__internal_95d28d04023161e4f84a29d918b3df4f6adc75d7642bce3c23dfb0619a9a25f0->leave($__internal_95d28d04023161e4f84a29d918b3df4f6adc75d7642bce3c23dfb0619a9a25f0_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "@WebProfiler/Profiler/open.html.twig", "C:\\xampp\\htdocs\\Maintenance\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\open.html.twig");
    }
}
