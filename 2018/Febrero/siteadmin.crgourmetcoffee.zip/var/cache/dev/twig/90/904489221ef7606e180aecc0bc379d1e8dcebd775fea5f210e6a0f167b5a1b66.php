<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_3acac5513e4f808676fa14ae85cf19cecb8887283daf40c7a75bf9e29bc0c78a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_aab020e1eb2c8a1ce74a5ff2b62f05a6e0ef1b97e3bea77a717b37e6b9662b2c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aab020e1eb2c8a1ce74a5ff2b62f05a6e0ef1b97e3bea77a717b37e6b9662b2c->enter($__internal_aab020e1eb2c8a1ce74a5ff2b62f05a6e0ef1b97e3bea77a717b37e6b9662b2c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_0c309f85e4f6cd20b4a68aa994ba141cdfcddbb4f1ce746e536cd8094bed3147 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0c309f85e4f6cd20b4a68aa994ba141cdfcddbb4f1ce746e536cd8094bed3147->enter($__internal_0c309f85e4f6cd20b4a68aa994ba141cdfcddbb4f1ce746e536cd8094bed3147_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_aab020e1eb2c8a1ce74a5ff2b62f05a6e0ef1b97e3bea77a717b37e6b9662b2c->leave($__internal_aab020e1eb2c8a1ce74a5ff2b62f05a6e0ef1b97e3bea77a717b37e6b9662b2c_prof);

        
        $__internal_0c309f85e4f6cd20b4a68aa994ba141cdfcddbb4f1ce746e536cd8094bed3147->leave($__internal_0c309f85e4f6cd20b4a68aa994ba141cdfcddbb4f1ce746e536cd8094bed3147_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_2fb36175e65a1a7100201e5afbe292f950158ff74e03c809bced283bd840606a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2fb36175e65a1a7100201e5afbe292f950158ff74e03c809bced283bd840606a->enter($__internal_2fb36175e65a1a7100201e5afbe292f950158ff74e03c809bced283bd840606a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_f31a32fddb7b4ec8f0ab75791bbbe729b4d0a8f51df98964a677d463769c625b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f31a32fddb7b4ec8f0ab75791bbbe729b4d0a8f51df98964a677d463769c625b->enter($__internal_f31a32fddb7b4ec8f0ab75791bbbe729b4d0a8f51df98964a677d463769c625b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_f31a32fddb7b4ec8f0ab75791bbbe729b4d0a8f51df98964a677d463769c625b->leave($__internal_f31a32fddb7b4ec8f0ab75791bbbe729b4d0a8f51df98964a677d463769c625b_prof);

        
        $__internal_2fb36175e65a1a7100201e5afbe292f950158ff74e03c809bced283bd840606a->leave($__internal_2fb36175e65a1a7100201e5afbe292f950158ff74e03c809bced283bd840606a_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_6792efaa23718c5b233178045aed4d163280a304ed6ddcb7b910bfd899d2481a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6792efaa23718c5b233178045aed4d163280a304ed6ddcb7b910bfd899d2481a->enter($__internal_6792efaa23718c5b233178045aed4d163280a304ed6ddcb7b910bfd899d2481a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_c8cee483e254f5eaeeaeaa94226eea14bf11e3cf80daf92582eec55fb3477d21 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c8cee483e254f5eaeeaeaa94226eea14bf11e3cf80daf92582eec55fb3477d21->enter($__internal_c8cee483e254f5eaeeaeaa94226eea14bf11e3cf80daf92582eec55fb3477d21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_c8cee483e254f5eaeeaeaa94226eea14bf11e3cf80daf92582eec55fb3477d21->leave($__internal_c8cee483e254f5eaeeaeaa94226eea14bf11e3cf80daf92582eec55fb3477d21_prof);

        
        $__internal_6792efaa23718c5b233178045aed4d163280a304ed6ddcb7b910bfd899d2481a->leave($__internal_6792efaa23718c5b233178045aed4d163280a304ed6ddcb7b910bfd899d2481a_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_5b7f79ac38bbc306cbada8bfa7e66696f19c9254c98ae480ea5c29a99dd98385 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5b7f79ac38bbc306cbada8bfa7e66696f19c9254c98ae480ea5c29a99dd98385->enter($__internal_5b7f79ac38bbc306cbada8bfa7e66696f19c9254c98ae480ea5c29a99dd98385_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_0622eae77d673e9518fafdc3c78e0833309f58438b6eaadf441cdfc63e4d145a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0622eae77d673e9518fafdc3c78e0833309f58438b6eaadf441cdfc63e4d145a->enter($__internal_0622eae77d673e9518fafdc3c78e0833309f58438b6eaadf441cdfc63e4d145a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_0622eae77d673e9518fafdc3c78e0833309f58438b6eaadf441cdfc63e4d145a->leave($__internal_0622eae77d673e9518fafdc3c78e0833309f58438b6eaadf441cdfc63e4d145a_prof);

        
        $__internal_5b7f79ac38bbc306cbada8bfa7e66696f19c9254c98ae480ea5c29a99dd98385->leave($__internal_5b7f79ac38bbc306cbada8bfa7e66696f19c9254c98ae480ea5c29a99dd98385_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\xampp\\htdocs\\Maintenance\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
