<?php

/* FarmBundle:Default:farm.html.twig */
class __TwigTemplate_2a11049ba262449e46d7b3988b5c5302b29e83b5e02bd1fa3c17f77089a5626e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "FarmBundle:Default:farm.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'navbar' => array($this, 'block_navbar'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fc02f79c3dfad14830ed3369fd5ce4a98f2e0835643079b246daa7fa0ac31e15 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fc02f79c3dfad14830ed3369fd5ce4a98f2e0835643079b246daa7fa0ac31e15->enter($__internal_fc02f79c3dfad14830ed3369fd5ce4a98f2e0835643079b246daa7fa0ac31e15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FarmBundle:Default:farm.html.twig"));

        $__internal_b43bae6cc1bdd71516c9cfc8d71f457389a93dc9a1974b1b567abb39be7ab41c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b43bae6cc1bdd71516c9cfc8d71f457389a93dc9a1974b1b567abb39be7ab41c->enter($__internal_b43bae6cc1bdd71516c9cfc8d71f457389a93dc9a1974b1b567abb39be7ab41c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FarmBundle:Default:farm.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fc02f79c3dfad14830ed3369fd5ce4a98f2e0835643079b246daa7fa0ac31e15->leave($__internal_fc02f79c3dfad14830ed3369fd5ce4a98f2e0835643079b246daa7fa0ac31e15_prof);

        
        $__internal_b43bae6cc1bdd71516c9cfc8d71f457389a93dc9a1974b1b567abb39be7ab41c->leave($__internal_b43bae6cc1bdd71516c9cfc8d71f457389a93dc9a1974b1b567abb39be7ab41c_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_8a372e75a55919a47cf938471f27a70cd3af1fc655cfbb9554516d39a1323b16 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8a372e75a55919a47cf938471f27a70cd3af1fc655cfbb9554516d39a1323b16->enter($__internal_8a372e75a55919a47cf938471f27a70cd3af1fc655cfbb9554516d39a1323b16_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_9a9c772ec7b3563ccd2a70df96601ea1752ce802b0c8e79aa4fc82cbd427ee8b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9a9c772ec7b3563ccd2a70df96601ea1752ce802b0c8e79aa4fc82cbd427ee8b->enter($__internal_9a9c772ec7b3563ccd2a70df96601ea1752ce802b0c8e79aa4fc82cbd427ee8b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Farm Maintenance";
        
        $__internal_9a9c772ec7b3563ccd2a70df96601ea1752ce802b0c8e79aa4fc82cbd427ee8b->leave($__internal_9a9c772ec7b3563ccd2a70df96601ea1752ce802b0c8e79aa4fc82cbd427ee8b_prof);

        
        $__internal_8a372e75a55919a47cf938471f27a70cd3af1fc655cfbb9554516d39a1323b16->leave($__internal_8a372e75a55919a47cf938471f27a70cd3af1fc655cfbb9554516d39a1323b16_prof);

    }

    // line 6
    public function block_navbar($context, array $blocks = array())
    {
        $__internal_8ed12355c5735bcd3cdce75f25e9a2991aa4e0481d226dfc153f6b8160fb94af = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8ed12355c5735bcd3cdce75f25e9a2991aa4e0481d226dfc153f6b8160fb94af->enter($__internal_8ed12355c5735bcd3cdce75f25e9a2991aa4e0481d226dfc153f6b8160fb94af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        $__internal_f7b913cc0ba2ee5a9ecc05d0558bdc64e8ce489c5809a9073aacb810aeb3f164 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f7b913cc0ba2ee5a9ecc05d0558bdc64e8ce489c5809a9073aacb810aeb3f164->enter($__internal_f7b913cc0ba2ee5a9ecc05d0558bdc64e8ce489c5809a9073aacb810aeb3f164_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        echo "Farm Maintenance";
        
        $__internal_f7b913cc0ba2ee5a9ecc05d0558bdc64e8ce489c5809a9073aacb810aeb3f164->leave($__internal_f7b913cc0ba2ee5a9ecc05d0558bdc64e8ce489c5809a9073aacb810aeb3f164_prof);

        
        $__internal_8ed12355c5735bcd3cdce75f25e9a2991aa4e0481d226dfc153f6b8160fb94af->leave($__internal_8ed12355c5735bcd3cdce75f25e9a2991aa4e0481d226dfc153f6b8160fb94af_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_741195643776736c9c914279910c2f7d9b85fe3f475ef218d10df25788ee5f15 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_741195643776736c9c914279910c2f7d9b85fe3f475ef218d10df25788ee5f15->enter($__internal_741195643776736c9c914279910c2f7d9b85fe3f475ef218d10df25788ee5f15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_dcfb57f10e41c001dee98f129ed136c23f3a4ca9d3943519fed8aa643dd2acb9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dcfb57f10e41c001dee98f129ed136c23f3a4ca9d3943519fed8aa643dd2acb9->enter($__internal_dcfb57f10e41c001dee98f129ed136c23f3a4ca9d3943519fed8aa643dd2acb9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo "    <div class=\"row col-md-20 col-md-offset-0 custyle\">
        <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_add");
        echo "\" class=\"btn btn-primary btn-xs pull-right\"><span class=\"glyphicon glyphicon-plus\"></span> Add</a>
        <table class=\"table table-striped custab table-region\">
            <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Image</th>
                <th>Elevation</th>
                <th>Harvest</th>
                <th>Latitude</th>
                <th>Longitude</th>
                <th class=\"text-center\">Action</th>
            </tr>
            </thead>
            <tbody>
            ";
        // line 26
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["farms"] ?? $this->getContext($context, "farms")));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 27
            echo "                <tr>
                    <td> ";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "</td>
                    <td> ";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo " </td>
                    <td class=\"text-area\" style=\"text-align: justify\">";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getDescription", array(), "method"), "html", null, true);
            echo " </td>
                    <td> <img src=\"../../..";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage", array(), "method"), "html", null, true);
            echo "\" class=\"mediana\"></td>
                    <td class=\"text-area\"> ";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getElevation", array(), "method"), "html", null, true);
            echo "</td>
                    <td class=\"text-area\"> ";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getHarvest", array(), "method"), "html", null, true);
            echo "</td>
                    <td> ";
            // line 34
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getLatitude", array(), "method"), "html", null, true);
            echo "</td>
                    <td> ";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getLongitude", array(), "method"), "html", null, true);
            echo "</td>
                    <td class=\"text-center\">
                        <a class='btn btn-info btn-xs btn-edit' style=\"margin-top: 10px\" id=\"";
            // line 37
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-edit\"></span> Edit</a>
                        <a href=\"";
            // line 38
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_delete", array("id" => $this->getAttribute($context["temp"], "getId", array(), "method"))), "html", null, true);
            echo "\" class=\"btn btn-danger btn-xs\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-remove\"></span> Delete</a>
                    </td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 42
        echo "            </tbody>
        </table>
    </div>
";
        
        $__internal_dcfb57f10e41c001dee98f129ed136c23f3a4ca9d3943519fed8aa643dd2acb9->leave($__internal_dcfb57f10e41c001dee98f129ed136c23f3a4ca9d3943519fed8aa643dd2acb9_prof);

        
        $__internal_741195643776736c9c914279910c2f7d9b85fe3f475ef218d10df25788ee5f15->leave($__internal_741195643776736c9c914279910c2f7d9b85fe3f475ef218d10df25788ee5f15_prof);

    }

    // line 48
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_d3bb3e4f48ba9cfbf6200d01b5eefdd5fe2504626b10aa6ff598dfab306ab2c5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d3bb3e4f48ba9cfbf6200d01b5eefdd5fe2504626b10aa6ff598dfab306ab2c5->enter($__internal_d3bb3e4f48ba9cfbf6200d01b5eefdd5fe2504626b10aa6ff598dfab306ab2c5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_cb22b16e85d699f032c6c6383baa300b68580c5fff4e5779a85888233fd302ad = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cb22b16e85d699f032c6c6383baa300b68580c5fff4e5779a85888233fd302ad->enter($__internal_cb22b16e85d699f032c6c6383baa300b68580c5fff4e5779a85888233fd302ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 49
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/styles.css"), "html", null, true);
        echo "\">
";
        
        $__internal_cb22b16e85d699f032c6c6383baa300b68580c5fff4e5779a85888233fd302ad->leave($__internal_cb22b16e85d699f032c6c6383baa300b68580c5fff4e5779a85888233fd302ad_prof);

        
        $__internal_d3bb3e4f48ba9cfbf6200d01b5eefdd5fe2504626b10aa6ff598dfab306ab2c5->leave($__internal_d3bb3e4f48ba9cfbf6200d01b5eefdd5fe2504626b10aa6ff598dfab306ab2c5_prof);

    }

    // line 52
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_595b873721d27539885baf9b7c8651c594cc457e3b5e3d933a05788591018d14 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_595b873721d27539885baf9b7c8651c594cc457e3b5e3d933a05788591018d14->enter($__internal_595b873721d27539885baf9b7c8651c594cc457e3b5e3d933a05788591018d14_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_6b10a76a29232ef249deb12612dccab942923bae5f846933de5ebbd91719e35f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6b10a76a29232ef249deb12612dccab942923bae5f846933de5ebbd91719e35f->enter($__internal_6b10a76a29232ef249deb12612dccab942923bae5f846933de5ebbd91719e35f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 53
        echo "    <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 54
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./js/farm.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_6b10a76a29232ef249deb12612dccab942923bae5f846933de5ebbd91719e35f->leave($__internal_6b10a76a29232ef249deb12612dccab942923bae5f846933de5ebbd91719e35f_prof);

        
        $__internal_595b873721d27539885baf9b7c8651c594cc457e3b5e3d933a05788591018d14->leave($__internal_595b873721d27539885baf9b7c8651c594cc457e3b5e3d933a05788591018d14_prof);

    }

    public function getTemplateName()
    {
        return "FarmBundle:Default:farm.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  214 => 54,  209 => 53,  200 => 52,  187 => 49,  178 => 48,  165 => 42,  155 => 38,  151 => 37,  146 => 35,  142 => 34,  138 => 33,  134 => 32,  130 => 31,  126 => 30,  122 => 29,  118 => 28,  115 => 27,  111 => 26,  92 => 10,  89 => 9,  80 => 8,  62 => 6,  44 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Farm Maintenance{% endblock %}

{% block navbar %}Farm Maintenance{% endblock %}

{% block body %}
    <div class=\"row col-md-20 col-md-offset-0 custyle\">
        <a href=\"{{ path('farm_add') }}\" class=\"btn btn-primary btn-xs pull-right\"><span class=\"glyphicon glyphicon-plus\"></span> Add</a>
        <table class=\"table table-striped custab table-region\">
            <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Image</th>
                <th>Elevation</th>
                <th>Harvest</th>
                <th>Latitude</th>
                <th>Longitude</th>
                <th class=\"text-center\">Action</th>
            </tr>
            </thead>
            <tbody>
            {% for temp in farms %}
                <tr>
                    <td> {{ temp.getId() }}</td>
                    <td> {{ temp.getName() }} </td>
                    <td class=\"text-area\" style=\"text-align: justify\">{{ temp.getDescription() }} </td>
                    <td> <img src=\"../../..{{ temp.getImage() }}\" class=\"mediana\"></td>
                    <td class=\"text-area\"> {{ temp.getElevation() }}</td>
                    <td class=\"text-area\"> {{ temp.getHarvest() }}</td>
                    <td> {{ temp.getLatitude() }}</td>
                    <td> {{ temp.getLongitude() }}</td>
                    <td class=\"text-center\">
                        <a class='btn btn-info btn-xs btn-edit' style=\"margin-top: 10px\" id=\"{{ temp.getId() }}\"><span class=\"glyphicon glyphicon-edit\"></span> Edit</a>
                        <a href=\"{{ path('farm_delete', { 'id': temp.getId() }) }}\" class=\"btn btn-danger btn-xs\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-remove\"></span> Delete</a>
                    </td>
                </tr>
            {% endfor %}
            </tbody>
        </table>
    </div>
{% endblock %}


{% block stylesheets %}
    <link rel=\"stylesheet\" href=\"{{ asset('css/styles.css') }}\">
{% endblock %}

{% block javascripts %}
    <script type=\"text/javascript\" src=\"{{ asset('./js/jquery-3.2.0.min.js') }}\"></script>
    <script type=\"text/javascript\" src=\"{{ asset('./js/farm.js') }}\"></script>
{% endblock %}

", "FarmBundle:Default:farm.html.twig", "C:\\xampp\\htdocs\\Maintenance\\src\\FarmBundle/Resources/views/Default/farm.html.twig");
    }
}
