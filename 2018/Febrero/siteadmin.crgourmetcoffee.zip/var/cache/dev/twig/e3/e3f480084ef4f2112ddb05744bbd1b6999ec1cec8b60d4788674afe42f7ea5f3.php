<?php

/* RegionBundle:Default:edit.html.twig */
class __TwigTemplate_eae08a105cf60b972d965b1299edac1b5aaedf458bea89d5f7a770ba2f2b1b07 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "RegionBundle:Default:edit.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'navbar' => array($this, 'block_navbar'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5874846e2980be4ed525fd01883ad45170a9df66269e74f485cc189eff644db3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5874846e2980be4ed525fd01883ad45170a9df66269e74f485cc189eff644db3->enter($__internal_5874846e2980be4ed525fd01883ad45170a9df66269e74f485cc189eff644db3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "RegionBundle:Default:edit.html.twig"));

        $__internal_63c7844d2586bcc675b7f417a4f4f804afaf38b6f587fa5d495bfd2a8b28530d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_63c7844d2586bcc675b7f417a4f4f804afaf38b6f587fa5d495bfd2a8b28530d->enter($__internal_63c7844d2586bcc675b7f417a4f4f804afaf38b6f587fa5d495bfd2a8b28530d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "RegionBundle:Default:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5874846e2980be4ed525fd01883ad45170a9df66269e74f485cc189eff644db3->leave($__internal_5874846e2980be4ed525fd01883ad45170a9df66269e74f485cc189eff644db3_prof);

        
        $__internal_63c7844d2586bcc675b7f417a4f4f804afaf38b6f587fa5d495bfd2a8b28530d->leave($__internal_63c7844d2586bcc675b7f417a4f4f804afaf38b6f587fa5d495bfd2a8b28530d_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_3f8432aa525c79665005dfd9dda2e6d12877c8aaf41b5382fa744a09f7d35746 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3f8432aa525c79665005dfd9dda2e6d12877c8aaf41b5382fa744a09f7d35746->enter($__internal_3f8432aa525c79665005dfd9dda2e6d12877c8aaf41b5382fa744a09f7d35746_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_362d3fc845d0be555531b57fee3433ca6a617b9f06ebbf652dcf53d9bd334a6d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_362d3fc845d0be555531b57fee3433ca6a617b9f06ebbf652dcf53d9bd334a6d->enter($__internal_362d3fc845d0be555531b57fee3433ca6a617b9f06ebbf652dcf53d9bd334a6d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Region Edit";
        
        $__internal_362d3fc845d0be555531b57fee3433ca6a617b9f06ebbf652dcf53d9bd334a6d->leave($__internal_362d3fc845d0be555531b57fee3433ca6a617b9f06ebbf652dcf53d9bd334a6d_prof);

        
        $__internal_3f8432aa525c79665005dfd9dda2e6d12877c8aaf41b5382fa744a09f7d35746->leave($__internal_3f8432aa525c79665005dfd9dda2e6d12877c8aaf41b5382fa744a09f7d35746_prof);

    }

    // line 6
    public function block_navbar($context, array $blocks = array())
    {
        $__internal_1711c3bd894ac4fcd9eea425891c47902ba5f36aa0057298988920255b8a5182 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1711c3bd894ac4fcd9eea425891c47902ba5f36aa0057298988920255b8a5182->enter($__internal_1711c3bd894ac4fcd9eea425891c47902ba5f36aa0057298988920255b8a5182_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        $__internal_dcab2803adea8c24b07c18ae5201a5eba7f70a6daa058cfc81db693f8c093dfd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dcab2803adea8c24b07c18ae5201a5eba7f70a6daa058cfc81db693f8c093dfd->enter($__internal_dcab2803adea8c24b07c18ae5201a5eba7f70a6daa058cfc81db693f8c093dfd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        echo "Region Maintenance - Edit";
        
        $__internal_dcab2803adea8c24b07c18ae5201a5eba7f70a6daa058cfc81db693f8c093dfd->leave($__internal_dcab2803adea8c24b07c18ae5201a5eba7f70a6daa058cfc81db693f8c093dfd_prof);

        
        $__internal_1711c3bd894ac4fcd9eea425891c47902ba5f36aa0057298988920255b8a5182->leave($__internal_1711c3bd894ac4fcd9eea425891c47902ba5f36aa0057298988920255b8a5182_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_35653016e9dfdbe5b9020b87068803c7fdcbe5afc5e68e0da437831620dd61cb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_35653016e9dfdbe5b9020b87068803c7fdcbe5afc5e68e0da437831620dd61cb->enter($__internal_35653016e9dfdbe5b9020b87068803c7fdcbe5afc5e68e0da437831620dd61cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_3006a9f821ac2abdac2a453bf8b4cfa1ea868f61e3031541779cb01925b09705 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3006a9f821ac2abdac2a453bf8b4cfa1ea868f61e3031541779cb01925b09705->enter($__internal_3006a9f821ac2abdac2a453bf8b4cfa1ea868f61e3031541779cb01925b09705_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo "    <div class=\"row col-md-8 col-md-offset-2 custyle\" style=\"margin-top: 20px\">
        <table class=\"table table-striped custab\">
            <tbody>
            ";
        // line 12
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["regions"] ?? $this->getContext($context, "regions")));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 13
            echo "                <tr>
                    <th>ID</th>
                    <td> ";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "</td>
                </tr>
                <tr>
                    <th>Name</th>
                    <td><input type=\"text\" name=\"name\" value=\"";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo "\" id=\"name\"></td>
                </tr>
                <tr>
                    <th>Description</th>
                    <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\">";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getDescription", array(), "method"), "html", null, true);
            echo "</textarea></td>
                </tr>
                <tr>
                    <th>Image</th>
                    <td> <img src=\"../../../..";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage", array(), "method"), "html", null, true);
            echo "\" class=\"mediana\"></td>
                </tr>
                <tr>
                    <th>Characteristics</th>
                    <td><textarea name=\"characteristics\" rows=\"7\" cols=\"45\" id=\"characteristics\">";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getCharacteristics", array(), "method"), "html", null, true);
            echo "</textarea></td>
                </tr>
                <tr>
                    <th>Latitude</th>
                    <td><input type=\"text\" name=\"latitude\" value=\"";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getLatitude", array(), "method"), "html", null, true);
            echo "\" id=\"latitude\"></td>
                </tr>
                <tr>
                    <th>Longitude</th>
                    <td><input type=\"text\" name=\"longitude\" value=\"";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getLongitude", array(), "method"), "html", null, true);
            echo "\" id=\"longitude\"></td>
                </tr>
                <tr>
                    <td class=\"text-center\" colspan=\"2\">
                        <a class='btn btn-success btn-xs btn-save' style=\"margin-top: 10px\" id=\"";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-save\"></span> Save</a>
                        <a href=\"";
            // line 44
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_homepage");
            echo "\" class=\"btn btn-warning btn-xs\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancel</a>
                    </td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 48
        echo "            </tbody>
        </table>
    </div>
";
        
        $__internal_3006a9f821ac2abdac2a453bf8b4cfa1ea868f61e3031541779cb01925b09705->leave($__internal_3006a9f821ac2abdac2a453bf8b4cfa1ea868f61e3031541779cb01925b09705_prof);

        
        $__internal_35653016e9dfdbe5b9020b87068803c7fdcbe5afc5e68e0da437831620dd61cb->leave($__internal_35653016e9dfdbe5b9020b87068803c7fdcbe5afc5e68e0da437831620dd61cb_prof);

    }

    // line 54
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_e8cbb44795d7e1d2bac5a22e485cc8dcbfe0be7fd8fbe57de45cea645ec33aaf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e8cbb44795d7e1d2bac5a22e485cc8dcbfe0be7fd8fbe57de45cea645ec33aaf->enter($__internal_e8cbb44795d7e1d2bac5a22e485cc8dcbfe0be7fd8fbe57de45cea645ec33aaf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_1179ffa5fc6f402fa20cca8eb67659877dc1a72a9feed236f076a0f4e9b53d75 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1179ffa5fc6f402fa20cca8eb67659877dc1a72a9feed236f076a0f4e9b53d75->enter($__internal_1179ffa5fc6f402fa20cca8eb67659877dc1a72a9feed236f076a0f4e9b53d75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 55
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/styles.css"), "html", null, true);
        echo "\">
";
        
        $__internal_1179ffa5fc6f402fa20cca8eb67659877dc1a72a9feed236f076a0f4e9b53d75->leave($__internal_1179ffa5fc6f402fa20cca8eb67659877dc1a72a9feed236f076a0f4e9b53d75_prof);

        
        $__internal_e8cbb44795d7e1d2bac5a22e485cc8dcbfe0be7fd8fbe57de45cea645ec33aaf->leave($__internal_e8cbb44795d7e1d2bac5a22e485cc8dcbfe0be7fd8fbe57de45cea645ec33aaf_prof);

    }

    // line 59
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_129e9a0fcf820d36c0dd4892232314cf4bde0f42a1e8d1f43722b11fd3c7d657 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_129e9a0fcf820d36c0dd4892232314cf4bde0f42a1e8d1f43722b11fd3c7d657->enter($__internal_129e9a0fcf820d36c0dd4892232314cf4bde0f42a1e8d1f43722b11fd3c7d657_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_b56e348f6583275617ecdf68169165438bb274c21f971f7c0450ce3c470b5f09 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b56e348f6583275617ecdf68169165438bb274c21f971f7c0450ce3c470b5f09->enter($__internal_b56e348f6583275617ecdf68169165438bb274c21f971f7c0450ce3c470b5f09_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 60
        echo "    <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 61
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./js/regions.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_b56e348f6583275617ecdf68169165438bb274c21f971f7c0450ce3c470b5f09->leave($__internal_b56e348f6583275617ecdf68169165438bb274c21f971f7c0450ce3c470b5f09_prof);

        
        $__internal_129e9a0fcf820d36c0dd4892232314cf4bde0f42a1e8d1f43722b11fd3c7d657->leave($__internal_129e9a0fcf820d36c0dd4892232314cf4bde0f42a1e8d1f43722b11fd3c7d657_prof);

    }

    public function getTemplateName()
    {
        return "RegionBundle:Default:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  214 => 61,  209 => 60,  200 => 59,  187 => 55,  178 => 54,  165 => 48,  155 => 44,  151 => 43,  144 => 39,  137 => 35,  130 => 31,  123 => 27,  116 => 23,  109 => 19,  102 => 15,  98 => 13,  94 => 12,  89 => 9,  80 => 8,  62 => 6,  44 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Region Edit{% endblock %}

{% block navbar %}Region Maintenance - Edit{% endblock %}

{% block body %}
    <div class=\"row col-md-8 col-md-offset-2 custyle\" style=\"margin-top: 20px\">
        <table class=\"table table-striped custab\">
            <tbody>
            {% for temp in regions %}
                <tr>
                    <th>ID</th>
                    <td> {{ temp.getId() }}</td>
                </tr>
                <tr>
                    <th>Name</th>
                    <td><input type=\"text\" name=\"name\" value=\"{{ temp.getName() }}\" id=\"name\"></td>
                </tr>
                <tr>
                    <th>Description</th>
                    <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\">{{ temp.getDescription() }}</textarea></td>
                </tr>
                <tr>
                    <th>Image</th>
                    <td> <img src=\"../../../..{{ temp.getImage() }}\" class=\"mediana\"></td>
                </tr>
                <tr>
                    <th>Characteristics</th>
                    <td><textarea name=\"characteristics\" rows=\"7\" cols=\"45\" id=\"characteristics\">{{ temp.getCharacteristics() }}</textarea></td>
                </tr>
                <tr>
                    <th>Latitude</th>
                    <td><input type=\"text\" name=\"latitude\" value=\"{{ temp.getLatitude() }}\" id=\"latitude\"></td>
                </tr>
                <tr>
                    <th>Longitude</th>
                    <td><input type=\"text\" name=\"longitude\" value=\"{{ temp.getLongitude() }}\" id=\"longitude\"></td>
                </tr>
                <tr>
                    <td class=\"text-center\" colspan=\"2\">
                        <a class='btn btn-success btn-xs btn-save' style=\"margin-top: 10px\" id=\"{{ temp.getId() }}\"><span class=\"glyphicon glyphicon-save\"></span> Save</a>
                        <a href=\"{{ path('region_homepage') }}\" class=\"btn btn-warning btn-xs\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancel</a>
                    </td>
                </tr>
            {% endfor %}
            </tbody>
        </table>
    </div>
{% endblock %}


{% block stylesheets %}
    <link rel=\"stylesheet\" href=\"{{ asset('css/styles.css') }}\">
{% endblock %}


{% block javascripts %}
    <script type=\"text/javascript\" src=\"{{ asset('./js/jquery-3.2.0.min.js') }}\"></script>
    <script type=\"text/javascript\" src=\"{{ asset('./js/regions.js') }}\"></script>
{% endblock %}
", "RegionBundle:Default:edit.html.twig", "C:\\xampp\\htdocs\\Maintenance\\src\\RegionBundle/Resources/views/Default/edit.html.twig");
    }
}
