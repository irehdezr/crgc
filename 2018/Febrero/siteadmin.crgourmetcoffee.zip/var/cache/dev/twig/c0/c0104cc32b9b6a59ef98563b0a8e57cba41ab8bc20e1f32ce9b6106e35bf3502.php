<?php

/* RegionBundle:Default:region.html.twig */
class __TwigTemplate_2ca3c9a923d3c92d4b035b22001178e7f44753a5488e638b254806314d7c10f4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "RegionBundle:Default:region.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'navbar' => array($this, 'block_navbar'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3be26ded9258fd36a5df093f2bf19f11a5c9778f7703ef21594c298818f9d6d2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3be26ded9258fd36a5df093f2bf19f11a5c9778f7703ef21594c298818f9d6d2->enter($__internal_3be26ded9258fd36a5df093f2bf19f11a5c9778f7703ef21594c298818f9d6d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "RegionBundle:Default:region.html.twig"));

        $__internal_f5262b9660e5fd260e25081e1c05cfe345e05eadd4f86b78bc07dd8cc4549b25 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f5262b9660e5fd260e25081e1c05cfe345e05eadd4f86b78bc07dd8cc4549b25->enter($__internal_f5262b9660e5fd260e25081e1c05cfe345e05eadd4f86b78bc07dd8cc4549b25_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "RegionBundle:Default:region.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3be26ded9258fd36a5df093f2bf19f11a5c9778f7703ef21594c298818f9d6d2->leave($__internal_3be26ded9258fd36a5df093f2bf19f11a5c9778f7703ef21594c298818f9d6d2_prof);

        
        $__internal_f5262b9660e5fd260e25081e1c05cfe345e05eadd4f86b78bc07dd8cc4549b25->leave($__internal_f5262b9660e5fd260e25081e1c05cfe345e05eadd4f86b78bc07dd8cc4549b25_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_5b3bff1ff1c43cbe154d2b746185a7aa48cc7ca83f0d5a7effb929317d03416c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5b3bff1ff1c43cbe154d2b746185a7aa48cc7ca83f0d5a7effb929317d03416c->enter($__internal_5b3bff1ff1c43cbe154d2b746185a7aa48cc7ca83f0d5a7effb929317d03416c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_afffe79e66adcfdf116c28d3abe5c52f5d9200d2fb90aa0c9b7166805845e7ba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_afffe79e66adcfdf116c28d3abe5c52f5d9200d2fb90aa0c9b7166805845e7ba->enter($__internal_afffe79e66adcfdf116c28d3abe5c52f5d9200d2fb90aa0c9b7166805845e7ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Region Maintenance";
        
        $__internal_afffe79e66adcfdf116c28d3abe5c52f5d9200d2fb90aa0c9b7166805845e7ba->leave($__internal_afffe79e66adcfdf116c28d3abe5c52f5d9200d2fb90aa0c9b7166805845e7ba_prof);

        
        $__internal_5b3bff1ff1c43cbe154d2b746185a7aa48cc7ca83f0d5a7effb929317d03416c->leave($__internal_5b3bff1ff1c43cbe154d2b746185a7aa48cc7ca83f0d5a7effb929317d03416c_prof);

    }

    // line 6
    public function block_navbar($context, array $blocks = array())
    {
        $__internal_59c0b0767652a98ed5336be50b1f8565a773d54b99751542bfe67b63c8fe0f48 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_59c0b0767652a98ed5336be50b1f8565a773d54b99751542bfe67b63c8fe0f48->enter($__internal_59c0b0767652a98ed5336be50b1f8565a773d54b99751542bfe67b63c8fe0f48_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        $__internal_e1a96c76a70248de5ca2eda5b2bd31a8773275873d96c7025025c89ea19b24b0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e1a96c76a70248de5ca2eda5b2bd31a8773275873d96c7025025c89ea19b24b0->enter($__internal_e1a96c76a70248de5ca2eda5b2bd31a8773275873d96c7025025c89ea19b24b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        echo "Region Maintenance";
        
        $__internal_e1a96c76a70248de5ca2eda5b2bd31a8773275873d96c7025025c89ea19b24b0->leave($__internal_e1a96c76a70248de5ca2eda5b2bd31a8773275873d96c7025025c89ea19b24b0_prof);

        
        $__internal_59c0b0767652a98ed5336be50b1f8565a773d54b99751542bfe67b63c8fe0f48->leave($__internal_59c0b0767652a98ed5336be50b1f8565a773d54b99751542bfe67b63c8fe0f48_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_65027a6e24a467c735663bedeea94aba346b4eb8d2d54e32195acb1ac4a86b78 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_65027a6e24a467c735663bedeea94aba346b4eb8d2d54e32195acb1ac4a86b78->enter($__internal_65027a6e24a467c735663bedeea94aba346b4eb8d2d54e32195acb1ac4a86b78_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_f8e71c84de84e50c3ca2f26aa33ac16e4f18d7541c613f614961fd1d303bb24c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f8e71c84de84e50c3ca2f26aa33ac16e4f18d7541c613f614961fd1d303bb24c->enter($__internal_f8e71c84de84e50c3ca2f26aa33ac16e4f18d7541c613f614961fd1d303bb24c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo "    <div class=\"row col-md-20 col-md-offset-0 custyle\">
        <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_add");
        echo "\" class=\"btn btn-primary btn-xs pull-right\"><span class=\"glyphicon glyphicon-plus\"></span> Add</a>
        <table class=\"table table-striped custab table-region\">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Image</th>
                    <th>Characteristics</th>
                    <th>Latitude</th>
                    <th>Longitude</th>
                    <th class=\"text-center\">Action</th>
                </tr>
            </thead>
            <tbody>
            ";
        // line 25
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["regions"] ?? $this->getContext($context, "regions")));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 26
            echo "                <tr>
                    <td> ";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "</td>
                    <td> ";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo " </td>
                    <td class=\"text-area\" style=\"text-align: justify\">";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getDescription", array(), "method"), "html", null, true);
            echo " </td>
                    <td> <img src=\"../../..";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage", array(), "method"), "html", null, true);
            echo "\" class=\"mediana\"></td>
                    <td class=\"text-area\"> ";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getCharacteristics", array(), "method"), "html", null, true);
            echo "</td>
                    <td> ";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getLatitude", array(), "method"), "html", null, true);
            echo "</td>
                    <td> ";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getLongitude", array(), "method"), "html", null, true);
            echo "</td>
                    <td class=\"text-center\">
                        ";
            // line 36
            echo "                        <a class='btn btn-info btn-xs btn-edit' style=\"margin-top: 10px\" id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-edit\"></span> Edit</a>
                        <a href=\"";
            // line 37
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_delete", array("id" => $this->getAttribute($context["temp"], "getId", array(), "method"))), "html", null, true);
            echo "\" class=\"btn btn-danger btn-xs\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-remove\"></span> Delete</a>
                    </td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 41
        echo "            </tbody>
        </table>
    </div>
";
        
        $__internal_f8e71c84de84e50c3ca2f26aa33ac16e4f18d7541c613f614961fd1d303bb24c->leave($__internal_f8e71c84de84e50c3ca2f26aa33ac16e4f18d7541c613f614961fd1d303bb24c_prof);

        
        $__internal_65027a6e24a467c735663bedeea94aba346b4eb8d2d54e32195acb1ac4a86b78->leave($__internal_65027a6e24a467c735663bedeea94aba346b4eb8d2d54e32195acb1ac4a86b78_prof);

    }

    // line 47
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_1d6c36c734f37c37af396927f34177c2df2f034a66ba843d2cbbcc52db14489f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1d6c36c734f37c37af396927f34177c2df2f034a66ba843d2cbbcc52db14489f->enter($__internal_1d6c36c734f37c37af396927f34177c2df2f034a66ba843d2cbbcc52db14489f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_88ef2a0fe026d1dd25863bb971f597b74cead7a4dc66ad39fb374c58f6ee2338 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_88ef2a0fe026d1dd25863bb971f597b74cead7a4dc66ad39fb374c58f6ee2338->enter($__internal_88ef2a0fe026d1dd25863bb971f597b74cead7a4dc66ad39fb374c58f6ee2338_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 48
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 49
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
";
        
        $__internal_88ef2a0fe026d1dd25863bb971f597b74cead7a4dc66ad39fb374c58f6ee2338->leave($__internal_88ef2a0fe026d1dd25863bb971f597b74cead7a4dc66ad39fb374c58f6ee2338_prof);

        
        $__internal_1d6c36c734f37c37af396927f34177c2df2f034a66ba843d2cbbcc52db14489f->leave($__internal_1d6c36c734f37c37af396927f34177c2df2f034a66ba843d2cbbcc52db14489f_prof);

    }

    // line 52
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_1a6036626b88e06b063cf64c4f950679e70529c8e9dc640ada1a79bba2ecdc7a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1a6036626b88e06b063cf64c4f950679e70529c8e9dc640ada1a79bba2ecdc7a->enter($__internal_1a6036626b88e06b063cf64c4f950679e70529c8e9dc640ada1a79bba2ecdc7a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_13a51537696a1e410ec0357faf96a0248502e2fcf3b198f1a0e230a16074f848 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_13a51537696a1e410ec0357faf96a0248502e2fcf3b198f1a0e230a16074f848->enter($__internal_13a51537696a1e410ec0357faf96a0248502e2fcf3b198f1a0e230a16074f848_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 53
        echo "    <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 54
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./js/regions.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_13a51537696a1e410ec0357faf96a0248502e2fcf3b198f1a0e230a16074f848->leave($__internal_13a51537696a1e410ec0357faf96a0248502e2fcf3b198f1a0e230a16074f848_prof);

        
        $__internal_1a6036626b88e06b063cf64c4f950679e70529c8e9dc640ada1a79bba2ecdc7a->leave($__internal_1a6036626b88e06b063cf64c4f950679e70529c8e9dc640ada1a79bba2ecdc7a_prof);

    }

    public function getTemplateName()
    {
        return "RegionBundle:Default:region.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  214 => 54,  209 => 53,  200 => 52,  188 => 49,  183 => 48,  174 => 47,  161 => 41,  151 => 37,  146 => 36,  141 => 33,  137 => 32,  133 => 31,  129 => 30,  125 => 29,  121 => 28,  117 => 27,  114 => 26,  110 => 25,  92 => 10,  89 => 9,  80 => 8,  62 => 6,  44 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Region Maintenance{% endblock %}

{% block navbar %}Region Maintenance{% endblock %}

{% block body %}
    <div class=\"row col-md-20 col-md-offset-0 custyle\">
        <a href=\"{{ path('region_add') }}\" class=\"btn btn-primary btn-xs pull-right\"><span class=\"glyphicon glyphicon-plus\"></span> Add</a>
        <table class=\"table table-striped custab table-region\">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Image</th>
                    <th>Characteristics</th>
                    <th>Latitude</th>
                    <th>Longitude</th>
                    <th class=\"text-center\">Action</th>
                </tr>
            </thead>
            <tbody>
            {% for temp in regions %}
                <tr>
                    <td> {{ temp.getId() }}</td>
                    <td> {{ temp.getName() }} </td>
                    <td class=\"text-area\" style=\"text-align: justify\">{{ temp.getDescription() }} </td>
                    <td> <img src=\"../../..{{ temp.getImage() }}\" class=\"mediana\"></td>
                    <td class=\"text-area\"> {{ temp.getCharacteristics() }}</td>
                    <td> {{ temp.getLatitude() }}</td>
                    <td> {{ temp.getLongitude() }}</td>
                    <td class=\"text-center\">
                        {#<a class='btn btn-info btn-xs btn-edit' href=\"{{ path('region_edit') }}\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-edit\"></span> Edit</a>#}
                        <a class='btn btn-info btn-xs btn-edit' style=\"margin-top: 10px\" id=\"{{ temp.getId() }}\"><span class=\"glyphicon glyphicon-edit\"></span> Edit</a>
                        <a href=\"{{ path('region_delete', { 'id': temp.getId() }) }}\" class=\"btn btn-danger btn-xs\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-remove\"></span> Delete</a>
                    </td>
                </tr>
            {% endfor %}
            </tbody>
        </table>
    </div>
{% endblock %}


{% block stylesheets %}
    {{parent()}}
    <link rel=\"stylesheet\" href=\"{{ asset('css/crgourmetcoffee.css') }}\">
{% endblock %}

{% block javascripts %}
    <script type=\"text/javascript\" src=\"{{ asset('./js/jquery-3.2.0.min.js') }}\"></script>
    <script type=\"text/javascript\" src=\"{{ asset('./js/regions.js') }}\"></script>
{% endblock %}
", "RegionBundle:Default:region.html.twig", "C:\\xampp\\htdocs\\Maintenance\\src\\RegionBundle/Resources/views/Default/region.html.twig");
    }
}
