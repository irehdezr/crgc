<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_007ddbb7d0eba1c1746c036d4424e8bf49612a9d4c91bfa659b14afcb64fe551 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4b510c1bcbcddf2a2ef4aed8aa4eb0d43d6fd2d73821a6762160643e5c4e80d5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4b510c1bcbcddf2a2ef4aed8aa4eb0d43d6fd2d73821a6762160643e5c4e80d5->enter($__internal_4b510c1bcbcddf2a2ef4aed8aa4eb0d43d6fd2d73821a6762160643e5c4e80d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_c966b9fdaa3dffdc5963b2a0ebe8a951c6a7c23600c3a905dd68b2b46cb2ab86 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c966b9fdaa3dffdc5963b2a0ebe8a951c6a7c23600c3a905dd68b2b46cb2ab86->enter($__internal_c966b9fdaa3dffdc5963b2a0ebe8a951c6a7c23600c3a905dd68b2b46cb2ab86_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4b510c1bcbcddf2a2ef4aed8aa4eb0d43d6fd2d73821a6762160643e5c4e80d5->leave($__internal_4b510c1bcbcddf2a2ef4aed8aa4eb0d43d6fd2d73821a6762160643e5c4e80d5_prof);

        
        $__internal_c966b9fdaa3dffdc5963b2a0ebe8a951c6a7c23600c3a905dd68b2b46cb2ab86->leave($__internal_c966b9fdaa3dffdc5963b2a0ebe8a951c6a7c23600c3a905dd68b2b46cb2ab86_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_5173e3020ef4304858e6d615c4ce037c8433b3a66d2b732e7a89c0ff7d7e7dc4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5173e3020ef4304858e6d615c4ce037c8433b3a66d2b732e7a89c0ff7d7e7dc4->enter($__internal_5173e3020ef4304858e6d615c4ce037c8433b3a66d2b732e7a89c0ff7d7e7dc4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_a6d19bae08a41540fd82b6a2c35acf26bde4bb35c9dfb7086cffb2d03258ac9f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a6d19bae08a41540fd82b6a2c35acf26bde4bb35c9dfb7086cffb2d03258ac9f->enter($__internal_a6d19bae08a41540fd82b6a2c35acf26bde4bb35c9dfb7086cffb2d03258ac9f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_a6d19bae08a41540fd82b6a2c35acf26bde4bb35c9dfb7086cffb2d03258ac9f->leave($__internal_a6d19bae08a41540fd82b6a2c35acf26bde4bb35c9dfb7086cffb2d03258ac9f_prof);

        
        $__internal_5173e3020ef4304858e6d615c4ce037c8433b3a66d2b732e7a89c0ff7d7e7dc4->leave($__internal_5173e3020ef4304858e6d615c4ce037c8433b3a66d2b732e7a89c0ff7d7e7dc4_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_b932f40bc4b4d72ba00babef6a12f3c36047ba975bd513dd21fad6a528e4b130 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b932f40bc4b4d72ba00babef6a12f3c36047ba975bd513dd21fad6a528e4b130->enter($__internal_b932f40bc4b4d72ba00babef6a12f3c36047ba975bd513dd21fad6a528e4b130_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_d4a3eda21a84e6b1dac8300dc250395cb37d0f2694f9a67d2a1d099527a61f38 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d4a3eda21a84e6b1dac8300dc250395cb37d0f2694f9a67d2a1d099527a61f38->enter($__internal_d4a3eda21a84e6b1dac8300dc250395cb37d0f2694f9a67d2a1d099527a61f38_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_d4a3eda21a84e6b1dac8300dc250395cb37d0f2694f9a67d2a1d099527a61f38->leave($__internal_d4a3eda21a84e6b1dac8300dc250395cb37d0f2694f9a67d2a1d099527a61f38_prof);

        
        $__internal_b932f40bc4b4d72ba00babef6a12f3c36047ba975bd513dd21fad6a528e4b130->leave($__internal_b932f40bc4b4d72ba00babef6a12f3c36047ba975bd513dd21fad6a528e4b130_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_03b49a1495e2c1375a6e1e83eecdfb6c0b4bf040d81809f4aa807d6fc935c5c2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_03b49a1495e2c1375a6e1e83eecdfb6c0b4bf040d81809f4aa807d6fc935c5c2->enter($__internal_03b49a1495e2c1375a6e1e83eecdfb6c0b4bf040d81809f4aa807d6fc935c5c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_be94078de5cb0bf9cf05c42b843b006a6794921241fd5772c20d8623d0063001 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_be94078de5cb0bf9cf05c42b843b006a6794921241fd5772c20d8623d0063001->enter($__internal_be94078de5cb0bf9cf05c42b843b006a6794921241fd5772c20d8623d0063001_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_be94078de5cb0bf9cf05c42b843b006a6794921241fd5772c20d8623d0063001->leave($__internal_be94078de5cb0bf9cf05c42b843b006a6794921241fd5772c20d8623d0063001_prof);

        
        $__internal_03b49a1495e2c1375a6e1e83eecdfb6c0b4bf040d81809f4aa807d6fc935c5c2->leave($__internal_03b49a1495e2c1375a6e1e83eecdfb6c0b4bf040d81809f4aa807d6fc935c5c2_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\xampp\\htdocs\\Maintenance\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
