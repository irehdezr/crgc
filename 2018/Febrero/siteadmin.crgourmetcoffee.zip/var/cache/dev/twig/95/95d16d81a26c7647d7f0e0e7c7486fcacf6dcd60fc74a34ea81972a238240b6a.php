<?php

/* RegionBundle:Default:insert.html.twig */
class __TwigTemplate_913cc7b327e0a96444547b914c1fb2ebdeffd0e6009554997d6095752b4e19af extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "RegionBundle:Default:insert.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'navbar' => array($this, 'block_navbar'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5b31a5ce789f7d615dbbca44ba8bda65fdc9a643b5ffdd011d743251edf38f60 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5b31a5ce789f7d615dbbca44ba8bda65fdc9a643b5ffdd011d743251edf38f60->enter($__internal_5b31a5ce789f7d615dbbca44ba8bda65fdc9a643b5ffdd011d743251edf38f60_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "RegionBundle:Default:insert.html.twig"));

        $__internal_ffb59fedfcc55c8bc22cfa47f3b7da842faf39390ca7b603feebe7196a998b34 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ffb59fedfcc55c8bc22cfa47f3b7da842faf39390ca7b603feebe7196a998b34->enter($__internal_ffb59fedfcc55c8bc22cfa47f3b7da842faf39390ca7b603feebe7196a998b34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "RegionBundle:Default:insert.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5b31a5ce789f7d615dbbca44ba8bda65fdc9a643b5ffdd011d743251edf38f60->leave($__internal_5b31a5ce789f7d615dbbca44ba8bda65fdc9a643b5ffdd011d743251edf38f60_prof);

        
        $__internal_ffb59fedfcc55c8bc22cfa47f3b7da842faf39390ca7b603feebe7196a998b34->leave($__internal_ffb59fedfcc55c8bc22cfa47f3b7da842faf39390ca7b603feebe7196a998b34_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_d1c3c9aeaff5c24810d36a38a44c1c07afcfa15960c2a7262aeb181193f0f76d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d1c3c9aeaff5c24810d36a38a44c1c07afcfa15960c2a7262aeb181193f0f76d->enter($__internal_d1c3c9aeaff5c24810d36a38a44c1c07afcfa15960c2a7262aeb181193f0f76d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_5115670c7e18db83d3bc8617b9ac01975a8c07c8cbdc2dc7d5b9ae760136ce3c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5115670c7e18db83d3bc8617b9ac01975a8c07c8cbdc2dc7d5b9ae760136ce3c->enter($__internal_5115670c7e18db83d3bc8617b9ac01975a8c07c8cbdc2dc7d5b9ae760136ce3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Region Add";
        
        $__internal_5115670c7e18db83d3bc8617b9ac01975a8c07c8cbdc2dc7d5b9ae760136ce3c->leave($__internal_5115670c7e18db83d3bc8617b9ac01975a8c07c8cbdc2dc7d5b9ae760136ce3c_prof);

        
        $__internal_d1c3c9aeaff5c24810d36a38a44c1c07afcfa15960c2a7262aeb181193f0f76d->leave($__internal_d1c3c9aeaff5c24810d36a38a44c1c07afcfa15960c2a7262aeb181193f0f76d_prof);

    }

    // line 6
    public function block_navbar($context, array $blocks = array())
    {
        $__internal_13b39d70c36847f23386cac547f9906ec067d8e0854dc6ebc4e3f0548c8a6543 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_13b39d70c36847f23386cac547f9906ec067d8e0854dc6ebc4e3f0548c8a6543->enter($__internal_13b39d70c36847f23386cac547f9906ec067d8e0854dc6ebc4e3f0548c8a6543_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        $__internal_7f509ea0a4cb8ea1fc111e5210f631b6ed2442c7e8d2f16c73103856d82f4398 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7f509ea0a4cb8ea1fc111e5210f631b6ed2442c7e8d2f16c73103856d82f4398->enter($__internal_7f509ea0a4cb8ea1fc111e5210f631b6ed2442c7e8d2f16c73103856d82f4398_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        echo "Region Maintenance - Add";
        
        $__internal_7f509ea0a4cb8ea1fc111e5210f631b6ed2442c7e8d2f16c73103856d82f4398->leave($__internal_7f509ea0a4cb8ea1fc111e5210f631b6ed2442c7e8d2f16c73103856d82f4398_prof);

        
        $__internal_13b39d70c36847f23386cac547f9906ec067d8e0854dc6ebc4e3f0548c8a6543->leave($__internal_13b39d70c36847f23386cac547f9906ec067d8e0854dc6ebc4e3f0548c8a6543_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_01b0ac6427097bbb1508ee34b12cfb48305da92e70ef3ccf8445368512e380fc = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_01b0ac6427097bbb1508ee34b12cfb48305da92e70ef3ccf8445368512e380fc->enter($__internal_01b0ac6427097bbb1508ee34b12cfb48305da92e70ef3ccf8445368512e380fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_e44dfa65b48a571c97ff0d3fb12de4b60a075931611df22354a4a7c6e286ac02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e44dfa65b48a571c97ff0d3fb12de4b60a075931611df22354a4a7c6e286ac02->enter($__internal_e44dfa65b48a571c97ff0d3fb12de4b60a075931611df22354a4a7c6e286ac02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo "    <div class=\"row col-md-8 col-md-offset-2 custyle\" style=\"margin-top: 20px\">
        <table class=\"table table-striped custab\">
            <tbody>
                <tr>
                    <th>Name</th>
                    <td><input type=\"text\" name=\"name\" value=\"\" id=\"name\"></td>
                </tr>
                <tr>
                    <th>Description</th>
                    <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\"></textarea></td>
                </tr>
                <tr>
                    <th>Image</th>
                    <td> imagen</td>
                </tr>
                <tr>
                    <th>Characteristics</th>
                    <td><textarea name=\"characteristics\" rows=\"7\" cols=\"45\" id=\"characteristics\"></textarea></td>
                </tr>
                <tr>
                    <th>Latitude</th>
                    <td><input type=\"text\" name=\"latitude\" value=\"\" id=\"latitude\"></td>
                </tr>
                <tr>
                    <th>Longitude</th>
                    <td><input type=\"text\" name=\"longitude\" value=\"\" id=\"longitude\"></td>
                </tr>
                <tr>
                    <td class=\"text-center\" colspan=\"2\">
                        <a class='btn btn-success btn-xs btn-insert' style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-save\"></span> Save</a>
                        <a href=\"";
        // line 39
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_homepage");
        echo "\" class=\"btn btn-warning btn-xs\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancel</a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
";
        
        $__internal_e44dfa65b48a571c97ff0d3fb12de4b60a075931611df22354a4a7c6e286ac02->leave($__internal_e44dfa65b48a571c97ff0d3fb12de4b60a075931611df22354a4a7c6e286ac02_prof);

        
        $__internal_01b0ac6427097bbb1508ee34b12cfb48305da92e70ef3ccf8445368512e380fc->leave($__internal_01b0ac6427097bbb1508ee34b12cfb48305da92e70ef3ccf8445368512e380fc_prof);

    }

    // line 48
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_d10fe303b6d9811aaca883a259b497d661b1cf9a7982038895f7f888025bba61 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d10fe303b6d9811aaca883a259b497d661b1cf9a7982038895f7f888025bba61->enter($__internal_d10fe303b6d9811aaca883a259b497d661b1cf9a7982038895f7f888025bba61_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_d860f46081ab3aede040806cfa851e8171145f59c637b95da17fbcedbb73dc19 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d860f46081ab3aede040806cfa851e8171145f59c637b95da17fbcedbb73dc19->enter($__internal_d860f46081ab3aede040806cfa851e8171145f59c637b95da17fbcedbb73dc19_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 49
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/styles.css"), "html", null, true);
        echo "\">
";
        
        $__internal_d860f46081ab3aede040806cfa851e8171145f59c637b95da17fbcedbb73dc19->leave($__internal_d860f46081ab3aede040806cfa851e8171145f59c637b95da17fbcedbb73dc19_prof);

        
        $__internal_d10fe303b6d9811aaca883a259b497d661b1cf9a7982038895f7f888025bba61->leave($__internal_d10fe303b6d9811aaca883a259b497d661b1cf9a7982038895f7f888025bba61_prof);

    }

    // line 52
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_50efbd0110f174663cc5ee31af3d2ad415089671a8178d27136e7362b630ca07 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_50efbd0110f174663cc5ee31af3d2ad415089671a8178d27136e7362b630ca07->enter($__internal_50efbd0110f174663cc5ee31af3d2ad415089671a8178d27136e7362b630ca07_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_0501b4aaf61587ab3d75607332c15822839ea9b212ebd7b139882091007e4915 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0501b4aaf61587ab3d75607332c15822839ea9b212ebd7b139882091007e4915->enter($__internal_0501b4aaf61587ab3d75607332c15822839ea9b212ebd7b139882091007e4915_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 53
        echo "    <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 54
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./js/regions.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_0501b4aaf61587ab3d75607332c15822839ea9b212ebd7b139882091007e4915->leave($__internal_0501b4aaf61587ab3d75607332c15822839ea9b212ebd7b139882091007e4915_prof);

        
        $__internal_50efbd0110f174663cc5ee31af3d2ad415089671a8178d27136e7362b630ca07->leave($__internal_50efbd0110f174663cc5ee31af3d2ad415089671a8178d27136e7362b630ca07_prof);

    }

    public function getTemplateName()
    {
        return "RegionBundle:Default:insert.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  174 => 54,  169 => 53,  160 => 52,  147 => 49,  138 => 48,  121 => 39,  89 => 9,  80 => 8,  62 => 6,  44 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Region Add{% endblock %}

{% block navbar %}Region Maintenance - Add{% endblock %}

{% block body %}
    <div class=\"row col-md-8 col-md-offset-2 custyle\" style=\"margin-top: 20px\">
        <table class=\"table table-striped custab\">
            <tbody>
                <tr>
                    <th>Name</th>
                    <td><input type=\"text\" name=\"name\" value=\"\" id=\"name\"></td>
                </tr>
                <tr>
                    <th>Description</th>
                    <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\"></textarea></td>
                </tr>
                <tr>
                    <th>Image</th>
                    <td> imagen</td>
                </tr>
                <tr>
                    <th>Characteristics</th>
                    <td><textarea name=\"characteristics\" rows=\"7\" cols=\"45\" id=\"characteristics\"></textarea></td>
                </tr>
                <tr>
                    <th>Latitude</th>
                    <td><input type=\"text\" name=\"latitude\" value=\"\" id=\"latitude\"></td>
                </tr>
                <tr>
                    <th>Longitude</th>
                    <td><input type=\"text\" name=\"longitude\" value=\"\" id=\"longitude\"></td>
                </tr>
                <tr>
                    <td class=\"text-center\" colspan=\"2\">
                        <a class='btn btn-success btn-xs btn-insert' style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-save\"></span> Save</a>
                        <a href=\"{{ path('region_homepage') }}\" class=\"btn btn-warning btn-xs\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancel</a>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
{% endblock %}


{% block stylesheets %}
    <link rel=\"stylesheet\" href=\"{{ asset('css/styles.css') }}\">
{% endblock %}

{% block javascripts %}
    <script type=\"text/javascript\" src=\"{{ asset('./js/jquery-3.2.0.min.js') }}\"></script>
    <script type=\"text/javascript\" src=\"{{ asset('./js/regions.js') }}\"></script>
{% endblock %}
", "RegionBundle:Default:insert.html.twig", "C:\\xampp\\htdocs\\Maintenance\\src\\RegionBundle/Resources/views/Default/insert.html.twig");
    }
}
