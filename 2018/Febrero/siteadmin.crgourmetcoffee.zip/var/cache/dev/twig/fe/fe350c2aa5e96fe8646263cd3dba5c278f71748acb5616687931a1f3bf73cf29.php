<?php

/* AppBundle:Default:home.html.twig */
class __TwigTemplate_c01bd66a087161641a7553d92742de30dc8127f17a44528eee5edf7b7a7c4059 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "AppBundle:Default:home.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4b418b6e8302e4426efd16444cac2ec7b8d61020a10ce17d5b781be8b1c6c5ea = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4b418b6e8302e4426efd16444cac2ec7b8d61020a10ce17d5b781be8b1c6c5ea->enter($__internal_4b418b6e8302e4426efd16444cac2ec7b8d61020a10ce17d5b781be8b1c6c5ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Default:home.html.twig"));

        $__internal_82caf8ab5ebc18005dbe367777adb4114c930f5369ece8033a5b0b0fa509d0a2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_82caf8ab5ebc18005dbe367777adb4114c930f5369ece8033a5b0b0fa509d0a2->enter($__internal_82caf8ab5ebc18005dbe367777adb4114c930f5369ece8033a5b0b0fa509d0a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Default:home.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4b418b6e8302e4426efd16444cac2ec7b8d61020a10ce17d5b781be8b1c6c5ea->leave($__internal_4b418b6e8302e4426efd16444cac2ec7b8d61020a10ce17d5b781be8b1c6c5ea_prof);

        
        $__internal_82caf8ab5ebc18005dbe367777adb4114c930f5369ece8033a5b0b0fa509d0a2->leave($__internal_82caf8ab5ebc18005dbe367777adb4114c930f5369ece8033a5b0b0fa509d0a2_prof);

    }

    // line 4
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_a2b30c2fdd1e32c08128d2cbf5d8ce6aa7843c0b42f91c8f8c137487c276432f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a2b30c2fdd1e32c08128d2cbf5d8ce6aa7843c0b42f91c8f8c137487c276432f->enter($__internal_a2b30c2fdd1e32c08128d2cbf5d8ce6aa7843c0b42f91c8f8c137487c276432f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_8787bfeac680bcfdab5454f446bee1f084cba2a88b594ece7c84b1e1e1c21fb0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8787bfeac680bcfdab5454f446bee1f084cba2a88b594ece7c84b1e1e1c21fb0->enter($__internal_8787bfeac680bcfdab5454f446bee1f084cba2a88b594ece7c84b1e1e1c21fb0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 5
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/styles.css"), "html", null, true);
        echo "\">
";
        
        $__internal_8787bfeac680bcfdab5454f446bee1f084cba2a88b594ece7c84b1e1e1c21fb0->leave($__internal_8787bfeac680bcfdab5454f446bee1f084cba2a88b594ece7c84b1e1e1c21fb0_prof);

        
        $__internal_a2b30c2fdd1e32c08128d2cbf5d8ce6aa7843c0b42f91c8f8c137487c276432f->leave($__internal_a2b30c2fdd1e32c08128d2cbf5d8ce6aa7843c0b42f91c8f8c137487c276432f_prof);

    }

    // line 8
    public function block_title($context, array $blocks = array())
    {
        $__internal_f895ca55ab6530aaa9a378ec6b4e8bd50d0a6a7533f84fa5a4b2724b43af6e75 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f895ca55ab6530aaa9a378ec6b4e8bd50d0a6a7533f84fa5a4b2724b43af6e75->enter($__internal_f895ca55ab6530aaa9a378ec6b4e8bd50d0a6a7533f84fa5a4b2724b43af6e75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_0d5b104cfb4d9a370d5635f6f07d60f560e49f3e41acc194c4648f04c3072c71 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0d5b104cfb4d9a370d5635f6f07d60f560e49f3e41acc194c4648f04c3072c71->enter($__internal_0d5b104cfb4d9a370d5635f6f07d60f560e49f3e41acc194c4648f04c3072c71_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 9
        echo "    Homepage
";
        
        $__internal_0d5b104cfb4d9a370d5635f6f07d60f560e49f3e41acc194c4648f04c3072c71->leave($__internal_0d5b104cfb4d9a370d5635f6f07d60f560e49f3e41acc194c4648f04c3072c71_prof);

        
        $__internal_f895ca55ab6530aaa9a378ec6b4e8bd50d0a6a7533f84fa5a4b2724b43af6e75->leave($__internal_f895ca55ab6530aaa9a378ec6b4e8bd50d0a6a7533f84fa5a4b2724b43af6e75_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_e5d6999515083167896a5273209f12e8a7ef462ddecd4d5d968d75360f62b1fb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e5d6999515083167896a5273209f12e8a7ef462ddecd4d5d968d75360f62b1fb->enter($__internal_e5d6999515083167896a5273209f12e8a7ef462ddecd4d5d968d75360f62b1fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_ccf23f8e07a093a73303158633cd450d993c25e3884109b4715d9f1c265a0376 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ccf23f8e07a093a73303158633cd450d993c25e3884109b4715d9f1c265a0376->enter($__internal_ccf23f8e07a093a73303158633cd450d993c25e3884109b4715d9f1c265a0376_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    <div class=\"row col-md-9 col-md-offset-1 custyle\">
        <table class=\"table table-striped custab\">
            <thead>
                <tr>
                    <th>Title</th>
                    <th class=\"text-center\">Action</th>
                </tr>
            </thead>
            <tr>
                <td>Regions</td>
                <td class=\"text-center\">
                    <a class='btn btn-primary btn-xs' href=\"";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_homepage");
        echo "\">
                        <span class=\"glyphicon glyphicon-ok\"></span> Select</a>
                </td>
            </tr>
            <tr>
                <td>Farm Information</td>
                <td class=\"text-center\">
                    <a class='btn btn-primary btn-xs' href=\"";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_homepage");
        echo "\">
                        <span class=\"glyphicon glyphicon-ok\"></span> Select</a>
                </td>
            </tr>
        </table>
    </div>
";
        
        $__internal_ccf23f8e07a093a73303158633cd450d993c25e3884109b4715d9f1c265a0376->leave($__internal_ccf23f8e07a093a73303158633cd450d993c25e3884109b4715d9f1c265a0376_prof);

        
        $__internal_e5d6999515083167896a5273209f12e8a7ef462ddecd4d5d968d75360f62b1fb->leave($__internal_e5d6999515083167896a5273209f12e8a7ef462ddecd4d5d968d75360f62b1fb_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Default:home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  120 => 30,  110 => 23,  97 => 12,  88 => 11,  77 => 9,  68 => 8,  56 => 6,  51 => 5,  42 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block stylesheets %}
    {{parent()}}
    <link rel=\"stylesheet\" href=\"{{ asset('css/styles.css') }}\">
{% endblock %}
{% block title %}
    Homepage
{% endblock %}
{% block body %}
    <div class=\"row col-md-9 col-md-offset-1 custyle\">
        <table class=\"table table-striped custab\">
            <thead>
                <tr>
                    <th>Title</th>
                    <th class=\"text-center\">Action</th>
                </tr>
            </thead>
            <tr>
                <td>Regions</td>
                <td class=\"text-center\">
                    <a class='btn btn-primary btn-xs' href=\"{{ path('region_homepage') }}\">
                        <span class=\"glyphicon glyphicon-ok\"></span> Select</a>
                </td>
            </tr>
            <tr>
                <td>Farm Information</td>
                <td class=\"text-center\">
                    <a class='btn btn-primary btn-xs' href=\"{{ path('farm_homepage') }}\">
                        <span class=\"glyphicon glyphicon-ok\"></span> Select</a>
                </td>
            </tr>
        </table>
    </div>
{% endblock %}

{#{% block javascripts %}
    <script type=\"text/javascript\" src=\"{{ asset('./js/jquery-3.2.0.min.js') }}\"></script>
    <script type=\"text/javascript\" src=\"{{ asset('./js/home.js') }}\"></script>
{% endblock %}#}
", "AppBundle:Default:home.html.twig", "C:\\xampp\\htdocs\\Maintenance\\src\\AppBundle/Resources/views/Default/home.html.twig");
    }
}
