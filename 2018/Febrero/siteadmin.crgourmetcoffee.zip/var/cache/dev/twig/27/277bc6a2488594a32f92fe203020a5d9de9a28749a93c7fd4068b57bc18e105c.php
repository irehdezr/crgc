<?php

/* FarmBundle:Default:edit.html.twig */
class __TwigTemplate_25e7cf7d7ee5b719e26b7476113ebe58627b4b1f645739087e2a81adafcc779d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "FarmBundle:Default:edit.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'navbar' => array($this, 'block_navbar'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3ace047f9a259df4452e88b30c467ec248e068a1c5487aa5d389d67ae9cf4e3b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3ace047f9a259df4452e88b30c467ec248e068a1c5487aa5d389d67ae9cf4e3b->enter($__internal_3ace047f9a259df4452e88b30c467ec248e068a1c5487aa5d389d67ae9cf4e3b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FarmBundle:Default:edit.html.twig"));

        $__internal_1eabc2e0d6d4b70282de9b75a61fa6f8f9c08eaf05dac186eeb40404729fdea3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1eabc2e0d6d4b70282de9b75a61fa6f8f9c08eaf05dac186eeb40404729fdea3->enter($__internal_1eabc2e0d6d4b70282de9b75a61fa6f8f9c08eaf05dac186eeb40404729fdea3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FarmBundle:Default:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3ace047f9a259df4452e88b30c467ec248e068a1c5487aa5d389d67ae9cf4e3b->leave($__internal_3ace047f9a259df4452e88b30c467ec248e068a1c5487aa5d389d67ae9cf4e3b_prof);

        
        $__internal_1eabc2e0d6d4b70282de9b75a61fa6f8f9c08eaf05dac186eeb40404729fdea3->leave($__internal_1eabc2e0d6d4b70282de9b75a61fa6f8f9c08eaf05dac186eeb40404729fdea3_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_bc97cc2cfde9956904793ea4c834d38a86212dafc3f57756c17c1f4c2dba43c9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bc97cc2cfde9956904793ea4c834d38a86212dafc3f57756c17c1f4c2dba43c9->enter($__internal_bc97cc2cfde9956904793ea4c834d38a86212dafc3f57756c17c1f4c2dba43c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_212a4a429391d8272f231290004b77b8ab53e55134217e9b74d72d4dca9b908c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_212a4a429391d8272f231290004b77b8ab53e55134217e9b74d72d4dca9b908c->enter($__internal_212a4a429391d8272f231290004b77b8ab53e55134217e9b74d72d4dca9b908c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Farm Maintenance";
        
        $__internal_212a4a429391d8272f231290004b77b8ab53e55134217e9b74d72d4dca9b908c->leave($__internal_212a4a429391d8272f231290004b77b8ab53e55134217e9b74d72d4dca9b908c_prof);

        
        $__internal_bc97cc2cfde9956904793ea4c834d38a86212dafc3f57756c17c1f4c2dba43c9->leave($__internal_bc97cc2cfde9956904793ea4c834d38a86212dafc3f57756c17c1f4c2dba43c9_prof);

    }

    // line 6
    public function block_navbar($context, array $blocks = array())
    {
        $__internal_e3c1b2b01e3042a8d7ba2fdc5b0392fe96f7b2584ba1065db93a28cabf82e838 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e3c1b2b01e3042a8d7ba2fdc5b0392fe96f7b2584ba1065db93a28cabf82e838->enter($__internal_e3c1b2b01e3042a8d7ba2fdc5b0392fe96f7b2584ba1065db93a28cabf82e838_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        $__internal_32a527b7f816ba5bf3888f8b6e497a6785b42c3ac2a3321adbb3014d1bee52ab = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_32a527b7f816ba5bf3888f8b6e497a6785b42c3ac2a3321adbb3014d1bee52ab->enter($__internal_32a527b7f816ba5bf3888f8b6e497a6785b42c3ac2a3321adbb3014d1bee52ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        echo "Farm Maintenance - Edit";
        
        $__internal_32a527b7f816ba5bf3888f8b6e497a6785b42c3ac2a3321adbb3014d1bee52ab->leave($__internal_32a527b7f816ba5bf3888f8b6e497a6785b42c3ac2a3321adbb3014d1bee52ab_prof);

        
        $__internal_e3c1b2b01e3042a8d7ba2fdc5b0392fe96f7b2584ba1065db93a28cabf82e838->leave($__internal_e3c1b2b01e3042a8d7ba2fdc5b0392fe96f7b2584ba1065db93a28cabf82e838_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_9070467fde2176d67d9005d4eab112b3119999ce454867de18b286b3f38828ad = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9070467fde2176d67d9005d4eab112b3119999ce454867de18b286b3f38828ad->enter($__internal_9070467fde2176d67d9005d4eab112b3119999ce454867de18b286b3f38828ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_7c7f8b8b652a600286170a934263ad13abe3c9be712b53a2d3074ca12a337e51 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7c7f8b8b652a600286170a934263ad13abe3c9be712b53a2d3074ca12a337e51->enter($__internal_7c7f8b8b652a600286170a934263ad13abe3c9be712b53a2d3074ca12a337e51_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo "    <div class=\"row col-md-8 col-md-offset-2 custyle\" style=\"margin-top: 20px\">
        <table class=\"table table-striped custab\">
            <tbody>
            ";
        // line 12
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["farms"] ?? $this->getContext($context, "farms")));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 13
            echo "                <tr>
                    <th>ID</th>
                    <td> ";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "</td>
                </tr>
                <tr>
                    <th>Name</th>
                    <td><input type=\"text\" name=\"name\" value=\"";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo "\" id=\"name\"></td>
                </tr>
                <tr>
                    <th>Description</th>
                    <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\">";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getDescription", array(), "method"), "html", null, true);
            echo "</textarea></td>
                </tr>
                <tr>
                    <th>Image</th>
                    <td> <img src=\"../../../..";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage", array(), "method"), "html", null, true);
            echo "\" class=\"mediana\"></td>
                </tr>
                <tr>
                    <th>Elevation</th>
                    <td><input type=\"text\" name=\"elevation\" value=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getElevation", array(), "method"), "html", null, true);
            echo "\" id=\"elevation\"></td>
                </tr>
                <tr>
                    <th>Harvest</th>
                    <td><input type=\"text\" name=\"harvest\" value=\"";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getHarvest", array(), "method"), "html", null, true);
            echo "\" id=\"harvest\"></td>
                </tr>
                <tr>
                    <th>Latitude</th>
                    <td><input type=\"text\" name=\"latitude\" value=\"";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getLatitude", array(), "method"), "html", null, true);
            echo "\" id=\"latitude\"></td>
                </tr>
                <tr>
                    <th>Longitude</th>
                    <td><input type=\"text\" name=\"longitude\" value=\"";
            // line 43
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getLongitude", array(), "method"), "html", null, true);
            echo "\" id=\"longitude\"></td>
                </tr>
                <tr>
                    <td class=\"text-center\" colspan=\"2\">
                        <a class='btn btn-success btn-xs' href=\"";
            // line 47
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_save");
            echo "\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-save\"></span> Save</a>
                        <a href=\"";
            // line 48
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_homepage");
            echo "\" class=\"btn btn-warning btn-xs\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancel</a>
                    </td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 52
        echo "            </tbody>
        </table>
    </div>
";
        
        $__internal_7c7f8b8b652a600286170a934263ad13abe3c9be712b53a2d3074ca12a337e51->leave($__internal_7c7f8b8b652a600286170a934263ad13abe3c9be712b53a2d3074ca12a337e51_prof);

        
        $__internal_9070467fde2176d67d9005d4eab112b3119999ce454867de18b286b3f38828ad->leave($__internal_9070467fde2176d67d9005d4eab112b3119999ce454867de18b286b3f38828ad_prof);

    }

    // line 58
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_a81189a134c3c749fda3f011f53d2df561b7a5def7cd4a8b1785e92e9c64ace9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a81189a134c3c749fda3f011f53d2df561b7a5def7cd4a8b1785e92e9c64ace9->enter($__internal_a81189a134c3c749fda3f011f53d2df561b7a5def7cd4a8b1785e92e9c64ace9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_308c31e52e992d7258d9185eacca33ac4719dfd98e8d2ad1eadb0bb692bf4de8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_308c31e52e992d7258d9185eacca33ac4719dfd98e8d2ad1eadb0bb692bf4de8->enter($__internal_308c31e52e992d7258d9185eacca33ac4719dfd98e8d2ad1eadb0bb692bf4de8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 59
        echo "    <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/styles.css"), "html", null, true);
        echo "\">
";
        
        $__internal_308c31e52e992d7258d9185eacca33ac4719dfd98e8d2ad1eadb0bb692bf4de8->leave($__internal_308c31e52e992d7258d9185eacca33ac4719dfd98e8d2ad1eadb0bb692bf4de8_prof);

        
        $__internal_a81189a134c3c749fda3f011f53d2df561b7a5def7cd4a8b1785e92e9c64ace9->leave($__internal_a81189a134c3c749fda3f011f53d2df561b7a5def7cd4a8b1785e92e9c64ace9_prof);

    }

    public function getTemplateName()
    {
        return "FarmBundle:Default:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  193 => 59,  184 => 58,  171 => 52,  161 => 48,  157 => 47,  150 => 43,  143 => 39,  136 => 35,  129 => 31,  122 => 27,  115 => 23,  108 => 19,  101 => 15,  97 => 13,  93 => 12,  88 => 9,  79 => 8,  61 => 6,  43 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Farm Maintenance{% endblock %}

{% block navbar %}Farm Maintenance - Edit{% endblock %}

{% block body %}
    <div class=\"row col-md-8 col-md-offset-2 custyle\" style=\"margin-top: 20px\">
        <table class=\"table table-striped custab\">
            <tbody>
            {% for temp in farms %}
                <tr>
                    <th>ID</th>
                    <td> {{ temp.getId() }}</td>
                </tr>
                <tr>
                    <th>Name</th>
                    <td><input type=\"text\" name=\"name\" value=\"{{ temp.getName() }}\" id=\"name\"></td>
                </tr>
                <tr>
                    <th>Description</th>
                    <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\">{{ temp.getDescription() }}</textarea></td>
                </tr>
                <tr>
                    <th>Image</th>
                    <td> <img src=\"../../../..{{ temp.getImage() }}\" class=\"mediana\"></td>
                </tr>
                <tr>
                    <th>Elevation</th>
                    <td><input type=\"text\" name=\"elevation\" value=\"{{ temp.getElevation() }}\" id=\"elevation\"></td>
                </tr>
                <tr>
                    <th>Harvest</th>
                    <td><input type=\"text\" name=\"harvest\" value=\"{{ temp.getHarvest() }}\" id=\"harvest\"></td>
                </tr>
                <tr>
                    <th>Latitude</th>
                    <td><input type=\"text\" name=\"latitude\" value=\"{{ temp.getLatitude() }}\" id=\"latitude\"></td>
                </tr>
                <tr>
                    <th>Longitude</th>
                    <td><input type=\"text\" name=\"longitude\" value=\"{{ temp.getLongitude() }}\" id=\"longitude\"></td>
                </tr>
                <tr>
                    <td class=\"text-center\" colspan=\"2\">
                        <a class='btn btn-success btn-xs' href=\"{{ path('farm_save') }}\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-save\"></span> Save</a>
                        <a href=\"{{ path('farm_homepage') }}\" class=\"btn btn-warning btn-xs\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancel</a>
                    </td>
                </tr>
            {% endfor %}
            </tbody>
        </table>
    </div>
{% endblock %}


{% block stylesheets %}
    <link rel=\"stylesheet\" href=\"{{ asset('css/styles.css') }}\">
{% endblock %}


{#{% block javascripts %}
    <script type=\"text/javascript\" src=\"{{ asset('/js/jquery-3.2.0.min.js') }}\"></script>
    <script type=\"text/javascript\" src=\"{{ asset('/js/edit.js') }}\"></script>
{% endblock %}#}", "FarmBundle:Default:edit.html.twig", "C:\\xampp\\htdocs\\Maintenance\\src\\FarmBundle/Resources/views/Default/edit.html.twig");
    }
}
