<?php

/* layout.html.twig */
class __TwigTemplate_8d38a2aa1a5b38f1026ba084215a1787a9632d63d86e2331de33209a2329f310 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_70a6c6cccd51821b0a39b5260636df74dfa8c8150f30c5d15ab6a83462671185 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_70a6c6cccd51821b0a39b5260636df74dfa8c8150f30c5d15ab6a83462671185->enter($__internal_70a6c6cccd51821b0a39b5260636df74dfa8c8150f30c5d15ab6a83462671185_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"es\">
    <head>
        <meta charset=\"UTF-8\"/>
        <title>
            ";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        // line 9
        echo "        </title>
        <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css\"
              integrity=\"sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7\" crossorigin=\"anonymous\">
        ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 13
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/favicon.ico"), "html", null, true);
        echo "\"/>
    </head>
    <body>

        <div class=\"container\">
            ";
        // line 18
        $this->loadTemplate("header.html.twig", "layout.html.twig", 18)->display($context);
        // line 19
        echo "            ";
        $this->displayBlock('body', $context, $blocks);
        // line 20
        echo "        </div>

        <script type=\"text/javascript\" src=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
        ";
        // line 23
        $this->displayBlock('javascripts', $context, $blocks);
        // line 24
        echo "    </body>
</html>";
        
        $__internal_70a6c6cccd51821b0a39b5260636df74dfa8c8150f30c5d15ab6a83462671185->leave($__internal_70a6c6cccd51821b0a39b5260636df74dfa8c8150f30c5d15ab6a83462671185_prof);

    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        $__internal_efce1f0c84bbfaf8f728e16d2da413fdd9f44b918c0836e5c0e3fc41feaad386 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_efce1f0c84bbfaf8f728e16d2da413fdd9f44b918c0836e5c0e3fc41feaad386->enter($__internal_efce1f0c84bbfaf8f728e16d2da413fdd9f44b918c0836e5c0e3fc41feaad386_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 7
        echo "                Mantenimiento
            ";
        
        $__internal_efce1f0c84bbfaf8f728e16d2da413fdd9f44b918c0836e5c0e3fc41feaad386->leave($__internal_efce1f0c84bbfaf8f728e16d2da413fdd9f44b918c0836e5c0e3fc41feaad386_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_b7fa48fbeb9848d1b718da3d2c8ab0e17ea3cb3e2bcb7d5119e587f8ebde25af = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b7fa48fbeb9848d1b718da3d2c8ab0e17ea3cb3e2bcb7d5119e587f8ebde25af->enter($__internal_b7fa48fbeb9848d1b718da3d2c8ab0e17ea3cb3e2bcb7d5119e587f8ebde25af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_b7fa48fbeb9848d1b718da3d2c8ab0e17ea3cb3e2bcb7d5119e587f8ebde25af->leave($__internal_b7fa48fbeb9848d1b718da3d2c8ab0e17ea3cb3e2bcb7d5119e587f8ebde25af_prof);

    }

    // line 19
    public function block_body($context, array $blocks = array())
    {
        $__internal_133160ab00a6260b3ce9f7bbe708afd6a1a47b752b0374132702e8342f26b902 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_133160ab00a6260b3ce9f7bbe708afd6a1a47b752b0374132702e8342f26b902->enter($__internal_133160ab00a6260b3ce9f7bbe708afd6a1a47b752b0374132702e8342f26b902_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_133160ab00a6260b3ce9f7bbe708afd6a1a47b752b0374132702e8342f26b902->leave($__internal_133160ab00a6260b3ce9f7bbe708afd6a1a47b752b0374132702e8342f26b902_prof);

    }

    // line 23
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_4d53c84efa8602dedbd75c95065e5ea6eed1c083b463994cd0e9a1de4169d67a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4d53c84efa8602dedbd75c95065e5ea6eed1c083b463994cd0e9a1de4169d67a->enter($__internal_4d53c84efa8602dedbd75c95065e5ea6eed1c083b463994cd0e9a1de4169d67a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_4d53c84efa8602dedbd75c95065e5ea6eed1c083b463994cd0e9a1de4169d67a->leave($__internal_4d53c84efa8602dedbd75c95065e5ea6eed1c083b463994cd0e9a1de4169d67a_prof);

    }

    public function getTemplateName()
    {
        return "layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  110 => 23,  99 => 19,  88 => 12,  80 => 7,  74 => 6,  66 => 24,  64 => 23,  60 => 22,  56 => 20,  53 => 19,  51 => 18,  42 => 13,  40 => 12,  35 => 9,  33 => 6,  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"es\">
    <head>
        <meta charset=\"UTF-8\"/>
        <title>
            {% block title %}
                Mantenimiento
            {% endblock %}
        </title>
        <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css\"
              integrity=\"sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7\" crossorigin=\"anonymous\">
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('/web/favicon.ico') }}\"/>
    </head>
    <body>

        <div class=\"container\">
            {% include \"header.html.twig\" %}
            {% block body %}{% endblock %}
        </div>

        <script type=\"text/javascript\" src=\"{{ asset('/web/js/jquery-3.2.0.min.js') }}\"></script>
        {% block javascripts %}{% endblock %}
    </body>
</html>", "layout.html.twig", "/home/crgourme/siteadmin.crgourmetcoffee.com/app/Resources/views/layout.html.twig");
    }
}
