<?php

/* FarmBundle:Default:editProduct.html.twig */
class __TwigTemplate_7f82111683a50255d113096e57b65cb47ebd2365230d2690af172cd2e599f9b1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "FarmBundle:Default:editProduct.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9f0045694c69cc0ae9ec6d2441ba3682bdb0477f62b3a4916a33e1626cf7079c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9f0045694c69cc0ae9ec6d2441ba3682bdb0477f62b3a4916a33e1626cf7079c->enter($__internal_9f0045694c69cc0ae9ec6d2441ba3682bdb0477f62b3a4916a33e1626cf7079c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FarmBundle:Default:editProduct.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9f0045694c69cc0ae9ec6d2441ba3682bdb0477f62b3a4916a33e1626cf7079c->leave($__internal_9f0045694c69cc0ae9ec6d2441ba3682bdb0477f62b3a4916a33e1626cf7079c_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_dc597d341859c098d456ca8796ce42428749365508ba03ab1f3cf5966d778076 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dc597d341859c098d456ca8796ce42428749365508ba03ab1f3cf5966d778076->enter($__internal_dc597d341859c098d456ca8796ce42428749365508ba03ab1f3cf5966d778076_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Mantenimiento de productos";
        
        $__internal_dc597d341859c098d456ca8796ce42428749365508ba03ab1f3cf5966d778076->leave($__internal_dc597d341859c098d456ca8796ce42428749365508ba03ab1f3cf5966d778076_prof);

    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        $__internal_64fd2c26dfa4ca50b0484c57eb955a15a0333599a91e52bb1ee385702a31edb4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_64fd2c26dfa4ca50b0484c57eb955a15a0333599a91e52bb1ee385702a31edb4->enter($__internal_64fd2c26dfa4ca50b0484c57eb955a15a0333599a91e52bb1ee385702a31edb4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "    <div class=\"row col-md-8 col-md-offset-2 custyle product-body\" style=\"margin-top: 20px\">
        <table class=\"table table-striped custab\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"2\">EDICIÓN DE PRODUCTOS</th>
            </tr>
            </thead>
            <tbody>
            ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["products"] ?? $this->getContext($context, "products")));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 16
            echo "                <tr>
                    <th>ID</th>
                    <td> ";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "</td>
                </tr>
                <tr>
                    <th>Nombre</th>
                    <td><input type=\"text\" name=\"name\" value=\"";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo "\" id=\"name\"></td>
                </tr>
                <tr>
                    <th>Descripción</th>
                    <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\">";
            // line 26
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getDescription", array(), "method"), "html", null, true);
            echo "</textarea></td>
                </tr>
                <tr>
                    <th>Imagen</th>
                    <td>
                        <img src=\"";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage", array(), "method"), "html", null, true);
            echo "\" class=\"mediana\">
                        <form id=\"myform1\" method=\"post\" style=\"margin-top: 5px;\">
                            <input type=\"button\" id=\"loadFileXml\" value=\"Seleccione un archivo\" onclick=\"document.getElementById('image').click();\" />
                            <input id=\"image\" style=\"display:none;\" type=\"file\" name=\"upload\" />
                        </form>
                        <p id=\"imageError\" style=\"color: red; display: none;\"><small>Selecciona una imagen </small></p>
                        <p id=\"image1Error\" style=\"color: red; display: none;\"><small>Selecciona una imagen con la extensión .jpg, .jpeg, .gif o .png</small></p>
                    </td>
                </tr>
                <tr>
                    <th>Nombre de la finca</th>
                    <td>";
            // line 42
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["temp"], "getFarm", array(), "method"), "getName", array(), "method"), "html", null, true);
            echo "</td>
                </tr>
                <tr>
                    <th>Cultivar</th>
                    <td>
                        <select name=\"cultivar\" id=\"cultivar\">
                            ";
            // line 48
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["cultivars"] ?? $this->getContext($context, "cultivars")));
            foreach ($context['_seq'] as $context["_key"] => $context["culti"]) {
                // line 49
                echo "                                ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($context["temp"], "getFarm", array(), "method"), "getCultivars", array(), "method"));
                foreach ($context['_seq'] as $context["_key"] => $context["aux"]) {
                    // line 50
                    echo "                                    ";
                    if (($this->getAttribute($context["aux"], "getId", array(), "method") == $this->getAttribute($context["culti"], "getId", array(), "method"))) {
                        // line 51
                        echo "                                        ";
                        if (($this->getAttribute($this->getAttribute($context["temp"], "getCultivar", array(), "method"), "getId", array(), "method") == $this->getAttribute($context["culti"], "getId", array(), "method"))) {
                            // line 52
                            echo "                                            <option value=\"";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getId", array(), "method"), "html", null, true);
                            echo "\" selected> ";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getDescription", array(), "method"), "html", null, true);
                            echo "</option>
                                        ";
                        } else {
                            // line 54
                            echo "                                            <option value=\"";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getId", array(), "method"), "html", null, true);
                            echo "\"> ";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["culti"], "getDescription", array(), "method"), "html", null, true);
                            echo "</option>
                                        ";
                        }
                        // line 56
                        echo "                                    ";
                    }
                    // line 57
                    echo "                                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['aux'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 58
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['culti'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 59
            echo "                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Grado</th>
                    <td>
                        <select name=\"grade\" id=\"grade\">
                            ";
            // line 66
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["grade"] ?? $this->getContext($context, "grade")));
            foreach ($context['_seq'] as $context["_key"] => $context["gr"]) {
                // line 67
                echo "                                ";
                if (($this->getAttribute($context["gr"], "getId", array(), "method") != 1)) {
                    // line 68
                    echo "                                    ";
                    if (($this->getAttribute($this->getAttribute($context["temp"], "getGrade", array(), "method"), "getId", array(), "method") == $this->getAttribute($context["gr"], "getId", array(), "method"))) {
                        // line 69
                        echo "                                        <option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["gr"], "getId", array(), "method"), "html", null, true);
                        echo "\" selected> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["gr"], "getDescription", array(), "method"), "html", null, true);
                        echo "</option>
                                    ";
                    } else {
                        // line 71
                        echo "                                        <option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["gr"], "getId", array(), "method"), "html", null, true);
                        echo "\"> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["gr"], "getDescription", array(), "method"), "html", null, true);
                        echo "</option>
                                    ";
                    }
                    // line 73
                    echo "                                ";
                }
                // line 74
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['gr'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 75
            echo "                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Tratamiento</th>
                    <td>
                        <select name=\"processing\" id=\"processing\">
                            ";
            // line 82
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["processing"] ?? $this->getContext($context, "processing")));
            foreach ($context['_seq'] as $context["_key"] => $context["pr"]) {
                // line 83
                echo "                                ";
                if (($this->getAttribute($context["pr"], "getId", array(), "method") != 1)) {
                    // line 84
                    echo "                                    ";
                    if (($this->getAttribute($this->getAttribute($context["temp"], "getProcessing", array(), "method"), "getId", array(), "method") == $this->getAttribute($context["pr"], "getId", array(), "method"))) {
                        // line 85
                        echo "                                        <option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["pr"], "getId", array(), "method"), "html", null, true);
                        echo "\" selected> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["pr"], "getDescription", array(), "method"), "html", null, true);
                        echo "</option>
                                    ";
                    } else {
                        // line 87
                        echo "                                        <option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["pr"], "getId", array(), "method"), "html", null, true);
                        echo "\"> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["pr"], "getDescription", array(), "method"), "html", null, true);
                        echo "</option>
                                    ";
                    }
                    // line 89
                    echo "                                ";
                }
                // line 90
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['pr'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 91
            echo "                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Sabor</th>
                    <td>
                        <select name=\"flavor\" id=\"flavor\">
                            ";
            // line 98
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["flavor"] ?? $this->getContext($context, "flavor")));
            foreach ($context['_seq'] as $context["_key"] => $context["fl"]) {
                // line 99
                echo "                                ";
                if (($this->getAttribute($context["fl"], "getId", array(), "method") != 1)) {
                    // line 100
                    echo "                                    ";
                    if (($this->getAttribute($this->getAttribute($context["temp"], "getFlavor", array(), "method"), "getId", array(), "method") == $this->getAttribute($context["fl"], "getId", array(), "method"))) {
                        // line 101
                        echo "                                        <option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["fl"], "getId", array(), "method"), "html", null, true);
                        echo "\" selected> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["fl"], "notes", array(), "method"), "html", null, true);
                        echo "</option>
                                    ";
                    } else {
                        // line 103
                        echo "                                        <option value=\"";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["fl"], "getId", array(), "method"), "html", null, true);
                        echo "\"> ";
                        echo twig_escape_filter($this->env, $this->getAttribute($context["fl"], "notes", array(), "method"), "html", null, true);
                        echo "</option>
                                    ";
                    }
                    // line 105
                    echo "                                ";
                }
                // line 106
                echo "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fl'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 107
            echo "                        </select>
                    </td>
                </tr>
                <tr>
                    <th class=\"text-center\" colspan=\"2\">
                        PRESENTACIONES
                        <a class=\"btn btn-primary btn-xs pull-right btn-add-presentation\" style=\"margin: 0px;\"><span class=\"glyphicon glyphicon-plus\"></span> Agregar Presentación</a>
                    </th>
                </tr>

                <tr>
                    <td colspan=\"2\">
                        <table class=\"table table-striped custab\" id=\"table-presentations\">
                            <thead>
                                <th>Tostado</th>
                                <th>Molido</th>
                                <th>Peso</th>
                                <th>Precio</th>
                                <th></th>
                            </thead>
                            <tbody id=\"tbody-presentations\">
                                ";
            // line 128
            $context["num"] = 1;
            // line 129
            echo "                                ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["temp"], "getPresentations", array(), "method"));
            foreach ($context['_seq'] as $context["_key"] => $context["presentation"]) {
                // line 130
                echo "                                    <tr id=\"";
                echo twig_escape_filter($this->env, ($context["num"] ?? $this->getContext($context, "num")), "html", null, true);
                echo "\">
                                        <td class=\"presentation-roast-";
                // line 131
                echo twig_escape_filter($this->env, ($context["num"] ?? $this->getContext($context, "num")), "html", null, true);
                echo "\" id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["presentation"], "getRoast", array(), "method"), "getId", array(), "method"), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["presentation"], "getRoast", array(), "method"), "getDescription", array(), "method"), "html", null, true);
                echo "</td>
                                        <td class=\"presentation-grind-";
                // line 132
                echo twig_escape_filter($this->env, ($context["num"] ?? $this->getContext($context, "num")), "html", null, true);
                echo "\" id=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["presentation"], "getGrind", array(), "method"), "getId", array(), "method"), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["presentation"], "getGrind", array(), "method"), "getDescription", array(), "method"), "html", null, true);
                echo "</td>
                                        <td class=\"presentation-weight-";
                // line 133
                echo twig_escape_filter($this->env, ($context["num"] ?? $this->getContext($context, "num")), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["presentation"], "getWeight", array(), "method"), "html", null, true);
                echo "</td>
                                        <td class=\"presentation-price-";
                // line 134
                echo twig_escape_filter($this->env, ($context["num"] ?? $this->getContext($context, "num")), "html", null, true);
                echo "\">\$";
                echo twig_escape_filter($this->env, $this->getAttribute($context["presentation"], "getPrice", array(), "method"), "html", null, true);
                echo "</td>
                                        <td>
                                            <a class=\"btn btn-xs btn-danger btn-delete-presentation\" style=\"margin: 0px;\" id=\"";
                // line 136
                echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
                echo "-";
                echo twig_escape_filter($this->env, ($context["num"] ?? $this->getContext($context, "num")), "html", null, true);
                echo "\">Eliminar</a>
                                        </td>
                                    </tr>
                                    ";
                // line 139
                $context["num"] = (($context["num"] ?? $this->getContext($context, "num")) + 1);
                // line 140
                echo "                                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['presentation'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 141
            echo "                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td class=\"text-center\" colspan=\"2\">
                        <a class='btn btn-success btn-xs btn-save' id=\"";
            // line 147
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-save\"></span> Guardar</a>
                        <a href=\"";
            // line 148
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_product_homepage", array("id" => $this->getAttribute($this->getAttribute($context["temp"], "farm", array()), "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-warning btn-xs\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancelar</a>
                    </td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 152
        echo "            </tbody>
        </table>
    </div>

    <!-- The Modal Add Presentations -->
    <div id=\"addPresentation\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
            <!-- Modal content -->
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <span class=\"close\">&times;</span>
                    <h3>Agregar Presentación</h3>
                </div>
                <div class=\"modal-body\" id=\"modal-body\">
                    <form>
                        <div class=\"form-group row\">
                            <label class=\"col-sm-3 form-control-label\">Tostado</label>
                            <div class=\"col-sm-9\">
                                ";
        // line 170
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["roast"] ?? $this->getContext($context, "roast")));
        foreach ($context['_seq'] as $context["_key"] => $context["rt"]) {
            // line 171
            echo "                                    ";
            if (($this->getAttribute($context["rt"], "id", array()) != 1)) {
                // line 172
                echo "                                        <label class=\"radio-inline\" for=\"roast";
                echo twig_escape_filter($this->env, $this->getAttribute($context["rt"], "id", array()), "html", null, true);
                echo "\">
                                            <input type=\"radio\" name=\"roast\" id=\"roast";
                // line 173
                echo twig_escape_filter($this->env, $this->getAttribute($context["rt"], "id", array()), "html", null, true);
                echo "\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["rt"], "id", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["rt"], "description", array()), "html", null, true);
                echo "
                                        </label>
                                    ";
            }
            // line 176
            echo "                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['rt'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 177
        echo "                            </div>
                        </div>
                        <div class=\"form-group row\">
                            <label class=\"col-sm-3 form-control-label\">Molido</label>
                            <div class=\"col-sm-9\">
                                ";
        // line 182
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["grind"] ?? $this->getContext($context, "grind")));
        foreach ($context['_seq'] as $context["_key"] => $context["gd"]) {
            // line 183
            echo "                                    ";
            if (($this->getAttribute($context["gd"], "id", array()) != 1)) {
                // line 184
                echo "                                        <label class=\"radio-inline\" for=\"grind";
                echo twig_escape_filter($this->env, $this->getAttribute($context["gd"], "id", array()), "html", null, true);
                echo "\">
                                            <input type=\"radio\" name=\"grind\" id=\"grind";
                // line 185
                echo twig_escape_filter($this->env, $this->getAttribute($context["gd"], "id", array()), "html", null, true);
                echo "\" value=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["gd"], "id", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["gd"], "description", array()), "html", null, true);
                echo "
                                        </label>
                                    ";
            }
            // line 188
            echo "                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['gd'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 189
        echo "                            </div>
                        </div>
                        <div class=\"form-group\">
                            <label>Peso</label>
                            <input type=\"number\" placeholder=\"Weight\" id=\"weight\" class=\"form-control\" min=\"1\">
                        </div>
                        <div class=\"form-group\">
                            <label>Precio</label>
                            <input type=\"number\" placeholder=\"Price\" id=\"price\" class=\"form-control\" min=\"1\">
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                    <button type=\"button\" class=\"btn btn-primary btn-save-presentation\">Guardar cambios</button>
                    <button type=\"button\" class=\"btn btn-close-modal\" style=\"margin: 0px;\">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

     <!-- The Modal -->
    <div id=\"errorModal\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
        <!-- Modal content -->
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <span class=\"close close-error\">&times;</span>
                <div id=\"modal-header\">
                    <h3 style=\"color: red;\">Error</h3>
                </div>
            </div>
            <div class=\"modal-body\" id=\"modal-body\">
                <span class='glyphicon glyphicon-remove-sign modal-icon'></span>
                <p class='modal-p'>Algunos campos se encuentran en blanco</p>
                <div id=\"modal-body-error\">
                </div>
            </div>
        </div>
    </div>

    ";
        // line 264
        echo "
";
        
        $__internal_64fd2c26dfa4ca50b0484c57eb955a15a0333599a91e52bb1ee385702a31edb4->leave($__internal_64fd2c26dfa4ca50b0484c57eb955a15a0333599a91e52bb1ee385702a31edb4_prof);

    }

    // line 268
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_6fc2716bf8927d7e66cda4d1c26dd59c19adc54445c7740a712beebbd61198a0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6fc2716bf8927d7e66cda4d1c26dd59c19adc54445c7740a712beebbd61198a0->enter($__internal_6fc2716bf8927d7e66cda4d1c26dd59c19adc54445c7740a712beebbd61198a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 269
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 270
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 271
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/styles.css"), "html", null, true);
        echo "\">
";
        
        $__internal_6fc2716bf8927d7e66cda4d1c26dd59c19adc54445c7740a712beebbd61198a0->leave($__internal_6fc2716bf8927d7e66cda4d1c26dd59c19adc54445c7740a712beebbd61198a0_prof);

    }

    // line 275
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_9017e7c74c0d8a8e2de74ffbf18992d34dad0a5473dcf8a64b576e583b9bbfda = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9017e7c74c0d8a8e2de74ffbf18992d34dad0a5473dcf8a64b576e583b9bbfda->enter($__internal_9017e7c74c0d8a8e2de74ffbf18992d34dad0a5473dcf8a64b576e583b9bbfda_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 276
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script type=\"text/javascript\" src=\"";
        // line 277
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/js/products.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_9017e7c74c0d8a8e2de74ffbf18992d34dad0a5473dcf8a64b576e583b9bbfda->leave($__internal_9017e7c74c0d8a8e2de74ffbf18992d34dad0a5473dcf8a64b576e583b9bbfda_prof);

    }

    public function getTemplateName()
    {
        return "FarmBundle:Default:editProduct.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  566 => 277,  561 => 276,  555 => 275,  546 => 271,  542 => 270,  537 => 269,  531 => 268,  523 => 264,  481 => 189,  475 => 188,  465 => 185,  460 => 184,  457 => 183,  453 => 182,  446 => 177,  440 => 176,  430 => 173,  425 => 172,  422 => 171,  418 => 170,  398 => 152,  388 => 148,  384 => 147,  376 => 141,  370 => 140,  368 => 139,  360 => 136,  353 => 134,  347 => 133,  339 => 132,  331 => 131,  326 => 130,  321 => 129,  319 => 128,  296 => 107,  290 => 106,  287 => 105,  279 => 103,  271 => 101,  268 => 100,  265 => 99,  261 => 98,  252 => 91,  246 => 90,  243 => 89,  235 => 87,  227 => 85,  224 => 84,  221 => 83,  217 => 82,  208 => 75,  202 => 74,  199 => 73,  191 => 71,  183 => 69,  180 => 68,  177 => 67,  173 => 66,  164 => 59,  158 => 58,  152 => 57,  149 => 56,  141 => 54,  133 => 52,  130 => 51,  127 => 50,  122 => 49,  118 => 48,  109 => 42,  95 => 31,  87 => 26,  80 => 22,  73 => 18,  69 => 16,  65 => 15,  55 => 7,  49 => 6,  37 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Mantenimiento de productos{% endblock %}

{% block body %}
    <div class=\"row col-md-8 col-md-offset-2 custyle product-body\" style=\"margin-top: 20px\">
        <table class=\"table table-striped custab\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"2\">EDICIÓN DE PRODUCTOS</th>
            </tr>
            </thead>
            <tbody>
            {% for temp in products %}
                <tr>
                    <th>ID</th>
                    <td> {{ temp.getId() }}</td>
                </tr>
                <tr>
                    <th>Nombre</th>
                    <td><input type=\"text\" name=\"name\" value=\"{{ temp.getName() }}\" id=\"name\"></td>
                </tr>
                <tr>
                    <th>Descripción</th>
                    <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\">{{ temp.getDescription() }}</textarea></td>
                </tr>
                <tr>
                    <th>Imagen</th>
                    <td>
                        <img src=\"{{ temp.getImage() }}\" class=\"mediana\">
                        <form id=\"myform1\" method=\"post\" style=\"margin-top: 5px;\">
                            <input type=\"button\" id=\"loadFileXml\" value=\"Seleccione un archivo\" onclick=\"document.getElementById('image').click();\" />
                            <input id=\"image\" style=\"display:none;\" type=\"file\" name=\"upload\" />
                        </form>
                        <p id=\"imageError\" style=\"color: red; display: none;\"><small>Selecciona una imagen </small></p>
                        <p id=\"image1Error\" style=\"color: red; display: none;\"><small>Selecciona una imagen con la extensión .jpg, .jpeg, .gif o .png</small></p>
                    </td>
                </tr>
                <tr>
                    <th>Nombre de la finca</th>
                    <td>{{ temp.getFarm().getName() }}</td>
                </tr>
                <tr>
                    <th>Cultivar</th>
                    <td>
                        <select name=\"cultivar\" id=\"cultivar\">
                            {% for culti in cultivars %}
                                {% for aux in temp.getFarm().getCultivars() %}
                                    {% if  aux.getId() == culti.getId() %}
                                        {% if  temp.getCultivar().getId() == culti.getId() %}
                                            <option value=\"{{ culti.getId() }}\" selected> {{ culti.getDescription() }}</option>
                                        {% else %}
                                            <option value=\"{{ culti.getId() }}\"> {{ culti.getDescription() }}</option>
                                        {% endif %}
                                    {% endif %}
                                {% endfor %}
                            {% endfor %}
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Grado</th>
                    <td>
                        <select name=\"grade\" id=\"grade\">
                            {% for gr in grade %}
                                {% if  gr.getId() != 1 %}
                                    {% if  temp.getGrade().getId() == gr.getId() %}
                                        <option value=\"{{ gr.getId() }}\" selected> {{ gr.getDescription() }}</option>
                                    {% else %}
                                        <option value=\"{{ gr.getId() }}\"> {{ gr.getDescription() }}</option>
                                    {% endif %}
                                {% endif %}
                            {% endfor %}
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Tratamiento</th>
                    <td>
                        <select name=\"processing\" id=\"processing\">
                            {% for pr in processing %}
                                {% if  pr.getId() != 1 %}
                                    {% if  temp.getProcessing().getId() == pr.getId() %}
                                        <option value=\"{{ pr.getId() }}\" selected> {{ pr.getDescription() }}</option>
                                    {% else %}
                                        <option value=\"{{ pr.getId() }}\"> {{ pr.getDescription() }}</option>
                                    {% endif %}
                                {% endif %}
                            {% endfor %}
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Sabor</th>
                    <td>
                        <select name=\"flavor\" id=\"flavor\">
                            {% for fl in flavor %}
                                {% if  fl.getId() != 1 %}
                                    {% if  temp.getFlavor().getId() == fl.getId() %}
                                        <option value=\"{{ fl.getId() }}\" selected> {{ fl.notes() }}</option>
                                    {% else %}
                                        <option value=\"{{ fl.getId() }}\"> {{ fl.notes() }}</option>
                                    {% endif %}
                                {% endif %}
                            {% endfor %}
                        </select>
                    </td>
                </tr>
                <tr>
                    <th class=\"text-center\" colspan=\"2\">
                        PRESENTACIONES
                        <a class=\"btn btn-primary btn-xs pull-right btn-add-presentation\" style=\"margin: 0px;\"><span class=\"glyphicon glyphicon-plus\"></span> Agregar Presentación</a>
                    </th>
                </tr>

                <tr>
                    <td colspan=\"2\">
                        <table class=\"table table-striped custab\" id=\"table-presentations\">
                            <thead>
                                <th>Tostado</th>
                                <th>Molido</th>
                                <th>Peso</th>
                                <th>Precio</th>
                                <th></th>
                            </thead>
                            <tbody id=\"tbody-presentations\">
                                {% set num=1 %}
                                {% for presentation in temp.getPresentations() %}
                                    <tr id=\"{{ num }}\">
                                        <td class=\"presentation-roast-{{ num }}\" id=\"{{ presentation.getRoast().getId() }}\">{{ presentation.getRoast().getDescription() }}</td>
                                        <td class=\"presentation-grind-{{ num }}\" id=\"{{ presentation.getGrind().getId() }}\">{{ presentation.getGrind().getDescription() }}</td>
                                        <td class=\"presentation-weight-{{ num }}\">{{ presentation.getWeight() }}</td>
                                        <td class=\"presentation-price-{{ num }}\">\${{ presentation.getPrice() }}</td>
                                        <td>
                                            <a class=\"btn btn-xs btn-danger btn-delete-presentation\" style=\"margin: 0px;\" id=\"{{ temp.getId() }}-{{ num }}\">Eliminar</a>
                                        </td>
                                    </tr>
                                    {% set num=num+1 %}
                                {% endfor %}
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td class=\"text-center\" colspan=\"2\">
                        <a class='btn btn-success btn-xs btn-save' id=\"{{ temp.getId() }}\"><span class=\"glyphicon glyphicon-save\"></span> Guardar</a>
                        <a href=\"{{ path('farm_product_homepage', {'id': temp.farm.id}) }}\" class=\"btn btn-warning btn-xs\"><span class=\"glyphicon glyphicon-ban-circle\"></span> Cancelar</a>
                    </td>
                </tr>
            {% endfor %}
            </tbody>
        </table>
    </div>

    <!-- The Modal Add Presentations -->
    <div id=\"addPresentation\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
            <!-- Modal content -->
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <span class=\"close\">&times;</span>
                    <h3>Agregar Presentación</h3>
                </div>
                <div class=\"modal-body\" id=\"modal-body\">
                    <form>
                        <div class=\"form-group row\">
                            <label class=\"col-sm-3 form-control-label\">Tostado</label>
                            <div class=\"col-sm-9\">
                                {% for rt in roast %}
                                    {% if rt.id != 1 %}
                                        <label class=\"radio-inline\" for=\"roast{{ rt.id }}\">
                                            <input type=\"radio\" name=\"roast\" id=\"roast{{ rt.id }}\" value=\"{{ rt.id }}\">{{ rt.description }}
                                        </label>
                                    {% endif %}
                                {% endfor %}
                            </div>
                        </div>
                        <div class=\"form-group row\">
                            <label class=\"col-sm-3 form-control-label\">Molido</label>
                            <div class=\"col-sm-9\">
                                {% for gd in grind %}
                                    {% if gd.id != 1 %}
                                        <label class=\"radio-inline\" for=\"grind{{ gd.id }}\">
                                            <input type=\"radio\" name=\"grind\" id=\"grind{{ gd.id }}\" value=\"{{ gd.id }}\">{{ gd.description }}
                                        </label>
                                    {% endif %}
                                {% endfor %}
                            </div>
                        </div>
                        <div class=\"form-group\">
                            <label>Peso</label>
                            <input type=\"number\" placeholder=\"Weight\" id=\"weight\" class=\"form-control\" min=\"1\">
                        </div>
                        <div class=\"form-group\">
                            <label>Precio</label>
                            <input type=\"number\" placeholder=\"Price\" id=\"price\" class=\"form-control\" min=\"1\">
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                    <button type=\"button\" class=\"btn btn-primary btn-save-presentation\">Guardar cambios</button>
                    <button type=\"button\" class=\"btn btn-close-modal\" style=\"margin: 0px;\">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

     <!-- The Modal -->
    <div id=\"errorModal\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
        <!-- Modal content -->
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <span class=\"close close-error\">&times;</span>
                <div id=\"modal-header\">
                    <h3 style=\"color: red;\">Error</h3>
                </div>
            </div>
            <div class=\"modal-body\" id=\"modal-body\">
                <span class='glyphicon glyphicon-remove-sign modal-icon'></span>
                <p class='modal-p'>Algunos campos se encuentran en blanco</p>
                <div id=\"modal-body-error\">
                </div>
            </div>
        </div>
    </div>

    {#<div class=\"col-lg-6\">
        <div class=\"card\">
            <div class=\"card-close\">
                <div class=\"dropdown\">
                    <button type=\"button\" id=\"closeCard\" data-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\" class=\"dropdown-toggle\"><i class=\"fa fa-ellipsis-v\"></i></button>
                    <div aria-labelledby=\"closeCard\" class=\"dropdown-menu has-shadow\"><a href=\"#\" class=\"dropdown-item remove\"> <i class=\"fa fa-times\"></i>Close</a><a href=\"#\" class=\"dropdown-item edit\"> <i class=\"fa fa-gear\"></i>Edit</a></div>
                </div>
            </div>
            <div class=\"card-header d-flex align-items-center\">
                <h3 class=\"h4\">Horizontal Form</h3>
            </div>
            <div class=\"card-body\">
                <p>Lorem ipsum dolor sit amet consectetur.</p>
                <form class=\"form-horizontal\">
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 form-control-label\">Email</label>
                        <div class=\"col-sm-9\">
                            <input id=\"inputHorizontalSuccess\" type=\"email\" placeholder=\"Email Address\" class=\"form-control form-control-success\"><small class=\"form-text\">Example help text that remains unchanged.</small>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <label class=\"col-sm-3 form-control-label\">Password</label>
                        <div class=\"col-sm-9\">
                            <input id=\"inputHorizontalWarning\" type=\"password\" placeholder=\"Pasword\" class=\"form-control form-control-warning\"><small class=\"form-text\">Example help text that remains unchanged.</small>
                        </div>
                    </div>
                    <div class=\"form-group row\">
                        <div class=\"col-sm-9 offset-sm-3\">
                            <input type=\"submit\" value=\"Signin\" class=\"btn btn-primary\">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>#}

{% endblock %}


{% block stylesheets %}
    {{ parent() }}
    <link rel=\"stylesheet\" href=\"{{ asset('/web/css/crgourmetcoffee.css') }}\">
    <link rel=\"stylesheet\" href=\"{{ asset('/web/css/styles.css') }}\">
{% endblock %}


{% block javascripts %}
    {{ parent() }}
    <script type=\"text/javascript\" src=\"{{ asset('/web/js/products.js') }}\"></script>
{% endblock %}", "FarmBundle:Default:editProduct.html.twig", "/home/crgourme/siteadmin.crgourmetcoffee.com/src/FarmBundle/Resources/views/Default/editProduct.html.twig");
    }
}
