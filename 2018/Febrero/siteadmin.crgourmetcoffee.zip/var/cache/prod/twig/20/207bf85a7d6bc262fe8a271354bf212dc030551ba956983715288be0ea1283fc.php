<?php

/* AppBundle:Default:home.html.twig */
class __TwigTemplate_19bd3288eecb615014bbc46d651406d2bf71e0bcd71546c27045de6e813017db extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "AppBundle:Default:home.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c7c788a0f4c87abc8b68ff58e2bda51d894e1db3453eee5c445947200bd0cd9e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c7c788a0f4c87abc8b68ff58e2bda51d894e1db3453eee5c445947200bd0cd9e->enter($__internal_c7c788a0f4c87abc8b68ff58e2bda51d894e1db3453eee5c445947200bd0cd9e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Default:home.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c7c788a0f4c87abc8b68ff58e2bda51d894e1db3453eee5c445947200bd0cd9e->leave($__internal_c7c788a0f4c87abc8b68ff58e2bda51d894e1db3453eee5c445947200bd0cd9e_prof);

    }

    // line 4
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_2c794fe6c15940359f29b23b57d67c03a1d497dab5c4bee58f0923452fc14b25 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2c794fe6c15940359f29b23b57d67c03a1d497dab5c4bee58f0923452fc14b25->enter($__internal_2c794fe6c15940359f29b23b57d67c03a1d497dab5c4bee58f0923452fc14b25_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 5
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/styles.css"), "html", null, true);
        echo "\">
";
        
        $__internal_2c794fe6c15940359f29b23b57d67c03a1d497dab5c4bee58f0923452fc14b25->leave($__internal_2c794fe6c15940359f29b23b57d67c03a1d497dab5c4bee58f0923452fc14b25_prof);

    }

    // line 8
    public function block_title($context, array $blocks = array())
    {
        $__internal_af6e82cd708b06b73316d195a7f3c1686e54845eddca5f6320a45e8a92c87b21 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_af6e82cd708b06b73316d195a7f3c1686e54845eddca5f6320a45e8a92c87b21->enter($__internal_af6e82cd708b06b73316d195a7f3c1686e54845eddca5f6320a45e8a92c87b21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 9
        echo "    Homepage
";
        
        $__internal_af6e82cd708b06b73316d195a7f3c1686e54845eddca5f6320a45e8a92c87b21->leave($__internal_af6e82cd708b06b73316d195a7f3c1686e54845eddca5f6320a45e8a92c87b21_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_39b2f9863dff36a331349650c60eb6327149173d71c64b826f22a8b8935bc02d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_39b2f9863dff36a331349650c60eb6327149173d71c64b826f22a8b8935bc02d->enter($__internal_39b2f9863dff36a331349650c60eb6327149173d71c64b826f22a8b8935bc02d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    <div class=\"row col-md-9 col-md-offset-1 custyle\">
        <table class=\"table table-striped custab\">
            <thead>
                <tr>
                    <th>Title</th>
                    <th class=\"text-center\">Action</th>
                </tr>
            </thead>
            <tr>
                <td>Regions</td>
                <td class=\"text-center\">
                    <a class='btn btn-primary btn-xs' href=\"";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_homepage");
        echo "\">
                        <span class=\"glyphicon glyphicon-ok\"></span> Select</a>
                </td>
            </tr>
            <tr>
                <td>Farm Information</td>
                <td class=\"text-center\">
                    <a class='btn btn-primary btn-xs' href=\"";
        // line 30
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_homepage");
        echo "\">
                        <span class=\"glyphicon glyphicon-ok\"></span> Select</a>
                </td>
            </tr>
        </table>
    </div>
";
        
        $__internal_39b2f9863dff36a331349650c60eb6327149173d71c64b826f22a8b8935bc02d->leave($__internal_39b2f9863dff36a331349650c60eb6327149173d71c64b826f22a8b8935bc02d_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Default:home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  99 => 30,  89 => 23,  76 => 12,  70 => 11,  62 => 9,  56 => 8,  47 => 6,  42 => 5,  36 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block stylesheets %}
    {{parent()}}
    <link rel=\"stylesheet\" href=\"{{ asset('css/styles.css') }}\">
{% endblock %}
{% block title %}
    Homepage
{% endblock %}
{% block body %}
    <div class=\"row col-md-9 col-md-offset-1 custyle\">
        <table class=\"table table-striped custab\">
            <thead>
                <tr>
                    <th>Title</th>
                    <th class=\"text-center\">Action</th>
                </tr>
            </thead>
            <tr>
                <td>Regions</td>
                <td class=\"text-center\">
                    <a class='btn btn-primary btn-xs' href=\"{{ path('region_homepage') }}\">
                        <span class=\"glyphicon glyphicon-ok\"></span> Select</a>
                </td>
            </tr>
            <tr>
                <td>Farm Information</td>
                <td class=\"text-center\">
                    <a class='btn btn-primary btn-xs' href=\"{{ path('farm_homepage') }}\">
                        <span class=\"glyphicon glyphicon-ok\"></span> Select</a>
                </td>
            </tr>
        </table>
    </div>
{% endblock %}

{#{% block javascripts %}
    <script type=\"text/javascript\" src=\"{{ asset('./js/jquery-3.2.0.min.js') }}\"></script>
    <script type=\"text/javascript\" src=\"{{ asset('./js/home.js') }}\"></script>
{% endblock %}#}
", "AppBundle:Default:home.html.twig", "C:\\xampp\\htdocs\\Maintenance\\src\\AppBundle/Resources/views/Default/home.html.twig");
    }
}
