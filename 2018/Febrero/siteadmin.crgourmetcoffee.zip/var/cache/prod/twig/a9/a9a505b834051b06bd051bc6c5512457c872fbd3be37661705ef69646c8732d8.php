<?php

/* RegionBundle:Default:region.html.twig */
class __TwigTemplate_fd5d0f6d916b60ed4c7b325a480ecdd599e4ea85c744c3d072ee38a8839811cf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "RegionBundle:Default:region.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'navbar' => array($this, 'block_navbar'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_acfd34d07b0db5fcc498f164db2948a43d0d6f5b1f4961967da8f8aa1eed607a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_acfd34d07b0db5fcc498f164db2948a43d0d6f5b1f4961967da8f8aa1eed607a->enter($__internal_acfd34d07b0db5fcc498f164db2948a43d0d6f5b1f4961967da8f8aa1eed607a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "RegionBundle:Default:region.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_acfd34d07b0db5fcc498f164db2948a43d0d6f5b1f4961967da8f8aa1eed607a->leave($__internal_acfd34d07b0db5fcc498f164db2948a43d0d6f5b1f4961967da8f8aa1eed607a_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_eb4e5bdfac1c338b4abf8400a48bc7d207901edbda8eb961dbc0632e0d1a657b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eb4e5bdfac1c338b4abf8400a48bc7d207901edbda8eb961dbc0632e0d1a657b->enter($__internal_eb4e5bdfac1c338b4abf8400a48bc7d207901edbda8eb961dbc0632e0d1a657b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Region Maintenance";
        
        $__internal_eb4e5bdfac1c338b4abf8400a48bc7d207901edbda8eb961dbc0632e0d1a657b->leave($__internal_eb4e5bdfac1c338b4abf8400a48bc7d207901edbda8eb961dbc0632e0d1a657b_prof);

    }

    // line 6
    public function block_navbar($context, array $blocks = array())
    {
        $__internal_9b068f76f2f78a1bd9514327a70f82140fcc7429a7e280e0b3a711092b0b3a19 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9b068f76f2f78a1bd9514327a70f82140fcc7429a7e280e0b3a711092b0b3a19->enter($__internal_9b068f76f2f78a1bd9514327a70f82140fcc7429a7e280e0b3a711092b0b3a19_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        echo "Region Maintenance";
        
        $__internal_9b068f76f2f78a1bd9514327a70f82140fcc7429a7e280e0b3a711092b0b3a19->leave($__internal_9b068f76f2f78a1bd9514327a70f82140fcc7429a7e280e0b3a711092b0b3a19_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_f90b252e1ff805da5c68c560bc742585f425ac476b59cea178467f63993c433f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f90b252e1ff805da5c68c560bc742585f425ac476b59cea178467f63993c433f->enter($__internal_f90b252e1ff805da5c68c560bc742585f425ac476b59cea178467f63993c433f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo "    <div class=\"row col-md-20 col-md-offset-0 custyle\">
        <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_add");
        echo "\" class=\"btn btn-primary btn-xs pull-right\"><span class=\"glyphicon glyphicon-plus\"></span> Add</a>
        <table class=\"table table-striped custab table-region\">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Image</th>
                    <th>Characteristics</th>
                    <th>Latitude</th>
                    <th>Longitude</th>
                    <th class=\"text-center\">Action</th>
                </tr>
            </thead>
            <tbody>
            ";
        // line 25
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["regions"] ?? $this->getContext($context, "regions")));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 26
            echo "                <tr>
                    <td> ";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "</td>
                    <td> ";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo " </td>
                    <td class=\"text-area\" style=\"text-align: justify\">";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getDescription", array(), "method"), "html", null, true);
            echo " </td>
                    <td> <img src=\"../../..";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage", array(), "method"), "html", null, true);
            echo "\" class=\"mediana\"></td>
                    <td class=\"text-area\"> ";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getCharacteristics", array(), "method"), "html", null, true);
            echo "</td>
                    <td> ";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getLatitude", array(), "method"), "html", null, true);
            echo "</td>
                    <td> ";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getLongitude", array(), "method"), "html", null, true);
            echo "</td>
                    <td class=\"text-center\">
                        ";
            // line 36
            echo "                        <a class='btn btn-info btn-xs btn-edit' style=\"margin-top: 10px\" id=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-edit\"></span> Edit</a>
                        <a href=\"";
            // line 37
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_delete");
            echo "\" class=\"btn btn-danger btn-xs\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-remove\"></span> Delete</a>
                    </td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 41
        echo "            </tbody>
        </table>
    </div>
";
        
        $__internal_f90b252e1ff805da5c68c560bc742585f425ac476b59cea178467f63993c433f->leave($__internal_f90b252e1ff805da5c68c560bc742585f425ac476b59cea178467f63993c433f_prof);

    }

    // line 47
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_3cb06913158a993ea81a0ec04f496cd2f233191c112d803a8e5c201b77000175 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3cb06913158a993ea81a0ec04f496cd2f233191c112d803a8e5c201b77000175->enter($__internal_3cb06913158a993ea81a0ec04f496cd2f233191c112d803a8e5c201b77000175_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 48
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 49
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
";
        
        $__internal_3cb06913158a993ea81a0ec04f496cd2f233191c112d803a8e5c201b77000175->leave($__internal_3cb06913158a993ea81a0ec04f496cd2f233191c112d803a8e5c201b77000175_prof);

    }

    // line 52
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_41e41177a830fd7f12fbbdc9768f3da2427d9367e12c3c685410832044b459cb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_41e41177a830fd7f12fbbdc9768f3da2427d9367e12c3c685410832044b459cb->enter($__internal_41e41177a830fd7f12fbbdc9768f3da2427d9367e12c3c685410832044b459cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 53
        echo "    <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
    <script type=\"text/javascript\" src=\"";
        // line 54
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("./js/regions.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_41e41177a830fd7f12fbbdc9768f3da2427d9367e12c3c685410832044b459cb->leave($__internal_41e41177a830fd7f12fbbdc9768f3da2427d9367e12c3c685410832044b459cb_prof);

    }

    public function getTemplateName()
    {
        return "RegionBundle:Default:region.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  181 => 54,  176 => 53,  170 => 52,  161 => 49,  156 => 48,  150 => 47,  140 => 41,  130 => 37,  125 => 36,  120 => 33,  116 => 32,  112 => 31,  108 => 30,  104 => 29,  100 => 28,  96 => 27,  93 => 26,  89 => 25,  71 => 10,  68 => 9,  62 => 8,  50 => 6,  38 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Region Maintenance{% endblock %}

{% block navbar %}Region Maintenance{% endblock %}

{% block body %}
    <div class=\"row col-md-20 col-md-offset-0 custyle\">
        <a href=\"{{ path('region_add') }}\" class=\"btn btn-primary btn-xs pull-right\"><span class=\"glyphicon glyphicon-plus\"></span> Add</a>
        <table class=\"table table-striped custab table-region\">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Image</th>
                    <th>Characteristics</th>
                    <th>Latitude</th>
                    <th>Longitude</th>
                    <th class=\"text-center\">Action</th>
                </tr>
            </thead>
            <tbody>
            {% for temp in regions %}
                <tr>
                    <td> {{ temp.getId() }}</td>
                    <td> {{ temp.getName() }} </td>
                    <td class=\"text-area\" style=\"text-align: justify\">{{ temp.getDescription() }} </td>
                    <td> <img src=\"../../..{{ temp.getImage() }}\" class=\"mediana\"></td>
                    <td class=\"text-area\"> {{ temp.getCharacteristics() }}</td>
                    <td> {{ temp.getLatitude() }}</td>
                    <td> {{ temp.getLongitude() }}</td>
                    <td class=\"text-center\">
                        {#<a class='btn btn-info btn-xs btn-edit' href=\"{{ path('region_edit') }}\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-edit\"></span> Edit</a>#}
                        <a class='btn btn-info btn-xs btn-edit' style=\"margin-top: 10px\" id=\"{{ temp.getId() }}\"><span class=\"glyphicon glyphicon-edit\"></span> Edit</a>
                        <a href=\"{{ path('region_delete') }}\" class=\"btn btn-danger btn-xs\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-remove\"></span> Delete</a>
                    </td>
                </tr>
            {% endfor %}
            </tbody>
        </table>
    </div>
{% endblock %}


{% block stylesheets %}
    {{parent()}}
    <link rel=\"stylesheet\" href=\"{{ asset('css/crgourmetcoffee.css') }}\">
{% endblock %}

{% block javascripts %}
    <script type=\"text/javascript\" src=\"{{ asset('./js/jquery-3.2.0.min.js') }}\"></script>
    <script type=\"text/javascript\" src=\"{{ asset('./js/regions.js') }}\"></script>
{% endblock %}
", "RegionBundle:Default:region.html.twig", "C:\\xampp\\htdocs\\Maintenance\\src\\RegionBundle/Resources/views/Default/region.html.twig");
    }
}
