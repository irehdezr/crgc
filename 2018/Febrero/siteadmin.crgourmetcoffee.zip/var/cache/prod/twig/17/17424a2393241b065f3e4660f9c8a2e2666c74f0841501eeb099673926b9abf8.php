<?php

/* ProductBundle:Default:product.html.twig */
class __TwigTemplate_69d7647e8accb88dd3369498c6b437e12607e22453d278c2f3f706dac4f2fb13 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "ProductBundle:Default:product.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9f9dcf3dade63c6a9d5bf9b79765ed67d7e2efba018f05f79b5d7d9025759523 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9f9dcf3dade63c6a9d5bf9b79765ed67d7e2efba018f05f79b5d7d9025759523->enter($__internal_9f9dcf3dade63c6a9d5bf9b79765ed67d7e2efba018f05f79b5d7d9025759523_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ProductBundle:Default:product.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9f9dcf3dade63c6a9d5bf9b79765ed67d7e2efba018f05f79b5d7d9025759523->leave($__internal_9f9dcf3dade63c6a9d5bf9b79765ed67d7e2efba018f05f79b5d7d9025759523_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_77d6fa80bf8f4740f16619408442eed530960f68f7be342a3fa0b4e2100384aa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_77d6fa80bf8f4740f16619408442eed530960f68f7be342a3fa0b4e2100384aa->enter($__internal_77d6fa80bf8f4740f16619408442eed530960f68f7be342a3fa0b4e2100384aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Product Maintenance";
        
        $__internal_77d6fa80bf8f4740f16619408442eed530960f68f7be342a3fa0b4e2100384aa->leave($__internal_77d6fa80bf8f4740f16619408442eed530960f68f7be342a3fa0b4e2100384aa_prof);

    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        $__internal_e99101dbe49e6f7a6e8c5b475fbe93c74e06adf6666b7d5c32491391ca903258 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e99101dbe49e6f7a6e8c5b475fbe93c74e06adf6666b7d5c32491391ca903258->enter($__internal_e99101dbe49e6f7a6e8c5b475fbe93c74e06adf6666b7d5c32491391ca903258_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "\t<div class=\"row col-md-9 col-md-offset-1 custyle\">
\t\t<a ";
        // line 8
        echo " class=\"btn btn-primary btn-xs pull-right\"><span class=\"glyphicon glyphicon-plus\"></span> Add</a>
\t\t<table class=\"table table-striped custab\">
\t\t\t<thead>
\t\t\t<tr>
\t\t\t\t<th>ID</th>
\t\t\t\t<th>Name</th>
\t\t\t\t";
        // line 15
        echo "\t\t\t\t<th>Image</th>
\t\t\t\t<th class=\"text-center\">Action</th>
\t\t\t</tr>
\t\t\t</thead>
\t\t\t<tbody>
            ";
        // line 20
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["products"] ?? $this->getContext($context, "products")));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 21
            echo "\t\t\t\t<tr>
\t\t\t\t\t<td> ";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "</td>
\t\t\t\t\t<td> ";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo " </td>
\t\t\t\t\t";
            // line 25
            echo "\t\t\t\t\t<td> <img src=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage", array(), "method"), "html", null, true);
            echo "\" class=\"mediana\"></td>
\t\t\t\t\t<td class=\"text-center\">
\t\t\t\t\t\t<a class='btn btn-info btn-xs btn-edit' style=\"margin-top: 10px\" id=\"";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-edit\"></span> Edit</a>
\t\t\t\t\t\t<a ";
            // line 28
            echo " class=\"btn btn-danger btn-xs\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-remove\"></span> Delete</a>
\t\t\t\t\t</td>
\t\t\t\t</tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "\t\t\t</tbody>
\t\t</table>
\t</div>
";
        
        $__internal_e99101dbe49e6f7a6e8c5b475fbe93c74e06adf6666b7d5c32491391ca903258->leave($__internal_e99101dbe49e6f7a6e8c5b475fbe93c74e06adf6666b7d5c32491391ca903258_prof);

    }

    // line 38
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_7cd6ac1ca2fb33624abe8399f2b37ec305ce8b939c34094a36db82ce39774dbb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7cd6ac1ca2fb33624abe8399f2b37ec305ce8b939c34094a36db82ce39774dbb->enter($__internal_7cd6ac1ca2fb33624abe8399f2b37ec305ce8b939c34094a36db82ce39774dbb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 39
        echo "\t<link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
\t<link rel=\"stylesheet\" href=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/styles.css"), "html", null, true);
        echo "\">
";
        
        $__internal_7cd6ac1ca2fb33624abe8399f2b37ec305ce8b939c34094a36db82ce39774dbb->leave($__internal_7cd6ac1ca2fb33624abe8399f2b37ec305ce8b939c34094a36db82ce39774dbb_prof);

    }

    // line 43
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_9d2a329c8a5e870167878a32b818c5d95cf03361cf33c8276c530f55df98ddb5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9d2a329c8a5e870167878a32b818c5d95cf03361cf33c8276c530f55df98ddb5->enter($__internal_9d2a329c8a5e870167878a32b818c5d95cf03361cf33c8276c530f55df98ddb5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 44
        echo "\t<script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
\t";
        
        $__internal_9d2a329c8a5e870167878a32b818c5d95cf03361cf33c8276c530f55df98ddb5->leave($__internal_9d2a329c8a5e870167878a32b818c5d95cf03361cf33c8276c530f55df98ddb5_prof);

    }

    public function getTemplateName()
    {
        return "ProductBundle:Default:product.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  143 => 44,  137 => 43,  128 => 40,  123 => 39,  117 => 38,  107 => 32,  98 => 28,  94 => 27,  88 => 25,  84 => 23,  80 => 22,  77 => 21,  73 => 20,  66 => 15,  58 => 8,  55 => 7,  49 => 6,  37 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Product Maintenance{% endblock %}

{% block body %}
\t<div class=\"row col-md-9 col-md-offset-1 custyle\">
\t\t<a {#href=\"{{ path('farm_add') }}\"#} class=\"btn btn-primary btn-xs pull-right\"><span class=\"glyphicon glyphicon-plus\"></span> Add</a>
\t\t<table class=\"table table-striped custab\">
\t\t\t<thead>
\t\t\t<tr>
\t\t\t\t<th>ID</th>
\t\t\t\t<th>Name</th>
\t\t\t\t{#<th>Description</th>#}
\t\t\t\t<th>Image</th>
\t\t\t\t<th class=\"text-center\">Action</th>
\t\t\t</tr>
\t\t\t</thead>
\t\t\t<tbody>
            {% for temp in products %}
\t\t\t\t<tr>
\t\t\t\t\t<td> {{ temp.getId() }}</td>
\t\t\t\t\t<td> {{ temp.getName() }} </td>
\t\t\t\t\t{#<td class=\"text-area\" style=\"text-align: justify\">{{ temp.getDescription() }} </td>#}
\t\t\t\t\t<td> <img src=\"{{ temp.getImage() }}\" class=\"mediana\"></td>
\t\t\t\t\t<td class=\"text-center\">
\t\t\t\t\t\t<a class='btn btn-info btn-xs btn-edit' style=\"margin-top: 10px\" id=\"{{ temp.getId() }}\"><span class=\"glyphicon glyphicon-edit\"></span> Edit</a>
\t\t\t\t\t\t<a {#href=\"{{ path('farm_delete', { 'id': temp.getId() }) }}\"#} class=\"btn btn-danger btn-xs\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-remove\"></span> Delete</a>
\t\t\t\t\t</td>
\t\t\t\t</tr>
            {% endfor %}
\t\t\t</tbody>
\t\t</table>
\t</div>
{% endblock %}


{% block stylesheets %}
\t<link rel=\"stylesheet\" href=\"{{ asset('/web/css/crgourmetcoffee.css') }}\">
\t<link rel=\"stylesheet\" href=\"{{ asset('/web/css/styles.css') }}\">
{% endblock %}

{% block javascripts %}
\t<script type=\"text/javascript\" src=\"{{ asset('/web/js/jquery-3.2.0.min.js') }}\"></script>
\t{#<script type=\"text/javascript\" src=\"{{ asset('/web/js/farm.js') }}\"></script>#}
{% endblock %}", "ProductBundle:Default:product.html.twig", "/home/crgourme/siteadmin.crgourmetcoffee.com/src/ProductBundle/Resources/views/Default/product.html.twig");
    }
}
