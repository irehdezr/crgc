<?php

/* FarmBundle:Default:farm.html.twig */
class __TwigTemplate_33cb2709a4ca59ed0407a2ebfce15355d14c03075db9a4b9de796fadc0e45b56 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "FarmBundle:Default:farm.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'navbar' => array($this, 'block_navbar'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a45f439b10f5647c5da638a10c9f9b24c99297fb240cf194c1d8b5aa2f99be02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a45f439b10f5647c5da638a10c9f9b24c99297fb240cf194c1d8b5aa2f99be02->enter($__internal_a45f439b10f5647c5da638a10c9f9b24c99297fb240cf194c1d8b5aa2f99be02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FarmBundle:Default:farm.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a45f439b10f5647c5da638a10c9f9b24c99297fb240cf194c1d8b5aa2f99be02->leave($__internal_a45f439b10f5647c5da638a10c9f9b24c99297fb240cf194c1d8b5aa2f99be02_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_81306bbbf3fae37d1353a09251755ccbbfd70c22e7358a6b466dc310c94d8664 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_81306bbbf3fae37d1353a09251755ccbbfd70c22e7358a6b466dc310c94d8664->enter($__internal_81306bbbf3fae37d1353a09251755ccbbfd70c22e7358a6b466dc310c94d8664_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Mantenimiento de fincas";
        
        $__internal_81306bbbf3fae37d1353a09251755ccbbfd70c22e7358a6b466dc310c94d8664->leave($__internal_81306bbbf3fae37d1353a09251755ccbbfd70c22e7358a6b466dc310c94d8664_prof);

    }

    // line 6
    public function block_navbar($context, array $blocks = array())
    {
        $__internal_f493c29bc85fa96fb88b392b52b3145abd0fbaaee0780dd907a790c0684bc171 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f493c29bc85fa96fb88b392b52b3145abd0fbaaee0780dd907a790c0684bc171->enter($__internal_f493c29bc85fa96fb88b392b52b3145abd0fbaaee0780dd907a790c0684bc171_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        echo "Mantenimiento de fincas";
        
        $__internal_f493c29bc85fa96fb88b392b52b3145abd0fbaaee0780dd907a790c0684bc171->leave($__internal_f493c29bc85fa96fb88b392b52b3145abd0fbaaee0780dd907a790c0684bc171_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_6eacf978614bff4f1c120b86f3a17e0166746a0e3d81b8fef39e66c3af09e4c7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6eacf978614bff4f1c120b86f3a17e0166746a0e3d81b8fef39e66c3af09e4c7->enter($__internal_6eacf978614bff4f1c120b86f3a17e0166746a0e3d81b8fef39e66c3af09e4c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo "    <div class=\"row col-md-20 col-md-offset-0 custyle\">
        <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_add");
        echo "\" class=\"btn btn-primary btn-xs pull-right\"><span class=\"glyphicon glyphicon-plus\"></span> Agregar</a>
        <table class=\"table table-striped custab\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"5\">FINCAS</th>
            </tr>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Imagen</th>
                <th class=\"text-center\">Acción</th>
            </tr>
            </thead>
            <tbody>
            ";
        // line 25
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["farms"] ?? $this->getContext($context, "farms")));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 26
            echo "                <tr>
                    <td> ";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "</td>
                    <td> ";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo " </td>
                    <td class=\"text-area\" style=\"text-align: justify\">";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getDescription", array(), "method"), "html", null, true);
            echo " </td>
                    <td> <img src=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage", array(), "method"), "html", null, true);
            echo "\" class=\"mediana\"></td>
                    <td class=\"text-center\">
                        <a class='btn btn-info btn-xs btn-edit' style=\"margin-top: 10px\" id=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-edit\"></span> Editar</a>
                        <a id=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\" name=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo "\" class=\"btn btn-danger btn-xs btn-delete\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-remove\"></span> Eliminar</a>
                    </td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 37
        echo "            </tbody>
        </table>
    </div>

    <!-- The Modal Delete Confirmation -->
    <div id=\"deleteConfirmation\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
            <!-- Modal content -->
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h3>Eliminar Fincas</h3>
                </div>
                <div class=\"modal-body\" id=\"modal-body\">
                    <form>
                        <div class=\"form-group row div-body\" id=\"div-body\">
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_6eacf978614bff4f1c120b86f3a17e0166746a0e3d81b8fef39e66c3af09e4c7->leave($__internal_6eacf978614bff4f1c120b86f3a17e0166746a0e3d81b8fef39e66c3af09e4c7_prof);

    }

    // line 63
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_73af69880cd3d9d99f88fe9fc4706d0a0dcf24133b195ccb941d8627bc26fe1a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_73af69880cd3d9d99f88fe9fc4706d0a0dcf24133b195ccb941d8627bc26fe1a->enter($__internal_73af69880cd3d9d99f88fe9fc4706d0a0dcf24133b195ccb941d8627bc26fe1a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 64
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 65
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 66
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/styles.css"), "html", null, true);
        echo "\">
";
        
        $__internal_73af69880cd3d9d99f88fe9fc4706d0a0dcf24133b195ccb941d8627bc26fe1a->leave($__internal_73af69880cd3d9d99f88fe9fc4706d0a0dcf24133b195ccb941d8627bc26fe1a_prof);

    }

    // line 69
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_562786cffd872ca0b718f21ad34ecacdf313c2132a3f6c786ec3d4c4d1369d14 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_562786cffd872ca0b718f21ad34ecacdf313c2132a3f6c786ec3d4c4d1369d14->enter($__internal_562786cffd872ca0b718f21ad34ecacdf313c2132a3f6c786ec3d4c4d1369d14_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 70
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script type=\"text/javascript\" src=\"";
        // line 71
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/js/farm.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_562786cffd872ca0b718f21ad34ecacdf313c2132a3f6c786ec3d4c4d1369d14->leave($__internal_562786cffd872ca0b718f21ad34ecacdf313c2132a3f6c786ec3d4c4d1369d14_prof);

    }

    public function getTemplateName()
    {
        return "FarmBundle:Default:farm.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  194 => 71,  189 => 70,  183 => 69,  174 => 66,  170 => 65,  165 => 64,  159 => 63,  129 => 37,  117 => 33,  113 => 32,  108 => 30,  104 => 29,  100 => 28,  96 => 27,  93 => 26,  89 => 25,  71 => 10,  68 => 9,  62 => 8,  50 => 6,  38 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Mantenimiento de fincas{% endblock %}

{% block navbar %}Mantenimiento de fincas{% endblock %}

{% block body %}
    <div class=\"row col-md-20 col-md-offset-0 custyle\">
        <a href=\"{{ path('farm_add') }}\" class=\"btn btn-primary btn-xs pull-right\"><span class=\"glyphicon glyphicon-plus\"></span> Agregar</a>
        <table class=\"table table-striped custab\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"5\">FINCAS</th>
            </tr>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Imagen</th>
                <th class=\"text-center\">Acción</th>
            </tr>
            </thead>
            <tbody>
            {% for temp in farms %}
                <tr>
                    <td> {{ temp.getId() }}</td>
                    <td> {{ temp.getName() }} </td>
                    <td class=\"text-area\" style=\"text-align: justify\">{{ temp.getDescription() }} </td>
                    <td> <img src=\"{{ temp.getImage() }}\" class=\"mediana\"></td>
                    <td class=\"text-center\">
                        <a class='btn btn-info btn-xs btn-edit' style=\"margin-top: 10px\" id=\"{{ temp.getId() }}\"><span class=\"glyphicon glyphicon-edit\"></span> Editar</a>
                        <a id=\"{{ temp.getId() }}\" name=\"{{ temp.getName() }}\" class=\"btn btn-danger btn-xs btn-delete\" style=\"margin-top: 10px\"><span class=\"glyphicon glyphicon-remove\"></span> Eliminar</a>
                    </td>
                </tr>
            {% endfor %}
            </tbody>
        </table>
    </div>

    <!-- The Modal Delete Confirmation -->
    <div id=\"deleteConfirmation\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
            <!-- Modal content -->
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h3>Eliminar Fincas</h3>
                </div>
                <div class=\"modal-body\" id=\"modal-body\">
                    <form>
                        <div class=\"form-group row div-body\" id=\"div-body\">
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                </div>
            </div>
        </div>
    </div>
{% endblock %}


{% block stylesheets %}
    {{ parent() }}
    <link rel=\"stylesheet\" href=\"{{ asset('/web/css/crgourmetcoffee.css') }}\">
    <link rel=\"stylesheet\" href=\"{{ asset('/web/css/styles.css') }}\">
{% endblock %}

{% block javascripts %}
    {{ parent() }}
    <script type=\"text/javascript\" src=\"{{ asset('/web/js/farm.js') }}\"></script>
{% endblock %}

", "FarmBundle:Default:farm.html.twig", "/home/crgourme/siteadmin.crgourmetcoffee.com/src/FarmBundle/Resources/views/Default/farm.html.twig");
    }
}
