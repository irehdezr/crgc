<?php

/* RegionBundle:Default:insert.html.twig */
class __TwigTemplate_6b95fa26ab8005a892f95cfadc80043de2f9f26aa4700fbaebf27b8a6218ebb8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "RegionBundle:Default:insert.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_05d426388712f3069575512360264e77d394870965cbf26e0bae05d39dcfdc89 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_05d426388712f3069575512360264e77d394870965cbf26e0bae05d39dcfdc89->enter($__internal_05d426388712f3069575512360264e77d394870965cbf26e0bae05d39dcfdc89_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "RegionBundle:Default:insert.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_05d426388712f3069575512360264e77d394870965cbf26e0bae05d39dcfdc89->leave($__internal_05d426388712f3069575512360264e77d394870965cbf26e0bae05d39dcfdc89_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_eca0536e8f1f2fefbf2ff65e5a76494536231d82b50b85d56b8e1953fd9f18ff = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eca0536e8f1f2fefbf2ff65e5a76494536231d82b50b85d56b8e1953fd9f18ff->enter($__internal_eca0536e8f1f2fefbf2ff65e5a76494536231d82b50b85d56b8e1953fd9f18ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Agregar Regiones";
        
        $__internal_eca0536e8f1f2fefbf2ff65e5a76494536231d82b50b85d56b8e1953fd9f18ff->leave($__internal_eca0536e8f1f2fefbf2ff65e5a76494536231d82b50b85d56b8e1953fd9f18ff_prof);

    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        $__internal_45595cdc2580c6bfc44bbc820107b75cb12214eeae4348b82e2e7d6d84128941 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_45595cdc2580c6bfc44bbc820107b75cb12214eeae4348b82e2e7d6d84128941->enter($__internal_45595cdc2580c6bfc44bbc820107b75cb12214eeae4348b82e2e7d6d84128941_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "<div class=\"row col-md-8 col-md-offset-2 custyle\" style=\"margin-top: 20px;\">
    <table class=\"table table-striped custab\">
        <thead>
        <tr>
            <th class=\"text-center\" colspan=\"2\">AGREGAR REGIONES</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <th>Nombre</th>
            <td><input type=\"text\" name=\"name\" value=\"\" id=\"name\"></td>
        </tr>
        <tr>
            <th>Imagen 1</th>
            <td>
                <form id=\"myform1\" method=\"post\">
                    <input type=\"button\" id=\"loadFileXml\" value=\"Seleccione un archivo\"
                           onclick=\"document.getElementById('image1').click();\"/>
                    <input id=\"image1\" style=\"display:none;\" type=\"file\" name=\"upload\"/>
                </form>
                <p id=\"image1Error\" style=\"color: red; display: none;\">
                    <small>Selecciona una imagen</small>
                </p>
                <p id=\"image1-1Error\" style=\"color: red; display: none;\">
                    <small>Selecciona una imagen con la extensión .jpg, .jpeg, .gif o .png</small>
                </p>
            </td>
        </tr>
        <tr>
            <th>Descripción de la imagen 1</th>
            <td><input type=\"text\" name=\"description-img1\" value=\"\" id=\"description-img1\"></td>
        </tr>
        <tr>
            <th>Imagen 2</th>
            <td>
                <form id=\"myform2\" method=\"post\">
                    <input type=\"button\" id=\"loadFileXml\" value=\"Seleccione un archivo\"
                           onclick=\"document.getElementById('image2').click();\"/>
                    <input id=\"image2\" style=\"display:none;\" type=\"file\" name=\"upload\"/>
                </form>
                <p id=\"image2Error\" style=\"color: red; display: none;\">
                    <small>Selecciona una imagen</small>
                </p>
                <p id=\"image2-2Error\" style=\"color: red; display: none;\">
                    <small>Selecciona una imagen con la extensión .jpg, .jpeg, .gif o .png</small>
                </p>
            </td>
        </tr>
        <tr>
            <th>Descripción de la imagen 2</th>
            <td><input type=\"text\" name=\"description-img2\" value=\"\" id=\"description-img2\"></td>
        </tr>
        <tr>
            <th>Imagen 3</th>
            <td>
                <form id=\"myform3\" method=\"post\">
                    <input type=\"button\" id=\"loadFileXml\" value=\"Seleccione un archivo\"
                           onclick=\"document.getElementById('image3').click();\"/>
                    <input id=\"image3\" style=\"display:none;\" type=\"file\" name=\"upload\"/>
                </form>
                <p id=\"image3Error\" style=\"color: red; display: none;\">
                    <small>Selecciona una imagen</small>
                </p>
                <p id=\"image3-3Error\" style=\"color: red; display: none;\">
                    <small>Selecciona una imagen con la extensión .jpg, .jpeg, .gif o .png</small>
                </p>
            </td>
        </tr>
        <tr>
            <th>Descripción de la imagen 3</th>
            <td><input type=\"text\" name=\"description-img3\" value=\"\" id=\"description-img3\"></td>
        </tr>
        <tr>
            <th>Descripción</th>
            <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\"></textarea></td>
        </tr>
        <tr>
            <th>Características organolépticas</th>
            <td><textarea name=\"organoleptic\" rows=\"7\" cols=\"45\" id=\"organoleptic\"></textarea></td>
        </tr>
        <tr>
            <th>Información</th>
            <td><textarea name=\"information\" rows=\"7\" cols=\"45\" id=\"information\"></textarea></td>
        </tr>
        <tr>
            <th>Latitud</th>
            <td><input type=\"text\" name=\"latitude\" value=\"\" id=\"latitude\"></td>
        </tr>
        <tr>
            <th>Longitud</th>
            <td><input type=\"text\" name=\"longitude\" value=\"\" id=\"longitude\"></td>
        </tr>
        <tr>
            <th>Zoom</th>
            <td>
                <input type=\"text\" name=\"zoom\" value=\"\" id=\"zoom\">
                <p id=\"zoomError\" style=\"color: red; display: none;\">
                    <small>El zoom no puede ser un número de más de dos dígitos</small>
                </p>
            </td>
        </tr>
        <tr>
            <td class=\"text-center\" colspan=\"2\">
                <a class='btn btn-success btn-xs btn-insert'><span class=\"glyphicon glyphicon-save\"></span> Guardar</a>
                <a href=\"";
        // line 111
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_homepage");
        echo "\" class=\"btn btn-warning btn-xs\"><span
                            class=\"glyphicon glyphicon-ban-circle\"></span> Cancelar</a>
            </td>
        </tr>
        </tbody>
    </table>
</div>

<!-- The Modal -->
<div id=\"errorModal\" class=\"modal\" role=\"dialog\">
    <div class=\"modal-dialog modal-lg\">
        <!-- Modal content -->
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <span class=\"close\">&times;</span>
                <div id=\"modal-header\">
                    <h3 style=\"color: red;\">Error</h3>
                </div>
            </div>
            <div class=\"modal-body\" id=\"modal-body\">
                <span class='glyphicon glyphicon-remove-sign modal-icon'></span>
                <p class='modal-p'>Algunos campos se encuentran en blanco</p>
            </div>
        </div>
    </div>
    ";
        
        $__internal_45595cdc2580c6bfc44bbc820107b75cb12214eeae4348b82e2e7d6d84128941->leave($__internal_45595cdc2580c6bfc44bbc820107b75cb12214eeae4348b82e2e7d6d84128941_prof);

    }

    // line 139
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_cf24a1b0e685c29fdcbad0bd29b263d567a9c2886ca9b4acd21926d5e8c8286f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cf24a1b0e685c29fdcbad0bd29b263d567a9c2886ca9b4acd21926d5e8c8286f->enter($__internal_cf24a1b0e685c29fdcbad0bd29b263d567a9c2886ca9b4acd21926d5e8c8286f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 140
        echo "        ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
        <link rel=\"stylesheet\" href=\"";
        // line 141
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 142
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/styles.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_cf24a1b0e685c29fdcbad0bd29b263d567a9c2886ca9b4acd21926d5e8c8286f->leave($__internal_cf24a1b0e685c29fdcbad0bd29b263d567a9c2886ca9b4acd21926d5e8c8286f_prof);

    }

    // line 145
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_c8dfb2488bb43935e3ce665f5f0cfaf3a755ae0299260d3c3f254316467e780a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c8dfb2488bb43935e3ce665f5f0cfaf3a755ae0299260d3c3f254316467e780a->enter($__internal_c8dfb2488bb43935e3ce665f5f0cfaf3a755ae0299260d3c3f254316467e780a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 146
        echo "        <script type=\"text/javascript\" src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 147
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/js/regions.js"), "html", null, true);
        echo "\"></script>
    ";
        
        $__internal_c8dfb2488bb43935e3ce665f5f0cfaf3a755ae0299260d3c3f254316467e780a->leave($__internal_c8dfb2488bb43935e3ce665f5f0cfaf3a755ae0299260d3c3f254316467e780a_prof);

    }

    public function getTemplateName()
    {
        return "RegionBundle:Default:insert.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  229 => 147,  224 => 146,  218 => 145,  209 => 142,  205 => 141,  200 => 140,  194 => 139,  161 => 111,  55 => 7,  49 => 6,  37 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Agregar Regiones{% endblock %}

{% block body %}
<div class=\"row col-md-8 col-md-offset-2 custyle\" style=\"margin-top: 20px;\">
    <table class=\"table table-striped custab\">
        <thead>
        <tr>
            <th class=\"text-center\" colspan=\"2\">AGREGAR REGIONES</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <th>Nombre</th>
            <td><input type=\"text\" name=\"name\" value=\"\" id=\"name\"></td>
        </tr>
        <tr>
            <th>Imagen 1</th>
            <td>
                <form id=\"myform1\" method=\"post\">
                    <input type=\"button\" id=\"loadFileXml\" value=\"Seleccione un archivo\"
                           onclick=\"document.getElementById('image1').click();\"/>
                    <input id=\"image1\" style=\"display:none;\" type=\"file\" name=\"upload\"/>
                </form>
                <p id=\"image1Error\" style=\"color: red; display: none;\">
                    <small>Selecciona una imagen</small>
                </p>
                <p id=\"image1-1Error\" style=\"color: red; display: none;\">
                    <small>Selecciona una imagen con la extensión .jpg, .jpeg, .gif o .png</small>
                </p>
            </td>
        </tr>
        <tr>
            <th>Descripción de la imagen 1</th>
            <td><input type=\"text\" name=\"description-img1\" value=\"\" id=\"description-img1\"></td>
        </tr>
        <tr>
            <th>Imagen 2</th>
            <td>
                <form id=\"myform2\" method=\"post\">
                    <input type=\"button\" id=\"loadFileXml\" value=\"Seleccione un archivo\"
                           onclick=\"document.getElementById('image2').click();\"/>
                    <input id=\"image2\" style=\"display:none;\" type=\"file\" name=\"upload\"/>
                </form>
                <p id=\"image2Error\" style=\"color: red; display: none;\">
                    <small>Selecciona una imagen</small>
                </p>
                <p id=\"image2-2Error\" style=\"color: red; display: none;\">
                    <small>Selecciona una imagen con la extensión .jpg, .jpeg, .gif o .png</small>
                </p>
            </td>
        </tr>
        <tr>
            <th>Descripción de la imagen 2</th>
            <td><input type=\"text\" name=\"description-img2\" value=\"\" id=\"description-img2\"></td>
        </tr>
        <tr>
            <th>Imagen 3</th>
            <td>
                <form id=\"myform3\" method=\"post\">
                    <input type=\"button\" id=\"loadFileXml\" value=\"Seleccione un archivo\"
                           onclick=\"document.getElementById('image3').click();\"/>
                    <input id=\"image3\" style=\"display:none;\" type=\"file\" name=\"upload\"/>
                </form>
                <p id=\"image3Error\" style=\"color: red; display: none;\">
                    <small>Selecciona una imagen</small>
                </p>
                <p id=\"image3-3Error\" style=\"color: red; display: none;\">
                    <small>Selecciona una imagen con la extensión .jpg, .jpeg, .gif o .png</small>
                </p>
            </td>
        </tr>
        <tr>
            <th>Descripción de la imagen 3</th>
            <td><input type=\"text\" name=\"description-img3\" value=\"\" id=\"description-img3\"></td>
        </tr>
        <tr>
            <th>Descripción</th>
            <td><textarea name=\"description\" rows=\"7\" cols=\"45\" id=\"description\"></textarea></td>
        </tr>
        <tr>
            <th>Características organolépticas</th>
            <td><textarea name=\"organoleptic\" rows=\"7\" cols=\"45\" id=\"organoleptic\"></textarea></td>
        </tr>
        <tr>
            <th>Información</th>
            <td><textarea name=\"information\" rows=\"7\" cols=\"45\" id=\"information\"></textarea></td>
        </tr>
        <tr>
            <th>Latitud</th>
            <td><input type=\"text\" name=\"latitude\" value=\"\" id=\"latitude\"></td>
        </tr>
        <tr>
            <th>Longitud</th>
            <td><input type=\"text\" name=\"longitude\" value=\"\" id=\"longitude\"></td>
        </tr>
        <tr>
            <th>Zoom</th>
            <td>
                <input type=\"text\" name=\"zoom\" value=\"\" id=\"zoom\">
                <p id=\"zoomError\" style=\"color: red; display: none;\">
                    <small>El zoom no puede ser un número de más de dos dígitos</small>
                </p>
            </td>
        </tr>
        <tr>
            <td class=\"text-center\" colspan=\"2\">
                <a class='btn btn-success btn-xs btn-insert'><span class=\"glyphicon glyphicon-save\"></span> Guardar</a>
                <a href=\"{{ path('region_homepage') }}\" class=\"btn btn-warning btn-xs\"><span
                            class=\"glyphicon glyphicon-ban-circle\"></span> Cancelar</a>
            </td>
        </tr>
        </tbody>
    </table>
</div>

<!-- The Modal -->
<div id=\"errorModal\" class=\"modal\" role=\"dialog\">
    <div class=\"modal-dialog modal-lg\">
        <!-- Modal content -->
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <span class=\"close\">&times;</span>
                <div id=\"modal-header\">
                    <h3 style=\"color: red;\">Error</h3>
                </div>
            </div>
            <div class=\"modal-body\" id=\"modal-body\">
                <span class='glyphicon glyphicon-remove-sign modal-icon'></span>
                <p class='modal-p'>Algunos campos se encuentran en blanco</p>
            </div>
        </div>
    </div>
    {% endblock %}


    {% block stylesheets %}
        {{ parent() }}
        <link rel=\"stylesheet\" href=\"{{ asset('/web/css/crgourmetcoffee.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('/web/css/styles.css') }}\">
    {% endblock %}

    {% block javascripts %}
        <script type=\"text/javascript\" src=\"{{ asset('/web/js/jquery-3.2.0.min.js') }}\"></script>
        <script type=\"text/javascript\" src=\"{{ asset('/web/js/regions.js') }}\"></script>
    {% endblock %}
", "RegionBundle:Default:insert.html.twig", "/home/crgourme/siteadmin.crgourmetcoffee.com/src/RegionBundle/Resources/views/Default/insert.html.twig");
    }
}
