<?php

/* layout.html.twig */
class __TwigTemplate_739152aed38d71e8ea7e31046beec5893aecae4c8213a7069b3a1ec7134774ca extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'navbar' => array($this, 'block_navbar'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3f432b5bdb62e210f8794e2ae49e12386ba84cff888e46fdfb52063cba89c0ea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3f432b5bdb62e210f8794e2ae49e12386ba84cff888e46fdfb52063cba89c0ea->enter($__internal_3f432b5bdb62e210f8794e2ae49e12386ba84cff888e46fdfb52063cba89c0ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css\" integrity=\"sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7\" crossorigin=\"anonymous\">
        ";
        // line 7
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 8
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
    <nav class=\"navbar navbar-default navbar-fixed-top\">
        <div class=\"container\">
            <div class=\"navbar-header\">
                <a class=\"navbar-brand\" href=\"#\">";
        // line 14
        $this->displayBlock('navbar', $context, $blocks);
        echo "</a>
            </div>
        </div>
    </nav>

    <div class=\"container\">
                ";
        // line 20
        $this->displayBlock('body', $context, $blocks);
        // line 21
        echo "    </div><!-- /.container -->
    ";
        // line 22
        $this->displayBlock('javascripts', $context, $blocks);
        // line 23
        echo "    </body>
</html>
";
        
        $__internal_3f432b5bdb62e210f8794e2ae49e12386ba84cff888e46fdfb52063cba89c0ea->leave($__internal_3f432b5bdb62e210f8794e2ae49e12386ba84cff888e46fdfb52063cba89c0ea_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_9993c33d9f158365b07ff29af3ba5657c4737eca16d4f914b7e009962b546b14 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9993c33d9f158365b07ff29af3ba5657c4737eca16d4f914b7e009962b546b14->enter($__internal_9993c33d9f158365b07ff29af3ba5657c4737eca16d4f914b7e009962b546b14_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Maintenance";
        
        $__internal_9993c33d9f158365b07ff29af3ba5657c4737eca16d4f914b7e009962b546b14->leave($__internal_9993c33d9f158365b07ff29af3ba5657c4737eca16d4f914b7e009962b546b14_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_8003f0e5b279063a14784e361a772063d30c2cedaf02dafba259e226faceb77d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8003f0e5b279063a14784e361a772063d30c2cedaf02dafba259e226faceb77d->enter($__internal_8003f0e5b279063a14784e361a772063d30c2cedaf02dafba259e226faceb77d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_8003f0e5b279063a14784e361a772063d30c2cedaf02dafba259e226faceb77d->leave($__internal_8003f0e5b279063a14784e361a772063d30c2cedaf02dafba259e226faceb77d_prof);

    }

    // line 14
    public function block_navbar($context, array $blocks = array())
    {
        $__internal_a37092601b59e4126cc9f170283319a051607a39bae6f4b9438ac1f205f0b64a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a37092601b59e4126cc9f170283319a051607a39bae6f4b9438ac1f205f0b64a->enter($__internal_a37092601b59e4126cc9f170283319a051607a39bae6f4b9438ac1f205f0b64a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "navbar"));

        echo "Maintenance";
        
        $__internal_a37092601b59e4126cc9f170283319a051607a39bae6f4b9438ac1f205f0b64a->leave($__internal_a37092601b59e4126cc9f170283319a051607a39bae6f4b9438ac1f205f0b64a_prof);

    }

    // line 20
    public function block_body($context, array $blocks = array())
    {
        $__internal_3afae3106087e7d982bebfef9d3fcaef3907e5c9619ef41f8f775b5853968154 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3afae3106087e7d982bebfef9d3fcaef3907e5c9619ef41f8f775b5853968154->enter($__internal_3afae3106087e7d982bebfef9d3fcaef3907e5c9619ef41f8f775b5853968154_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_3afae3106087e7d982bebfef9d3fcaef3907e5c9619ef41f8f775b5853968154->leave($__internal_3afae3106087e7d982bebfef9d3fcaef3907e5c9619ef41f8f775b5853968154_prof);

    }

    // line 22
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_33fe8641f7a2621b2abe867d7b4cb2d705ae2a4e742216cbbb4a83d2e44b151b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_33fe8641f7a2621b2abe867d7b4cb2d705ae2a4e742216cbbb4a83d2e44b151b->enter($__internal_33fe8641f7a2621b2abe867d7b4cb2d705ae2a4e742216cbbb4a83d2e44b151b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_33fe8641f7a2621b2abe867d7b4cb2d705ae2a4e742216cbbb4a83d2e44b151b->leave($__internal_33fe8641f7a2621b2abe867d7b4cb2d705ae2a4e742216cbbb4a83d2e44b151b_prof);

    }

    public function getTemplateName()
    {
        return "layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  121 => 22,  110 => 20,  98 => 14,  87 => 7,  75 => 5,  66 => 23,  64 => 22,  61 => 21,  59 => 20,  50 => 14,  40 => 8,  38 => 7,  33 => 5,  27 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Maintenance{% endblock %}</title>
        <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css\" integrity=\"sha384-1q8mTJOASx8j1Au+a5WDVnPi2lkFfwwEAa8hDDdjZlpLegxhjVME1fgjWPGmkzs7\" crossorigin=\"anonymous\">
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
    <nav class=\"navbar navbar-default navbar-fixed-top\">
        <div class=\"container\">
            <div class=\"navbar-header\">
                <a class=\"navbar-brand\" href=\"#\">{% block navbar %}Maintenance{% endblock %}</a>
            </div>
        </div>
    </nav>

    <div class=\"container\">
                {% block body %}{% endblock %}
    </div><!-- /.container -->
    {% block javascripts %}{% endblock %}
    </body>
</html>
", "layout.html.twig", "C:\\xampp\\htdocs\\Maintenance\\app\\Resources\\views\\layout.html.twig");
    }
}
