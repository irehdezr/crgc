<?php

/* RegionBundle:Default:region.html.twig */
class __TwigTemplate_1171479e73cc53a04aaff9c458f30a2862daa5ca26c2f07ba2042a134097109e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "RegionBundle:Default:region.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8c93865df7285a37fa305570b39860e1abb048a8dcffe925a3a84a05b63e62ef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8c93865df7285a37fa305570b39860e1abb048a8dcffe925a3a84a05b63e62ef->enter($__internal_8c93865df7285a37fa305570b39860e1abb048a8dcffe925a3a84a05b63e62ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "RegionBundle:Default:region.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8c93865df7285a37fa305570b39860e1abb048a8dcffe925a3a84a05b63e62ef->leave($__internal_8c93865df7285a37fa305570b39860e1abb048a8dcffe925a3a84a05b63e62ef_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_6380d91a24613b8c5c23ccc8beccd2180f248688c1f2b0568eedd30a336363d4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6380d91a24613b8c5c23ccc8beccd2180f248688c1f2b0568eedd30a336363d4->enter($__internal_6380d91a24613b8c5c23ccc8beccd2180f248688c1f2b0568eedd30a336363d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Mantenimiento de regiones";
        
        $__internal_6380d91a24613b8c5c23ccc8beccd2180f248688c1f2b0568eedd30a336363d4->leave($__internal_6380d91a24613b8c5c23ccc8beccd2180f248688c1f2b0568eedd30a336363d4_prof);

    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        $__internal_779749c1967fe9e6c48d6ddccff8fa41bc99cdfc6d5241c9bbedb68d1844c8f8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_779749c1967fe9e6c48d6ddccff8fa41bc99cdfc6d5241c9bbedb68d1844c8f8->enter($__internal_779749c1967fe9e6c48d6ddccff8fa41bc99cdfc6d5241c9bbedb68d1844c8f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "    <div class=\"row col-md-20 col-md-offset-0 custyle\">
        <a href=\"";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_add");
        echo "\" class=\"btn btn-primary btn-xs pull-right\"><span
                    class=\"glyphicon glyphicon-plus\"></span> Agregar</a>
        <div>
            <table class=\"table table-striped custab\">
                <thead>
                <tr>
                    <th class=\"text-center\" colspan=\"5\">REGIONES</th>
                </tr>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Imagen 1</th>
                    <th>Descripción</th>
                    <th class=\"text-center\">Acción</th>
                </tr>
                </thead>
                <tbody>
                ";
        // line 25
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["regions"] ?? $this->getContext($context, "regions")));
        foreach ($context['_seq'] as $context["_key"] => $context["temp"]) {
            // line 26
            echo "                    <tr>
                        <td> ";
            // line 27
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "</td>
                        <td> ";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo " </td>
                        <td><img src=\"";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getImage1", array(), "method"), "html", null, true);
            echo "\" class=\"mediana\"></td>
                        <td class=\"text-area\" style=\"text-align: justify\">";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getDescription", array(), "method"), "html", null, true);
            echo " </td>
                        <td class=\"text-center\">
                            <a class='btn btn-info btn-xs btn-edit' id=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\"><span class=\"glyphicon glyphicon-edit\"></span> Editar</a>
                            <a id=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getId", array(), "method"), "html", null, true);
            echo "\" name=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["temp"], "getName", array(), "method"), "html", null, true);
            echo "\" class=\"btn btn-danger btn-xs btn-delete\"><span class=\"glyphicon glyphicon-remove\"></span> Eliminar</a>
                        </td>
                    </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['temp'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 37
        echo "                </tbody>
            </table>
        </div>
    </div>

    <!-- The Modal Delete Confirmation -->
    <div id=\"deleteConfirmation\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
            <!-- Modal content -->
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h3>Eliminar regiones</h3>
                </div>
                <div class=\"modal-body\" id=\"modal-body\">
                    <form>
                        <div class=\"form-group row div-body\" id=\"div-body\">
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_779749c1967fe9e6c48d6ddccff8fa41bc99cdfc6d5241c9bbedb68d1844c8f8->leave($__internal_779749c1967fe9e6c48d6ddccff8fa41bc99cdfc6d5241c9bbedb68d1844c8f8_prof);

    }

    // line 64
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_7174216b2127b91427f7be42e69f546142113412ce957cb3cbe89c5596683150 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7174216b2127b91427f7be42e69f546142113412ce957cb3cbe89c5596683150->enter($__internal_7174216b2127b91427f7be42e69f546142113412ce957cb3cbe89c5596683150_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 65
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 66
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 67
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/styles.css"), "html", null, true);
        echo "\">
";
        
        $__internal_7174216b2127b91427f7be42e69f546142113412ce957cb3cbe89c5596683150->leave($__internal_7174216b2127b91427f7be42e69f546142113412ce957cb3cbe89c5596683150_prof);

    }

    // line 70
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_530588331a2235022b08d45c8720822a92fc1de6bedf5036a8c0894e9dfa2f2b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_530588331a2235022b08d45c8720822a92fc1de6bedf5036a8c0894e9dfa2f2b->enter($__internal_530588331a2235022b08d45c8720822a92fc1de6bedf5036a8c0894e9dfa2f2b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 71
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/js/jquery-3.2.0.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 72
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/js/regions.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_530588331a2235022b08d45c8720822a92fc1de6bedf5036a8c0894e9dfa2f2b->leave($__internal_530588331a2235022b08d45c8720822a92fc1de6bedf5036a8c0894e9dfa2f2b_prof);

    }

    public function getTemplateName()
    {
        return "RegionBundle:Default:region.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  184 => 72,  179 => 71,  173 => 70,  164 => 67,  160 => 66,  155 => 65,  149 => 64,  118 => 37,  106 => 33,  102 => 32,  97 => 30,  93 => 29,  89 => 28,  85 => 27,  82 => 26,  78 => 25,  58 => 8,  55 => 7,  49 => 6,  37 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block title %}Mantenimiento de regiones{% endblock %}

{% block body %}
    <div class=\"row col-md-20 col-md-offset-0 custyle\">
        <a href=\"{{ path('region_add') }}\" class=\"btn btn-primary btn-xs pull-right\"><span
                    class=\"glyphicon glyphicon-plus\"></span> Agregar</a>
        <div>
            <table class=\"table table-striped custab\">
                <thead>
                <tr>
                    <th class=\"text-center\" colspan=\"5\">REGIONES</th>
                </tr>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Imagen 1</th>
                    <th>Descripción</th>
                    <th class=\"text-center\">Acción</th>
                </tr>
                </thead>
                <tbody>
                {% for temp in regions %}
                    <tr>
                        <td> {{ temp.getId() }}</td>
                        <td> {{ temp.getName() }} </td>
                        <td><img src=\"{{ temp.getImage1() }}\" class=\"mediana\"></td>
                        <td class=\"text-area\" style=\"text-align: justify\">{{ temp.getDescription() }} </td>
                        <td class=\"text-center\">
                            <a class='btn btn-info btn-xs btn-edit' id=\"{{ temp.getId() }}\"><span class=\"glyphicon glyphicon-edit\"></span> Editar</a>
                            <a id=\"{{ temp.getId() }}\" name=\"{{ temp.getName() }}\" class=\"btn btn-danger btn-xs btn-delete\"><span class=\"glyphicon glyphicon-remove\"></span> Eliminar</a>
                        </td>
                    </tr>
                {% endfor %}
                </tbody>
            </table>
        </div>
    </div>

    <!-- The Modal Delete Confirmation -->
    <div id=\"deleteConfirmation\" class=\"modal\" role=\"dialog\">
        <div class=\"modal-dialog modal-lg\">
            <!-- Modal content -->
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <h3>Eliminar regiones</h3>
                </div>
                <div class=\"modal-body\" id=\"modal-body\">
                    <form>
                        <div class=\"form-group row div-body\" id=\"div-body\">
                        </div>
                    </form>
                </div>
                <div class=\"modal-footer\">
                </div>
            </div>
        </div>
    </div>
{% endblock %}


{% block stylesheets %}
    {{ parent() }}
    <link rel=\"stylesheet\" href=\"{{ asset('/web/css/crgourmetcoffee.css') }}\">
    <link rel=\"stylesheet\" href=\"{{ asset('/web/css/styles.css') }}\">
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('/web/js/jquery-3.2.0.min.js') }}\"></script>
    <script src=\"{{ asset('/web/js/regions.js') }}\"></script>
{% endblock %}
", "RegionBundle:Default:region.html.twig", "/home/crgourme/siteadmin.crgourmetcoffee.com/src/RegionBundle/Resources/views/Default/region.html.twig");
    }
}
