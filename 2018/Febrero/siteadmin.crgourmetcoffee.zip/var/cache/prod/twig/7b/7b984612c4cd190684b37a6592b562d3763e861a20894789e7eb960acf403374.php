<?php

/* AppBundle:Default:home.html.twig */
class __TwigTemplate_41c9bdf2be5ecac5cb3eea63a13f0020edb18ed5f57f61f0c7cf74f3bd51bbf0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "AppBundle:Default:home.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4ccd2aa34d3daea35525d03ad12f9d4fa1990dc8ac5e9836c3ef9fe5b569677b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4ccd2aa34d3daea35525d03ad12f9d4fa1990dc8ac5e9836c3ef9fe5b569677b->enter($__internal_4ccd2aa34d3daea35525d03ad12f9d4fa1990dc8ac5e9836c3ef9fe5b569677b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Default:home.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4ccd2aa34d3daea35525d03ad12f9d4fa1990dc8ac5e9836c3ef9fe5b569677b->leave($__internal_4ccd2aa34d3daea35525d03ad12f9d4fa1990dc8ac5e9836c3ef9fe5b569677b_prof);

    }

    // line 4
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_51b059533f6e2ded779ce962814846f57fdadbc1865fc7b91f006dd0d8fe91b0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_51b059533f6e2ded779ce962814846f57fdadbc1865fc7b91f006dd0d8fe91b0->enter($__internal_51b059533f6e2ded779ce962814846f57fdadbc1865fc7b91f006dd0d8fe91b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 5
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/crgourmetcoffee.css"), "html", null, true);
        echo "\">
    <link rel=\"stylesheet\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("/web/css/styles.css"), "html", null, true);
        echo "\">
";
        
        $__internal_51b059533f6e2ded779ce962814846f57fdadbc1865fc7b91f006dd0d8fe91b0->leave($__internal_51b059533f6e2ded779ce962814846f57fdadbc1865fc7b91f006dd0d8fe91b0_prof);

    }

    // line 10
    public function block_title($context, array $blocks = array())
    {
        $__internal_515ac421b94634732288948c454db2d6e87afa6452d88bdc3133780b1691476f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_515ac421b94634732288948c454db2d6e87afa6452d88bdc3133780b1691476f->enter($__internal_515ac421b94634732288948c454db2d6e87afa6452d88bdc3133780b1691476f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 11
        echo "    Principal
";
        
        $__internal_515ac421b94634732288948c454db2d6e87afa6452d88bdc3133780b1691476f->leave($__internal_515ac421b94634732288948c454db2d6e87afa6452d88bdc3133780b1691476f_prof);

    }

    // line 14
    public function block_body($context, array $blocks = array())
    {
        $__internal_b2b7fde20a82345e3876d1541fd157d22a83e33ce2ec31b9beceaa522909e0c6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b2b7fde20a82345e3876d1541fd157d22a83e33ce2ec31b9beceaa522909e0c6->enter($__internal_b2b7fde20a82345e3876d1541fd157d22a83e33ce2ec31b9beceaa522909e0c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 15
        echo "    <div class=\"row col-md-9 col-md-offset-1 custyle\">
        <table class=\"table table-striped custab\" style=\"margin-top: 20px;\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"2\">MANTENIMIENTO</th>
            </tr>
            <tr>
                <th>Título</th>
                <th class=\"text-center\">Acción</th>
            </tr>
            </thead>
            <tr>
                <td>Regiones</td>
                <td class=\"text-center\">
                    <a class='btn btn-primary btn-xs' href=\"";
        // line 29
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_homepage");
        echo "\">
                        <span class=\"glyphicon glyphicon-ok\"></span> Seleccionar</a>
                </td>
            </tr>
            <tr>
                <td>Fincas</td>
                <td class=\"text-center\">
                    <a class='btn btn-primary btn-xs' href=\"";
        // line 36
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_homepage");
        echo "\">
                        <span class=\"glyphicon glyphicon-ok\"></span> Seleccionar</a>
                </td>
            </tr>
            ";
        // line 47
        echo "        </table>
    </div>
";
        
        $__internal_b2b7fde20a82345e3876d1541fd157d22a83e33ce2ec31b9beceaa522909e0c6->leave($__internal_b2b7fde20a82345e3876d1541fd157d22a83e33ce2ec31b9beceaa522909e0c6_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Default:home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  113 => 47,  106 => 36,  96 => 29,  80 => 15,  74 => 14,  66 => 11,  60 => 10,  51 => 7,  47 => 6,  42 => 5,  36 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig' %}


{% block stylesheets %}
    {{parent()}}
    <link rel=\"stylesheet\" href=\"{{ asset('/web/css/crgourmetcoffee.css') }}\">
    <link rel=\"stylesheet\" href=\"{{ asset('/web/css/styles.css') }}\">
{% endblock %}

{% block title %}
    Principal
{% endblock %}

{% block body %}
    <div class=\"row col-md-9 col-md-offset-1 custyle\">
        <table class=\"table table-striped custab\" style=\"margin-top: 20px;\">
            <thead>
            <tr>
                <th class=\"text-center\" colspan=\"2\">MANTENIMIENTO</th>
            </tr>
            <tr>
                <th>Título</th>
                <th class=\"text-center\">Acción</th>
            </tr>
            </thead>
            <tr>
                <td>Regiones</td>
                <td class=\"text-center\">
                    <a class='btn btn-primary btn-xs' href=\"{{ path('region_homepage') }}\">
                        <span class=\"glyphicon glyphicon-ok\"></span> Seleccionar</a>
                </td>
            </tr>
            <tr>
                <td>Fincas</td>
                <td class=\"text-center\">
                    <a class='btn btn-primary btn-xs' href=\"{{ path('farm_homepage') }}\">
                        <span class=\"glyphicon glyphicon-ok\"></span> Seleccionar</a>
                </td>
            </tr>
            {# <tr>
                 <td>Products</td>
                 <td class=\"text-center\">
                     <a class='btn btn-primary btn-xs' href=\"{{ path('product_homepage') }}\">
                         <span class=\"glyphicon glyphicon-ok\"></span> Select</a>
                 </td>
             </tr>#}
        </table>
    </div>
{% endblock %}", "AppBundle:Default:home.html.twig", "/home/crgourme/siteadmin.crgourmetcoffee.com/src/AppBundle/Resources/views/Default/home.html.twig");
    }
}
