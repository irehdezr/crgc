<?php

/* header.html.twig */
class __TwigTemplate_54b5a67338d54a5684201163170f0effc61d1efdda742e6b49a140b429474d97 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_33a8833efc9c2bede42bad50289a4280ea24fb199f2795303ab01ffdd7a4a04c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_33a8833efc9c2bede42bad50289a4280ea24fb199f2795303ab01ffdd7a4a04c->enter($__internal_33a8833efc9c2bede42bad50289a4280ea24fb199f2795303ab01ffdd7a4a04c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "header.html.twig"));

        // line 1
        echo "<header class='col-xs-12'>
    <nav id='navBar' class=\"navbar navbar-inverse navbar-fixed-top\">
        <div class=\"container-fluid\">
            <div class=\"navbar-header\">
                <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#myNavbar\">
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                </button>
                <a class=\"navbar-brand\">cr<span>gourmet</span><span>coffee.com</span></a>
            </div>
            <div class=\"collapse navbar-collapse\" id=\"myNavbar\">
                <ul id='mainMenu' class=\"nav navbar-nav\">
                    <li><a href=\"";
        // line 14
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("app_homepage");
        echo "\">Principal</a></li>
                    <li><a href=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("region_homepage");
        echo "\">Regiones</a></li>
                    <li><a href=\"";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("farm_homepage");
        echo "\">Fincas</a></li>
                    ";
        // line 27
        echo "                </ul>
            </div>
        </div>
    </nav>
</header>
<div class='clearfix'></div>";
        
        $__internal_33a8833efc9c2bede42bad50289a4280ea24fb199f2795303ab01ffdd7a4a04c->leave($__internal_33a8833efc9c2bede42bad50289a4280ea24fb199f2795303ab01ffdd7a4a04c_prof);

    }

    public function getTemplateName()
    {
        return "header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  49 => 27,  45 => 16,  41 => 15,  37 => 14,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<header class='col-xs-12'>
    <nav id='navBar' class=\"navbar navbar-inverse navbar-fixed-top\">
        <div class=\"container-fluid\">
            <div class=\"navbar-header\">
                <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\"#myNavbar\">
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                </button>
                <a class=\"navbar-brand\">cr<span>gourmet</span><span>coffee.com</span></a>
            </div>
            <div class=\"collapse navbar-collapse\" id=\"myNavbar\">
                <ul id='mainMenu' class=\"nav navbar-nav\">
                    <li><a href=\"{{ path('app_homepage') }}\">Principal</a></li>
                    <li><a href=\"{{ path('region_homepage') }}\">Regiones</a></li>
                    <li><a href=\"{{ path('farm_homepage') }}\">Fincas</a></li>
                    {#<li class=\"dropdown\">
                       <a href=\"{{ path('region_homepage') }}\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"true\">Regions <span class=\"caret\"></span></a>
                       <ul class=\"dropdown-menu\">
                       </ul>
                    </li>
                    <li class=\"dropdown\">
                       <a href=\"{{ path('farm_homepage') }}\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"true\">Farms <span class=\"caret\"></span></a>
                       <ul class=\"dropdown-menu\">
                       </ul>
                    </li>#}
                </ul>
            </div>
        </div>
    </nav>
</header>
<div class='clearfix'></div>", "header.html.twig", "/home/crgourme/siteadmin.crgourmetcoffee.com/app/Resources/views/header.html.twig");
    }
}
