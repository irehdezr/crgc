$.ajaxSetup({

    error: function( jqXHR, textStatus, errorThrown ) {

        if (jqXHR.status === 0) {

            alert('Not connect: Verify Network.');

        } else if (jqXHR.status == 404) {

            alert('Requested page not found [404]');

        } else if (jqXHR.status == 500) {

            alert('Internal Server Error [500].');

        } else if (textStatus === 'parsererror') {

            alert('Requested JSON parse failed.');

        } else if (textStatus === 'timeout') {

            alert('Time out error.');

        } else if (textStatus === 'abort') {

            alert('Ajax request aborted.');

        } else {

            alert('Uncaught Error: ' + jqXHR.responseText);

        }

    }
});

$(document).ready(function () {
    $('.btn-select').on('click', doSelect);
});


function doSelect(){
    var resultado = select(this.id);
    if(resultado){
        //alert(resultado)
        location.href = resultado;
    }
};


function select(id){
    var url;
    if(id == "regions"){
        url = "region/";
    }
    var response = null;
    $.post({
            url: url,
            async: false
    })
        .done( function(result) {
            response = result;
        });
    return response;
}
