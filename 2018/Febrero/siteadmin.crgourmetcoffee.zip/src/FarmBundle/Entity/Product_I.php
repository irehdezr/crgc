<?php

namespace FarmBundle\Entity;

/**
* Product_I 
*/
class Product_I{ 
    
    /**   
    * @var integer   
    */   
    private $id;    
    
    /**  
    * @var string     
    */   
    private $name;  
    
    /**  
    * @var string   
    */  
    private $image;   
    
    /**  
    * @var integer    
    */ 
    private $rank;   
    
    /**  
    * @var integer    
    */   
    private $reviews; 
    
    /**  
    * @var string  
    */   
    private $description;    
    
    /**  
    * @var \Doctrine\Common\Collections\Collection   
    */   
    private $presentations;   
    
    /**  
    * @var \FarmBundle\Entity\Farm_I    
    */   
    private $farm;   
    
    /**  
    * @var \FarmBundle\Entity\Cultivar 
    */    
    private $cultivar;   
    
    /**    
    * @var \FarmBundle\Entity\Grade   
    */   
    private $grade;  
    
    /**    
    * @var \FarmBundle\Entity\Processing   
    */   
    private $processing;  
    
    /**    
    * @var \FarmBundle\Entity\Flavor  
    */   
    private $flavor;   
    
    /** 
    * Constructor   
    */    
    public function __construct(){       
        $this->presentations = new \Doctrine\Common\Collections\ArrayCollection();    
        
    }    
    
    /**  
    * Get id   
    *  
    * @return integer  
    */  
    public function getId(){    
        return $this->id;    
        
    }    
    
    /**   
    * Set id  
    *   
    * @param integer $id    
    *   
    * @return Product_I   
    */  
    public function setID($id){      
        $this->id = $id;  
        return $this;    
        
    }   
    
    /**   
    * Set name 
    *    
    * @param string $name  
    *   
    * @return Product_I 
    */   
    public function setName($name){  
        $this->name = $name;     
        return $this;    
        
    }    
    
    /**     
    * Get name  
    *   
    * @return string  
    */  
    public function getName(){   
        return $this->name;    
        
    }    
    
    /**  
    * Set image     
    *    
    * @param string $image   
    *    
    * @return Product_I    
    */   
    public function setImage($image){  
        $this->image = $image;    
        return $this;    
        
    }    
    
    /**   
    * Get image    
    *    
    * @return string   
    */   
    public function getImage(){      
        return $this->image;    
        
    }    
    
    /**  
    * Set rank   
    *    
    * @param integer $rank 
    *   
    * @return Product_I  
    */ 
    public function setRank($rank){  
        $this->rank = $rank;     
        return $this;    
        
    }    
    
    /**   
    * Get rank    
    *    
    * @return integer  
    */   
    public function getRank(){     
        return $this->rank;    
        
    }    
    
    /**  
    * Set reviews    
    *     
    * @param integer $reviews  
    *  
    * @return Product_I     
    */    
    public function setReviews($reviews){       
        $this->reviews = $reviews;        
        return $this;    
        
    }    
    
    /**   
    * Get reviews 
    *    
    * @return integer    
    */    
    public function getReviews(){   
        return $this->reviews;    
        
    }    
    
    /**    
    * Set description 
    *    
    * @param string $description   
    *    
    * @return Product_I   
    */   
    public function setDescription($description){  
        $this->description = $description;   
        return $this;    
        
    }    
    
    /**   
    * Get description    
    *   
    * @return string    
    */    
    public function getDescription(){  
        return $this->description;    
        
    }    
    
    /**   
    * Add presentation  
    *    
    * @param \FarmBundle\Entity\Presentation $presentation  
    *   
    * @return Product_I   
    */    
    public function addPresentation(\FarmBundle\Entity\Presentation $presentation){        
        $this->presentations[] = $presentation;       
        return $this;    
        
    }    
    
    /** 
    * Remove presentation  
    *   
    * @param \FarmBundle\Entity\Presentation $presentation     
    */   
    public function removePresentation(\FarmBundle\Entity\Presentation $presentation){       
        $this->presentations->removeElement($presentation);  
    }
    
    /**   
    * Get presentations  
    *  
    * @return \Doctrine\Common\Collections\Collection  
    */   
    public function getPresentations(){    
        return $this->presentations;    
        
    }    
    
    /**   
    * Set farm   
    *   
    * @param \FarmBundle\Entity\Farm_I $farm    
    *    
    * @return Product_I    
    */   
    public function setFarm(\FarmBundle\Entity\Farm_I $farm = null){        
        $this->farm = $farm;     
        return $this;    
        
    }    
    
    /**  
    * Get farm   
    *   
    * @return \FarmBundle\Entity\Farm_I     
    */    
    public function getFarm(){  
        return $this->farm;    
        
    }   
    
    /** 
    * Set cultivar     
    *    
    * @param \FarmBundle\Entity\Cultivar $cultivar  
    *     
    * @return Product_I    
    */    
    public function setCultivar(\FarmBundle\Entity\Cultivar $cultivar = null){
        $this->cultivar = $cultivar;        
        return $this;    
        
    }    
    
    /** 
    * Get cultivar   
    *  
    * @return \FarmBundle\Entity\Cultivar   
    */   
    public function getCultivar(){     
        return $this->cultivar;    
        
    }    
    
    /**  
    * Set grade   
    *  
    * @param \FarmBundle\Entity\Grade $grade  
    *    
    * @return Product_I  
    */   
    public function setGrade(\FarmBundle\Entity\Grade $grade = null){        
        $this->grade = $grade;    
        return $this;    
        
    }    
    
    /**   
    * Get grade   
    *   
    * @return \FarmBundle\Entity\Grade   
    */  
    public function getGrade(){   
        return $this->grade;    
        
    }    
    
    /**   
    * Set processing 
    *   
    * @param \FarmBundle\Entity\Processing $processing   
    *    
    * @return Product_I  
    */   
    public function setProcessing(\FarmBundle\Entity\Processing $processing = null){        
        $this->processing = $processing;       
        return $this;    
        
    }    
    
    /**   
    * Get processing     
    *   
    * @return \FarmBundle\Entity\Processing   
    */   
    public function getProcessing(){      
        return $this->processing;    
        
    }    
    
    /**  
    * Set flavor 
    *   
    * @param \FarmBundle\Entity\Flavor $flavor   
    *    
    * @return Product_I   
    */   
    public function setFlavor(\FarmBundle\Entity\Flavor $flavor = null){        
        $this->flavor = $flavor;    
        return $this;    
        
    }    
    
    /**  
    * Get flavor 
    *   
    * @return \FarmBundle\Entity\Flavor  
    */   
    public function getFlavor(){   
        return $this->flavor;    
        
    }
    
}