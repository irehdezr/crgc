<?php

namespace FarmBundle\Entity;

/**
* Presentation 
*/
class Presentation{  
    
    /**   
    * @var integer  
    */  
    private $id;   
    
    /**   
    * @var float    
    */   
    private $price;   
    
    /**  
    * @var integer    
    */   
    private $weight;   
    
    /**  
    * @var \FarmBundle\Entity\Product_I  
    */   
    private $product;  
    
    /**   
    * @var \FarmBundle\Entity\Roast  
    */   
    private $roast;  
    
    /**   
    * @var \FarmBundle\Entity\Grind   
    */    
    private $grind;  
    
    /**   
    * Get id   
    *   
    * @return integer   
    */ 
    public function getId(){    
        return $this->id;    
        
    }   
    
    /**  
    * Set price 
    *  
    * @param float $price     
    *    
    * @return Presentation  
    */   
    public function setPrice($price){  
        $this->price = $price;  
        return $this;    
        
    }    
    
    /**    
    * Get price   
    *  
    * @return float  
    */  
    public function getPrice(){  
        return $this->price;   
    }  
    
    /**  
    * Set weight    
    *    
    * @param integer $weight   
    *   
    * @return Presentation    
    */   
    public function setWeight($weight){     
        $this->weight = $weight;     
        return $this;   
    }  
    
    /**   
    * Get weight    
    *    
    * @return integer  
    */    
    public function getWeight(){  
        return $this->weight;   
    }   
    
    /**  
    * Set product  
    *    
    * @param \FarmBundle\Entity\Product_I $product 
    *   
    * @return Presentation    
    */  
    public function setProduct(\FarmBundle\Entity\Product_I $product = null){
        $this->product = $product;  
        return $this;    
        
    }    
    
    /**   
    * Get product 
    *  
    * @return \FarmBundle\Entity\Product_I  
    */ 
    public function getProduct(){   
        return $this->product;  
        
    }   
    
    /**  
    * Set roast   
    *   
    * @param \FarmBundle\Entity\Roast $roast   
    *   
    * @return Presentation  
    */   
    public function setRoast(\FarmBundle\Entity\Roast $roast = null){        
        $this->roast = $roast;    
        return $this;    
        
    }    
    
    /**   
    * Get roast    
    *    
    * @return \FarmBundle\Entity\Roast   
    */  
    public function getRoast()    {  
        return $this->roast; 
    }   
    
    /**  
    * Set grind     
    *   
    * @param \FarmBundle\Entity\Grind $grind   
    *    
    * @return Presentation  
    */   
    public function setGrind(\FarmBundle\Entity\Grind $grind = null)    {
        $this->grind = $grind;    
        return $this;    
        
    }    
    
    /**  
    * Get grind    
    *  
    * @return \FarmBundle\Entity\Grind 
    */   
    public function getGrind()    {      
        return $this->grind;    
        
    }
    
}