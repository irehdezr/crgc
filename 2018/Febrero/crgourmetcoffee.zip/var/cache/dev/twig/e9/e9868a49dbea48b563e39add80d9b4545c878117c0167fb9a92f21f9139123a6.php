<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_595b6d45a4694893c08eca0e94a97e4ea81f02b20d9861e72c23d5c13dbe0fde extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_68e3def6df66f08b919fb3fbda76152413c4b31f21bb846497d0b7ad3a2598e2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_68e3def6df66f08b919fb3fbda76152413c4b31f21bb846497d0b7ad3a2598e2->enter($__internal_68e3def6df66f08b919fb3fbda76152413c4b31f21bb846497d0b7ad3a2598e2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        $__internal_2f85b6abdf1c95f8df924b52771738e131e5ccd84d07fda91d6587b23df5776b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2f85b6abdf1c95f8df924b52771738e131e5ccd84d07fda91d6587b23df5776b->enter($__internal_2f85b6abdf1c95f8df924b52771738e131e5ccd84d07fda91d6587b23df5776b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_68e3def6df66f08b919fb3fbda76152413c4b31f21bb846497d0b7ad3a2598e2->leave($__internal_68e3def6df66f08b919fb3fbda76152413c4b31f21bb846497d0b7ad3a2598e2_prof);

        
        $__internal_2f85b6abdf1c95f8df924b52771738e131e5ccd84d07fda91d6587b23df5776b->leave($__internal_2f85b6abdf1c95f8df924b52771738e131e5ccd84d07fda91d6587b23df5776b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "C:\\xampp\\htdocs\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_label.html.php");
    }
}
