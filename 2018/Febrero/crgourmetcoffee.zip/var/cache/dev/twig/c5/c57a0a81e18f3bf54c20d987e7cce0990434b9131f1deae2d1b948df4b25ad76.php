<?php

/* PageBundle:Default:onDevelopment.html.twig */
class __TwigTemplate_33901060144ff8a47959dd97c77c6502f1cae7c0bfbcb4a295ff32bdcd1a05a1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "PageBundle:Default:onDevelopment.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5cc6a1caee30c8a6ea6c56bf4172db07487a6cf016ad2f144909ffc65c2a5793 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5cc6a1caee30c8a6ea6c56bf4172db07487a6cf016ad2f144909ffc65c2a5793->enter($__internal_5cc6a1caee30c8a6ea6c56bf4172db07487a6cf016ad2f144909ffc65c2a5793_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PageBundle:Default:onDevelopment.html.twig"));

        $__internal_0895eedc0adcd6618e4fbb4a60ba37eb93a69e2dfbeaa734705cf3d0604d92a4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0895eedc0adcd6618e4fbb4a60ba37eb93a69e2dfbeaa734705cf3d0604d92a4->enter($__internal_0895eedc0adcd6618e4fbb4a60ba37eb93a69e2dfbeaa734705cf3d0604d92a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PageBundle:Default:onDevelopment.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5cc6a1caee30c8a6ea6c56bf4172db07487a6cf016ad2f144909ffc65c2a5793->leave($__internal_5cc6a1caee30c8a6ea6c56bf4172db07487a6cf016ad2f144909ffc65c2a5793_prof);

        
        $__internal_0895eedc0adcd6618e4fbb4a60ba37eb93a69e2dfbeaa734705cf3d0604d92a4->leave($__internal_0895eedc0adcd6618e4fbb4a60ba37eb93a69e2dfbeaa734705cf3d0604d92a4_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_5b3a2dfd317d0743b275fb0efc9eaa8ba5f89e2aa9a3bcdbe4326c0509195a59 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5b3a2dfd317d0743b275fb0efc9eaa8ba5f89e2aa9a3bcdbe4326c0509195a59->enter($__internal_5b3a2dfd317d0743b275fb0efc9eaa8ba5f89e2aa9a3bcdbe4326c0509195a59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_927fe6606d09b3bab93fffbf8ec79074adf554b98bc83046dad60fea5e4f142f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_927fe6606d09b3bab93fffbf8ec79074adf554b98bc83046dad60fea5e4f142f->enter($__internal_927fe6606d09b3bab93fffbf8ec79074adf554b98bc83046dad60fea5e4f142f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "On Development";
        
        $__internal_927fe6606d09b3bab93fffbf8ec79074adf554b98bc83046dad60fea5e4f142f->leave($__internal_927fe6606d09b3bab93fffbf8ec79074adf554b98bc83046dad60fea5e4f142f_prof);

        
        $__internal_5b3a2dfd317d0743b275fb0efc9eaa8ba5f89e2aa9a3bcdbe4326c0509195a59->leave($__internal_5b3a2dfd317d0743b275fb0efc9eaa8ba5f89e2aa9a3bcdbe4326c0509195a59_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_078e2d2488a27045622c588c04789ff959f087488682ae4411584e7588e7fde3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_078e2d2488a27045622c588c04789ff959f087488682ae4411584e7588e7fde3->enter($__internal_078e2d2488a27045622c588c04789ff959f087488682ae4411584e7588e7fde3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_7d22c10a085394b81b81e67c31e922150c5a92a2f9384644ed99434390e3bb22 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7d22c10a085394b81b81e67c31e922150c5a92a2f9384644ed99434390e3bb22->enter($__internal_7d22c10a085394b81b81e67c31e922150c5a92a2f9384644ed99434390e3bb22_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "<main>
\t<center>
\t    <h2 class=\"center-block\">
\t        <br/>Oooops...<br/>
\t        This page is under development....
\t    </h2>
    </center>
</main>
";
        
        $__internal_7d22c10a085394b81b81e67c31e922150c5a92a2f9384644ed99434390e3bb22->leave($__internal_7d22c10a085394b81b81e67c31e922150c5a92a2f9384644ed99434390e3bb22_prof);

        
        $__internal_078e2d2488a27045622c588c04789ff959f087488682ae4411584e7588e7fde3->leave($__internal_078e2d2488a27045622c588c04789ff959f087488682ae4411584e7588e7fde3_prof);

    }

    public function getTemplateName()
    {
        return "PageBundle:Default:onDevelopment.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 5,  59 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"layout.html.twig\" %}

{% block title%}On Development{% endblock %}
{% block body %}
<main>
\t<center>
\t    <h2 class=\"center-block\">
\t        <br/>Oooops...<br/>
\t        This page is under development....
\t    </h2>
    </center>
</main>
{% endblock %}", "PageBundle:Default:onDevelopment.html.twig", "C:\\xampp\\htdocs\\src\\PageBundle/Resources/views/Default/onDevelopment.html.twig");
    }
}
