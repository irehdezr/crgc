<?php

namespace FarmBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class FarmBundle extends Bundle
{
}
